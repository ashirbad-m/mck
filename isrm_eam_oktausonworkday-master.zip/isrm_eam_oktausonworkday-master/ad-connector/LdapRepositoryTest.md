# Source Data for LdapRepositoryTest
* need to map mshusontest 127.0.0.2:636 through ssh
* need to provide in VM options: 
    * javax.net.ssl.trustStore=_**path_to_certificates_file**_
    * javax.net.ssl.trustStorePassword=_**some_password**_
    * TEST_PASSWORD_1=_**password_to_mshusontest_domain**_

## application.yml:
### Single enabled domain
```yml
domains:
    ldap:
        nodes:
#...
            -   enabled: true
                domain: mshusontest
                url: ldaps://127.0.0.2:636
                user: Svc-test@mshusontest.com
                password: ${TEST_PASSWORD_1:HereShoullBePassword}
                base-dn: OU=B2E_Workday,DC=mshusontest,DC=com
#...
```
## Structure inside mshusontest (need to check existence)
```
dn: OU=B2E_Workday,DC=mshusontest,DC=com
objectClass: organizationalUnit
objectClass: top
objectCategory: CN=Organizational-Unit,CN=Schema,CN=Configuration,DC=mshusontest,DC=com
ou: B2E_Workday

dn: OU=MSHPS,OU=B2E_Workday,DC=mshusontest,DC=com
objectClass: organizationalUnit
objectClass: top
objectCategory: CN=Organizational-Unit,CN=Schema,CN=Configuration,DC=mshusontest,DC=com
ou: MSHPS

dn: OU=Users,OU=MSHPS,OU=B2E_Workday,DC=mshusontest,DC=com
objectClass: organizationalUnit
objectClass: top
objectCategory: CN=Organizational-Unit,CN=Schema,CN=Configuration,DC=mshusontest,DC=com
ou: Users

dn: OU=OtherUsers,OU=MSHPS,OU=B2E_Workday,DC=mshusontest,DC=com
objectClass: organizationalUnit
objectClass: top
objectCategory: CN=Organizational-Unit,CN=Schema,CN=Configuration,DC=mshusontest,DC=com
ou: OtherUsers

dn: OU=USON,OU=B2E_Workday,DC=mshusontest,DC=com
objectClass: organizationalUnit
objectClass: top
objectCategory: CN=Organizational-Unit,CN=Schema,CN=Configuration,DC=mshusontest,DC=com
ou: USON

dn: OU=Computers,OU=USON,OU=B2E_Workday,DC=mshusontest,DC=com
objectClass: organizationalUnit
objectClass: top
objectCategory: CN=Organizational-Unit,CN=Schema,CN=Configuration,DC=mshusontest,DC=com
ou: Computers

dn: OU=Groups,OU=USON,OU=B2E_Workday,DC=mshusontest,DC=com
objectClass: organizationalUnit
objectClass: top
objectCategory: CN=Organizational-Unit,CN=Schema,CN=Configuration,DC=mshusontest,DC=com
ou: Groups
```
