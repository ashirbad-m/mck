package com.mckesson.ad.entity;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.DnAttribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;
import org.springframework.ldap.odm.annotations.Transient;

import javax.naming.Name;
import java.util.Set;

@Entry(objectClasses = { "group" })
@Data
@EqualsAndHashCode(of = { "dn" })
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public final class AdGroupEntry implements AdEntry {

    @Attribute(name="objectGUID", type = Attribute.Type.BINARY, readonly = true)
    byte[] uid;

    @Transient
    String domain;

    @Id
    Name dn;

    @Attribute(name="cn")
    @DnAttribute(value="cn")
    String cn;

    @Attribute(name="member")
    Set<Name> member;

    @Attribute(name="description")
    String description;

    @Attribute(name="groupType")
    Long groupType;

    @Attribute(name="managedBy")
    Name managedBy;

    @Attribute(name="displayName")
    String displayName;

    @Attribute(name="objectSid", type = Attribute.Type.BINARY, readonly = true)
    byte[] adSid;
}
