package com.mckesson.ad.entity;

import com.mckesson.common.domain.AdEntryData;

import javax.naming.Name;

public interface AdEntry extends AdEntryData<Name, byte[]> {
}
