package com.mckesson.ad.entity.mapper;

import com.mckesson.ad.entity.AdGroupEntry;
import com.mckesson.ad.entity.AdServerEntry;
import com.mckesson.ad.entity.AdUserEntry;
import com.mckesson.ad.entity.mapper.annotations.Byte2String;
import com.mckesson.ad.entity.mapper.annotations.SidMappingRules;
import com.mckesson.ad.entity.mapper.annotations.String2Byte;
import com.mckesson.ad.entity.mapper.annotations.UidMappingRules;
import com.mckesson.common.domain.AdGroup;
import com.mckesson.common.domain.AdServer;
import com.mckesson.common.domain.OktaUser;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import javax.naming.Name;
import javax.naming.ldap.LdapName;
import java.util.List;

@Mapper(uses = { LdapMapperUtils.class , SidUtils.class, UidUtils.class })
public interface LdapEntityMapper {

    LdapEntityMapper LDAP_ENTITY_MAPPER = Mappers.getMapper(LdapEntityMapper.class);

    @InheritInverseConfiguration
    @Mapping(target = "workerId", qualifiedByName = {"LdapMappingRules", "workerId2Long"})
    //@Mapping(target = "accountExpires", qualifiedByName = {"LdapMappingRules", "long2Date"})
    @Mapping(target = "uid", qualifiedBy = { UidMappingRules.class, String2Byte.class })
    @Mapping(target = "facsimileTelephoneNumber", source = "fax")
    AdUserEntry toAdUserEntry(final OktaUser dto);

    @Mapping(target = "employee", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "workerId", qualifiedByName = {"LdapMappingRules", "workerId2String"})
    //@Mapping(target = "accountExpires", qualifiedByName = {"LdapMappingRules", "date2Long"})
    @Mapping(target = "uid", qualifiedBy = { UidMappingRules.class, Byte2String.class })
    @Mapping(target = "fax", source = "facsimileTelephoneNumber")
    OktaUser toAdUserDto(final AdUserEntry entry);

    List<OktaUser> toAdUserDtoList(final List<AdUserEntry> entries);

    @Mapping(target = "uid", qualifiedBy = { UidMappingRules.class, String2Byte.class })
    @Mapping(target = "adSid", qualifiedBy = { SidMappingRules.class, String2Byte.class })
    AdGroupEntry toAdGroupEntry(final AdGroup dto);

    @Mapping(target = "uid", qualifiedBy = { UidMappingRules.class, Byte2String.class })
    @Mapping(target = "adSid", qualifiedBy = { SidMappingRules.class, Byte2String.class })
    AdGroup toAdGroupDto(final AdGroupEntry entry);

    List<AdGroup> toAdGroupDtoList(final List<AdGroupEntry> entries);

    @Mapping(target = "uid", qualifiedBy = { UidMappingRules.class, String2Byte.class })
    AdServerEntry toAdServerEntry(final AdServer dto);
    @Mapping(target = "uid", qualifiedBy = { UidMappingRules.class, Byte2String.class })
    AdServer toAdServerDto(final AdServerEntry entry);

    List<AdServer> toAdServerDtoList(final List<AdServerEntry> entries);

    default LdapName castName2LdapName(final Name name) {
        return (LdapName) name;
    }
}
