package com.mckesson.ad.rest;

import com.mckesson.common.AbstractCoreEventProcessor;
import com.mckesson.common.model.CoreEvent;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/ad")
@ConditionalOnProperty(name="rest.controller.enabled", havingValue = "true")
public class ActiveDirectoryController {

    private final AbstractCoreEventProcessor activeDirectoryProcessor;

    public ActiveDirectoryController(AbstractCoreEventProcessor activeDirectoryProcessor) {
        this.activeDirectoryProcessor = activeDirectoryProcessor;
    }

    @PostMapping("/process")
    public ResponseEntity<Object> processEvent(@RequestBody CoreEvent event) {
        activeDirectoryProcessor.processEvent(event);
        return ResponseEntity.ok().build();
    }
}