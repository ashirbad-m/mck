package com.mckesson.ad.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tool to parse LDAP login values
 *
 * @author Alexandr Saltykov
 */
@Service
public class LoginParserService {

    //TODO length of max sAMAccountName ?
    public static final Pattern PREFIX_REGEXP = Pattern.compile("^([A-z0-9_-]+)\\\\([A-z0-9_\\.-]{3,30})$");
    public static final Pattern SUFFIX_REGEXP = Pattern.compile("^([A-z0-9_\\.-]+)@([A-z0-9_\\.]+)$");

    /**
     * Extracts prefix from LDAP login (prefix notation)
     *
     * @param login login value
     * @return prefix value or empty string
     */
    public String getPrefix(String login) {
        Matcher m = PREFIX_REGEXP.matcher(login);
        if (m.matches()) {
            return m.group(1).toLowerCase();
        }
        return StringUtils.EMPTY;
    }

    /**
     * Extracts domain value from LDAP login (user principal name)
     *
     * @param login login (user principal name)
     * @return domain name or empty string
     */
    public String getDomain(String login) {
        Matcher m = SUFFIX_REGEXP.matcher(login);
        if (m.matches()) {
            return m.group(2);
        }
        return StringUtils.EMPTY;
    }

    /**
     * Extract username from login
     *
     * @param login login (prefix notation or user principal name)
     * @return username or empty string
     */
    public String getLogin(String login) {
        Matcher m = PREFIX_REGEXP.matcher(login);
        if (m.matches()) {
            return m.group(2);
        } else {
            m = SUFFIX_REGEXP.matcher(login);
            if (m.matches()) {
                return m.group(1);
            }
        }
        return StringUtils.EMPTY;
    }
}