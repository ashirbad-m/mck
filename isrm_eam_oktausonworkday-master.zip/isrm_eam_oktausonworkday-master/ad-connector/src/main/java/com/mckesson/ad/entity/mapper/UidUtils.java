package com.mckesson.ad.entity.mapper;

import com.mckesson.ad.entity.mapper.annotations.Byte2String;
import com.mckesson.ad.entity.mapper.annotations.String2Byte;
import com.mckesson.ad.entity.mapper.annotations.UidMappingRules;
import com.mckesson.common.ldap.LdapUtils;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@UidMappingRules
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class UidUtils {
    @Byte2String
    public static String guid2String(final byte[] guid) {
        if (guid == null) {
            return null;
        }
        return LdapUtils.guid2String(guid);
    }

    @String2Byte
    public static byte[] string2Guid(final String guid) {
        if (guid == null) {
            return null;
        }
        return LdapUtils.string2Guid(guid);
    }
}
