package com.mckesson.ad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.mckesson.ad", "com.mckesson.common", "com.mckesson.config", "com.mckesson.common.workday.converter"})
public class ActiveDirectoryApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(ActiveDirectoryApplication.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(ActiveDirectoryApplication.class, args);
    }
}
