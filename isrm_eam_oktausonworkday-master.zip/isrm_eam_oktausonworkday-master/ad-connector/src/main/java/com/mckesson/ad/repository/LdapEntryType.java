package com.mckesson.ad.repository;

import com.mckesson.ad.entity.AdEntry;
import com.mckesson.ad.entity.AdGroupEntry;
import com.mckesson.ad.entity.AdServerEntry;
import com.mckesson.ad.entity.AdUserEntry;
import com.mckesson.common.domain.AdGroup;
import com.mckesson.common.domain.AdServer;
import com.mckesson.common.domain.OktaEntryDto;
import com.mckesson.common.domain.OktaUser;
import lombok.*;
import lombok.experimental.FieldDefaults;
import org.springframework.ldap.core.ContextMapper;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.ldap.core.LdapOperations;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.Filter;
import org.springframework.ldap.support.LdapUtils;

import javax.naming.Name;
import javax.naming.ldap.LdapName;
import javax.validation.constraints.NotNull;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

import static com.mckesson.ad.entity.mapper.LdapEntityMapper.LDAP_ENTITY_MAPPER;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class LdapEntryType<E extends AdEntry, D extends OktaEntryDto> {

    //<editor-fold defaultstate="collapsed" desc="static methods">
    public static final LdapEntryType<AdUserEntry, OktaUser> USER =
            new LdapEntryType<>(
                    AdUserEntry.class,
                    LDAP_ENTITY_MAPPER::toAdUserEntry,
                    LDAP_ENTITY_MAPPER::toAdUserDto,
                    LDAP_ENTITY_MAPPER::toAdUserDtoList,
                    s -> String.format("(&(objectClass=user)(!(objectClass=computer))%s)", s)
            );

    public static final LdapEntryType<AdGroupEntry, AdGroup> GROUP =
            new LdapEntryType<>(
                    AdGroupEntry.class,
                    LDAP_ENTITY_MAPPER::toAdGroupEntry,
                    LDAP_ENTITY_MAPPER::toAdGroupDto,
                    LDAP_ENTITY_MAPPER::toAdGroupDtoList,
                    s -> String.format("(&(objectClass=group)%s)", s)
            );

    public static final LdapEntryType<AdServerEntry, AdServer> SERVER =
            new LdapEntryType<>(
                    AdServerEntry.class,
                    LDAP_ENTITY_MAPPER::toAdServerEntry,
                    LDAP_ENTITY_MAPPER::toAdServerDto,
                    LDAP_ENTITY_MAPPER::toAdServerDtoList,
                    s -> String.format("(&(objectClass=computer)%s)", s)
            );

    private static Name truncate(@NonNull Name source, @NonNull Name baseDn, Name defaultValue) {
        if (source.startsWith(baseDn)) {
            return source.getSuffix(baseDn.size());
        }
        return defaultValue;
    }

    public static Name truncate(@NonNull Name source, @NonNull Name baseDn) {
        return truncate(source, baseDn, source);
    }

    public static Name truncateOrNull(@NonNull Name source, @NonNull Name baseDn) {
        return truncate(source, baseDn, null);
    }

    @Value
    @AllArgsConstructor
    private static class EntityMapper<X extends AdEntry> implements ContextMapper<X> {
        LdapTemplate ldapTemplate;
        Class<X> clazz;

        @Override
        public X mapFromContext(Object ctx) {
            return ldapTemplate.getObjectDirectoryMapper().mapFromLdapDataEntry((DirContextOperations) ctx, clazz);
        }
    }
    //</editor-fold>

    @Getter
    Class<E> clazz;
    Function<D, E> toEntryConverter;
    Function<E, D> toDtoConverter;
    Function<List<E>, List<D>> toListDtoConverter;
    UnaryOperator<String> filterEnricher;

    public ContextMapper<E> getMapper(final LdapTemplate template) {
        return new EntityMapper<>(template, clazz);
    }

    public E lookup(final LdapTemplate template, final Name n) {
        return template.lookup(n, getMapper(template));
    }
    public E lookup(final LdapTemplate template, final LdapOperations ops, final Name n) {
        return ops.lookup(n, getMapper(template));
    }

    public D map2Dto(final E entry, final String domain, @NonNull final LdapName baseDn) {
        if (entry == null) {
            return null;
        }
        D result = toDtoConverter.apply(entry);
        result.setDomain(domain);
        result.setDn(LdapUtils.prepend(result.getDn(), baseDn));
        return result;
    }

    public E map2Entry(@NonNull final D entry, @NonNull final LdapName baseDn) {
        E result = toEntryConverter.apply(entry);
        result.setDn(truncate(result.getDn(), baseDn));
        return result;
    }

    public List<D> map2DtoList(final List<E> entries, final String domain, @NonNull final LdapName baseDn) {
        List<D> result = toListDtoConverter.apply(entries);
        if (result == null) {
            return Collections.emptyList();
        }
        return result.stream().filter(Objects::nonNull).map(
                e -> {
                    e.setDomain(domain);
                    e.setDn(LdapUtils.prepend(e.getDn(), baseDn));
                    return e;
                }
        ).collect(Collectors.toList());
    }

    public String completeFilter(@NotNull Filter queryFilter) {
        return filterEnricher.apply(queryFilter.encode());
    }
}
