package com.mckesson.ad.entity.mapper;

import com.mckesson.ad.entity.mapper.annotations.Byte2String;
import com.mckesson.ad.entity.mapper.annotations.SidMappingRules;
import com.mckesson.ad.entity.mapper.annotations.String2Byte;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;

import static org.springframework.ldap.support.LdapUtils.convertBinarySidToString;
import static org.springframework.ldap.support.LdapUtils.convertStringSidToBinary;

@SidMappingRules
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class SidUtils {

    @Byte2String
    public static String sid2String(final byte[] sid) {
        if (sid == null) {
            return null;
        }
        return convertBinarySidToString(sid);
    }

    @String2Byte
    public static byte[] string2Sid(final String sid) {
        if (sid == null) {
            return null;
        }
        return convertStringSidToBinary(sid);
    }
}
