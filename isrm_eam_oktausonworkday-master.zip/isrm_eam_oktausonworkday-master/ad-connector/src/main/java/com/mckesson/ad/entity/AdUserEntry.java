package com.mckesson.ad.entity;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.DnAttribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;
import org.springframework.ldap.odm.annotations.Transient;

import javax.naming.Name;
import java.util.Set;

@Entry(objectClasses = {"user", "person"})
@Data
@EqualsAndHashCode(of = {"dn"})
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public final class AdUserEntry implements AdEntry {

    @Attribute(name = "objectGUID", type = Attribute.Type.BINARY, readonly = true)
    byte[] uid;

    @Transient
    String domain;

    @Id
    Name dn;

    @Attribute(name = "cn")
    @DnAttribute(value = "cn")
    String cn;

    @Attribute(name = "mail")
    String mail;

    @Attribute(name = "sAMAccountName")
    String samAccountName;

    @Attribute(name = "userPrincipalName")
    String userPrincipalName;

    @Attribute(name = "middleName")
    String middleName;

    @Attribute(name = "company")
    String company;

    @Attribute(name = "uSNChanged", readonly = true)
    String usnChanged;

    @Attribute(name = "division")
    String division;

    @Attribute(name = "displayName")
    String displayName;

    @Attribute(name = "facsimileTelephoneNumber")
    String facsimileTelephoneNumber;

    @Attribute(name = "l")
    String city;

    @Attribute(name = "homeDirectory")
    String homeDirectory;

    @Attribute(name = "postalCode")
    String postalCode;

    @Attribute(name = "extensionAttribute2")
    String state;

    @Attribute(name = "st")
    String st;

    @Attribute(name = "manager")
    Name manager;

    @Attribute(name = "department")
    String department;

    // TODO Just in case: length in AD is essentially restricted
    @Attribute(name = "initials")
    String initials;

    @Attribute(name = "sn")
    String lastName;

    @Attribute(name = "streetAddress")
    String streetAddress;

    @Attribute(name = "givenName")
    String firstName;

    @Attribute(name = "extensionAttribute8")
    String workerId;

    @Attribute(name = "co")
    String country;

    @Attribute(name = "telephoneNumber")
    String telephoneNumber;

    @Attribute(name = "title")
    String title;

    @Attribute(name = "extensionAttribute3")
    String workerType;

    @Attribute(name = "postalAddress")
    String postalAddress;

    @Attribute(name = "homeDrive")
    String homeDrive;

    @Attribute(name = "mobile")
    String mobile;

    @Attribute(name = "primaryGroupID", readonly = true)
    Long primaryGroupId;

    @Attribute(name = "street")
    String street;

    @Attribute(name = "scriptPath")
    String scriptPath;

    @Attribute(name = "accountExpires")
    Long accountExpires;

    @Attribute(name = "mailNickname")
    String mailNickname;

    @Attribute(name = "msTSProfilePath")
    String terminalServicesProfilePath;

    @Attribute(name = "userAccountControl")
    Long userAccountControl;

    @Attribute(name = "msExchRecipientTypeDetails")
    Long msExchRecipientTypeDetails;

    @Attribute(name = "physicalDeliveryOfficeName")
    String physicalDeliveryOfficeName;

    @Attribute(name = "proxyAddresses")
    Set<String> proxyAddresses;

    @Attribute(name = "description")
    String description;

    @Attribute(name = "info")
    String info;

    @Attribute(name = "showInAddressBook")
    Set<Name> showInAddressBook;

    @Attribute(name = "memberOf", readonly = true)
    Set<Name> memberOf;

    @Attribute(name = "logonHours", type = Attribute.Type.BINARY)
    byte[] logonHours;
}
