package com.mckesson.ad.actuate;

import com.mckesson.ad.config.LdapDomainConfiguration;
import com.mckesson.ad.config.LdapServer;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.boot.actuate.ldap.LdapHealthIndicator;
import org.springframework.ldap.core.LdapOperations;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.HashMap;
import java.util.Map;

/**
 * Checks status of AD servers
 */
@Component
public class AdHealthIndicator extends AbstractHealthIndicator {

    private final Map<String, LdapHealthIndicator> ldapHealthIndicators;

    public AdHealthIndicator(LdapDomainConfiguration ldapDomainConfiguration) {
        super("AD health check failed");
        Assert.notNull(ldapDomainConfiguration, "LdapDomainConfiguration must not be null");
        ldapHealthIndicators = new HashMap<>();
        for (LdapServer ldapServer : ldapDomainConfiguration.getNodes()) {
            if (ldapServer.isEnabled()) {
                String key = ldapServer.getDomain() + " (" + ldapServer.getUrl() + ")";
                ldapHealthIndicators.put(key, createLdapHealthIndicator(ldapServer.getLdapRepository().getLdapTemplate()));
            }
        }
    }

    protected LdapHealthIndicator createLdapHealthIndicator(LdapOperations ldapOperations) {
        return new LdapHealthIndicator(ldapOperations);
    }

    @Override
    protected void doHealthCheck(Health.Builder builder) {
        Status status;
        Map<String, Object> details = new HashMap<>();
        if (ldapHealthIndicators.isEmpty()) {
            status = Status.OUT_OF_SERVICE;
        } else {
            status = Status.UP;
            for (Map.Entry<String, LdapHealthIndicator> entry : ldapHealthIndicators.entrySet()) {
                Health health = entry.getValue().health();
                if (!Status.UP.equals(health.getStatus())) {
                    status = Status.DOWN;
                }
                details.put(entry.getKey(), health);
            }
        }
        builder.status(status).withDetails(details);
    }
}
