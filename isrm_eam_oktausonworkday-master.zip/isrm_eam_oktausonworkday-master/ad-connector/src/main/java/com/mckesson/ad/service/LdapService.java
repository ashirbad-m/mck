package com.mckesson.ad.service;

import com.mckesson.ad.repository.LdapEntryType;
import com.mckesson.common.domain.AdGroup;
import com.mckesson.common.domain.AdServer;
import com.mckesson.common.domain.OktaEntryDto;
import com.mckesson.common.domain.OktaUser;
import com.mckesson.common.model.DomainConfig;

import javax.naming.ldap.LdapName;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface LdapService {
    /**
     * Generates unique email and assign this value to given user
     *
     * @param adUser            AD user
     * @param withUserPrincipal
     */
    void generateAndSetEmails(OktaUser adUser, boolean withUserPrincipal);

    /**
     * Generates unique DN
     *
     * @param dnBase base DN
     * @return unique value
     */
    LdapName generateDn(LdapName dnBase);

    /**
     * Generates unique CN
     *
     * @param cn           CN
     * @param originalDn   original DN
     * @param domainConfig Domain config
     * @param parents      parents
     * @return generated CN
     */
    String generateCn(String cn, LdapName originalDn, DomainConfig domainConfig, LdapName... parents);

    /**
     * Generates unique UID
     *
     * @param uidBase base UID
     * @return generated value
     */
    String generateUID(String uidBase);

    /**
     * Finds AD servers managed by entity
     *
     * @param domainConfigs domain configs
     * @param dn            entity DN
     * @return found AD servers
     */
    List<AdServer> findManagedServers(List<DomainConfig> domainConfigs, LdapName dn);

    /**
     * Updates objects Manager
     *
     * @param objects        updating objects
     * @param dn             DN
     * @param type           type
     * @param managerAttName manager attribute name
     * @param <D>            type of objects
     */
    <D extends OktaEntryDto> void updateObjectsManager(
            List<D> objects, LdapName dn, LdapEntryType<?, D> type, String managerAttName
    );

    /**
     * Finds AD admins managed by entity
     *
     * @param domainConfigs domain config
     * @param dn            entity DN
     * @return managed admins by domain
     */
    Map<DomainConfig, List<OktaUser>> findAdminsManagedByDN(List<DomainConfig> domainConfigs, LdapName dn);

    /**
     * Disables admins
     *
     * @param domainConfig domain config
     * @param admins       list of admins
     */
    void disableAdmins(DomainConfig domainConfig, List<OktaUser> admins);

    /**
     * Finds service accounts managed by entity
     *
     * @param domainConfigs domain configs
     * @param dn            entity DN
     * @return managed service accounts
     */
    List<OktaUser> findServiceAccountsManagedByDN(List<DomainConfig> domainConfigs, LdapName dn);

    /**
     * Finds groups managed by entity
     *
     * @param domainConfigs domain configs
     * @param dn            entity DN
     * @return managed groups
     */
    List<AdGroup> findGroupsManagedByDN(List<DomainConfig> domainConfigs, LdapName dn);

    /**
     * Finds user groups
     *
     * @param dn user DN
     * @return user groups
     */
    List<AdGroup> findUserGroups(LdapName dn);

    /**
     * Finds user by DN directly
     *
     * @param dn user ND
     * @return found user or null
     */
    OktaUser findUserByDNDirect(String dn);

    /**
     * Finds user by worker ID
     *
     * @param workerId worker ID
     * @return found user or null
     */
    OktaUser findUserByWorkerId(String workerId);

    /**
     * Removes group memberships
     *
     * @param memberDn member DN
     * @param groups   groups
     */
    void removeGroupMemberships(String memberDn, Collection<AdGroup> groups);

    /**
     * Add group memberships
     *
     * @param domainConfig domain config
     * @param memberDn     member DN
     * @param groups       groups
     */
    void addGroupMemberships(DomainConfig domainConfig, String memberDn, Collection<String> groups);
}
