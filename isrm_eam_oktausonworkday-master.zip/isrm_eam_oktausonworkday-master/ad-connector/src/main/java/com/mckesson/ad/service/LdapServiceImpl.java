package com.mckesson.ad.service;

import com.google.common.collect.ImmutableSet;
import com.mckesson.ad.config.LdapDomainConfiguration;
import com.mckesson.ad.config.LdapServer;
import com.mckesson.ad.entity.AdEntry;
import com.mckesson.ad.repository.LdapEntryType;
import com.mckesson.ad.repository.LdapRepository;
import com.mckesson.common.domain.*;
import com.mckesson.common.imdg.ImdgInstance;
import com.mckesson.common.imdg.ImdgMap;
import com.mckesson.common.ldap.LdapUtils;
import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.HrbuConfig;
import com.mckesson.common.model.WorkdayConfig;
import com.mckesson.common.workday.configuration.controller.ConfigurationClient;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.naming.InvalidNameException;
import javax.naming.Name;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.ldap.LdapName;
import javax.naming.ldap.Rdn;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.function.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.mckesson.ad.repository.LdapEntryType.*;
import static com.mckesson.common.ldap.LdapUtils.*;
import static com.mckesson.common.workday.converter.ConverterUtils.REQUIRED_STRING_GETTER;

@Service
@RequiredArgsConstructor
@Slf4j
public class LdapServiceImpl implements LdapService, FindManagerService {

    private static final String KEY_LOGINS = "logins";
    private static final String KEY_EMAILS = "emails";
    private static final String KEY_DNS = "dns";

    @Value("${ad.cache.expire-time.users}")
    private int usersTtl;

    private final ImdgInstance imdgInstance;
    private final ConfigurationClient configurationClient;
    private final LdapDomainConfiguration ldapDomainConfiguration;

    private static final BiFunction<OktaUser, Boolean, Manager> MANAGER_VALUE = (user, real) -> Manager.builder().user(Manager.truncateToManagerAttributes(user)).real(real).build();

    private static IntFunction<String> quadrupleStringValueGenerator(final String value, final String indent, final String postfix) {
        return i -> (i == 0) ? String.format("%s%s", value, postfix) : String.format("%s%s%d%s", value, indent, i, postfix);
    }

    private static IntFunction<LdapName> dnValueGenerator(@NonNull final LdapName dn) {
        final List<Rdn> rDns = dn.getRdns();
        final List<Rdn> parentRDNs = rDns.subList(0, rDns.size() - 1);
        final Rdn child = rDns.get(rDns.size() - 1);
        return i -> {
            if (i == 0) {
                return dn;
            }
            try {
                LdapName result = new LdapName(parentRDNs);
                result.add(new Rdn(child.getType(), String.format("%s %d", child.getValue(), i)));
                return result;
            } catch (InvalidNameException e) {
                throw new RuntimeException("Illegal Rdn value: " + child.getValue());
            }
        };
    }

    private static Function<List<DomainConfig>, Predicate<OktaUser>> getServiceAccountChecker() {
        return getDistinguishedNameChecker(domainConfig -> {
            Set<LdapName> s = new HashSet<>(domainConfig.getWorkersOu());
            s.add(domainConfig.getTerminatedOu());
            return s;
        }, false);
    }

    private static Function<List<DomainConfig>, Predicate<OktaUser>> getDistinguishedNameChecker(Function<DomainConfig, Set<LdapName>> mapper, boolean isTrue) {
        if (isTrue) {
            return domainConfigs -> (oktaUser -> domainConfigs.stream().anyMatch(domainConfig -> (mapper.apply(domainConfig).stream().anyMatch(container -> oktaUser.getDn().startsWith(container)))));
        } else {
            return domainConfigs -> (oktaUser -> domainConfigs.stream().noneMatch(domainConfig -> (mapper.apply(domainConfig).stream().anyMatch(container -> oktaUser.getDn().startsWith(container)))));
        }
    }

    private static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
        Map<Object, Boolean> map = new ConcurrentHashMap<>();
        return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

    private ImdgMap<String, Date> getImdgMap(String key) {
        return imdgInstance.getMap("ad.user-" + key);
    }

    private boolean containsKey(String key, String value) {
        return getImdgMap(key).containsKey(value);
    }

    private void addKey(String key, String value) {
        getImdgMap(key).set(value, new Date(), usersTtl, TimeUnit.SECONDS);
    }

    @Override
    public void generateAndSetEmails(final OktaUser adUser, final boolean withUserPrincipal) {
        final String principalFromOkta = Objects.requireNonNull(adUser.getUserPrincipalName());
        BiConsumer<String, Consumer<String>> uniqueSetter = (value, setter) -> {
            if (StringUtils.isBlank(value)) {
                setter.accept(value);
                return;
            }
            String unique = generateUniqueMail(value);
            addKey(KEY_EMAILS, unique);
            setter.accept(unique);
            if (withUserPrincipal && principalFromOkta.equals(value)) {
                adUser.setUserPrincipalName(unique);
            }
        };
        uniqueSetter.accept(Objects.requireNonNull(adUser.getEmailPrimary()), adUser::setEmailPrimary);
        uniqueSetter.accept(adUser.getEmailSecondary(), adUser::setEmailSecondary);
        uniqueSetter.accept(adUser.getEmailSecondaryAdditional(), adUser::setEmailSecondaryAdditional);
    }

    @Override
    public synchronized String generateUID(final String uidBase) {
        String result = generateVerifiedValue(quadrupleStringValueGenerator(uidBase, "", ""), this::checkSamAccountNamePredicate);
        addKey(KEY_LOGINS, result);
        return result;
    }

    @Override
    public synchronized LdapName generateDn(@NonNull final LdapName dnBase) {
        LdapName result = generateVerifiedValue(dnValueGenerator(dnBase), this::checkDn);
        addKey(KEY_DNS, result.toString());
        return result;
    }

    @Override
    public synchronized String generateCn(String cn, LdapName originalDn, DomainConfig domainConfig, LdapName... parents) {
        String result = generateVerifiedValue(quadrupleStringValueGenerator(cn, " ", ""), getCnChecker(originalDn, domainConfig, parents));
        try {
            Rdn childRdn = new Rdn("CN", result);
            Stream.of(parents).map(value -> new LdapName(value.getRdns()).add(childRdn)).forEach(dn -> addKey(KEY_DNS, dn.toString()));
        } catch (InvalidNameException e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }

    private LdapName generateDn(DomainConfig domainConfig, String uid, LdapName oldDn) {
        String ou = LdapUtils.getParentDN(oldDn);
        uid = LdapUtils.normalizeCN(uid);

        String cn = uid;
        LdapName dn = LdapUtils.appendToLdapName(ou, "cn", cn);
        int counter = 1;

        while (findUserByDn(domainConfig, dn) != null && counter < 1000) {
            cn = uid + " " + counter;
            dn = LdapUtils.appendToLdapName(ou, "cn", cn);
            counter++;
        }

        return dn;
    }

    private OktaUser findUserByDn(final DomainConfig domainConfig, final Name dn) {
        return findUserByDn(domainConfig, dn, null);
    }

    private OktaUser findUserByDn(final DomainConfig domainConfig, final Name dn, final String excludedUid) {
        if (dn != null) {
            LdapRepository ldapRepository = ldapDomainConfiguration.getServer(domainConfig.getName()).getLdapRepository();
            if (ldapRepository.truncateOrNull(dn) != null) {
                LdapQuery query = LdapQueryBuilder.query().where(DISTINGUISHED_NAME).is(dn.toString());
                List<OktaUser> users = find(domainConfig, query, USER);
                if (!(excludedUid != null && users.size() == 1 && excludedUid.equals(users.get(0).getUid()))) {
                    return users.isEmpty() ? null : users.get(0);
                }
            }
        }

        return null;
    }

    private <D extends OktaEntryDto> void updateObject(D object, Function<D, ModificationItem[]> modificationProducer, LdapEntryType<?, D> type) {
        LdapRepository ldapRepository = ldapDomainConfiguration.getServer(object.getDomain()).getLdapRepository();
        ModificationItem[] items = modificationProducer.apply(object);
        if (items != null && items.length != 0) {
            ldapRepository.modifyAttributes(object, items, type);
        }
    }

    private <D extends OktaEntryDto> void updateObject(DomainConfig domainConfig, D object, Function<D, ModificationItem[]> modificationProducer, LdapEntryType<?, D> type) {
        LdapRepository ldapRepository = ldapDomainConfiguration.getServer(domainConfig.getName()).getLdapRepository();
        ModificationItem[] items = modificationProducer.apply(object);
        if (items != null && items.length != 0) {
            ldapRepository.modifyAttributes(object, items, type);
        }
    }

    private <D extends OktaEntryDto> void updateObjects(List<D> objects, Function<D, ModificationItem[]> modificationProducer, LdapEntryType<?, D> type) {
        objects.forEach(o -> updateObject(o, modificationProducer, type));
    }

    @Override
    public <D extends OktaEntryDto> void updateObjectsManager(List<D> objects, LdapName dn, LdapEntryType<?, D> type, String managerAttName) {
        updateObjects(objects, o -> new ModificationItem[]{new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute(managerAttName, dn.toString()))}, type);
    }

    @Override
    public void disableAdmins(DomainConfig domainConfig, List<OktaUser> admins) {
        admins.forEach(admin -> {
            updateObject(domainConfig, admin, user -> {
                if (user.isEnabled()) {
                    return new ModificationItem[]{new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute(USER_ACCOUNT_CONTROL, String.valueOf(user.getUserAccountControl() ^ 2)))};
                }
                return new ModificationItem[0];
            }, USER);
            List<AdGroup> userGroups = findUserGroups(admin.getDn());
            removeGroupMemberships(domainConfig, admin.getDn(), userGroups);
        });
    }

    @Override
    public List<AdServer> findManagedServers(List<DomainConfig> domainConfigs, LdapName dn) {
        return findInDomains(domainConfigs, SERVER, dc -> List.of(LdapQueryBuilder.query()
                .where(GROUP_COMPUTER_MANAGER).is(dn.toString())
                .and(LdapQueryBuilder.query()
                        .where(COMPUTER_OS).like("*server*")
                        .or(COMPUTER_OS).like("*linux*")
                        .or(COMPUTER_OS).like("*redhat*")
                        .or(COMPUTER_OS).like("*sunos*")
                        .or(COMPUTER_OS).like("*ontap*")
                        .or(COMPUTER_OS).like("*sles*")
                        .or(COMPUTER_OS).like("*centos*")
                )));
    }

    @Override
    public Map<DomainConfig, List<OktaUser>> findAdminsManagedByDN(List<DomainConfig> domainConfigs, LdapName dn) {
        return domainConfigs.stream().collect(Collectors.toMap(Function.identity(), domainConfig -> findInDomain(domainConfig, USER, dc -> {
            Set<LdapName> ous = dc.getAdminsOu();
            LdapRepository ldapRepository = ldapDomainConfiguration.getServer(dc.getName()).getLdapRepository();
            return ous.stream().map(ldapName -> {
                final Name base = ldapRepository.truncateOrNull(ldapName);
                if (base == null) {
                    return null;
                } else {
                    return LdapQueryBuilder.query().base(base).where(ACCOUNT_MANAGER).is(dn.toString()).and(SAM_ACCOUNT_NAME).like("a-*");
                }
            }).filter(Objects::nonNull).collect(Collectors.toList());
        })));
    }

    @Override
    public List<OktaUser> findServiceAccountsManagedByDN(List<DomainConfig> domainConfigs, LdapName dn) {
        List<OktaUser> result = findInDomains(domainConfigs, USER, dc -> List.of(LdapQueryBuilder.query().where(ACCOUNT_MANAGER).is(dn.toString()).and(SAM_ACCOUNT_NAME).not().like("a-*")));
        return result.stream().filter(getServiceAccountChecker().apply(domainConfigs)).collect(Collectors.toList());
    }

    @Override
    public List<AdGroup> findGroupsManagedByDN(List<DomainConfig> domainConfigs, LdapName dn) {
        return findInDomains(domainConfigs, GROUP, dc -> List.of(LdapQueryBuilder.query().where(GROUP_COMPUTER_MANAGER).is(dn.toString())));
    }

    @Override
    public List<AdGroup> findUserGroups(LdapName dn) {
        List<DomainConfig> domainConfigs = configurationClient.allDomainConfigs();
        return findInDomains(domainConfigs, GROUP, dc -> List.of(LdapQueryBuilder.query().where(CONTAINER_MEMBER).is(dn.toString())));
    }

    @Override
    public void removeGroupMemberships(String memberDn, Collection<AdGroup> groups) {
        if (!CollectionUtils.isEmpty(groups)) {
            for (AdGroup group : groups) {
                LdapRepository ldapRepository = ldapDomainConfiguration.getServer(group.getDomain()).getLdapRepository();
                ldapRepository.modifyAttributes(group, new ModificationItem[]{new ModificationItem(DirContext.REMOVE_ATTRIBUTE, new BasicAttribute(CONTAINER_MEMBER, memberDn))}, GROUP);
            }
        }
    }

    private void removeGroupMemberships(DomainConfig domainConfig, LdapName memberDn, Collection<AdGroup> groups) {
        if (!CollectionUtils.isEmpty(groups)) {
            LdapServer ldapServer = ldapDomainConfiguration.getServer(domainConfig.getName());
            LdapRepository ldapRepository = ldapServer.getLdapRepository();
            for (AdGroup group : groups) {
                ldapRepository.modifyAttributes(group, new ModificationItem[]{new ModificationItem(DirContext.REMOVE_ATTRIBUTE, new BasicAttribute(CONTAINER_MEMBER, memberDn.toString()))}, GROUP);
            }
        }
    }

    @Override
    public void addGroupMemberships(DomainConfig domainConfig, String memberDn, Collection<String> groups) {
        if (!CollectionUtils.isEmpty(groups)) {
            LdapServer ldapServer = ldapDomainConfiguration.getServer(domainConfig.getName());
            LdapRepository ldapRepository = ldapServer.getLdapRepository();
            for (String groupCn : groups) {
                List<AdGroup> foundGroups = ldapRepository.find(LdapQueryBuilder.query().where(DISTINGUISHED_NAME).is(groupCn), GROUP);
                if (foundGroups.size() == 1) {
                    AdGroup group = foundGroups.get(0);
                    ldapRepository.modifyAttributes(group, new ModificationItem[]{new ModificationItem(DirContext.ADD_ATTRIBUTE, new BasicAttribute(CONTAINER_MEMBER, memberDn))}, GROUP);
                } else if (foundGroups.size() > 1) {
                    throw new IllegalStateException("More than 1 group found");
                }
            }
        }
    }

    private <E extends AdEntry, D extends OktaEntryDto> List<D> find(DomainConfig domainConfig, LdapQuery query, LdapEntryType<E, D> type) {
        LdapServer ldapServer = ldapDomainConfiguration.getServer(domainConfig.getName());
        LdapRepository ldapRepository = ldapServer.getLdapRepository();
        return ldapRepository.find(query, type);
    }

    private <E extends AdEntry, D extends OktaEntryDto> List<D> findInDomain(DomainConfig domainConfig, LdapEntryType<E, D> type, Function<DomainConfig, List<LdapQuery>> queryConsumer) {
        return findInDomains(Arrays.asList(domainConfig), type, queryConsumer);
    }

    private <E extends AdEntry, D extends OktaEntryDto> List<D> findInDomains(List<DomainConfig> domainConfigs, LdapEntryType<E, D> type, Function<DomainConfig, List<LdapQuery>> queryConsumer) {
        final List<D> result = new ArrayList<>();
        domainConfigs.forEach(dc -> queryConsumer.apply(dc).forEach(query -> result.addAll(find(dc, query, type))));
        return result.stream().filter(distinctByKey(AdEntryData::getUid)).collect(Collectors.toList());
    }

    @Override
    public Manager findManager(HrbuConfig wdUserHRBUConfig, HrbuConfig adUserHRBUConfig, String wdManagerWorkerId, String wdManagerUserId, String wdManagerHrbu, final String adManagerDn, final String wdExecutiveDirectorWorkerId, String wdExecutiveDirectorUserId, String wdExecutiveDirectorHrbu, boolean findNewManager, boolean includeTerminations) {
        try {
            return (!findNewManager) ? getManagerByDn(new LdapName(adManagerDn), adUserHRBUConfig, wdExecutiveDirectorWorkerId, wdExecutiveDirectorUserId, wdExecutiveDirectorHrbu, includeTerminations) : getManagerByWorkerId(wdManagerWorkerId, wdUserHRBUConfig, wdManagerUserId, wdManagerHrbu, wdExecutiveDirectorWorkerId, wdExecutiveDirectorUserId, wdExecutiveDirectorHrbu);
        } catch (InvalidNameException ex) {
            log.error("Find Manager failed:", ex);
            return null;
        }
    }

    private Predicate<DomainConfig> checkEmailPredicate(final String valueToCheck) {
        return domainConfig -> notExistsUserByUpnOrEmail(domainConfig, valueToCheck);
    }

    private Predicate<DomainConfig> checkSamAccountNamePredicate(final String valueToCheck) {
        return domainConfig -> notExistsUserBySamAccountName(domainConfig, valueToCheck);
    }

    private Predicate<DomainConfig> checkDn(final Name valueToCheck) {
        return domainConfig -> notExistsUserByDn(domainConfig, valueToCheck, null);
    }

    private Function<String, Predicate<DomainConfig>> getCnChecker(final LdapName originalDn, final DomainConfig domainConfig, final LdapName... parents) {
        final String uid = Objects.requireNonNull(findUserByDn(domainConfig, originalDn)).getUid();
        return valueToCheck -> {
            try {
                final Rdn childRdn = new Rdn("CN", valueToCheck);
                return dc -> Stream.of(parents).map(value -> new LdapName(value.getRdns()).add(childRdn)).allMatch(child -> notExistsUserByDn(dc, child, uid));
            } catch (InvalidNameException e) {
                throw new RuntimeException("Invalid cn", e);
            }
        };
    }

    private synchronized String generateUniqueMail(@NonNull String emailParam) {
        String[] split = emailParam.split("@");
        String emailBase = split[0];
        String emailDomain = split[1];

        return generateVerifiedValue(quadrupleStringValueGenerator(emailBase, "", "@" + emailDomain), this::checkEmailPredicate);
    }

    private <T> T generateVerifiedValue(final IntFunction<T> generator, final Function<T, Predicate<DomainConfig>> func) {
        T result = null;
        List<DomainConfig> domainConfigs = configurationClient.allDomainConfigs();
        int counter = 0;
        while (result == null && counter < 1000) {
            T tmpValue = generator.apply(counter);
            if (domainConfigs.stream().allMatch(func.apply(tmpValue))) {
                result = tmpValue;
            }
            counter++;
        }
        return result;
    }

    private boolean notExistsUserByUpnOrEmail(final DomainConfig domainConfig, final String email) {
        if (containsKey(KEY_EMAILS, email)) {
            return false;
        } else {
            LdapQuery query = LdapQueryBuilder.query().attributes(OBJECT_GUID).where(USER_PRINCIPAL_NAME).is(email).or(MAIL).is(email).or(PROXY_ADDRESSES).is(SMTP_PREFIX + email);
            return find(domainConfig, query, USER).isEmpty();
        }
    }

    private boolean notExistsUserBySamAccountName(DomainConfig domainConfig, String samAccountName) {
        if (containsKey(KEY_LOGINS, samAccountName)) {
            return false;
        } else {
            LdapQuery query = LdapQueryBuilder.query().attributes(OBJECT_GUID).where(SAM_ACCOUNT_NAME).is(samAccountName);
            return find(domainConfig, query, USER).isEmpty();
        }
    }


    private boolean notExistsUserByDn(final DomainConfig domainConfig, final Name dn, final String excludedUid) {
        if (containsKey(KEY_DNS, dn.toString())) {
            return false;
        } else {
            return findUserByDn(domainConfig, dn, excludedUid) == null;
        }
    }


    private OktaUser findUserByDN(final String dn, final boolean isVantage, final boolean includeTerminations) {
        OktaUser result = null;
        List<DomainConfig> domainConfigs = configurationClient.allDomainConfigs();
        for (DomainConfig domainConfig : domainConfigs) {
            ImmutableSet.Builder<LdapName> rootOUs = ImmutableSet.<LdapName>builder().addAll(domainConfig.getWorkersOu());
            if (isVantage) {
                rootOUs = rootOUs.addAll(domainConfig.getQuestOu());
            }
            if (includeTerminations) {
                rootOUs = rootOUs.add(domainConfig.getTerminatedOu());
            }
            result = findFirstUserInOUs(ldapDomainConfiguration.getServer(domainConfig.getName()).getLdapRepository(), rootOUs.build(), DISTINGUISHED_NAME, dn);
            if (!Objects.isNull(result)) {
                break;
            }
        }
        return result;
    }

    private OktaUser findByCNInQCS(final String cn, final boolean isInMcKessonHRBU, final boolean isFilterByTerminationOU) {
        OktaUser result = null;
        if (isInMcKessonHRBU && StringUtils.isNotBlank(cn)) {
            List<DomainConfig> domainConfigs = configurationClient.allDomainConfigs();
            for (DomainConfig domainConfig : domainConfigs) {
                Set<LdapName> rootOUs = domainConfig.getQuestOu();
                for (LdapName rootOU : rootOUs) {
                    LdapRepository repository = ldapDomainConfiguration.getServer(domainConfig.getName()).getLdapRepository();
                    final Name base = repository.truncateOrNull(rootOU);
                    if (base == null) {
                        continue;
                    }
                    List<OktaUser> users = repository.find(LdapQueryBuilder.query().base(base).where(CN).is(cn), USER);
                    if (isFilterByTerminationOU) {
                        if (!CollectionUtils.isEmpty(users)) {
                            users = users.stream().filter(oktaUser -> !oktaUser.getDn().toString().contains(domainConfig.getTerminatedOu().toString())).collect(Collectors.toList());
                        }
                    }
                    if (!CollectionUtils.isEmpty(users)) {
                        result = users.get(0);
                        break;
                    }
                }
            }
        }
        return result;
    }

    private OktaUser findFirstUserInOUs(LdapRepository repository, final Set<LdapName> rootOUs, final String attributeName, final String attributeValue) {
        OktaUser result = null;
        for (LdapName rootOU : rootOUs) {
            final Name base = repository.truncateOrNull(rootOU);
            if (base == null) {
                continue;
            }
            List<OktaUser> users = repository.find(LdapQueryBuilder.query().base(base).where(attributeName).is(attributeValue), USER);
            if (!CollectionUtils.isEmpty(users)) {
                result = users.get(0);
                break;
            }
        }
        return result;
    }

    @Override
    public OktaUser findUserByDNDirect(final String dn) {
        OktaUser result = null;
        List<DomainConfig> domainConfigs = configurationClient.allDomainConfigs();
        for (DomainConfig domainConfig : domainConfigs) {
            LdapRepository repository = ldapDomainConfiguration.getServer(domainConfig.getName()).getLdapRepository();
            List<OktaUser> users = repository.find(LdapQueryBuilder.query().where(DISTINGUISHED_NAME).is(dn), USER);
            if (!CollectionUtils.isEmpty(users)) {
                result = users.get(0);
                break;
            }
        }
        return result;
    }

    @Override
    public @NonNull Manager getManagerByDn(final LdapName managerDn, @NonNull final String hrbu, final String city, final String address, final String executiveDirectorWorkerId, final String executiveDirectorUserId, final String executiveDirectorHrbu, boolean includeTerminations) {
        return getManagerByDn(managerDn, configurationClient.findHrbuConfig(hrbu, city, address), executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu, includeTerminations);
    }

    @Override
    public @NonNull Manager getManagerByDn(final LdapName managerDn, @NonNull final HrbuConfig hrbuConfig, final String executiveDirectorWorkerId, final String executiveDirectorUserId, final String executiveDirectorHrbu, boolean includeTerminations) {
        return getManagerByDn(managerDn, hrbuConfig, configurationClient.findDomainConfig(hrbuConfig), executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu, includeTerminations);
    }

    @Override
    public @NonNull Manager getManagerByDn(final LdapName managerDn, @NonNull final HrbuConfig hrbuConfig, @NonNull final DomainConfig domainConfig, final String executiveDirectorWorkerId, final String executiveDirectorUserId, final String executiveDirectorHrbu, boolean includeTerminations) {
        return getManagerByDn(managerDn, hrbuConfig, domainConfig, configurationClient.findGlobalConfig(), executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu, includeTerminations);
    }

    @Override
    public @NonNull Manager getManagerByDn(final LdapName managerDn, @NonNull final HrbuConfig hrbuConfig, @NonNull final DomainConfig domainConfig, @NonNull final WorkdayConfig workdayConfig, final String executiveDirectorWorkerId, final String executiveDirectorUserId, final String executiveDirectorHrbu, final boolean includeTerminations) {
        OktaUser ou = (managerDn == null) ? null : findUserByDN(managerDn.toString(), hrbuConfig.isVantageLookupStrategy(), includeTerminations);
        return (ou == null) ? getManagerSubstitution(domainConfig, workdayConfig, executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu) : MANAGER_VALUE.apply(ou, true);
    }

    @Override
    public @NonNull Manager getManagerByWorkerId(final String managerWorkerId, @NonNull final String hrbu, final String city, final String address, final String managerUserId, final String managerHrbu, final String executiveDirectorWorkerId, final String executiveDirectorUserId, String executiveDirectorHrbu) {
        return getManagerByWorkerId(managerWorkerId, configurationClient.findHrbuConfig(hrbu, city, address), managerUserId, managerHrbu, executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu);
    }

    @Override
    public @NonNull Manager getManagerByWorkerId(final String managerWorkerId, @NonNull final HrbuConfig hrbuConfig, final String managerUserId, final String managerHrbu, final String executiveDirectorWorkerId, final String executiveDirectorUserId, final String executiveDirectorHrbu) {
        return getManagerByWorkerId(managerWorkerId, hrbuConfig, configurationClient.findDomainConfig(hrbuConfig), managerUserId, managerHrbu, executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu);
    }

    @Override
    public @NonNull Manager getManagerByWorkerId(final String managerWorkerId, @NonNull final HrbuConfig hrbuConfig, @NonNull final DomainConfig domainConfig, final String managerUserId, final String managerHrbu, final String executiveDirectorWorkerId, final String executiveDirectorUserId, final String executiveDirectorHrbu) {
        return getManagerByWorkerId(managerWorkerId, hrbuConfig, domainConfig, configurationClient.findGlobalConfig(), managerUserId, managerHrbu, executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu);
    }

    @Override
    public @NonNull Manager getManagerByWorkerId(final String managerWorkerId, @NonNull final HrbuConfig hrbuConfig, @NonNull final DomainConfig domainConfig, @NonNull final WorkdayConfig workdayConfig, final String managerUserId, final String managerHrbu, final String executiveDirectorWorkerId, final String executiveDirectorUserId, final String executiveDirectorHrbu) {
        OktaUser ou = findUserByIds(managerWorkerId, managerUserId, managerHrbu != null && workdayConfig.isMcKessonHRBU(managerHrbu), hrbuConfig.isVantageLookupStrategy());
        return (ou == null) ? getManagerSubstitution(domainConfig, workdayConfig, executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu) : MANAGER_VALUE.apply(ou, true);
    }

    @Override
    public OktaUser findUserByWorkerId(final String workerId) {
        OktaUser result = null;
        if (StringUtils.isNotBlank(workerId)) {
            List<DomainConfig> domainConfigs = configurationClient.allDomainConfigs();
            for (DomainConfig domainConfig : domainConfigs) {
                Set<LdapName> rootOUs = domainConfig.getWorkersOu();
                result = findFirstUserInOUs(ldapDomainConfiguration.getServer(domainConfig.getName()).getLdapRepository(), rootOUs, WORKER_ID, workerId);
                if (!Objects.isNull(result)) {
                    break;
                }
            }
        }
        return result;
    }

    private @NonNull Manager getManagerSubstitution(@NonNull final DomainConfig domainConfig, @NonNull final WorkdayConfig workdayConfig, final String executiveDirectorWorkerId, final String executiveDirectorUserId, final String executiveDirectorHrbu) {
        OktaUser ou = null;
        if (StringUtils.isNotBlank(executiveDirectorHrbu)) {
            ou = findExecutiveDirectorByIds(executiveDirectorWorkerId, executiveDirectorUserId, workdayConfig.isMcKessonHRBU(executiveDirectorHrbu));
        }
        if (ou == null) {
            Map<String, Object> manager = Objects.requireNonNull(domainConfig.getDefaultManager());
            String sDn = REQUIRED_STRING_GETTER.apply(manager, "distinguishedName");

            ou = findUserByDNDirect(sDn);
            OktaUser.OktaUserBuilder builder = (ou == null) ? OktaUser.builder() : ou.toBuilder();

            ou = Manager.parseOktaUser(manager, builder, "distinguishedName", "sAMAccountName", false);
        }
        return MANAGER_VALUE.apply(ou, false);
    }

    private OktaUser findUserByIds(final String workerId, final String userId, boolean isInMcKessonHRBU, final boolean isVantage) {
        OktaUser result = findUserByWorkerId(workerId);
        if (Objects.isNull(result) && isVantage) {
            // if vantage lookup strategy uses - need to find QCS object inside of McKesson HRBU
            result = findByCNInQCS(userId, isInMcKessonHRBU, false);
        }
        return result;
    }

    private OktaUser findExecutiveDirectorByIds(final String executiveDirectorWorkerId, final String executiveDirectorUserId, final boolean isInMcKessonHrbu) {
        OktaUser result = null;
        if (isInMcKessonHrbu) {
            result = findByCNInQCS(executiveDirectorUserId, true, true);
        } else {
            result = findUserByIds(executiveDirectorWorkerId, executiveDirectorUserId, false, false);
        }
        return result;
    }

}
