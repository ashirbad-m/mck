package com.mckesson.ad.config;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.mckesson.ad.repository.LdapRepository;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;

import java.util.HashMap;
import java.util.Map;

import static com.mckesson.common.ldap.LdapUtils.OBJECT_GUID;
import static com.mckesson.common.ldap.LdapUtils.OBJECT_SID;
import static com.mckesson.common.ldap.LdapUtils.LOGON_HOURS;
import static com.mckesson.common.ldap.LdapUtils.PWD_NATIVE;
import static com.mckesson.common.workday.converter.ConverterUtils.nullableLdapName;

/**
 * LDAP(AD) Server descriptor
 */
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class LdapServer {

    private static final String BINARY_FIELDS = String.join(" ", OBJECT_GUID, OBJECT_SID, LOGON_HOURS, PWD_NATIVE);

    boolean enabled;

    /**
     * internal name of domain
     */
    String domain;

    /**
     * connection url
     */
    String url;

    /**
     * connection user
     */
    String user;

    /**
     * connection user password
     */
    @ToString.Exclude
    String password;

    /**
     * Domain bas DN
     */
    String baseDn;

    /**
     * Set the method to handle referrals.
     * Default is 'ignore'; setting this flag to 'follow' will enable referrals to be automatically followed.
     */
    String referral;

    @JsonIgnore
    @Getter(lazy = true)
    final LdapRepository ldapRepository = createLdapRepository();

    private LdapRepository createLdapRepository() {
        final LdapContextSource ctx = new LdapContextSource();
        ctx.setUrl(url);
        ctx.setBase(baseDn);
        ctx.setUserDn(user);
        ctx.setPassword(password);
        ctx.setReferral(referral);

        final Map<String, Object> envProps = new HashMap<>();
        envProps.put("java.naming.ldap.attributes.binary", BINARY_FIELDS);
        ctx.setBaseEnvironmentProperties(envProps);
        ctx.afterPropertiesSet();
        LdapTemplate ldapTemplate = new LdapTemplate(ctx);
//        ldapTemplate.setIgnorePartialResultException(true);
//        ldapTemplate.setIgnoreNameNotFoundException(true);
        return new LdapRepository(ldapTemplate, domain, nullableLdapName(baseDn));
    }
}
