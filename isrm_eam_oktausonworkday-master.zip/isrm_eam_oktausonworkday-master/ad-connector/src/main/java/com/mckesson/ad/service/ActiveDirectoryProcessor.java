package com.mckesson.ad.service;

import com.mckesson.ad.repository.LdapEntryType;
import com.mckesson.common.AbstractCoreEventProcessor;
import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.SyncCheckProcessor;
import com.mckesson.common.audit.AuditService;
import com.mckesson.common.domain.*;
import com.mckesson.common.ldap.LdapUtils;
import com.mckesson.common.model.*;
import com.mckesson.common.scenario.ScenarioProvider;
import com.mckesson.common.security.VeracodeUtils;
import com.mckesson.common.workday.configuration.controller.ConfigurationClient;
import com.mckesson.common.workday.configuration.dto.GroupMappingDto;
import com.mckesson.common.workday.configuration.dto.GroupMappingType;
import com.mckesson.common.workday.converter.ConverterUtils;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import javax.naming.ldap.LdapName;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.mckesson.common.ldap.LdapUtils.ACCOUNT_MANAGER;
import static com.mckesson.common.ldap.LdapUtils.GROUP_COMPUTER_MANAGER;

@Service
@Slf4j
public class ActiveDirectoryProcessor extends AbstractCoreEventProcessor implements SyncCheckProcessor {
    private static final String PREFIX = "passport.ad.";
    private static final String MANAGER = PREFIX + "manager";
    private static final String EMAILS = PREFIX + "emails";
    private static final String SAMACCOUNTNAME = PREFIX + "set-SAMAccountName";
    private static final String DN = PREFIX + "set-dn";
    private static final String CN = PREFIX + "set-cn";
    private static final String REMOVE_GROUPS = PREFIX + "remove-groups";
    private static final String REMOVE_SERVICE_GROUPS = PREFIX + "remove-service-groups";
    private static final String ADD_GROUPS = PREFIX + "add-groups";
    private static final String REMOVE_ADMINS = PREFIX + "remove-admins";
    private static final String SET_GROUP_MANAGER = PREFIX + "set-groups-manager";
    private static final String SET_ADMIN_ACCOUNT_MANAGER = PREFIX + "set-admins-manager";
    private static final String SET_SERVICE_ACCOUNT_MANAGER = PREFIX + "set-service-account-manager";

    public static final String CSA_GROUPS_PREFIX = "Last-Names-";

    private static final Pattern PROXY_MATCHER_PATTERN = Pattern.compile("^(smtp:)?(.+?)(\\d*)@([^@]+)$", Pattern.CASE_INSENSITIVE);

    private static final String MAIL_REPLACE_CANONICAL = "$2@$4";

    private static final String MAIL_REPLACE_NO_SMTP = "$2$3@$4";

    private static final Function<String, Matcher> GET_MAIL_MATCHER = mail -> {
        if (!StringUtils.isBlank(mail)) {
            Matcher m = PROXY_MATCHER_PATTERN.matcher(mail);
            if (m.find() && m.groupCount() == 4) {
                return m;
            }
        }
        return null;
    };

    private static final BiFunction<Matcher, Matcher, String> GET_MATCHED = (mExistent, mGenerated) -> (
            mExistent != null && mGenerated != null &&
                    mExistent.replaceAll(MAIL_REPLACE_CANONICAL).equalsIgnoreCase(mGenerated.replaceAll(MAIL_REPLACE_CANONICAL))
    ) ? mExistent.replaceAll(MAIL_REPLACE_NO_SMTP) : null;

    private static void checkEMail(final Set<String> proxies, final String generated, final Consumer<String> setter) {
        final Matcher mGenerated = GET_MAIL_MATCHER.apply(generated);
        if (proxies != null && mGenerated != null) {
            proxies.stream().map(GET_MAIL_MATCHER).map(proxyMatcher -> GET_MATCHED.apply(proxyMatcher, mGenerated))
                    .filter(Objects::nonNull).findFirst()
                    .ifPresent(setter);
        }
    }

    private final Map<ScenarioEnum, Consumer<CoreEvent>> processors = Stream.<Pair<ScenarioEnum, Consumer<CoreEvent>>>of(
            Pair.of(ScenarioEnum.CREATE, this::onCreate),
            Pair.of(ScenarioEnum.UPDATE, this::onUpdate),
            Pair.of(ScenarioEnum.CROSSDOMAIN, this::onTerminate),
            Pair.of(ScenarioEnum.TERMINATE, this::onTerminate),
            Pair.of(ScenarioEnum.REQUEST, this::onRequest),
            Pair.of(ScenarioEnum.DEFERRED, this::onDeferred),
            Pair.of(ScenarioEnum.SYNCHRONIZE, this::onSynchronize)
    ).collect(Collectors.toMap(Pair::getLeft, Pair::getRight));
    private final LdapService ldapService;
    private final FindManagerService findManagerService;
    private final ConfigurationClient configurationClient;
    private final AuditService auditService;

    public ActiveDirectoryProcessor(ScenarioProvider scenarioProvider, MessageBrokerPublisher messageBrokerPublisher,
                                    LdapService ldapService, FindManagerService findManagerService, ConfigurationClient configurationClient,
                                    AuditService auditService) {
        super(scenarioProvider, messageBrokerPublisher, ModuleEnum.ACTIVE_DIRECTORY);
        this.ldapService = ldapService;
        this.findManagerService = findManagerService;
        this.configurationClient = configurationClient;
        this.auditService = auditService;
    }

    @Override
    protected Map<ScenarioEnum, Consumer<CoreEvent>> getProcessors() {
        return processors;
    }

    private void onCreate(CoreEvent event) {
        if ("start".equals(event.getStage())) {
            OktaUser user = event.getOktaUser();
            // generate and set emails
            ldapService.generateAndSetEmails(user, true);
            auditService.audit(generateEvent(event).situation(EMAILS).message("Generated emails for: " + user.getUserPrincipalName())
                    .newValues(ConverterUtils.writeValueAsString(user.getEmails())).build());
            // generate SamAccountName
            final String samAccountName = ldapService.generateUID(Objects.requireNonNull(user.getSamAccountName()));
            user.setSamAccountName(samAccountName);
            auditService.audit(generateEvent(event).situation(SAMACCOUNTNAME).message("Set SAMAccount name as " + samAccountName).build());
            final LdapName userDn = user.getDn();
            // generate DN
            final LdapName dn = ldapService.generateDn(userDn);
            user.setDn(dn);
            user.setCn(dn.getRdn(dn.size() - 1).getValue().toString());
            auditService.audit(generateEvent(event).situation(DN).message("Set DN for: " + userDn).newValues(dn.toString()).build());
            event.setNextOktaUser(user);
        }
    }

    private void onUpdate(CoreEvent event) {
        OktaUser user = event.getNextOktaUser();
        OktaUser prev = event.getPrevOktaUser();
        if ("prepare".equals(event.getStage())) {
            prepareDns(user);
        } else {
            HrbuConfig wdUserHRBUConfig = configurationClient.findHrbuConfig(user.getHrbu(), user.getCity(), user.getStreetAddress());
            HrbuConfig adUserHRBUConfig = configurationClient.findHrbuConfig(prev.getHrbu(), prev.getCity(), prev.getStreetAddress());

            if ("nameChange-cn".equals(event.getStage())
                    || "nameChange-email".equals(event.getStage())
                    || "nameChange-all".equals(event.getStage())) {
                if (!"nameChange-cn".equals(event.getStage())) {
                    ldapService.generateAndSetEmails(user, false);
                    auditService.audit(generateEvent(event).situation(EMAILS).message("Generated emails for: " + user.getUserPrincipalName())
                            .newValues(ConverterUtils.writeValueAsString(user.getEmails())).build());
                }
                if (!"nameChange-email".equals(event.getStage())) {
                    final LdapName dn = user.getDn();
                    final String generateCn = ldapService.generateCn(user.getCn(), dn, event.getDomainConfig(),
                            new LdapName(dn.getRdns().subList(0, dn.size() - 1)));
                    user.setCn(generateCn);
                    auditService.audit(generateEvent(event).situation(CN).message("Generated CN for: " + dn).newValues(generateCn).build());
                }
            } else if ("conversion-ps".equalsIgnoreCase(event.getStage())) {
                conversion(event);// audit inside `conversion` method
            } else if ("ClinicalTransfer".equalsIgnoreCase(event.getStage()) || "HRBUTransfer".equalsIgnoreCase(event.getStage())) {
                // generateDN
//            if ("updateTransfer".equals(event.getStage())) {
//                user.setDn(ldapService.generateDn(event.getDomainConfig(), user.getBaseCn(), user.getDn()));
//            }
                // link manager

                String executiveDirectorStr = Objects.isNull(user.getExecutiveDirector()) ? "" : user.getExecutiveDirector().toString();
                OktaUser wdManager = user.getManagerObject().getUser();
                OktaUser adManager = user.getManagerObject().getUser();
                String wdManagerId = Objects.isNull(wdManager.getId()) ? "" : wdManager.getId().toString();
                Manager linkedManager = findManagerService.findManager(wdUserHRBUConfig, adUserHRBUConfig, wdManagerId,
                        wdManager.getUserId(), wdManager.getHrbu(), adManager.getDn().toString(), executiveDirectorStr,
                        user.getExecutiveDirectorUserId(), user.getExecutiveDirectorHrbu(), false, false);
                if (!Objects.isNull(linkedManager)) {
                    user.setManagerObject(linkedManager);
                } else {
                    log.error("Unable find Manager for the user: {}", VeracodeUtils.encode4java(user.toString()));
                }

                // run common termination
                commonTermination(event, linkedManager);// audit is inside `commonTermination`

                // process own groups of the user
                processOwnGroups(event, wdUserHRBUConfig, user);

                // generate HomeDirName
                user.setHomeDirectory(wdUserHRBUConfig.getHomeDir() + user.getUserName());
            } else if ("TXOTransfer".equalsIgnoreCase(event.getStage())) {
                Set<GroupModel> groupsToAdd = generateGroups(user.getLastName(), user.getWorkerTypeDescriptor(), user.isEmployee(), wdUserHRBUConfig, false);
                //Set<GroupModel> groupsToRemove = generateGroups(user.getLastName(), user.getWorkerTypeDescriptor(), user.isEmployee(), adUserHRBUConfig, false);
                // if we need to add any SVR groups  - we have to remove existing one first
                if (groupsToAdd.stream().anyMatch(group -> group.getName().startsWith("SVR_"))) {

                    List<AdGroup> userGroups = ldapService.findUserGroups(user.getDn());
                    // get all SVR groups who does not have mapping and remove them
                    Set<LdapName> groupMappingsDNs = configurationClient.findGroupMappingsByType(GroupMappingType.HRBU).stream().map(GroupMappingDto::getDn).collect(Collectors.toSet());
                    Set<AdGroup> userSVRGroups = userGroups.stream().filter(group -> (group.getDn().toString().startsWith("CN=SVR_") || group.getDn().toString().startsWith("CN=Svr-"))).collect(Collectors.toSet());
                    Set<AdGroup> svrToRemove = userSVRGroups.stream().filter(userSVRGroup -> !groupMappingsDNs.contains(userSVRGroup.getDn())).collect(Collectors.toSet());

                    ldapService.removeGroupMemberships(user.getDn().toString(), svrToRemove);
                    if (!svrToRemove.isEmpty()) {
                        auditService.audit(generateEvent(event).situation(REMOVE_SERVICE_GROUPS)
                                .message(String.format("Removing [%s] user from service groups", user.getDn()))
                                .newValues(svrToRemove.stream().map(AdGroup::getDn).map(LdapName::toString).collect(Collectors.joining("; ")))
                                .build());
                    }
                }
//            event.getOktaUser().setGroups(groupsToAdd);
//            event.getPrevOktaUser().setGroups(groupsToRemove);
            } else if ("commit".equals(event.getStage())) {
                final Manager manager = calculateManager(user, prev, wdUserHRBUConfig, adUserHRBUConfig);
                auditService.audit(generateEvent(event).situation(MANAGER)
                        .message(String.format("Calculated manager for [%s] user", user.getDn()))
                        .newValues(manager.getManagerAsString()).build());
            }
        }
    }

    private void onTerminate(CoreEvent event) {
        if ("start".equals(event.getStage())) {
            OktaUser prev = event.getPrevOktaUser();
            HrbuConfig prevHRBUConfig = configurationClient.findHrbuConfig(prev.getHrbu(), prev.getCity(), prev.getStreetAddress());
            Manager manager = findManagerService.getManagerByDn(
                    prev.getManager(),
                    prevHRBUConfig,
                    Optional.ofNullable(prev.getExecutiveDirector()).map(String::valueOf).orElse(null),
                    prev.getExecutiveDirectorUserId(),
                    prev.getExecutiveDirectorHrbu(),
                    false
            );
            prev.setManagerObject(manager);
            commonTermination(event, manager);

            processOwnGroups(event, prevHRBUConfig, prev);

            // generate CN
            LdapName dn = prev.getDn();
            DomainConfig prevDomainConfig = configurationClient.findDomainConfigByOu(dn);
            event.getNextOktaUser().setCn(ldapService.generateCn(
                    prev.getCn(),
                    dn,
                    prevDomainConfig,
                    prevDomainConfig.getTerminatedOu(),
                    new LdapName(dn.getRdns().subList(0, dn.size() - 1))
            ));
        } else if ("prepare".equals(event.getStage())) {
            prepareDns(event.getNextOktaUser());
        }
    }

    private void conversion(CoreEvent event) {
        OktaUser user = event.getNextOktaUser();
        HrbuConfig wdUserHRBUConfig = configurationClient.findHrbuConfig(user.getHrbu(), user.getCity(), user.getStreetAddress());

        log.info("Process update conversions");
        OktaUser prevUser = event.getPrevOktaUser();
        WorkerTypeDescriptorEnum cwtOld = WorkerTypeDescriptorEnum.getCwtValue(prevUser.getWorkerTypeDescriptor(), prevUser.isEmployee());
        WorkerTypeDescriptorEnum cwtNew = WorkerTypeDescriptorEnum.getCwtValue(user.getWorkerTypeDescriptor(), user.isEmployee());
        log.debug("Conversion '{}' -> '{}'", cwtOld, cwtNew);
        Set<GroupModel> newGroups;
        List<AdGroup> userGroups = ldapService.findUserGroups(user.getDn());
        if (cwtOld == WorkerTypeDescriptorEnum.CWT_EMPLOYEE && cwtNew == WorkerTypeDescriptorEnum.CWT_CONTRACTOR) {
            newGroups = cwtChangeGroups(wdUserHRBUConfig, userGroups, true, user.getLastName());
        } else if (cwtOld == WorkerTypeDescriptorEnum.CWT_CONTRACTOR && cwtNew == WorkerTypeDescriptorEnum.CWT_EMPLOYEE) {
            newGroups = cwtChangeGroups(wdUserHRBUConfig, userGroups, false, user.getLastName());
        } else {
            newGroups = cwtGenerateGroups(wdUserHRBUConfig, user.getWorkerTypeDescriptor(), user.isEmployee(), user.getLastName());
        }
        Set<AdGroup> removedGroups = modifyGroupMembership(user.getDn(), newGroups);
        auditService.audit(generateEvent(event).situation(ADD_GROUPS)
                .message(String.format("Conversion from %s to %s for : %s inside [hrbu-id: %s]", cwtOld.getValue(), cwtNew.getValue(),
                        user.getUserPrincipalName(), wdUserHRBUConfig.getId()))
                .newValues(ConverterUtils.writeValueAsString(removedGroups)).build());
    }

    private void processOwnGroups(CoreEvent event, HrbuConfig adUserHRBUConfig, OktaUser user) {
        List<AdGroup> userGroups = ldapService.findUserGroups(user.getDn());

        Set<String> workerTypeDescriptorGroups = generateGroups(user.getLastName(), user.getWorkerTypeDescriptor(), user.isEmployee(), adUserHRBUConfig, true)
                .stream()
                .map(model -> model.getDn().toString())
                .collect(Collectors.toSet());
        // get own user groups
        Set<AdGroup> ownUserGroups = userGroups.stream()
                .filter(userGroup -> !workerTypeDescriptorGroups.contains(userGroup.getDn().toString()))
                .collect(Collectors.toSet());

        ldapService.removeGroupMemberships(user.getDn().toString(), ownUserGroups);
        if (!ownUserGroups.isEmpty()) {
            auditService.audit(generateEvent(event).situation(REMOVE_GROUPS).message(String.format("Groups removed for [%s] user", user.getDn()))
                    .newValues(ownUserGroups.stream().map(AdGroup::getDn).map(LdapName::toString).collect(Collectors.joining("; ")))
                    .build());
        }
    }

    private void commonTermination(CoreEvent event, Manager manager) {
        List<DomainConfig> domainConfigs = configurationClient.allDomainConfigs();
        OktaUser user = event.getNextOktaUser();
        List<AdServer> servers = new ArrayList<>(ldapService.findManagedServers(domainConfigs, user.getDn()));
        for (AdServer server : ldapService.findManagedServers(domainConfigs, event.getPrevOktaUser().getDn())) {
            if (!servers.contains(server)) servers.add(server);
        }

        final LdapName dn4Manager = manager.getUser().getDn();
        ldapService.updateObjectsManager(servers, dn4Manager, LdapEntryType.SERVER, GROUP_COMPUTER_MANAGER);
        if (!servers.isEmpty()) {
            auditService.audit(generateEvent(event).situation(MANAGER).message("Updated objects manager to: " + dn4Manager)
                    .newValues(servers.stream().map(server -> String.format("[%s]@[%s]", server.getDn(), server.getDomain()))
                            .collect(Collectors.joining("; ")))
                    .build());
        }
        Set<String> serverNames = servers.stream().map(AdServer::getCn).collect(Collectors.toSet());
        user.setServerNames(serverNames);

        final LdapName managerDn = user.getDn();

        Map<String, Object> associatedAccountsTermination = new HashMap<>();

        Map<DomainConfig, List<OktaUser>> adminsManagedByDN = new HashMap<>();
        for (Map.Entry<DomainConfig, List<OktaUser>> entry : ldapService.findAdminsManagedByDN(domainConfigs, managerDn).entrySet()) {
            adminsManagedByDN.put(entry.getKey(), new ArrayList<>(entry.getValue()));
        }
        for (Map.Entry<DomainConfig, List<OktaUser>> entry : ldapService.findAdminsManagedByDN(domainConfigs, event.getPrevOktaUser().getDn()).entrySet()) {
            DomainConfig domainConfig = entry.getKey();
            for (OktaUser admin : entry.getValue()) {
                List<OktaUser> admins = adminsManagedByDN.get(domainConfig);
                if (admins == null) {
                    admins = new ArrayList<>();
                }
                if (!admins.contains(admin)) {
                    admins.add(admin);
                    adminsManagedByDN.put(domainConfig, admins);
                }
            }
        }
        for (Map.Entry<DomainConfig, List<OktaUser>> entry : adminsManagedByDN.entrySet()) {
            final List<OktaUser> accounts = entry.getValue();
            final DomainConfig domainConfig = entry.getKey();
            ldapService.disableAdmins(domainConfig, accounts);
            if (!accounts.isEmpty()) {
                auditService.audit(generateEvent(event).situation(REMOVE_ADMINS)
                        .message(String.format("Disabled admin accounts at [%s] domain", domainConfig.getId()))
                        .newValues(accounts.stream().map(u -> u.getDn().toString()).collect(Collectors.joining("; "))).build());
            }
        }
        List<Map<String, Object>> adminAccountsTerminationData = adminsManagedByDN.entrySet().stream()
                .flatMap(entry -> entry.getValue().stream().map(account -> {
                            Map<String, Object> originalAdminAccount = Map.of(
                                    "uid", account.getUid(),
                                    "domain", account.getDomain(),
                                    "dn", account.getDn().toString(),
                                    "enable", account.isEnabled()
                            );
                            Map<String, Object> updateData = Map.of(
                                    "uid", account.getUid(),
                                    "domain", account.getDomain(),
                                    "dn", account.getDn().toString(),
                                    "enable", false
                            );
                            return Map.<String, Object>of("original", originalAdminAccount, "updated", updateData);
                        })
                ).collect(Collectors.toList());

        associatedAccountsTermination.put("adminAccounts", adminAccountsTerminationData);

        //Find all groups managed by this person
        List<AdGroup> groupsManagedByDN = new ArrayList<>(ldapService.findGroupsManagedByDN(domainConfigs, managerDn));
        for (AdGroup group : ldapService.findGroupsManagedByDN(domainConfigs, event.getPrevOktaUser().getDn())) {
            if (!groupsManagedByDN.contains(group)) groupsManagedByDN.add(group);
        }
        ldapService.updateObjectsManager(groupsManagedByDN, dn4Manager, LdapEntryType.GROUP, GROUP_COMPUTER_MANAGER);
        if (!groupsManagedByDN.isEmpty()) {
            auditService.audit(generateEvent(event).situation(SET_GROUP_MANAGER)
                    .message(String.format("Set new manager [%s] for groups", dn4Manager))
                    .newValues(groupsManagedByDN.stream().map(AdGroup::getDn).map(LdapName::toString).collect(Collectors.joining("; ")))
                    .build());
        }
        List<Map<String, String>> serviceGroups = groupsManagedByDN.stream().map(group -> Map.of(
                "uid", group.getUid(),
                "domain", group.getDomain(),
                "dn", group.getDn().toString(),
                "managedBy", String.valueOf(group.getManagedBy())
        )).collect(Collectors.toList());
        associatedAccountsTermination.put("serviceGroups", serviceGroups);

        //Find all other accounts managed by this person
        List<OktaUser> accountsManagedByDN = new ArrayList<>(ldapService.findServiceAccountsManagedByDN(domainConfigs, managerDn));
        for (OktaUser admin : ldapService.findServiceAccountsManagedByDN(domainConfigs, event.getPrevOktaUser().getDn())) {
            if (!accountsManagedByDN.contains(admin)) accountsManagedByDN.add(admin);
        }
        ldapService.updateObjectsManager(accountsManagedByDN, dn4Manager, LdapEntryType.USER, ACCOUNT_MANAGER);
        if (!accountsManagedByDN.isEmpty()) {
            auditService.audit(generateEvent(event).situation(SET_ADMIN_ACCOUNT_MANAGER)
                    .message(String.format("Set new manager [%s] for admin accounts", dn4Manager))
                    .newValues(accountsManagedByDN.stream().map(OktaUser::getDn).map(LdapName::toString).collect(Collectors.joining("; ")))
                    .build());
        }

        List<Map<String, String>> serviceAccounts = accountsManagedByDN.stream().map(account -> Map.of(
                "uid", account.getUid(),
                "domain", account.getDomain(),
                "dn", account.getDn().toString(),
                "manager", managerDn.toString()
        )).collect(Collectors.toList());
        associatedAccountsTermination.put("serviceAccounts", serviceAccounts);

        if (!serviceAccounts.isEmpty()) {
            auditService.audit(generateEvent(event).situation(SET_SERVICE_ACCOUNT_MANAGER).message(String.format("Set new manager[%s] for service accounts", dn4Manager))
                    .newValues(serviceAccounts.stream().map(map -> String.join("@", map.get("uid"), map.get("domain")))
                            .collect(Collectors.joining("; ")))
                    .build());
        }

        user.setAssociatedAccountsTermination(ConverterUtils.writeValueAsString(associatedAccountsTermination));

        List<AdGroup> userGroups = ldapService.findUserGroups(user.getDn());
        List<String> info = userGroups.stream()
                .map(group -> LdapUtils.dnToRDNValue(group.getDn()))
                .collect(Collectors.toList());
        user.setInfo(StringUtils.truncate(StringUtils.join(info, ", "), 1024));
    }

    protected Set<String> getCwtGroups(String workerTypeDescriptor, boolean employee, HrbuConfig hrbuConfig) {
        WorkerTypeDescriptorEnum cwt = WorkerTypeDescriptorEnum.getCwtValue(workerTypeDescriptor, employee);
        return getCwtGroups(cwt, hrbuConfig);
    }

    protected Set<GroupModel> cwtChangeGroups(HrbuConfig hrbuConfig, List<AdGroup> userGroups, boolean regular2contractor, String lastName) {
        String workerTypeDescriptorOld, workerTypeDescriptorNew;
        if (regular2contractor) {
            workerTypeDescriptorOld = WorkerTypeDescriptorEnum.CWT_REGULAR;
            workerTypeDescriptorNew = WorkerTypeDescriptorEnum.CWT_CONTRACTOR.getValue();
        } else {
            workerTypeDescriptorOld = WorkerTypeDescriptorEnum.CWT_CONTRACTOR.getValue();
            workerTypeDescriptorNew = WorkerTypeDescriptorEnum.CWT_REGULAR;
        }
        Set<String> oldGroups = cwtGenerateGroups(hrbuConfig, workerTypeDescriptorOld, false, lastName).stream()
                .map(dto -> dto.getDn().toString())
                .collect(Collectors.toSet());
        Stream<GroupModel> newGroups = cwtGenerateGroups(hrbuConfig, workerTypeDescriptorNew, false, lastName).stream();
        Stream<GroupModel> ownGroups = userGroups.stream()
                .filter(group -> !oldGroups.contains(group.getDn().toString()))
                .map(GroupModel::new);

        return Stream.concat(ownGroups, newGroups).collect(Collectors.toSet());
    }

    protected Set<GroupModel> cwtGenerateGroups(HrbuConfig hrbuConfig, String workerTypeDescriptor, boolean employee, String lastName) {
        return generateGroups(lastName, workerTypeDescriptor, employee, hrbuConfig, true);
    }

    private Set<AdGroup> modifyGroupMembership(LdapName dn, Set<GroupModel> newGroups) {
        List<AdGroup> userGroups = ldapService.findUserGroups(dn);
        Set<String> newGroupsDns = newGroups.stream().map(model -> model.getDn().toString()).collect(Collectors.toSet());
        // get own user groups
        Set<AdGroup> adGroupsToRemove = userGroups.stream()
                .filter(userGroup -> !newGroupsDns.contains(userGroup.getDn().toString()))
                .collect(Collectors.toSet());

        /*Set<String> adGroupsToAdd = Sets.difference(newGroupsDns,
                userGroups.stream().map(model -> model.getDn().toString()).collect(Collectors.toSet()));*/

        if (log.isDebugEnabled()) {
            log.debug("Conversion user '{}',\nuser groups -> {}", VeracodeUtils.encode4java(dn.toString()),
                    userGroups.stream().map(group -> VeracodeUtils.encode4java(group.getDn().toString())).sorted().collect(Collectors.toList()));
            log.debug("Conversion user '{}',\nremove groups -> {}", VeracodeUtils.encode4java(dn.toString()),
                    adGroupsToRemove.stream().map(group -> VeracodeUtils.encode4java(group.getDn().toString())).sorted().collect(Collectors.toList()));
        }
        ldapService.removeGroupMemberships(dn.toString(), adGroupsToRemove);
        //ldapService.addGroupMemberships(domainConfig, dn.toString(), adGroupsToAdd);
        return adGroupsToRemove;
    }

    private Set<String> getCwtGroups(WorkerTypeDescriptorEnum cwt, HrbuConfig hrbuConfig) {
        switch (cwt) {
            case CWT_EMPLOYEE:
                return hrbuConfig.getGroups();
            case CWT_CONTRACTOR:
                return hrbuConfig.getContractorGroups();
            case CWT_OUTSIDE:
                return hrbuConfig.getOutsideWorkerGroups();
            case CWT_X:
                return hrbuConfig.getExtGroups();
            default:
                throw new IllegalStateException();
        }
    }

    private Set<GroupModel> generateGroups(final String lastName, final String workerTypeDescriptor, boolean employee, HrbuConfig hrbuConfig, final boolean processCSA) {
        List<GroupModel> defaultGroups = configurationClient.findGroupMappingsByType(GroupMappingType.DEFAULT)
                .stream()
                .map(GroupModel::new)
                .collect(Collectors.toList());
        List<GroupModel> cwtGroups = configurationClient.findGroupMappingsByNames(getCwtGroups(workerTypeDescriptor, employee, hrbuConfig))
                .stream()
                .map(GroupModel::new)
                .collect(Collectors.toList());
        Set<GroupModel> csaGroups = new HashSet<>();
        if (employee && processCSA) {
            String csaGroupName = CSA_GROUPS_PREFIX + String.valueOf(lastName.charAt(0)).toUpperCase();
            log.debug("findGroupMappingsByType(GroupMappingType.CSA): {}", configurationClient.findGroupMappingsByType(GroupMappingType.CSA).stream()
                    .map(dto -> dto.getName() + " | " + dto.getDn()).collect(Collectors.toList()));
            // add CAS groups for the employee
            configurationClient.findGroupMappingsByType(GroupMappingType.CSA).stream()
                    .filter(groupMappingDto -> groupMappingDto.getName().equalsIgnoreCase(csaGroupName))
                    .findFirst()
                    .ifPresent(groupMappingDto -> csaGroups.add(new GroupModel(groupMappingDto)));
        }
        log.debug("generateGroups({}, {}) defaultGroups: {}", VeracodeUtils.encode4java(workerTypeDescriptor), employee,
                defaultGroups.stream().map(dto -> VeracodeUtils.encode4java(dto.getDn().toString())).collect(Collectors.toList()));
        log.debug("generateGroups({}, {}) cwtGroups: {}", VeracodeUtils.encode4java(workerTypeDescriptor), employee,
                cwtGroups.stream().map(dto -> VeracodeUtils.encode4java(dto.getDn().toString())).collect(Collectors.toList()));
        log.debug("generateGroups({}, {}) csaGroups: {}", VeracodeUtils.encode4java(workerTypeDescriptor), employee,
                csaGroups.stream().map(dto -> VeracodeUtils.encode4java(dto.getDn().toString())).collect(Collectors.toList()));
        return Stream.of(defaultGroups, cwtGroups, csaGroups).flatMap(Collection::stream).collect(Collectors.toSet());
    }

    private void onRequest(CoreEvent event) {
        if ("adInfo".equals(event.getStage())) {
            final OktaUser ou = event.getOktaUser();
            fillAdInfo(ou.getAdInfo(), ou.getDn());
        }
    }

    private void fillAdInfo(AdInfo adInfo, LdapName dn) {
        final AdInfo info = Objects.requireNonNull(adInfo);
        if (info.isRequested()) {
            OktaUser aou = ldapService.findUserByDNDirect(dn.toString());
            info.setDepartment(aou.getDepartment());
            info.setRequested(false);
        }
        Consumer<Collection<AdGroup>> groupConsumer = null;
        if (info.getCurrent().isRequested()) {
            groupConsumer = info::storeCurrentGroups;
        } else if (info.getOriginal().isRequested()) {
            groupConsumer = info::storeOriginalGroups;
        }
        if (groupConsumer != null) {
            groupConsumer.accept(ldapService.findUserGroups(dn));
        }
    }


    private void onDeferred(CoreEvent event) {
        final OktaUser ou = event.getOktaUser();
        if ("linkmanager".equals(event.getStage())) {
            final Manager manager = findManagerService.getManagerByWorkerId(
                    ou.getManagerId(),
                    event.getHrbuConfig(),
                    event.getDomainConfig(),
                    ou.getManagerUserId(), ou.getManagerHrbu(),
                    String.valueOf(ou.getExecutiveDirector()),
                    ou.getExecutiveDirectorUserId(),
                    ou.getExecutiveDirectorHrbu()
            );
            manager.setLinked(true);
            ou.setManagerObject(manager);
            LdapName dn = manager.getUser().getDn();
            ou.setManager(dn);
            ldapService.updateObjectsManager(List.of(ou), dn, LdapEntryType.USER, ACCOUNT_MANAGER);
        } else if ("getManagerForEMail".equals(event.getStage())) {
            final Manager manager = findManagerService.getManagerByDn(
                    ou.getManager(),
                    event.getHrbuConfig(),
                    event.getDomainConfig(),
                    String.valueOf(ou.getExecutiveDirector()),
                    ou.getExecutiveDirectorUserId(),
                    ou.getExecutiveDirectorHrbu(),
                    false
            );
            manager.setForEMail(true);
            ou.setManagerObject(manager);
        }
    }

    private Manager calculateManager(
            final OktaUser current,
            final OktaUser prev,
            final HrbuConfig currentHrbuConfig,
            final HrbuConfig prevHrbuConfig
    ) {
        final String workerId = current.getWorkerId();
        final String sdn = current.getDn().toString();
        OktaUser actualAd = ldapService.findUserByDNDirect(sdn);
        if (actualAd == null) {
            log.warn("#calculateManager: User with dn '{}' not found", VeracodeUtils.encode4java(sdn));
            if (workerId != null) {
                actualAd = ldapService.findUserByWorkerId(workerId);
            }
        }
        if (actualAd == null) {
            throw new RuntimeException("AD User not found: workerId = '" + workerId + "'; dn='" + sdn + "'");
        }
        final LdapName actualMDn = actualAd.getManager();
        final Manager actualManager = findManagerService.getManagerByDn(
                actualMDn,
                prevHrbuConfig,
                Optional.ofNullable(prev.getExecutiveDirector()).map(String::valueOf).orElse(null),
                prev.getExecutiveDirectorUserId(),
                prev.getExecutiveDirectorHrbu(),
                true
        );
        final Manager newManager = findManagerService.getManagerByWorkerId(
                current.getManagerId(),
                currentHrbuConfig,
                current.getManagerUserId(),
                current.getManagerHrbu(),
                Optional.ofNullable(current.getExecutiveDirector()).map(String::valueOf).orElse(null),
                current.getExecutiveDirectorUserId(),
                current.getExecutiveDirectorHrbu()
        );

        final BiConsumer<Manager, Boolean> saver = (m, b) -> {
            m.setLinked(b);
            current.setManagerObject(m);
            final LdapName dn = m.getUser().getDn();
            current.setManager(dn);

            prev.setManagerObject(m);
            prev.setManager(dn);
        };

        if (newManager.isReal() && newManager.getUser().getDn().equals(actualManager.getUser().getDn())) {
            saver.accept(newManager, true);
            return newManager;
        } else {
            saver.accept(actualManager, false);
            return actualManager;
        }

    }

    private OktaUser prepareDns(final OktaUser current) {
        String workerId = current.getWorkerId();
        final OktaUser target = (workerId == null) ? null : ldapService.findUserByWorkerId(workerId);
        if (target == null) {
            throw new RuntimeException("AD User not found: workerId = " + workerId);
        }
        final LdapName dn = target.getDn();
        current.setDn(dn);
        current.setCn(dn.getRdn(dn.size() - 1).getValue().toString());
        final LdapName manager = target.getManager();
        current.setManager(manager);
        return target;
    }

    private AuditEvent.AuditEventBuilder generateEvent(CoreEvent event) {
        return AuditEvent.generateEvent(event).module(getModule()).status("SUCCESS");
    }

    private void onSynchronize(CoreEvent event) {
        if ("start".equals(event.getStage())) {
            OktaUser user = event.getNextOktaUser();

            final OktaUser target = prepareDns(user);

            if (user.getManager() != null) {
                final Manager actualManager = findManagerService.getManagerByDn(
                        user.getManager(),
                        event.getHrbuConfig(),
                        event.getDomainConfig(),
                        Optional.ofNullable(user.getExecutiveDirector()).map(String::valueOf).orElse(null),
                        user.getExecutiveDirectorUserId(),
                        user.getExecutiveDirectorHrbu(),
                        true
                );
                actualManager.setLinked(actualManager.isReal());
                user.setManagerObject(actualManager);
            }

            user.setUserPrincipalName(target.getUserPrincipalName());
            user.setSamAccountName(target.getSamAccountName());
            user.setAccountExpires(target.getAccountExpires());

            final Set<String> existentEmails = target.getProxyAddresses();

            checkEMail(existentEmails, user.getEmailPrimary(), user::setEmailPrimary);
            checkEMail(existentEmails, user.getEmailSecondary(), user::setEmailSecondary);
            checkEMail(existentEmails, user.getEmailSecondaryAdditional(), user::setEmailSecondaryAdditional);

            user.setMail(user.getEmailPrimary());
        }
    }

    @Override
    public void process(SyncCheck message) {
        var oktaUser = message.getUser();
        var user = ldapService.findUserByWorkerId(oktaUser.getWorkerId());
        if (user != null) {
            if (user.getLogonHours() == null) {
                user.setLogonHours(new byte[21]);
                Arrays.fill(user.getLogonHours(), (byte) 0);
            }
            var adUser = CommonUser.builder()
                    .dn(user.getDn().toString())
                    .userPrincipalName(user.getUserPrincipalName())
                    .samAccountName(user.getSamAccountName())
                    .city(user.getCity())
                    .firstName(user.getFirstName())
                    .primaryGroupId(user.getPrimaryGroupId())
                    .mail(user.getMail())
                    .proxyAddresses(user.getProxyAddresses().stream()
                            .map(item -> item.replace("smtp:", "SMTP:"))
                            .sorted().distinct()
                            .collect(Collectors.toList()))
                    .physicalDeliveryOfficeName(user.getPhysicalDeliveryOfficeName())
                    .country(user.getCountry())
                    .lastName(user.getLastName())
                    .cn(user.getCn())
                    .description(user.getDescription())
                    .displayName(user.getDisplayName())
                    .fax(user.getFax())
                    .middleName(user.getMiddleName())
                    .address(user.getStreetAddress())
                    .postalCode(user.getPostalCode())
                    .mobile(user.getMobile())
                    .telephoneNumber(user.getTelephoneNumber())
                    .state(user.getState())
                    .workerType(user.getWorkerType())
                    .title(user.getTitle())
                    .workerId(user.getWorkerId())
                    .postalAddress(user.getPostalAddress())
                    .homeDrive(user.getHomeDrive())
                    .scriptPath(user.getScriptPath())
                    .homeDirectory(user.getHomeDirectory())
                    .msExchRecipientTypeDetails(user.getMsExchRecipientTypeDetails())
                    .company(user.getCompany())
                    .accountExpires(user.getAccountExpires())
                    .terminalServicesProfilePath(user.getTerminalServicesProfilePath())
                    .showInAddressBook(user.getShowInAddressBook().stream().map(LdapName::toString).sorted().collect(Collectors.toList()))
                    .info(user.getInfo())
                    .manager(user.getManager() != null ? user.getManager().toString() : null)
                    .logonHours(Hex.encodeHexString(user.getLogonHours()))
                    .memberOf(Stream.concat(
                                    Stream.of(new CommonGroup("orgUnit", LdapUtils.getParentDN(user.getDn()))),
                                    user.getMemberOf().stream().map(dn -> new CommonGroup("", dn.toString())))
                            .sorted(Comparator.comparing(CommonGroup::getDn))
                            .collect(Collectors.toList()))
                    .build();
            if (!adUser.same(oktaUser)) {
                var auditEvent = AuditEvent.builder()
                        .date(new Date())
                        .app(AuditEvent.Application.PASSPORT)
                        .oktaUserId(message.getOktaUserId())
                        .message("ERROR")
                        .situation("Sync check")
                        .status("ERROR")
                        .module(ModuleEnum.OKTA_CLIENT)
                        .newValues(CommonUser.printDiff(adUser, oktaUser))
                        .build();
                auditService.audit(auditEvent);
            }
        } else {
            var auditEvent = AuditEvent.builder()
                    .date(new Date())
                    .app(AuditEvent.Application.PASSPORT)
                    .oktaUserId(message.getOktaUserId())
                    .message("Cannot find user by workerId: " + oktaUser.getWorkerId())
                    .situation("Sync check")
                    .status("ERROR")
                    .module(ModuleEnum.ACTIVE_DIRECTORY)
                    .build();
            auditService.audit(auditEvent);
        }
    }


    @Value
    @Builder(toBuilder = true)
    @FieldDefaults(level = AccessLevel.PRIVATE)
    @AllArgsConstructor
    @Validated
    public static class GroupModel {
        String name;
        LdapName dn;

        public GroupModel(GroupMappingDto dto) {
            this(dto.getName(), dto.getDn());
        }

        public GroupModel(AdGroup group) {
            this(group.getDisplayName(), group.getDn());
        }
    }
}
