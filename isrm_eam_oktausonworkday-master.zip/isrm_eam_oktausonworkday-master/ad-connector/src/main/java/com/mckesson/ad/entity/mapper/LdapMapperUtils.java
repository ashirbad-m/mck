package com.mckesson.ad.entity.mapper;

import org.mapstruct.Named;

import java.util.Date;

@Named("LdapMappingRules")
public class LdapMapperUtils {

    private static final long DATE_DIFF = 11644473600000L;

    @Named("workerId2String")
    public String workerId2String(final Long value) {
        return value == null ? null : value.toString();
    }

    @Named("workerId2Long")
    public Long workerIdLong(final String value) {
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException nfe) {
            return 0L;
        }
    }

    @Named("long2Date")
    public Date long2Date(final Long value) {
        if (value == null) {
            return null;
        }
        return new Date(value / 10000 - DATE_DIFF);
    }

    @Named("date2Long")
    public Long date2Long(final Date value) {
        if (value == null) {
            return null;
        }
        return (value.getTime() + DATE_DIFF) * 10000;
    }

    @Named("string2Date")
    public Date string2Date(final String value) {
        if (value == null || value.length() < 4) {
            return null;
        }
        try {
            return new Date(Long.parseLong(value.substring(0, value.length() - 4)) - DATE_DIFF);
        } catch (NumberFormatException nfe) {
            return null;
        }
    }

    @Named("date2String")
    public String date2String(final Date value) {
        if (value == null) {
            return null;
        }
        return (value.getTime() + DATE_DIFF) + "0000";
    }

}
