package com.mckesson.ad.repository;

import com.mckesson.ad.entity.AdEntry;
import com.mckesson.common.domain.OktaEntryDto;
import com.mckesson.common.domain.OktaUser;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;
import org.springframework.ldap.control.PagedResultsDirContextProcessor;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.SingleContextSource;
import org.springframework.ldap.odm.core.ObjectDirectoryMapper;
import org.springframework.ldap.query.LdapQuery;

import javax.naming.Name;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.ldap.LdapName;
import javax.validation.constraints.NotNull;
import java.util.LinkedList;
import java.util.List;

import static com.mckesson.ad.repository.LdapEntryType.USER;
import static com.mckesson.common.ldap.LdapUtils.DEF_PAGE_SIZE;
import static com.mckesson.common.workday.converter.ConverterUtils.nullableLdapName;

@Data
@AllArgsConstructor
public class LdapRepository {

    @NonNull
    private final LdapTemplate ldapTemplate;

    @NonNull
    private final String domain;

    @NonNull
    private final LdapName baseDn;

    public Name truncate(@NotNull Name source) {
        return LdapEntryType.truncate(source, baseDn);
    }

    public Name truncate(@NotNull String source) {
        return LdapEntryType.truncate(nullableLdapName(source), baseDn);
    }

    public Name truncateOrNull(@NotNull Name source) {
        return LdapEntryType.truncateOrNull(source, baseDn);
    }

    public Name truncateOrNull(@NotNull String source) {
        return LdapEntryType.truncateOrNull(nullableLdapName(source), baseDn);
    }

    public <E extends AdEntry, D extends OktaEntryDto> D create(@NonNull final D dto, @NonNull final LdapEntryType<E, D> type) {
        E e = type.map2Entry(dto, baseDn);
        E newE = SingleContextSource.doWithSingleContext(ldapTemplate.getContextSource(), operations -> {
            final ObjectDirectoryMapper odm = operations.getObjectDirectoryMapper();
            Name id = odm.getId(e);
            DirContextAdapter context = new DirContextAdapter(id);
            odm.mapToLdapDataEntry(e, context);
            operations.bind(context);
            return type.lookup(ldapTemplate, operations, id);
        });
        return type.map2Dto(newE, domain, baseDn);
    }

    public <E extends AdEntry, D extends OktaEntryDto> D update(@NonNull final D dto, @NonNull final LdapEntryType<E, D> type) {
        E e = type.map2Entry(dto, baseDn);
        ldapTemplate.update(e);
        E newE = type.lookup(ldapTemplate, truncate(dto.getDn()));
        return type.map2Dto(newE, domain, baseDn);
    }

    public <E extends AdEntry, D extends OktaEntryDto> D modifyAttributes(@NonNull final D dto, @NonNull ModificationItem[] items, @NonNull final LdapEntryType<E, D> type) {
        Name relative = truncate(dto.getDn());
        ldapTemplate.modifyAttributes(relative, items);
        E newE = type.lookup(ldapTemplate, relative);
        return type.map2Dto(newE, domain, baseDn);
    }

    public <E extends AdEntry, D extends OktaEntryDto> void delete(@NonNull final D dto, @NonNull final LdapEntryType<E, D> type) {
        ldapTemplate.delete(type.map2Entry(dto, baseDn));
    }

    public <E extends AdEntry, D extends OktaEntryDto> List<D> find(@NonNull final LdapQuery query, @NonNull final LdapEntryType<E, D> type) {
        final SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        final PagedResultsDirContextProcessor processor = new PagedResultsDirContextProcessor(DEF_PAGE_SIZE);

        List<E> entries = SingleContextSource.doWithSingleContext(
                ldapTemplate.getContextSource(),
                operations -> {
                    List<E> result = new LinkedList<>();

                    do {
                        List<E> oneResult = operations.search(
                                query.base(),
                                type.completeFilter(query.filter()),
                                searchControls,
                                type.getMapper(ldapTemplate),
                                processor);
                        result.addAll(oneResult);
                    } while (processor.hasMore());

                    return result;
                }, true, true, false);

        return type.map2DtoList(entries, domain, baseDn);
    }

    public OktaUser authenticate(@NonNull final LdapQuery query, String password) {
        return USER.map2Dto(
                ldapTemplate.authenticate(query, password, (ctx, identification) -> USER.lookup(ldapTemplate, identification.getRelativeName())),
                domain, baseDn);
    }

    public <E extends AdEntry, D extends OktaEntryDto> D findSingle(@NonNull final LdapQuery query, @NonNull final LdapEntryType<E, D> type) {
        return type.map2Dto(ldapTemplate.findOne(query, type.getClazz()), domain, baseDn);
    }

    public <E extends AdEntry, D extends OktaEntryDto> D findByDn(@NonNull final Name dn, @NonNull final LdapEntryType<E, D> type) {
        return type.map2Dto(ldapTemplate.findByDn(truncate(dn), type.getClazz()), domain, baseDn);
    }

    public <E extends AdEntry, D extends OktaEntryDto> D changeDn(@NonNull final D dto, @NonNull Name newDn, @NonNull final LdapEntryType<E, D> type) {
        Name newTruncated = truncate(newDn);
        ldapTemplate.rename(truncate(dto.getDn()), newTruncated);
        E newE = type.lookup(ldapTemplate, newTruncated);
        return type.map2Dto(newE, domain, baseDn);
    }

    /*
    @SneakyThrows(NamingException.class)
    public <T> Set<T> getLargeValue(@NonNull final Name dn, @NotNull final String attributeName, @NotNull final Function<Object, T> mapper) {
        final Attributes result = DefaultIncrementalAttributesMapper.lookupAttributes(ldapTemplate, truncate(dn), new String[]{attributeName});
        Attribute attribute;
        Enumeration<?> values;
        if (
                (attribute = result.get(attributeName)) == null ||
                        (values = attribute.getAll()) == null
        ) {
            return ImmutableSet.of();
        }
        return Collections.list(values).stream().filter(Objects::nonNull).map(mapper).collect(Collectors.toSet());
    }*/
}
