package com.mckesson.ad.config;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * Contains list of LDAP servers
 */
@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "domains.ldap", ignoreUnknownFields = false)
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class LdapDomainConfiguration {
    private List<LdapServer> nodes;

    public LdapServer getServer(final String domain) {
        return nodes.stream().filter(node -> node.isEnabled() && node.getDomain().equalsIgnoreCase(domain)).findFirst()
                .orElseThrow(() -> new RuntimeException("Ldap Server Configuration not found for domain = " + domain + ", please check configuration service"));
    }
}