package com.mckesson.ad.service;

import com.mckesson.common.domain.Manager;
import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.HrbuConfig;
import com.mckesson.common.model.WorkdayConfig;
import lombok.NonNull;

import javax.naming.ldap.LdapName;

/**
 * Defines interface to find manager
 */
public interface FindManagerService {

    /**
     * Finds manager
     *
     * @param wdUserHRBUConfig           Workday user HRBU config
     * @param adUserHRBUConfig           AD user HRBU config
     * @param wdManagerWorkerId          Workday manager worker ID
     * @param wdManagerUserId            Workday manager user ID
     * @param wdManagerHrbu              Workday manager HRBU
     * @param adManagerDn                AD manager DN
     * @param wdExecutiveDirectorWokerId Workday executive director Worker ID
     * @param wdExecutiveDirectorUserId  Workday executive director User ID
     * @param wdExecutiveDirectorHrbu    Workday executive director HRBU
     * @param findNewManager             find new manager
     * @param includeTerminations        include terminations
     * @return found manager or null
     */
    Manager findManager(final HrbuConfig wdUserHRBUConfig, final HrbuConfig adUserHRBUConfig,
                        final String wdManagerWorkerId, final String wdManagerUserId, final String wdManagerHrbu,
                        final String adManagerDn,
                        final String wdExecutiveDirectorWokerId, final String wdExecutiveDirectorUserId, final String wdExecutiveDirectorHrbu,
                        final boolean findNewManager,
                        final boolean includeTerminations
    );

    /**
     * Finds manager by DN
     *
     * @param managerDn                 manager DN
     * @param hrbu                      HRBU value
     * @param city                      city
     * @param address                   address
     * @param executiveDirectorWorkerId executive director Worker ID
     * @param executiveDirectorUserId   executive director User ID
     * @param executiveDirectorHrbu     executive director HRBU
     * @param includeTerminations       include terminations
     * @return found manager or throws exception
     */
    @NonNull
    Manager getManagerByDn(
            LdapName managerDn,
            @NonNull String hrbu, String city, String address,
            String executiveDirectorWorkerId, String executiveDirectorUserId, String executiveDirectorHrbu,
            boolean includeTerminations
    );

    /**
     * Finds manager by DN
     *
     * @param managerDn                 manager DN
     * @param hrbuConfig                HRBU config
     * @param executiveDirectorWorkerId executive director Worker ID
     * @param executiveDirectorUserId   executive director User ID
     * @param executiveDirectorHrbu     executive director HRBU
     * @param includeTerminations       include terminations
     * @return found manager or throws exception
     */
    @NonNull
    Manager getManagerByDn(
            LdapName managerDn,
            @NonNull HrbuConfig hrbuConfig,
            String executiveDirectorWorkerId, String executiveDirectorUserId, String executiveDirectorHrbu,
            boolean includeTerminations
    );

    /**
     * Finds manager by DN
     *
     * @param managerDn                 manager DN
     * @param hrbuConfig                HRBU config
     * @param domainConfig              domain config
     * @param executiveDirectorWorkerId executive director Worker ID
     * @param executiveDirectorUserId   executive director User ID
     * @param executiveDirectorHrbu     executive director HRBU
     * @param includeTerminations       include terminations
     * @return found manager or throws exception
     */
    @NonNull
    Manager getManagerByDn(
            LdapName managerDn,
            @NonNull HrbuConfig hrbuConfig,
            @NonNull DomainConfig domainConfig,
            String executiveDirectorWorkerId, String executiveDirectorUserId, String executiveDirectorHrbu,
            boolean includeTerminations
    );

    /**
     * Finds manager by DN
     *
     * @param managerDn                 manager DN
     * @param hrbuConfig                HRBU config
     * @param domainConfig              domain config
     * @param workdayConfig             workday config
     * @param executiveDirectorWorkerId executive director Worker ID
     * @param executiveDirectorUserId   executive director User ID
     * @param executiveDirectorHrbu     executive director HRBU
     * @param includeTerminations       include terminations
     * @return found manager or throws exception
     */
    @NonNull
    Manager getManagerByDn(
            LdapName managerDn,
            @NonNull HrbuConfig hrbuConfig,
            @NonNull DomainConfig domainConfig,
            @NonNull WorkdayConfig workdayConfig,
            String executiveDirectorWorkerId, String executiveDirectorUserId, String executiveDirectorHrbu,
            boolean includeTerminations
    );

    /**
     * Finds manager by Worker ID
     *
     * @param managerWorkerId           manager Worker ID
     * @param hrbu                      HRBU value
     * @param city                      city
     * @param address                   address
     * @param managerUserId             manager user ID
     * @param managerHrbu               manager HRBU
     * @param executiveDirectorWorkerId executive director Worker ID
     * @param executiveDirectorUserId   executive director User ID
     * @param executiveDirectorHrbu     executive director HRBU
     * @return found manager or throws exception
     */
    @NonNull
    Manager getManagerByWorkerId(
            String managerWorkerId,
            @NonNull String hrbu, String city, String address,
            String managerUserId, String managerHrbu,
            String executiveDirectorWorkerId, String executiveDirectorUserId, String executiveDirectorHrbu
    );

    /**
     * Finds manager by Worker ID
     *
     * @param managerWorkerId           manager Worker ID
     * @param hrbuConfig                HRBU config
     * @param managerUserId             manager user ID
     * @param managerHrbu               manager HRBU
     * @param executiveDirectorWorkerId executive director Worker ID
     * @param executiveDirectorUserId   executive director User ID
     * @param executiveDirectorHrbu     executive director HRBU
     * @return found manager or throws exception
     */
    @NonNull
    Manager getManagerByWorkerId(
            String managerWorkerId,
            @NonNull HrbuConfig hrbuConfig,
            String managerUserId, String managerHrbu,
            String executiveDirectorWorkerId, String executiveDirectorUserId, String executiveDirectorHrbu
    );

    /**
     * Finds manager by Worker ID
     *
     * @param managerWorkerId           manager Worker ID
     * @param hrbuConfig                HRBU config
     * @param domainConfig              domain config
     * @param managerUserId             manager user ID
     * @param managerHrbu               manager HRBU
     * @param executiveDirectorWorkerId executive director Worker ID
     * @param executiveDirectorUserId   executive director User ID
     * @param executiveDirectorHrbu     executive director HRBU
     * @return found manager or throws exception
     */
    @NonNull
    Manager getManagerByWorkerId(
            String managerWorkerId,
            @NonNull HrbuConfig hrbuConfig,
            @NonNull DomainConfig domainConfig,
            String managerUserId, String managerHrbu,
            String executiveDirectorWorkerId, String executiveDirectorUserId, String executiveDirectorHrbu
    );

    /**
     * Finds manager by Worker ID
     *
     * @param managerWorkerId           manager Worker ID
     * @param hrbuConfig                HRBU config
     * @param domainConfig              domain config
     * @param workdayConfig             workday config
     * @param managerUserId             manager user ID
     * @param managerHrbu               manager HRBU
     * @param executiveDirectorWorkerId executive director Worker ID
     * @param executiveDirectorUserId   executive director User ID
     * @param executiveDirectorHrbu     executive director HRBU
     * @return found manager or throws exception
     */
    @NonNull
    Manager getManagerByWorkerId(
            String managerWorkerId,
            @NonNull HrbuConfig hrbuConfig,
            @NonNull DomainConfig domainConfig,
            @NonNull WorkdayConfig workdayConfig,
            String managerUserId, String managerHrbu,
            String executiveDirectorWorkerId, String executiveDirectorUserId, String executiveDirectorHrbu
    );
}
