package com.mckesson.ad.actuate;

import com.mckesson.ad.config.LdapDomainConfiguration;
import com.mckesson.ad.config.LdapServer;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.boot.actuate.ldap.LdapHealthIndicator;
import org.springframework.ldap.core.LdapOperations;

import java.util.Arrays;

class AdHealthIndicatorTest {

    @Test
    void doHealthCheck() {
        LdapDomainConfiguration config = Mockito.mock(LdapDomainConfiguration.class);

        LdapServer node1 = new LdapServer();
        node1.setEnabled(false);
        node1.setDomain("domain1");
        node1.setUrl("url1");
        node1.setUser("user1");
        node1.setPassword("password1");
        node1.setBaseDn("DC=uson,DC=pkicorp,DC=pkimck,DC=com");
        node1.setReferral("referral1");
        LdapServer node2 = new LdapServer();
        node2.setEnabled(true);
        node2.setDomain("domain2");
        node2.setUrl("url2");
        node2.setUser("user2");
        node2.setPassword("password2");
        node2.setBaseDn("baseDC=uson,DC=pkicorp,DC=pkimck,DC=comDn2");
        node2.setReferral("referral2");
        Mockito.when(config.getNodes()).thenReturn(Arrays.asList(node1, node2));

        AdHealthIndicator instance = new AdHealthIndicator(config) {
            @Override
            protected LdapHealthIndicator createLdapHealthIndicator(LdapOperations ldapOperations) {
                return new LdapHealthIndicator(ldapOperations) {
                    @Override
                    protected void doHealthCheck(Health.Builder builder) throws Exception {
                        builder.down().withDetail("version", "1");
                    }
                };
            }
        };

        Health health = instance.health();
        Assertions.assertEquals(Status.DOWN, health.getStatus());
        var details = health.getDetails();
        Assertions.assertEquals(1, details.size());
        Assertions.assertEquals("DOWN {version=1}", details.get("domain2 (url2)").toString());


        instance = new AdHealthIndicator(config) {
            @Override
            protected LdapHealthIndicator createLdapHealthIndicator(LdapOperations ldapOperations) {
                return new LdapHealthIndicator(ldapOperations) {
                    @Override
                    protected void doHealthCheck(Health.Builder builder) throws Exception {
                        builder.up().withDetail("version", "1");
                    }
                };
            }
        };

        health = instance.health();
        Assertions.assertEquals(Status.UP, health.getStatus());
        details = health.getDetails();
        Assertions.assertEquals(1, details.size());
        Assertions.assertEquals("UP {version=1}", details.get("domain2 (url2)").toString());


        node1.setEnabled(false);
        node2.setEnabled(false);
        instance = new AdHealthIndicator(config) {
            @Override
            protected LdapHealthIndicator createLdapHealthIndicator(LdapOperations ldapOperations) {
                return new LdapHealthIndicator(ldapOperations) {
                    @Override
                    protected void doHealthCheck(Health.Builder builder) throws Exception {
                        builder.up().withDetail("version", "1");
                    }
                };
            }
        };
        health = instance.health();
        Assertions.assertEquals(Status.OUT_OF_SERVICE, health.getStatus());
        Assertions.assertTrue(health.getDetails().isEmpty());
    }
}