package com.mckesson.ad.service;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class LoginParserServiceTest {

    @Test
    void getPrefix() {
        var instance = new LoginParserService();
        Assertions.assertEquals(StringUtils.EMPTY, instance.getPrefix("test"));
        Assertions.assertEquals("labad", instance.getPrefix("labad\\test"));
        Assertions.assertEquals("labad_1-2", instance.getPrefix("labad_1-2\\test_1.domain"));
    }

    @Test
    void getDomain() {
        var instance = new LoginParserService();
        Assertions.assertEquals(StringUtils.EMPTY, instance.getDomain("test"));
        Assertions.assertEquals("labad", instance.getDomain("test@labad"));
        Assertions.assertEquals("labad_1.com", instance.getDomain("test_1.domain@labad_1.com"));
    }

    @Test
    void getLogin() {
        var instance = new LoginParserService();
        Assertions.assertEquals(StringUtils.EMPTY, instance.getLogin("test"));
        Assertions.assertEquals("test", instance.getLogin("labad\\test"));
        Assertions.assertEquals("test_1.domain", instance.getLogin("labad_1-2\\test_1.domain"));

        Assertions.assertEquals("test", instance.getLogin("test@labad"));
        Assertions.assertEquals("test_1.domain", instance.getLogin("test_1.domain@labad_1.com"));
    }
}