package com.mckesson.ad.config;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;

class LdapDomainConfigurationTest {

    @Test
    void getServer() {
        var instance = new LdapDomainConfiguration();

        try {
            instance.getServer("domain1");
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
        }

        instance.setNodes(Collections.emptyList());
        try {
            instance.getServer("domain1");
            Assertions.fail("Wrong behavior");
        } catch (RuntimeException ex) {
            Assertions.assertEquals("Ldap Server Configuration not found for domain = domain1, please check configuration service", ex.getMessage());
        }

        LdapServer node1 = new LdapServer();
        node1.setEnabled(false);
        node1.setDomain("domain1");
        node1.setUrl("url1");
        node1.setUser("user1");
        node1.setPassword("password1");
        node1.setBaseDn("DC=uson,DC=pkicorp,DC=pkimck,DC=com");
        node1.setReferral("referral1");
        LdapServer node2 = new LdapServer();
        node2.setEnabled(true);
        node2.setDomain("domain2");
        node2.setUrl("url2");
        node2.setUser("user2");
        node2.setPassword("password2");
        node2.setBaseDn("baseDC=uson,DC=pkicorp,DC=pkimck,DC=comDn2");
        node2.setReferral("referral2");
        instance.setNodes(Arrays.asList(node1, node2));
        try {
            instance.getServer("domain1");
            Assertions.fail("Wrong behavior");
        } catch (RuntimeException ex) {
            Assertions.assertEquals("Ldap Server Configuration not found for domain = domain1, please check configuration service", ex.getMessage());
        }

        Assertions.assertEquals(node2, instance.getServer("domain2"));
    }
}