package com.mckesson.ad.repository;

import com.mckesson.ad.entity.AdUserEntry;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.ldap.core.*;
import org.springframework.ldap.odm.core.ObjectDirectoryMapper;
import org.springframework.ldap.query.LdapQueryBuilder;

import javax.naming.InvalidNameException;
import javax.naming.Name;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;
import javax.naming.ldap.Control;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.LdapName;
import javax.naming.ldap.PagedResultsResponseControl;
import java.util.Arrays;
import java.util.Iterator;
import java.util.UUID;

import static com.mckesson.ad.repository.LdapEntryType.USER;
import static com.mckesson.common.ldap.LdapUtils.*;
import static com.mckesson.common.workday.converter.ConverterUtils.nullableLdapName;

class LdapRepositoryTest {

    @Test
    void truncate() throws InvalidNameException {

        var ldapTemplate = new LdapTemplate();
        String domain = "domain";
        var baseDn = new LdapName("OU=B2E_Workday,DC=mshusontest,DC=com");
        var instance = new LdapRepository(ldapTemplate, domain, baseDn);

        try {
            instance.truncate("null");
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
            Assertions.assertEquals("source is marked non-null but is null", ex.getMessage());
        }

        var source = "OU=MSHPS,OU=B2E_Workday,DC=mshusontest,DC=com";
        Assertions.assertEquals("OU=MSHPS", instance.truncate(source).toString());
        source = "OU=MSHPS,OU=B2E_Workday,DC=mshusontest2,DC=com";
        Assertions.assertEquals(source, instance.truncate(source).toString());

        var ldapName = new LdapName("OU=MSHPS,OU=B2E_Workday,DC=mshusontest,DC=com");
        Assertions.assertEquals("OU=MSHPS", instance.truncate(ldapName).toString());
        ldapName = new LdapName("OU=MSHPS,OU=B2E_Workday,DC=mshusontest2,DC=com");
        Assertions.assertEquals(ldapName, instance.truncate(ldapName));
    }

    @Test
    void truncateOrNull() throws InvalidNameException {
        var ldapTemplate = new LdapTemplate();
        String domain = "domain";
        var baseDn = new LdapName("OU=B2E_Workday,DC=mshusontest,DC=com");
        var instance = new LdapRepository(ldapTemplate, domain, baseDn);

        try {
            instance.truncateOrNull("null");
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
            Assertions.assertEquals("source is marked non-null but is null", ex.getMessage());
        }

        var source = "OU=MSHPS,OU=B2E_Workday,DC=mshusontest,DC=com";
        Assertions.assertEquals("OU=MSHPS", instance.truncateOrNull(source).toString());
        source = "OU=MSHPS,OU=B2E_Workday,DC=mshusontest2,DC=com";
        Assertions.assertNull(instance.truncateOrNull(source));

        var ldapName = new LdapName("OU=MSHPS,OU=B2E_Workday,DC=mshusontest,DC=com");
        Assertions.assertEquals("OU=MSHPS", instance.truncateOrNull(ldapName).toString());
        ldapName = new LdapName("OU=MSHPS,OU=B2E_Workday,DC=mshusontest2,DC=com");
        Assertions.assertNull(instance.truncateOrNull(ldapName));
    }


    @Test
    void update() throws InvalidNameException {
        var ldapTemplate = Mockito.mock(LdapTemplate.class);
        String domain = "domain 1001";
        var baseDn = new LdapName("OU=B2E_Workday,DC=mshusontest,DC=com");
        var instance = new LdapRepository(ldapTemplate, domain, baseDn);

        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        var user = LdapEntryType.USER.map2Entry(userDto, baseDn);
        Mockito.when(ldapTemplate.lookup(Mockito.any(Name.class), Mockito.any(ContextMapper.class))).thenReturn(user);
        Assertions.assertEquals(userDto, instance.update(userDto, LdapEntryType.USER));
        Mockito.verify(ldapTemplate).update(Mockito.refEq(user));

        var groupDto = LdapRepositorySpringTest.adGroupGenerator.apply(1);
        var group = LdapEntryType.GROUP.map2Entry(groupDto, baseDn);
        Mockito.when(ldapTemplate.lookup(Mockito.any(Name.class), Mockito.any(ContextMapper.class))).thenReturn(group);
        Assertions.assertEquals(groupDto, instance.update(groupDto, LdapEntryType.GROUP));
        Mockito.verify(ldapTemplate).update(Mockito.refEq(group));

        var serverDto = LdapRepositorySpringTest.adServerGenerator.apply(1);
        var server = LdapEntryType.SERVER.map2Entry(serverDto, baseDn);
        Mockito.when(ldapTemplate.lookup(Mockito.any(Name.class), Mockito.any(ContextMapper.class))).thenReturn(server);
        Assertions.assertEquals(serverDto, instance.update(serverDto, LdapEntryType.SERVER));
        Mockito.verify(ldapTemplate).update(Mockito.refEq(server));
    }

    @Test
    void modifyAttributes() throws InvalidNameException {
        var ldapTemplate = Mockito.mock(LdapTemplate.class);
        String domain = "domain 1001";
        var baseDn = new LdapName("OU=B2E_Workday,DC=mshusontest,DC=com");
        var instance = new LdapRepository(ldapTemplate, domain, baseDn);

        var managerDn = nullableLdapName("CN=UserTest11,OU=Users,OU=MSHPS,OU=B2E_Workday,DC=mshusontest,DC=com");

        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        userDto.setManager(managerDn);
        var user = LdapEntryType.USER.map2Entry(userDto, baseDn);
        Mockito.when(ldapTemplate.lookup(Mockito.any(Name.class), Mockito.any(ContextMapper.class))).thenReturn(user);
        Assertions.assertEquals(userDto, instance.modifyAttributes(userDto, new ModificationItem[]{new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute(ACCOUNT_MANAGER, managerDn.toString()))}, LdapEntryType.USER));
        Mockito.verify(ldapTemplate).modifyAttributes(Mockito.eq(user.getDn()), Mockito.any());

        var groupDto = LdapRepositorySpringTest.adGroupGenerator.apply(1);
        groupDto.setManagedBy(managerDn);
        var group = LdapEntryType.GROUP.map2Entry(groupDto, baseDn);
        Mockito.when(ldapTemplate.lookup(Mockito.any(Name.class), Mockito.any(ContextMapper.class))).thenReturn(group);
        Assertions.assertEquals(groupDto, instance.modifyAttributes(groupDto, new ModificationItem[]{new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute(GROUP_COMPUTER_MANAGER, managerDn.toString()))}, LdapEntryType.GROUP));
        Mockito.verify(ldapTemplate).modifyAttributes(Mockito.eq(group.getDn()), Mockito.any());

        var serverDto = LdapRepositorySpringTest.adServerGenerator.apply(1);
        serverDto.setManagedBy(managerDn);
        var server = LdapEntryType.SERVER.map2Entry(serverDto, baseDn);
        Mockito.when(ldapTemplate.lookup(Mockito.any(Name.class), Mockito.any(ContextMapper.class))).thenReturn(server);
        Assertions.assertEquals(serverDto, instance.modifyAttributes(serverDto, new ModificationItem[]{new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute(GROUP_COMPUTER_MANAGER, managerDn.toString()))}, LdapEntryType.SERVER));
        Mockito.verify(ldapTemplate).modifyAttributes(Mockito.eq(server.getDn()), Mockito.any());
    }

    @Test
    void delete() throws InvalidNameException {
        var ldapTemplate = Mockito.mock(LdapTemplate.class);
        String domain = "domain 1001";
        var baseDn = new LdapName("OU=B2E_Workday,DC=mshusontest,DC=com");
        var instance = new LdapRepository(ldapTemplate, domain, baseDn);

        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        var user = LdapEntryType.USER.map2Entry(userDto, baseDn);
        instance.delete(userDto, LdapEntryType.USER);
        Mockito.verify(ldapTemplate).delete(Mockito.eq(user));

        var groupDto = LdapRepositorySpringTest.adGroupGenerator.apply(1);
        var group = LdapEntryType.GROUP.map2Entry(groupDto, baseDn);
        instance.delete(groupDto, LdapEntryType.GROUP);
        Mockito.verify(ldapTemplate).delete(Mockito.eq(group));

        var serverDto = LdapRepositorySpringTest.adServerGenerator.apply(1);
        var server = LdapEntryType.SERVER.map2Entry(serverDto, baseDn);
        instance.delete(serverDto, LdapEntryType.SERVER);
        Mockito.verify(ldapTemplate).delete(Mockito.eq(server));
    }

    @Test
    void findSingle() throws InvalidNameException {
        var ldapTemplate = Mockito.mock(LdapTemplate.class);
        String domain = "domain 1001";
        var baseDn = new LdapName("OU=B2E_Workday,DC=mshusontest,DC=com");
        var instance = new LdapRepository(ldapTemplate, domain, baseDn);

        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        userDto.setUid(UUID.randomUUID().toString());
        var user = LdapEntryType.USER.map2Entry(userDto, baseDn);
        var guidQuery = LdapQueryBuilder.query().filter(String.format("(%s=%s)", OBJECT_GUID, getGuidForSearch(userDto.getUid())));
        Mockito.when(ldapTemplate.findOne(Mockito.eq(guidQuery), Mockito.eq(LdapEntryType.USER.getClazz()))).thenReturn(user);
        Assertions.assertEquals(userDto, instance.findSingle(guidQuery, LdapEntryType.USER));

        var groupDto = LdapRepositorySpringTest.adGroupGenerator.apply(1);
        groupDto.setUid(UUID.randomUUID().toString());
        var group = LdapEntryType.GROUP.map2Entry(groupDto, baseDn);
        guidQuery = LdapQueryBuilder.query().filter(String.format("(%s=%s)", OBJECT_GUID, getGuidForSearch(groupDto.getUid())));
        Mockito.when(ldapTemplate.findOne(Mockito.eq(guidQuery), Mockito.eq(LdapEntryType.GROUP.getClazz()))).thenReturn(group);
        Assertions.assertEquals(groupDto, instance.findSingle(guidQuery, LdapEntryType.GROUP));

        var serverDto = LdapRepositorySpringTest.adServerGenerator.apply(1);
        serverDto.setUid(UUID.randomUUID().toString());
        var server = LdapEntryType.SERVER.map2Entry(serverDto, baseDn);
        guidQuery = LdapQueryBuilder.query().filter(String.format("(%s=%s)", OBJECT_GUID, getGuidForSearch(serverDto.getUid())));
        Mockito.when(ldapTemplate.findOne(Mockito.eq(guidQuery), Mockito.eq(LdapEntryType.SERVER.getClazz()))).thenReturn(server);
        Assertions.assertEquals(serverDto, instance.findSingle(guidQuery, LdapEntryType.SERVER));
    }

    @Test
    void findByDn() throws InvalidNameException {
        var ldapTemplate = Mockito.mock(LdapTemplate.class);
        String domain = "domain 1001";
        var baseDn = new LdapName("OU=B2E_Workday,DC=mshusontest,DC=com");
        var instance = new LdapRepository(ldapTemplate, domain, baseDn);

        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        var user = LdapEntryType.USER.map2Entry(userDto, baseDn);
        Mockito.when(ldapTemplate.findByDn(Mockito.eq(instance.truncate(userDto.getDn())), Mockito.eq(LdapEntryType.USER.getClazz()))).thenReturn(user);
        Assertions.assertEquals(userDto, instance.findByDn(user.getDn(), LdapEntryType.USER));

        var groupDto = LdapRepositorySpringTest.adGroupGenerator.apply(1);
        var group = LdapEntryType.GROUP.map2Entry(groupDto, baseDn);
        Mockito.when(ldapTemplate.findByDn(Mockito.eq(instance.truncate(groupDto.getDn())), Mockito.eq(LdapEntryType.GROUP.getClazz()))).thenReturn(group);
        Assertions.assertEquals(groupDto, instance.findByDn(groupDto.getDn(), LdapEntryType.GROUP));

        var serverDto = LdapRepositorySpringTest.adServerGenerator.apply(1);
        var server = LdapEntryType.SERVER.map2Entry(serverDto, baseDn);
        Mockito.when(ldapTemplate.findByDn(Mockito.eq(instance.truncate(serverDto.getDn())), Mockito.eq(LdapEntryType.SERVER.getClazz()))).thenReturn(server);
        Assertions.assertEquals(serverDto, instance.findByDn(serverDto.getDn(), LdapEntryType.SERVER));
    }

    @Test
    void changeDn() throws InvalidNameException {
        var ldapTemplate = Mockito.mock(LdapTemplate.class);
        String domain = "domain 1001";
        var baseDn = new LdapName("OU=B2E_Workday,DC=mshusontest,DC=com");
        var instance = new LdapRepository(ldapTemplate, domain, baseDn);

        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        userDto.setCn("UserTest1");
        var newDn = new LdapName("CN=UserTest2,OU=Users,OU=MSHPS,OU=B2E_Workday,DC=mshusontest,DC=com");
        var expectedUser = LdapEntryType.USER.map2Entry(userDto, baseDn).builder().dn(newDn).cn("UserTest1").build();
        var expectedDto = LdapEntryType.USER.map2Dto(expectedUser, domain, baseDn);

        Mockito.when(ldapTemplate.lookup(Mockito.eq(instance.truncate(newDn)), Mockito.any(ContextMapper.class))).thenReturn(expectedUser);

        var actual = instance.changeDn(userDto, newDn, LdapEntryType.USER);
        Assertions.assertEquals(expectedDto, actual);

        Mockito.verify(ldapTemplate).rename(Mockito.eq(instance.truncate(userDto.getDn())), Mockito.eq(instance.truncate(newDn)));
    }

    @Test
    void authenticate() throws InvalidNameException {
        var ldapTemplate = Mockito.mock(LdapTemplate.class);
        String domain = "domain 1001";
        var baseDn = new LdapName("OU=B2E_Workday,DC=mshusontest,DC=com");
        var instance = new LdapRepository(ldapTemplate, domain, baseDn);
        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        var query = LdapQueryBuilder.query().where(SAM_ACCOUNT_NAME).is(userDto.getSamAccountName());
        var pwd = UUID.randomUUID().toString();
        var dirContext = Mockito.mock(DirContext.class);
        var ldapEntryIdentification = Mockito.mock(LdapEntryIdentification.class);
        var relativeName = userDto.getDn();
        Mockito.when(ldapEntryIdentification.getRelativeName()).thenReturn(relativeName);
        var user = LdapEntryType.USER.map2Entry(userDto, baseDn);
        Mockito.when(ldapTemplate.lookup(Mockito.eq(relativeName), Mockito.any(ContextMapper.class))).thenReturn(user);

        Mockito.when(ldapTemplate.authenticate(Mockito.eq(query), Mockito.eq(pwd), Mockito.any(AuthenticatedLdapEntryContextMapper.class))).thenAnswer(invocation -> ((AuthenticatedLdapEntryContextMapper<AdUserEntry>) invocation.getArgument(2)).mapWithContext(dirContext, ldapEntryIdentification));
        Assertions.assertNotNull(ldapTemplate.authenticate(query, pwd, (ctx, identification) -> USER.lookup(ldapTemplate, identification.getRelativeName())));
        Assertions.assertEquals(userDto, instance.authenticate(query, pwd));
    }

    @Test
    void create() throws NamingException {
        var ldapTemplate = Mockito.mock(LdapTemplate.class);
        String domain = "domain 1001";
        var baseDn = new LdapName("OU=B2E_Workday,DC=mshusontest,DC=com");
        var instance = new LdapRepository(ldapTemplate, domain, baseDn);

        var ctx = Mockito.mock(DirContextOperations.class);
        var readWriteContext = Mockito.mock(DirContext.class);
        var contextSource = Mockito.mock(ContextSource.class);
        Mockito.when(contextSource.getReadWriteContext()).thenReturn(readWriteContext);
        Mockito.when(ldapTemplate.getContextSource()).thenReturn(contextSource);
        var objectDirectoryMapper = Mockito.mock(ObjectDirectoryMapper.class);
        Mockito.when(ldapTemplate.getObjectDirectoryMapper()).thenReturn(objectDirectoryMapper);

        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        var user = LdapEntryType.USER.map2Entry(userDto, baseDn);
        Mockito.when(readWriteContext.lookup(Mockito.eq(instance.truncate(userDto.getDn())))).thenReturn(ctx);
        Mockito.when(objectDirectoryMapper.mapFromLdapDataEntry(Mockito.eq(ctx), Mockito.eq(LdapEntryType.USER.getClazz()))).thenReturn(user);
        Mockito.when(ldapTemplate.lookup(Mockito.eq(instance.truncate(userDto.getDn())), Mockito.any(ContextMapper.class))).thenReturn(null);
        Assertions.assertEquals(userDto, instance.create(userDto, LdapEntryType.USER));

        var groupDto = LdapRepositorySpringTest.adGroupGenerator.apply(1);
        var group = LdapEntryType.GROUP.map2Entry(groupDto, baseDn);
        Mockito.when(readWriteContext.lookup(Mockito.eq(instance.truncate(groupDto.getDn())))).thenReturn(ctx);
        Mockito.when(objectDirectoryMapper.mapFromLdapDataEntry(Mockito.eq(ctx), Mockito.eq(LdapEntryType.GROUP.getClazz()))).thenReturn(group);
        Mockito.when(ldapTemplate.lookup(Mockito.eq(instance.truncate(groupDto.getDn())), Mockito.any(ContextMapper.class))).thenReturn(null);
        Assertions.assertEquals(groupDto, instance.create(groupDto, LdapEntryType.GROUP));

        var serverDto = LdapRepositorySpringTest.adServerGenerator.apply(1);
        var server = LdapEntryType.SERVER.map2Entry(serverDto, baseDn);
        Mockito.when(readWriteContext.lookup(Mockito.eq(instance.truncate(serverDto.getDn())))).thenReturn(ctx);
        Mockito.when(objectDirectoryMapper.mapFromLdapDataEntry(Mockito.eq(ctx), Mockito.eq(LdapEntryType.SERVER.getClazz()))).thenReturn(server);
        Mockito.when(ldapTemplate.lookup(Mockito.eq(instance.truncate(serverDto.getDn())), Mockito.any(ContextMapper.class))).thenReturn(null);
        Assertions.assertEquals(serverDto, instance.create(serverDto, LdapEntryType.SERVER));
    }

    @Test
    void find() throws Exception {
        var ldapTemplate = Mockito.mock(LdapTemplate.class);
        String domain = "domain 1001";
        var baseDn = new LdapName("OU=B2E_Workday,DC=mshusontest,DC=com");
        var instance = new LdapRepository(ldapTemplate, domain, baseDn);

        var ctx = Mockito.mock(DirContextOperations.class);
        var readOnlyContext = Mockito.mock(LdapContext.class);
        var contextSource = Mockito.mock(ContextSource.class);
        Mockito.when(contextSource.getReadOnlyContext()).thenReturn(readOnlyContext);
        Mockito.when(ldapTemplate.getContextSource()).thenReturn(contextSource);
        var objectDirectoryMapper = Mockito.mock(ObjectDirectoryMapper.class);
        Mockito.when(ldapTemplate.getObjectDirectoryMapper()).thenReturn(objectDirectoryMapper);

        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        userDto.setUid(UUID.randomUUID().toString());
        var user = LdapEntryType.USER.map2Entry(userDto, baseDn);
        var query = LdapQueryBuilder.query().filter(String.format("(%s=%s)", OBJECT_GUID, getGuidForSearch(userDto.getUid())));

        var item = new SearchResult("user", ctx, null);
        var search = new NamingEnumeration<SearchResult>() {
            private Iterator<SearchResult> iterator = Arrays.asList(item).iterator();

            @Override
            public SearchResult nextElement() {
                return this.nextElement();
            }

            @Override
            public boolean hasMoreElements() {
                return iterator.hasNext();
            }

            @Override
            public SearchResult next() {
                return iterator.next();
            }

            @Override
            public boolean hasMore() {
                return this.hasMoreElements();
            }

            @Override
            public void close() {
            }
        };
        Mockito.when(readOnlyContext.search(Mockito.eq(query.base()), Mockito.anyString(), Mockito.any(SearchControls.class))).thenReturn(search);
        Mockito.when(objectDirectoryMapper.mapFromLdapDataEntry(Mockito.eq(ctx), Mockito.eq(LdapEntryType.USER.getClazz()))).thenReturn(user);


        var value = new byte[]{(byte) 0x84, 0x00, 0x02, 0x00, 0x00, 0x04, 0x00};
        var responseControls = new PagedResultsResponseControl("1", false, value);
        Mockito.when(readOnlyContext.getResponseControls()).thenReturn(new Control[]{responseControls});


        var result = instance.find(query, LdapEntryType.USER);
        Assertions.assertEquals(1, result.size());
        Assertions.assertEquals(userDto, result.get(0));
    }
}