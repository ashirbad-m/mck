package com.mckesson.ad.repository;

import com.google.common.collect.ImmutableSet;
import com.mckesson.ad.config.LdapDomainConfiguration;
import com.mckesson.common.DummyMessageBrokerPublisher;
import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.domain.AdGroup;
import com.mckesson.common.domain.AdServer;
import com.mckesson.common.domain.OktaUser;
import com.mckesson.common.ldap.LdapUtils;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.ldap.LdapName;
import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.IntFunction;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.mckesson.ad.repository.LdapEntryType.GROUP;
import static com.mckesson.ad.repository.LdapEntryType.SERVER;
import static com.mckesson.ad.repository.LdapEntryType.USER;
import static com.mckesson.common.ldap.LdapUtils.ACCOUNT_MANAGER;
import static com.mckesson.common.ldap.LdapUtils.COMPONENT_MEMBER;
import static com.mckesson.common.ldap.LdapUtils.COMPUTER_OS;
import static com.mckesson.common.ldap.LdapUtils.CONTAINER_MEMBER;
import static com.mckesson.common.ldap.LdapUtils.GROUP_COMPUTER_MANAGER;
import static com.mckesson.common.ldap.LdapUtils.OBJECT_GUID;
import static com.mckesson.common.ldap.LdapUtils.PWD_NATIVE;
import static com.mckesson.common.ldap.LdapUtils.SAM_ACCOUNT_NAME;
import static com.mckesson.common.ldap.LdapUtils.USER_ACCOUNT_CONTROL;
import static com.mckesson.common.ldap.LdapUtils.WORKER_ID_NATIVE;
import static com.mckesson.common.ldap.LdapUtils.b16le2String;
import static com.mckesson.common.ldap.LdapUtils.getGuidForSearch;
import static com.mckesson.common.ldap.LdapUtils.string2B16le;
import static com.mckesson.common.workday.converter.ConverterUtils.nullableLdapName;
import static java.time.temporal.ChronoUnit.MONTHS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Slf4j
@Disabled
public class LdapRepositorySpringTest {

    private static final String DOMAIN = "mshusontest";
    private static final byte[] ALL_HOURS = new byte[]{
        (byte)255, (byte)255, (byte)255, (byte)255, (byte)255, (byte)255, (byte)255,
        (byte)255, (byte)255, (byte)255, (byte)255, (byte)255, (byte)255, (byte)255,
        (byte)255, (byte)255, (byte)255, (byte)255, (byte)255, (byte)255, (byte)255
    };
    private static final long USER_LIMIT = 10L;
    private static final long GROUP_LIMIT = 5L;
    private static final long SERVER_LIMIT = 5L;

    private static Calendar add0(final Duration duration) {
        return new Calendar.Builder()
                .setInstant(
                    Instant.ofEpochMilli(Calendar.getInstance().getTimeInMillis())
                        .plus(duration)
                        .toEpochMilli()
                ).build();
    }
    private static Date nextDateValue(final int amount) {
        return add0(MONTHS.getDuration().multipliedBy(amount)).getTime();
    }

    public static final IntFunction<OktaUser> adUserGenerator = j0-> {
        int j = j0 * 1000 + j0;
        return OktaUser.builder()
// Not need for create
//                  .adUid("adUid " + j)
                .domain("domain " + j)
                .dn(nullableLdapName("CN=UserTest"  + j0 + ",OU=Users,OU=MSHPS,OU=B2E_Workday,DC=mshusontest,DC=com"))
                .cn("UserTest" + j0)
                .mail("mail_" + j+"@mshusontest.com")
                .samAccountName("efgh" + j0)
                .userPrincipalName("userPrincipalName" + j)
                .middleName("middleName " + j)
                .company("company " + j)
// Read Only
//                .usnChanged("usnChanged " + j)
                .division("division " + j)
                .displayName("displayName " + j)
                .fax("fax " + j)
                .city("city " + j)
                .homeDirectory("homeDirectory " + j)
                .postalCode("postalCode " + j)
                .state("state " + j)
                .st("st " + j)
// Implemented in other tests
//                  .manager(nullableLdapName("CN=ManagerTest" + j))
                .department("department " + j)
                .initials("i" + j0)
                .lastName("lastName " + j)
                .streetAddress("streetAddress " + j)
                .firstName("firstName " + j)
                .workerId(String.valueOf(235000L + j0))
                .country("country " + j)
                .telephoneNumber("telephoneNumber " + j)
                .title("title " + j)
                .workerType("workerType " + j)
                .postalAddress("postalAddress " + j)
                .homeDrive("homeDrive " + j)
                .mobile("mobile " + j)
// TODO Need to investigate how to change (m.b Read Only?)
//                  .primaryGroupId(513L)
                .street("street " + j)
                .scriptPath("scriptPath " + j)
                .accountExpires((nextDateValue((j0 + 1) * 5).getTime() + 11644473600000L) * 10000)
                //.mailNickname("mailNickname " + j)
// Absent in mshusontest
//                  .terminalServicesProfilePath("terminalServicesProfilePath " + j)
                .userAccountControl(514L)
                .msExchRecipientTypeDetails(1L)
                .physicalDeliveryOfficeName("physicalDeliveryOfficeName " + j)
                .proxyAddresses(ImmutableSet.of(
                    "smtp:mail" + j + "_1",
                    "smtp:mail" + j + "_2"
                ))
                .description("description " + j)
                .info("info " + j)
                .showInAddressBook(ImmutableSet.of(
                    nullableLdapName("CN=All Address Lists,CN=Address Lists Container,CN=MSHUSONTEST,CN=Microsoft Exchange,CN=Services,CN=Configuration,DC=mshusontest,DC=com"),
                    nullableLdapName("CN=All Global Address Lists,CN=Address Lists Container,CN=MSHUSONTEST,CN=Microsoft Exchange,CN=Services,CN=Configuration,DC=mshusontest,DC=com")
                ))
// Implemented in other tests
//                                  .memberOf(ImmutableSet.of(
//                                              nullableLdapName("CN=TestGroupA" + j),
//                                              nullableLdapName("CN=TestGroupB" + j),
//                                              nullableLdapName("CN=TestGroupC" + j)
//                                  ))
                .logonHours(ALL_HOURS)
                .build();
    };

    public static final IntFunction<AdGroup> adGroupGenerator = j0-> {
        int j = j0 * 1000 + j0;
        return AdGroup.builder()
            .domain("domain " + j)
            .dn(nullableLdapName("CN=GroupTest"  + j0 + ",OU=Groups,OU=USON,OU=B2E_Workday,DC=mshusontest,DC=com"))
            .cn("GroupTest" + j0)
            .description("description " + j)
            .groupType(
                (j0 % 2 == 0) ? 4L : (2147483648L | 4L)
            )
            .displayName("displayName " + j)
            .build();
    };

    public static final IntFunction<AdServer> adServerGenerator = j0-> {
        int j = j0 * 1000 + j0;
        return AdServer.builder()
            .domain("domain " + j)
            .dn(nullableLdapName("CN=ServerTest"  + j0 + ",OU=Computers,OU=USON,OU=B2E_Workday,DC=mshusontest,DC=com"))
            .cn("ServerTest" + j0)
            .operatingSystem((j0 % 2 == 0) ? "some_linux_system" : "some_sunos_system")
            .build();
    };

    private static <T> List<T> generateList(final IntFunction<T> generator, final long limit) {
        return Stream.iterate(0, i -> i + 1).limit(limit).map(generator::apply).collect(Collectors.toList());
    }

    protected static final List<OktaUser> TEST_AD_USERS = generateList(adUserGenerator, USER_LIMIT);
    protected static final List<AdGroup> TEST_AD_GROUPS = generateList(adGroupGenerator, GROUP_LIMIT);
    protected static final List<AdServer> TEST_AD_SERVERS = generateList(adServerGenerator, SERVER_LIMIT);

    private static boolean initialized;

    // Should be equals to count of @Tests
    private static int testCount = 12;

    @TestConfiguration
    static class LdapRepositoryTestConfiguration {
        @Bean
        public MessageBrokerPublisher getPublisher() {
            return new DummyMessageBrokerPublisher();
        }
    }


    @BeforeEach
    void init0() {
        if (!initialized) {
            TEST_AD_USERS.forEach(u -> {
                OktaUser newUser = getRepository().create(u, USER);
                u.setDomain(newUser.getDomain());
                u.setUid(newUser.getUid());
                u.setPrimaryGroupId(newUser.getPrimaryGroupId());
                u.setUsnChanged(newUser.getUsnChanged());
                if (u.getMemberOf() == null) {
                    Set<LdapName> mem = newUser.getMemberOf();
                    if (mem == null || mem.isEmpty()) {
                        u.setMemberOf(mem);
                    }
                }
            });
            TEST_AD_GROUPS.forEach(g -> {
                AdGroup newGroup = getRepository().create(g, GROUP);
                g.setDomain(newGroup.getDomain());
                g.setUid(newGroup.getUid());
                g.setAdSid(newGroup.getAdSid());
                g.setGroupType(newGroup.getGroupType());
                g.setMember(newGroup.getMember());
            });
            TEST_AD_SERVERS.forEach(s -> {
                AdServer newServer = getRepository().create(s, SERVER);
                s.setDomain(newServer.getDomain());
                s.setUid(newServer.getUid());
            });
            initialized = true;
        }
    }

    @AfterEach
    void clean () {
        testCount--;
        if (testCount == 0 && initialized) {
            TEST_AD_USERS.forEach(i -> getRepository().delete(i, USER));
            TEST_AD_GROUPS.forEach(i -> getRepository().delete(i, GROUP));
            TEST_AD_SERVERS.forEach(i -> getRepository().delete(i, SERVER));
            initialized = false;
        }
    }

    @Autowired
    LdapDomainConfiguration ldapDomainConfiguration;

    private LdapRepository getRepository() {
        return ldapDomainConfiguration.getServer(DOMAIN).getLdapRepository();
    }

    @Test
    void guidConversionTest() {
        Stream.of(
            "d5fc8128-6dc2-44e8-a62c-1a364700a19a",
            "b47d65b8-0d19-4107-b211-ad2846ab6fe3",
            "a9b2532c-9ddd-4935-b18c-4350347c7b9d",
            "1bee2895-cd01-4bb4-a072-483c9f07ba2a"
        ).forEach(stringUid -> {
                byte[] b = LdapUtils.string2Guid(stringUid);
                String s = LdapUtils.guid2String(b);
                assertEquals(stringUid, s);
        });
    }

    @Test
    void b16LeTest() {
        Stream.of(
            "L8FE%dd<8+z[N2f5%ww3M7@Y",
            "|H{3B<76V0{9Rcq9h6885}K5",
            "}f-0\\z315OqSTu{I*k\\]ZF7["
        ).forEach(stringUid -> {
                byte[] b = string2B16le(stringUid);
                String s = b16le2String(b);
                assertEquals(stringUid, s);
        });
    }

    @Test
    void searchUsersTest() {
        final LdapQuery query = LdapQueryBuilder.query().base(
                getRepository().truncate("OU=MSHPS,OU=B2E_Workday,DC=mshusontest,DC=com")
        ).where(WORKER_ID_NATIVE).isPresent();
        final List<OktaUser> users = getRepository().find(query, USER);
        assertEquals(USER_LIMIT, users.size());
        users.forEach(u -> {
            OktaUser old = TEST_AD_USERS.stream().filter(oldU -> u.getUid().equalsIgnoreCase(oldU.getUid())).findFirst().orElse(null);
            assertNotNull(old);
            assertEquals(old, u);
        });
        final OktaUser expected = TEST_AD_USERS.get(4);
        final LdapQuery guidQuery =  LdapQueryBuilder.query().filter(
            String.format("(%s=%s)", OBJECT_GUID, getGuidForSearch(expected.getUid()))
        );
        final OktaUser actual = getRepository().findSingle(guidQuery, USER);
        assertEquals(expected, actual);
    }

    @Test
    void pwdUserTest() {
        final OktaUser au = TEST_AD_USERS.get(0);
        final String pwd = "L8FE%dd<8+z[N2f5%ww3M7@Y" + new SecureRandom().nextInt(100);
        final byte[] bytes = string2B16le(pwd);
        final Set<ModificationItem> items = new HashSet<>();
        items.add(
            new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
                new BasicAttribute(PWD_NATIVE, bytes)
            )
        );
        if (!au.isEnabled()) {
            items.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute(
                USER_ACCOUNT_CONTROL,
                String.valueOf(au.getUserAccountControl() ^ 2)
            )));
        }
        getRepository().modifyAttributes(au, items.toArray(new ModificationItem[0]), USER);
        final OktaUser newAu = getRepository().authenticate(
            LdapQueryBuilder.query().where(SAM_ACCOUNT_NAME).is(au.getSamAccountName()),
            pwd
        );
        assertNotNull(newAu);
        assertEquals(
            au.toBuilder()
                .userAccountControl(newAu.getUserAccountControl())
                .usnChanged(newAu.getUsnChanged())
                .build(),
            newAu
        );
        au.setUserAccountControl(newAu.getUserAccountControl());
        au.setUsnChanged(newAu.getUsnChanged());
    }

    @Test
    void updateUserTest() {
        final OktaUser au = TEST_AD_USERS.get(TEST_AD_USERS.size() - 1);

        final OktaUser newAu = adUserGenerator.apply((int)USER_LIMIT + 5).toBuilder()
                .uid(au.getUid())
                .dn(au.getDn())
                .cn(au.getCn())
                .memberOf(au.getMemberOf())
                .primaryGroupId(au.getPrimaryGroupId())
                .userAccountControl(au.getUserAccountControl())
                .domain(au.getDomain())
            .build();

        final OktaUser newAuUpdated = getRepository().update(newAu, USER);
        assertEquals(newAu.toBuilder().usnChanged(newAuUpdated.getUsnChanged()).build(), newAuUpdated);
        TEST_AD_USERS.set(TEST_AD_USERS.size() - 1, newAuUpdated);

        final OktaUser newAuUpdated0 = getRepository().findByDn(newAuUpdated.getDn(), USER);
        assertEquals(newAuUpdated, newAuUpdated0);

    }

    @Test
    void changeUserDnTest () {
        final OktaUser au = TEST_AD_USERS.get(4);
        final LdapName newDn = nullableLdapName("CN=UserTestMoved4,OU=OtherUsers,OU=MSHPS,OU=B2E_Workday,DC=mshusontest,DC=com");
        final OktaUser moved = getRepository().changeDn(au, newDn, USER);
        assertEquals(
            au.toBuilder().dn(moved.getDn()).usnChanged(moved.getUsnChanged()).cn(moved.getCn()).build(),
            moved
        );
        TEST_AD_USERS.set(4, moved);
    }

    @Test
    void accountManagerTest () {
        final OktaUser managed = TEST_AD_USERS.get(4);
        final OktaUser manager = TEST_AD_USERS.get(5);
        final OktaUser newManaged = getRepository().modifyAttributes(managed, new ModificationItem[] {
            new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
                new BasicAttribute(ACCOUNT_MANAGER, manager.getDn().toString())
            )
        }, USER);
        assertEquals(managed.toBuilder().manager(manager.getDn()).usnChanged(newManaged.getUsnChanged()).build(), newManaged);
        TEST_AD_USERS.set(4, newManaged);

        final OktaUser secondManaged = TEST_AD_USERS.get(6);
        secondManaged.setManager(manager.getDn());
        final OktaUser newSecondManaged = getRepository().update(secondManaged, USER);
        assertEquals(secondManaged.toBuilder().manager(manager.getDn()).usnChanged(newSecondManaged.getUsnChanged()).build(), newSecondManaged);
        TEST_AD_USERS.set(6, newSecondManaged);

        final List<OktaUser> managedUsers = getRepository().find(
            LdapQueryBuilder.query().where(ACCOUNT_MANAGER).is(manager.getDn().toString()), USER
        );
        assertEquals(2, managedUsers.size());
        assertTrue(managedUsers.contains(TEST_AD_USERS.get(4)));
        assertTrue(managedUsers.contains(TEST_AD_USERS.get(6)));
    }

    @Test
    void searchGroupsTest() {
        final LdapQuery query = LdapQueryBuilder.query().base(
                getRepository().truncate("OU=USON,OU=B2E_Workday,DC=mshusontest,DC=com")
        ).where("groupType").isPresent();
        final List<AdGroup> groups = getRepository().find(query, GROUP);
        assertEquals(GROUP_LIMIT, groups.size());
        groups.forEach(g -> {
            AdGroup old = TEST_AD_GROUPS.stream().filter(oldG -> g.getUid().equalsIgnoreCase(oldG.getUid())).findFirst().orElse(null);
            assertNotNull(old);
            assertEquals(old, g);
        });
    }

    @Test
    void groupManagerTest () {
        final OktaUser manager = TEST_AD_USERS.get(5);
        final AdGroup managed = TEST_AD_GROUPS.get(0);

        final AdGroup newManaged = getRepository().modifyAttributes(managed, new ModificationItem[] {
            new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
                new BasicAttribute(GROUP_COMPUTER_MANAGER, manager.getDn().toString())
            )
        }, GROUP);
        assertEquals(managed.toBuilder().managedBy(manager.getDn()).build(), newManaged);
        TEST_AD_GROUPS.set(0, newManaged);

        final AdGroup secondManaged = TEST_AD_GROUPS.get(1);
        secondManaged.setManagedBy(manager.getDn());
        final AdGroup newSecondManaged = getRepository().update(secondManaged, GROUP);
        assertEquals(secondManaged.toBuilder().managedBy(manager.getDn()).build(), newSecondManaged);
        TEST_AD_GROUPS.set(1, newSecondManaged);

        final List<AdGroup> managedGroups = getRepository().find(
            LdapQueryBuilder.query().where(GROUP_COMPUTER_MANAGER).is(manager.getDn().toString()), GROUP
        );
        assertEquals(2, managedGroups.size());
        assertTrue(managedGroups.contains(TEST_AD_GROUPS.get(0)));
        assertTrue(managedGroups.contains(TEST_AD_GROUPS.get(1)));
    }

    @Test
    void searchServersTest() {
        final LdapQuery query = LdapQueryBuilder.query().base(
                getRepository().truncate("OU=Computers,OU=USON,OU=B2E_Workday,DC=mshusontest,DC=com")
        ).where(COMPUTER_OS).isPresent();
        final List<AdServer> servers = getRepository().find(query, SERVER);
        assertEquals(SERVER_LIMIT, servers.size());
        servers.forEach(s -> {
            AdServer old = TEST_AD_SERVERS.stream().filter(oldS -> s.getUid().equalsIgnoreCase(oldS.getUid())).findFirst().orElse(null);
            assertNotNull(old);
            assertEquals(old, s);
        });
    }

    @Test
    void serverManagerTest () {
        final OktaUser manager = TEST_AD_USERS.get(5);
        final AdServer managed = TEST_AD_SERVERS.get(0);

        final AdServer newManaged = getRepository().modifyAttributes(managed, new ModificationItem[] {
            new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
                new BasicAttribute(GROUP_COMPUTER_MANAGER, manager.getDn().toString())
            )
        }, SERVER);

        assertEquals(managed.toBuilder().managedBy(manager.getDn()).build(), newManaged);
        TEST_AD_SERVERS.set(0, newManaged);

        final AdServer secondManaged = TEST_AD_SERVERS.get(1);
        secondManaged.setManagedBy(manager.getDn());
        final AdServer newSecondManaged = getRepository().update(secondManaged, SERVER);
        assertEquals(secondManaged.toBuilder().managedBy(manager.getDn()).build(), newSecondManaged);
        TEST_AD_SERVERS.set(1, newSecondManaged);

        final List<AdServer> managedServers = getRepository().find(
            LdapQueryBuilder.query().where(GROUP_COMPUTER_MANAGER).is(manager.getDn().toString()), SERVER
        );
        assertEquals(2, managedServers.size());
        assertTrue(managedServers.contains(TEST_AD_SERVERS.get(0)));
        assertTrue(managedServers.contains(TEST_AD_SERVERS.get(1)));

        final List<AdServer> linuxManagedServers = getRepository().find(
            LdapQueryBuilder.query().where(GROUP_COMPUTER_MANAGER).is(manager.getDn().toString()).and(COMPUTER_OS).like("*linux*"), SERVER
        );
        assertEquals(1, linuxManagedServers.size());
        assertEquals(TEST_AD_SERVERS.get(0), linuxManagedServers.get(0));
    }

    @Test
    void groupMemberTest () {
        final OktaUser user7 = TEST_AD_USERS.get(7);
        final OktaUser user8 = TEST_AD_USERS.get(8);
        final OktaUser user9 = TEST_AD_USERS.get(9);

        final AdGroup group3 = TEST_AD_GROUPS.get(3);
        final AdGroup group4 = TEST_AD_GROUPS.get(4);

        final AdGroup newGroup3
         = getRepository().modifyAttributes(group3, new ModificationItem[] {
                new ModificationItem(DirContext.ADD_ATTRIBUTE,
                    new BasicAttribute(CONTAINER_MEMBER, user7.getDn().toString())
                ),
                new ModificationItem(DirContext.ADD_ATTRIBUTE,
                    new BasicAttribute(CONTAINER_MEMBER, user8.getDn().toString())
                ),
        }, GROUP);
        assertEquals(group3.toBuilder().member(ImmutableSet.of(user7.getDn(), user8.getDn())).build(), newGroup3);

        newGroup3.getMember().add(user9.getDn());
        final AdGroup newGroup31 = getRepository().update(newGroup3, GROUP);
        assertEquals(group3.toBuilder().member(ImmutableSet.of(user7.getDn(), user8.getDn(), user9.getDn())).build(), newGroup31);
        TEST_AD_GROUPS.set(3, newGroup31);

        group4.getMember().add(user9.getDn());
        final AdGroup newGroup41 = getRepository().update(group4, GROUP);
        assertEquals(group4.toBuilder().member(ImmutableSet.of(user9.getDn())).build(), newGroup41);
        TEST_AD_GROUPS.set(4, newGroup41);

        final List<AdGroup> groupsFor0 = getRepository().find(
            LdapQueryBuilder.query().where(CONTAINER_MEMBER).is(TEST_AD_USERS.get(0).getDn().toString()), GROUP
        );
        assertEquals(0, groupsFor0.size());

        TEST_AD_USERS.set(7, getRepository().findByDn(user7.getDn(), USER));
        TEST_AD_USERS.set(8, getRepository().findByDn(user8.getDn(), USER));
        TEST_AD_USERS.set(9, getRepository().findByDn(user9.getDn(), USER));

        final List<AdGroup> groupsFor9 = getRepository().find(
                LdapQueryBuilder.query().where(CONTAINER_MEMBER).is(user9.getDn().toString()), GROUP
        );
        assertEquals(2, groupsFor9.size());
        assertTrue(groupsFor9.contains(newGroup31));
        assertTrue(groupsFor9.contains(newGroup41));

        final List<OktaUser> usersFor3_4 = getRepository().find(
            LdapQueryBuilder.query()
                .where(COMPONENT_MEMBER).is(group3.getDn().toString())
                .and(COMPONENT_MEMBER).is(group4.getDn().toString()),
            USER
        );
        assertEquals(1, usersFor3_4.size());
        assertEquals(usersFor3_4.get(0), TEST_AD_USERS.get(9));

        /*Set<LdapName> large31 = getRepository().getLargeValue(newGroup31.getDn(), CONTAINER_MEMBER, o -> nullableLdapName(String.valueOf(o)));
        assertNotNull(large31);
        assertEquals(ImmutableSet.of(user7.getDn(), user8.getDn(), user9.getDn()), large31);*/
    }

}
