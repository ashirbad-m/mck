package com.mckesson.ad.rest;

import com.mckesson.ad.service.ActiveDirectoryProcessor;
import com.mckesson.common.model.CoreEvent;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

class ActiveDirectoryControllerTest {

    @Test
    void processEvent() {
        var activeDirectoryProcessor = Mockito.mock(ActiveDirectoryProcessor.class);
        CoreEvent event = Mockito.mock(CoreEvent.class);

        var instance = new ActiveDirectoryController(activeDirectoryProcessor);
        instance.processEvent(event);
        Mockito.verify(activeDirectoryProcessor).processEvent(Mockito.eq(event));
    }
}