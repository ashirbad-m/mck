package com.mckesson.ad.entity.mapper;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;

class LdapMapperUtilsTest {

    @Test
    void workerId2String() {
        var instance = new LdapMapperUtils();
        Assertions.assertNull(instance.workerId2String(null));
        Assertions.assertEquals("-10", instance.workerId2String(-10L));
        Assertions.assertEquals("14", instance.workerId2String(14L));
    }

    @Test
    void workerIdLong() {
        var instance = new LdapMapperUtils();
        Assertions.assertEquals(0, instance.workerIdLong("Ax"));
        Assertions.assertEquals(0, instance.workerIdLong("0"));
        Assertions.assertEquals(-10L, instance.workerIdLong("-10"));
        Assertions.assertEquals(14L, instance.workerIdLong("14"));
    }

    @Test
    void long2Date() {
        var instance = new LdapMapperUtils();
        Assertions.assertNull(instance.long2Date(null));

        var time = 1640000000000L;
        var value = (time + 11644473600000L) * 10000;
        Assertions.assertEquals(new Date(time), instance.long2Date(value));
    }

    @Test
    void date2Long() {
        var instance = new LdapMapperUtils();
        Assertions.assertNull(instance.date2Long(null));
        var time = 1640000000000L;
        var expected = (time + 11644473600000L) * 10000;
        Assertions.assertEquals(expected, instance.date2Long(new Date(time)));
    }

    @Test
    void string2Date() {
        var instance = new LdapMapperUtils();
        Assertions.assertNull(instance.string2Date(null));
        Assertions.assertNull(instance.string2Date(""));
        Assertions.assertNull(instance.string2Date("1"));
        Assertions.assertNull(instance.string2Date("12"));
        Assertions.assertNull(instance.string2Date("123"));
        Assertions.assertNull(instance.string2Date("abcdx"));

        var time = 1640000000000L;
        var value = (time + 11644473600000L) + "0000";
        Assertions.assertEquals(new Date(time), instance.string2Date(value));
    }

    @Test
    void date2String() {
        var instance = new LdapMapperUtils();
        Assertions.assertNull(instance.date2String(null));
        var time = 1640000000000L;
        var expected = (time + 11644473600000L) + "0000";
        Assertions.assertEquals(expected, instance.date2String(new Date(time)));
    }
}