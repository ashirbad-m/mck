package com.mckesson.ad.service;

import com.mckesson.ad.repository.LdapEntryType;
import com.mckesson.ad.repository.LdapRepositorySpringTest;
import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.audit.AuditService;
import com.mckesson.common.domain.*;
import com.mckesson.common.ldap.LdapUtils;
import com.mckesson.common.model.*;
import com.mckesson.common.scenario.ScenarioProvider;
import com.mckesson.common.workday.configuration.controller.ConfigurationClient;
import com.mckesson.common.workday.configuration.dto.GroupMappingDto;
import com.mckesson.common.workday.configuration.dto.GroupMappingType;
import com.mckesson.common.workday.converter.ConverterUtils;
import lombok.SneakyThrows;
import org.apache.commons.codec.binary.Hex;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.stubbing.Answer;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class ActiveDirectoryProcessorTest {

    private final ScenarioProvider scenarioProvider = new ScenarioProvider();
    private final MessageBrokerPublisher messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
    private final LdapService ldapService = Mockito.mock(LdapService.class);
    private final FindManagerService findManagerService = Mockito.mock(FindManagerService.class);
    private final ConfigurationClient configurationClient = Mockito.mock(ConfigurationClient.class);
    private final AuditService auditService = Mockito.mock(AuditService.class);

    @BeforeEach
    public void beforeEach() {
        Mockito.reset(messageBrokerPublisher, ldapService, findManagerService, configurationClient);
    }

    private ActiveDirectoryProcessor getInstance() {
        return new ActiveDirectoryProcessor(scenarioProvider, messageBrokerPublisher, ldapService, findManagerService, configurationClient, auditService);
    }

    @SneakyThrows
    private HrbuConfig getHrbuConfig(String commonGroup) {
        return new HrbuConfig(
                new LdapName("DC=COM"),
                "homeDrive",
                "homeDir",
                "loginScript",
                new HashSet<>(Arrays.asList(commonGroup, "groups")),
                new HashSet<>(Arrays.asList(commonGroup, "contractorGroups")),
                new HashSet<>(Arrays.asList(commonGroup, "outsideWorkerGroups")),
                new HashSet<>(Arrays.asList(commonGroup, "extGroups")),
                false,
                "itcMail",
                "hrbu",
                "mailSuffix",
                "secondaryMailSuffix",
                true,
                false,
                false,
                "city",
                "street",
                "id",
                false);
    }

    @Test
    public void testGetCwtGroups() {
        ActiveDirectoryProcessor instance = getInstance();

        String commonGroup = "common";
        HrbuConfig hrbuConfig = getHrbuConfig(commonGroup);

        Set<String> cwtGroups = instance.getCwtGroups(WorkerTypeDescriptorEnum.CWT_REGULAR, false, hrbuConfig);
        Assertions.assertEquals(2, cwtGroups.size());
        Assertions.assertTrue(cwtGroups.contains(commonGroup));
        Assertions.assertTrue(cwtGroups.contains("groups"));

        cwtGroups = instance.getCwtGroups(WorkerTypeDescriptorEnum.CWT_EMPLOYEE.getValue(), true, hrbuConfig);
        Assertions.assertEquals(2, cwtGroups.size());
        Assertions.assertTrue(cwtGroups.contains(commonGroup));
        Assertions.assertTrue(cwtGroups.contains("groups"));

        cwtGroups = instance.getCwtGroups(WorkerTypeDescriptorEnum.CWT_CONTRACTOR.getValue(), false, hrbuConfig);
        Assertions.assertEquals(2, cwtGroups.size());
        Assertions.assertTrue(cwtGroups.contains(commonGroup));
        Assertions.assertTrue(cwtGroups.contains("contractorGroups"));

        cwtGroups = instance.getCwtGroups(WorkerTypeDescriptorEnum.CWT_OUTSIDE.getValue(), false, hrbuConfig);
        Assertions.assertEquals(2, cwtGroups.size());
        Assertions.assertTrue(cwtGroups.contains(commonGroup));
        Assertions.assertTrue(cwtGroups.contains("outsideWorkerGroups"));

        cwtGroups = instance.getCwtGroups(WorkerTypeDescriptorEnum.CWT_X.getValue(), false, hrbuConfig);
        Assertions.assertEquals(2, cwtGroups.size());
        Assertions.assertTrue(cwtGroups.contains(commonGroup));
        Assertions.assertTrue(cwtGroups.contains("extGroups"));

        cwtGroups = instance.getCwtGroups("Default", false, hrbuConfig);
        Assertions.assertEquals(2, cwtGroups.size());
        Assertions.assertTrue(cwtGroups.contains(commonGroup));
        Assertions.assertTrue(cwtGroups.contains("contractorGroups"));
    }

    @SneakyThrows
    @Test
    public void testCwtChangeGroups() {
        ActiveDirectoryProcessor instance = getInstance();

        String lastName = "lastName";
        String commonGroup = "common";
        HrbuConfig hrbuConfig = getHrbuConfig(commonGroup);

        String csaGroupName = ActiveDirectoryProcessor.CSA_GROUPS_PREFIX + String.valueOf(lastName.charAt(0)).toUpperCase();
        GroupMappingDto csaGroup = new GroupMappingDto(1L, csaGroupName, new LdapName("CN=" + csaGroupName + ",OU=Test,DC=mshusontest,DC=com"), GroupMappingType.CSA, "");
        Mockito.when(configurationClient.findGroupMappingsByType(Mockito.eq(GroupMappingType.CSA))).thenReturn(Collections.singletonList(csaGroup));
        Mockito.when(configurationClient.findGroupMappingsByNames(Mockito.any())).thenAnswer((Answer<List<GroupMappingDto>>) invocation -> ((Collection<String>) invocation.getArgument(0)).stream()
                .map(Object::toString)
                .map(this::toGroupModel)
                .map(model -> new GroupMappingDto(0L, model.getName(), model.getDn(), GroupMappingType.DEFAULT, ""))
                .collect(Collectors.toList()));

        List<AdGroup> userGroups = toAdGroup("group1", "group2", commonGroup, csaGroup.getName());

        Set<ActiveDirectoryProcessor.GroupModel> groups = instance.cwtChangeGroups(hrbuConfig, userGroups, true, lastName);
        Assertions.assertEquals(5, groups.size());
        Assertions.assertTrue(groups.contains(toGroupModel(commonGroup)));
        Assertions.assertTrue(groups.contains(toGroupModel("group1")));
        Assertions.assertTrue(groups.contains(toGroupModel("group2")));
        Assertions.assertTrue(groups.contains(toGroupModel("contractorGroups")));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(csaGroup)));

        groups = instance.cwtChangeGroups(hrbuConfig, userGroups, false, lastName);
        Assertions.assertEquals(5, groups.size());
        Assertions.assertTrue(groups.contains(toGroupModel(commonGroup)));
        Assertions.assertTrue(groups.contains(toGroupModel("group1")));
        Assertions.assertTrue(groups.contains(toGroupModel("group2")));
        Assertions.assertTrue(groups.contains(toGroupModel("groups")));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(csaGroup)));


        userGroups = toAdGroup("group1", "group2", commonGroup);

        groups = instance.cwtChangeGroups(hrbuConfig, userGroups, true, lastName);
        Assertions.assertEquals(4, groups.size());
        Assertions.assertTrue(groups.contains(toGroupModel(commonGroup)));
        Assertions.assertTrue(groups.contains(toGroupModel("group1")));
        Assertions.assertTrue(groups.contains(toGroupModel("group2")));
        Assertions.assertTrue(groups.contains(toGroupModel("contractorGroups")));
        Assertions.assertFalse(groups.contains(new ActiveDirectoryProcessor.GroupModel(csaGroup)));

        groups = instance.cwtChangeGroups(hrbuConfig, userGroups, false, lastName);
        Assertions.assertEquals(4, groups.size());
        Assertions.assertTrue(groups.contains(toGroupModel(commonGroup)));
        Assertions.assertTrue(groups.contains(toGroupModel("group1")));
        Assertions.assertTrue(groups.contains(toGroupModel("group2")));
        Assertions.assertTrue(groups.contains(toGroupModel("groups")));
        Assertions.assertFalse(groups.contains(new ActiveDirectoryProcessor.GroupModel(csaGroup)));
    }


    @SneakyThrows
    @Test
    public void testCwtGenerateGroups() {
        ActiveDirectoryProcessor instance = getInstance();

        String lastName = "lastName";
        String commonGroup = "common";
        HrbuConfig hrbuConfig = getHrbuConfig(commonGroup);

        List<GroupMappingDto> defaultGroups = Arrays.asList(
                new GroupMappingDto(11L, "group1", new LdapName("CN=group1,OU=Test,DC=mshusontest,DC=com"), GroupMappingType.DEFAULT, ""),
                new GroupMappingDto(12L, "group2", new LdapName("CN=group2,OU=Test,DC=mshusontest,DC=com"), GroupMappingType.DEFAULT, "")
        );

        String csaGroupName = ActiveDirectoryProcessor.CSA_GROUPS_PREFIX + String.valueOf(lastName.charAt(0)).toUpperCase();
        GroupMappingDto csaGroup = new GroupMappingDto(21L, csaGroupName, new LdapName("CN=" + csaGroupName + ",OU=Test,DC=mshusontest,DC=com"), GroupMappingType.CSA, "");
        Mockito.when(configurationClient.findGroupMappingsByType(Mockito.eq(GroupMappingType.CSA))).thenReturn(Collections.singletonList(csaGroup));
        Mockito.when(configurationClient.findGroupMappingsByType(Mockito.eq(GroupMappingType.DEFAULT))).thenReturn(defaultGroups);
        Mockito.when(configurationClient.findGroupMappingsByNames(Mockito.any())).thenAnswer((Answer<List<GroupMappingDto>>) invocation -> ((Collection<String>) invocation.getArgument(0)).stream()
                .map(Object::toString)
                .map(this::toGroupModel)
                .map(model -> new GroupMappingDto(0L, model.getName(), model.getDn(), GroupMappingType.DEFAULT, ""))
                .collect(Collectors.toList()));

        //configurationClient.findGroupMappingsByNames(getCwtGroups(workerTypeDescriptor, employee, hrbuConfig))

        Set<ActiveDirectoryProcessor.GroupModel> groups = instance.cwtGenerateGroups(hrbuConfig, WorkerTypeDescriptorEnum.CWT_REGULAR, false, lastName);
        Assertions.assertEquals(4, groups.size());
        Assertions.assertTrue(groups.contains(toGroupModel(commonGroup)));
        Assertions.assertTrue(groups.contains(toGroupModel("groups")));
        Assertions.assertFalse(groups.contains(new ActiveDirectoryProcessor.GroupModel(csaGroup)));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(defaultGroups.get(0))));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(defaultGroups.get(1))));

        groups = instance.cwtGenerateGroups(hrbuConfig, WorkerTypeDescriptorEnum.CWT_EMPLOYEE.getValue(), true, lastName);
        Assertions.assertEquals(5, groups.size());
        Assertions.assertTrue(groups.contains(toGroupModel(commonGroup)));
        Assertions.assertTrue(groups.contains(toGroupModel("groups")));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(csaGroup)));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(defaultGroups.get(0))));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(defaultGroups.get(1))));

        groups = instance.cwtGenerateGroups(hrbuConfig, WorkerTypeDescriptorEnum.CWT_CONTRACTOR.getValue(), false, lastName);
        Assertions.assertEquals(4, groups.size());
        Assertions.assertTrue(groups.contains(toGroupModel(commonGroup)));
        Assertions.assertTrue(groups.contains(toGroupModel("contractorGroups")));
        Assertions.assertFalse(groups.contains(new ActiveDirectoryProcessor.GroupModel(csaGroup)));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(defaultGroups.get(0))));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(defaultGroups.get(1))));


        groups = instance.cwtGenerateGroups(hrbuConfig, WorkerTypeDescriptorEnum.CWT_OUTSIDE.getValue(), false, lastName);
        Assertions.assertEquals(4, groups.size());
        Assertions.assertTrue(groups.contains(toGroupModel(commonGroup)));
        Assertions.assertTrue(groups.contains(toGroupModel("outsideWorkerGroups")));
        Assertions.assertFalse(groups.contains(new ActiveDirectoryProcessor.GroupModel(csaGroup)));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(defaultGroups.get(0))));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(defaultGroups.get(1))));


        groups = instance.cwtGenerateGroups(hrbuConfig, WorkerTypeDescriptorEnum.CWT_X.getValue(), false, lastName);
        Assertions.assertEquals(4, groups.size());
        Assertions.assertTrue(groups.contains(toGroupModel(commonGroup)));
        Assertions.assertTrue(groups.contains(toGroupModel("extGroups")));
        Assertions.assertFalse(groups.contains(new ActiveDirectoryProcessor.GroupModel(csaGroup)));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(defaultGroups.get(0))));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(defaultGroups.get(1))));


        groups = instance.cwtGenerateGroups(hrbuConfig, "Default", false, lastName);
        Assertions.assertEquals(4, groups.size());
        Assertions.assertTrue(groups.contains(toGroupModel(commonGroup)));
        Assertions.assertTrue(groups.contains(toGroupModel("contractorGroups")));
        Assertions.assertFalse(groups.contains(new ActiveDirectoryProcessor.GroupModel(csaGroup)));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(defaultGroups.get(0))));
        Assertions.assertTrue(groups.contains(new ActiveDirectoryProcessor.GroupModel(defaultGroups.get(1))));
    }

    @SneakyThrows
    private ActiveDirectoryProcessor.GroupModel toGroupModel(String name) {
        return new ActiveDirectoryProcessor.GroupModel(name, new LdapName("CN=" + name + ",OU=Test,DC=mshusontest,DC=com"));
    }

    @SneakyThrows
    private List<AdGroup> toAdGroup(String... a) {
        List<AdGroup> result = new ArrayList<>(a.length);
        for (String name : a) {
            String dn = "CN=" + name + ",OU=Test,DC=mshusontest,DC=com";
            AdGroup group = new AdGroup("uid", "domain",
                    new LdapName(dn), dn, Collections.emptySet(), "description", null, null, name, null);
            result.add(group);
        }
        return result;
    }

    @Test
    void onCreate() throws InvalidNameException {
        ActiveDirectoryProcessor instance = getInstance();
        var eventBuilder = CoreEvent.builder()
                .target("passport")
                .stage("test")
                .scenario(ScenarioEnum.CREATE)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .metrics(new ArrayList<>());
        instance.processEvent(eventBuilder.build());

        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.OKTA_CLIENT), Mockito.any(CoreEvent.class));
        Mockito.verifyNoMoreInteractions(messageBrokerPublisher, ldapService, findManagerService, configurationClient, auditService);

        var event = eventBuilder.build();
        event.setStage("start");
        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        event.setNextOktaUser(nextOktaUser);
        event.setPrevOktaUser(prevOktaUser);
        nextOktaUser.setSamAccountName("samAccountName1");
        var samAccountName = "samAccountName2";
        var dn = new LdapName("CN=User2,OU=Test,DC=mshusontest,DC=com");

        Mockito.when(ldapService.generateUID(Mockito.eq(nextOktaUser.getSamAccountName()))).thenReturn(samAccountName);
        Mockito.when(ldapService.generateDn(Mockito.eq(nextOktaUser.getDn()))).thenReturn(dn);
        instance.processEvent(event);
        Assertions.assertEquals(samAccountName, nextOktaUser.getSamAccountName());
        Assertions.assertEquals(dn, nextOktaUser.getDn());
        Assertions.assertEquals(dn, nextOktaUser.getDn());
        Assertions.assertEquals(dn.getRdn(dn.size() - 1).getValue().toString(), nextOktaUser.getCn());
        Mockito.verify(ldapService).generateAndSetEmails(Mockito.eq(event.getOktaUser()), Mockito.eq(true));
    }

    @Test
    void onUpdate() throws InvalidNameException {
        ActiveDirectoryProcessor instance = getInstance();

        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        prevOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));

        var wdUserHRBUConfig = new HrbuConfig();
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(nextOktaUser.getHrbu()), Mockito.eq(nextOktaUser.getCity()), Mockito.eq(nextOktaUser.getStreetAddress()))).thenReturn(wdUserHRBUConfig);
        var adUserHRBUConfig = new HrbuConfig();
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(prevOktaUser.getHrbu()), Mockito.eq(prevOktaUser.getCity()), Mockito.eq(prevOktaUser.getStreetAddress()))).thenReturn(adUserHRBUConfig);

        var eventBuilder = CoreEvent.builder()
                .target("passport")
                .scenario(ScenarioEnum.UPDATE)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .metrics(new ArrayList<>())
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser);

        instance.processEvent(eventBuilder.stage("test").build());

        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.OKTA_CLIENT), Mockito.any(CoreEvent.class));
        Mockito.verifyNoMoreInteractions(messageBrokerPublisher, ldapService, findManagerService, auditService);

        eventBuilder.stage("prepare");

        var event = eventBuilder.build();
        instance.processEvent(event);

        event = eventBuilder.build();
        nextOktaUser.setWorkerId(null);
        instance.processEvent(event);
        Assertions.assertTrue(event.isFailed());

        var workerId = UUID.randomUUID().toString();
        nextOktaUser.setWorkerId(workerId);

        event = eventBuilder.build();
        Mockito.when(ldapService.findUserByWorkerId(Mockito.eq(workerId))).thenReturn(null);
        instance.processEvent(event);
        Assertions.assertTrue(event.isFailed());

        event = eventBuilder.build();
        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        userDto.setManager(new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com"));
        Mockito.when(ldapService.findUserByWorkerId(Mockito.eq(workerId))).thenReturn(userDto);

        instance.processEvent(event);
        Assertions.assertEquals(userDto.getDn(), nextOktaUser.getDn());
        Assertions.assertEquals(userDto.getDn().getRdn(userDto.getDn().size() - 1).getValue().toString(), nextOktaUser.getCn());
        Assertions.assertEquals(userDto.getManager(), nextOktaUser.getManager());
    }


    @Test
    void onUpdateNameChange() throws InvalidNameException {
        ActiveDirectoryProcessor instance = getInstance();

        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        prevOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));

        var wdUserHRBUConfig = new HrbuConfig();
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(nextOktaUser.getHrbu()), Mockito.eq(nextOktaUser.getCity()), Mockito.eq(nextOktaUser.getStreetAddress()))).thenReturn(wdUserHRBUConfig);
        var adUserHRBUConfig = new HrbuConfig();
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(prevOktaUser.getHrbu()), Mockito.eq(prevOktaUser.getCity()), Mockito.eq(prevOktaUser.getStreetAddress()))).thenReturn(adUserHRBUConfig);

        var eventBuilder = CoreEvent.builder()
                .target("passport")
                .scenario(ScenarioEnum.UPDATE)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .metrics(new ArrayList<>())
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser);

        var event = eventBuilder.build();
        event.setStage("nameChange-cn");
        var generateCn = "UserTest1.1";
        Mockito.when(ldapService.generateCn(Mockito.eq(nextOktaUser.getCn()), Mockito.eq(nextOktaUser.getDn()),
                Mockito.eq(event.getDomainConfig()), Mockito.any())).thenReturn(generateCn);
        instance.processEvent(event);
        Assertions.assertEquals(generateCn, nextOktaUser.getCn());
        var auditEvent = AuditEvent.generateEvent(event)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .status("SUCCESS")
                .situation("passport.ad.set-cn")
                .message("Generated CN for: " + nextOktaUser.getDn())
                .newValues(generateCn)
                .build();
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));

        Mockito.reset(ldapService, auditService);
        event = eventBuilder.build();
        event.setStage("nameChange-email");
        instance.processEvent(event);
        Mockito.verify(ldapService).generateAndSetEmails(Mockito.eq(nextOktaUser), Mockito.eq(false));
        auditEvent = AuditEvent.generateEvent(event)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .status("SUCCESS")
                .situation("passport.ad.emails")
                .message("Generated emails for: " + nextOktaUser.getUserPrincipalName())
                .newValues(ConverterUtils.writeValueAsString(nextOktaUser.getEmails()))
                .build();
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));

        Mockito.reset(ldapService, auditService);
        event = eventBuilder.build();
        event.setStage("nameChange-all");
        Mockito.when(ldapService.generateCn(Mockito.eq(nextOktaUser.getCn()), Mockito.eq(nextOktaUser.getDn()), Mockito.eq(event.getDomainConfig()), Mockito.any())).thenReturn(generateCn);
        instance.processEvent(event);
        Assertions.assertEquals(generateCn, nextOktaUser.getCn());
        Mockito.verify(ldapService).generateAndSetEmails(Mockito.eq(nextOktaUser), Mockito.eq(false));
        auditEvent = AuditEvent.generateEvent(event)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .status("SUCCESS")
                .situation("passport.ad.emails")
                .message("Generated emails for: " + nextOktaUser.getUserPrincipalName())
                .newValues(ConverterUtils.writeValueAsString(nextOktaUser.getEmails()))
                .build();
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
        auditEvent = AuditEvent.generateEvent(event)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .status("SUCCESS")
                .situation("passport.ad.set-cn")
                .message("Generated CN for: " + nextOktaUser.getDn())
                .newValues(generateCn)
                .build();
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
    }

    @Test
    void onUpdateConversion() throws InvalidNameException {
        ActiveDirectoryProcessor instance = getInstance();

        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        prevOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));

        var eventBuilder = CoreEvent.builder()
                .target("passport")
                .stage("conversion-ps")
                .scenario(ScenarioEnum.UPDATE)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .metrics(new ArrayList<>())
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser);

        var event = eventBuilder.build();

        var workerId = UUID.randomUUID().toString();
        nextOktaUser.setWorkerId(workerId);

        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        userDto.setManager(new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com"));

        userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        userDto.setManager(new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com"));

        var wdUserHRBUConfig = new HrbuConfig();
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(nextOktaUser.getHrbu()), Mockito.eq(nextOktaUser.getCity()), Mockito.eq(nextOktaUser.getStreetAddress()))).thenReturn(wdUserHRBUConfig);
        var adUserHRBUConfig = new HrbuConfig();
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(prevOktaUser.getHrbu()), Mockito.eq(prevOktaUser.getCity()), Mockito.eq(prevOktaUser.getStreetAddress()))).thenReturn(adUserHRBUConfig);

        var groupDto = LdapRepositorySpringTest.adGroupGenerator.apply(1);
        Mockito.when(ldapService.findUserGroups(Mockito.eq(prevOktaUser.getDn()))).thenReturn(List.of(groupDto));


        prevOktaUser.setEmployee(false);
        prevOktaUser.setWorkerTypeDescriptor("Regular");
        nextOktaUser.setEmployee(false);
        nextOktaUser.setWorkerTypeDescriptor("Contractor");
/*
if (cwtOld == WorkerTypeDescriptorEnum.CWT_EMPLOYEE && cwtNew == WorkerTypeDescriptorEnum.CWT_CONTRACTOR) {
            newGroups = cwtChangeGroups(wdUserHRBUConfig, userGroups, true, user.getLastName());
        }
 */
        event = eventBuilder.build();
        instance.processEvent(event);

        prevOktaUser.setEmployee(false);
        prevOktaUser.setWorkerTypeDescriptor("Contractor");
        nextOktaUser.setEmployee(false);
        nextOktaUser.setWorkerTypeDescriptor("Regular");
        /*
        if (cwtOld == WorkerTypeDescriptorEnum.CWT_CONTRACTOR && cwtNew == WorkerTypeDescriptorEnum.CWT_EMPLOYEE) {
            newGroups = cwtChangeGroups(wdUserHRBUConfig, userGroups, false, user.getLastName());
        }
         */
        event = eventBuilder.build();
        instance.processEvent(event);


        prevOktaUser.setEmployee(false);
        prevOktaUser.setWorkerTypeDescriptor("Contractor");
        nextOktaUser.setEmployee(false);
        nextOktaUser.setWorkerTypeDescriptor("utside Company Worker");
        /*
        newGroups = cwtGenerateGroups(wdUserHRBUConfig, user.getWorkerTypeDescriptor(), user.isEmployee(), user.getLastName());
         */
        event = eventBuilder.build();
        instance.processEvent(event);


/*
        Set<AdGroup> removedGroups = modifyGroupMembership(event.getDomainConfig(), user.getDn(), newGroups);
        auditService.audit(generateEvent(event).situation(ADD_GROUPS)
                .message(String.format("Conversion from %s to %s for : %s inside [hrbu-id: %s]", cwtOld.getValue(), cwtNew.getValue(),
                        user.getUserPrincipalName(), wdUserHRBUConfig.getId()))
                .newValues(ConverterUtils.writeValueAsString(removedGroups)).build());
         */
    }

    @Test
    void onUpdateClinicalTransferAndHRBUTransfer() throws InvalidNameException {
        for (String stage : List.of("ClinicalTransfer", "HRBUTransfer")) {
            Mockito.reset(messageBrokerPublisher, ldapService, findManagerService, configurationClient);

            ActiveDirectoryProcessor instance = getInstance();

            OktaUser nextOktaUser = new OktaUser();
            nextOktaUser.setUserId(UUID.randomUUID().toString());
            nextOktaUser.setDn(new LdapName("CN=User1Next,OU=Test,DC=mshusontest,DC=com"));
            OktaUser prevOktaUser = new OktaUser();
            prevOktaUser.setUserId(UUID.randomUUID().toString());
            prevOktaUser.setDn(new LdapName("CN=User1Prev,OU=Test,DC=mshusontest,DC=com"));

            var eventBuilder = CoreEvent.builder()
                    .target("passport")
                    .stage(stage)
                    .scenario(ScenarioEnum.UPDATE)
                    .module(ModuleEnum.ACTIVE_DIRECTORY)
                    .metrics(new ArrayList<>())
                    .nextOktaUser(nextOktaUser)
                    .prevOktaUser(prevOktaUser);

            var event = eventBuilder.build();

            var workerId = UUID.randomUUID().toString();
            nextOktaUser.setWorkerId(workerId);

            var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
            userDto.setManager(new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com"));

            userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
            userDto.setManager(new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com"));

            var wdUserHRBUConfig = new HrbuConfig();
            Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(nextOktaUser.getHrbu()), Mockito.eq(nextOktaUser.getCity()), Mockito.eq(nextOktaUser.getStreetAddress()))).thenReturn(wdUserHRBUConfig);
            var adUserHRBUConfig = new HrbuConfig();
            Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(prevOktaUser.getHrbu()), Mockito.eq(prevOktaUser.getCity()), Mockito.eq(prevOktaUser.getStreetAddress()))).thenReturn(adUserHRBUConfig);

            var userManager = new Manager();
            userManager.setUser(LdapRepositorySpringTest.adUserGenerator.apply(10));
            nextOktaUser.setManagerObject(userManager);

            var manager = new Manager();
            manager.setUser(LdapRepositorySpringTest.adUserGenerator.apply(11));

            Mockito.when(findManagerService.findManager(Mockito.eq(wdUserHRBUConfig), Mockito.eq(adUserHRBUConfig),
                    Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                    Mockito.eq(nextOktaUser.getExecutiveDirectorUserId()), Mockito.eq(nextOktaUser.getExecutiveDirectorHrbu()),
                    Mockito.eq(false), Mockito.eq(false))
            ).thenReturn(manager);

            //commonTermination(event, linkedManager);
            var domainConfig = DomainConfig.builder().build();
            var domainConfigs = List.of(domainConfig);
            Mockito.when(configurationClient.allDomainConfigs()).thenReturn(domainConfigs);

            var server1 = LdapRepositorySpringTest.adServerGenerator.apply(1);
            Mockito.when(ldapService.findManagedServers(Mockito.any(), Mockito.eq(nextOktaUser.getDn()))).thenReturn(List.of(server1));
            var server2 = LdapRepositorySpringTest.adServerGenerator.apply(2);
            Mockito.when(ldapService.findManagedServers(Mockito.any(), Mockito.eq(prevOktaUser.getDn()))).thenReturn(List.of(server2));
            Set<String> serverNames = Stream.of(server1, server2).map(AdServer::getCn).collect(Collectors.toSet());

            var adminDto1 = LdapRepositorySpringTest.adUserGenerator.apply(31);
            adminDto1.setUid(UUID.randomUUID().toString());
            var adminDto2 = LdapRepositorySpringTest.adUserGenerator.apply(32);
            adminDto2.setUid(UUID.randomUUID().toString());
            Mockito.when(ldapService.findAdminsManagedByDN(Mockito.any(), Mockito.eq(nextOktaUser.getDn()))).thenReturn(
                    Map.of(domainConfig, List.of(adminDto1)));
            Mockito.when(ldapService.findAdminsManagedByDN(Mockito.any(), Mockito.eq(prevOktaUser.getDn()))).thenReturn(
                    Map.of(domainConfig, List.of(adminDto2)));

            var groupDto1 = LdapRepositorySpringTest.adGroupGenerator.apply(31);
            groupDto1.setUid(UUID.randomUUID().toString());
            var groupDto2 = LdapRepositorySpringTest.adGroupGenerator.apply(32);
            groupDto2.setUid(UUID.randomUUID().toString());
            Mockito.when(ldapService.findGroupsManagedByDN(Mockito.any(), Mockito.eq(nextOktaUser.getDn()))).thenReturn(List.of(groupDto1));
            Mockito.when(ldapService.findGroupsManagedByDN(Mockito.any(), Mockito.eq(prevOktaUser.getDn()))).thenReturn(List.of(groupDto2));


            var accountDto1 = LdapRepositorySpringTest.adUserGenerator.apply(33);
            accountDto1.setUid(UUID.randomUUID().toString());
            var accountDto2 = LdapRepositorySpringTest.adUserGenerator.apply(34);
            accountDto2.setUid(UUID.randomUUID().toString());
            Mockito.when(ldapService.findServiceAccountsManagedByDN(Mockito.any(), Mockito.eq(nextOktaUser.getDn()))).thenReturn(List.of(accountDto1));
            Mockito.when(ldapService.findServiceAccountsManagedByDN(Mockito.any(), Mockito.eq(prevOktaUser.getDn()))).thenReturn(List.of(accountDto2));

            //TODO processOwnGroups(event, wdUserHRBUConfig, user);

            instance.processEvent(event);
            Assertions.assertEquals(manager, nextOktaUser.getManagerObject());
            Assertions.assertEquals(wdUserHRBUConfig.getHomeDir() + nextOktaUser.getUserName(), nextOktaUser.getHomeDirectory());

            //commonTermination(event, linkedManager);
            Mockito.verify(ldapService)
                    .updateObjectsManager(Mockito.any(), Mockito.eq(manager.getUser().getDn()), Mockito.eq(LdapEntryType.SERVER), Mockito.eq(LdapUtils.GROUP_COMPUTER_MANAGER));
            var auditEvent = AuditEvent.generateEvent(event)
                    .module(ModuleEnum.ACTIVE_DIRECTORY)
                    .status("SUCCESS")
                    .situation("passport.ad.manager")
                    .message("Updated objects manager to: " + manager.getUser().getDn())
                    .newValues(Stream.of(server1, server2).map(server -> String.format("[%s]@[%s]", server.getDn(), server.getDomain())).collect(Collectors.joining("; ")))
                    .build();
            Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
            Assertions.assertEquals(serverNames, nextOktaUser.getServerNames());

            auditEvent = AuditEvent.generateEvent(event)
                    .module(ModuleEnum.ACTIVE_DIRECTORY)
                    .status("SUCCESS")
                    .situation("passport.ad.remove-admins")
                    .message(String.format("Disabled admin accounts at [%s] domain", domainConfig.getId()))
                    .newValues(Stream.of(adminDto1, adminDto2).map(u -> u.getDn().toString()).collect(Collectors.joining("; ")))
                    .build();
            Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));

            auditEvent = AuditEvent.generateEvent(event)
                    .module(ModuleEnum.ACTIVE_DIRECTORY)
                    .status("SUCCESS")
                    .situation("passport.ad.set-groups-manager")
                    .message(String.format("Set new manager [%s] for groups", manager.getUser().getDn()))
                    .newValues(Stream.of(groupDto1, groupDto2).map(u -> u.getDn().toString()).collect(Collectors.joining("; ")))
                    .build();
            Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));

            auditEvent = AuditEvent.generateEvent(event)
                    .module(ModuleEnum.ACTIVE_DIRECTORY)
                    .status("SUCCESS")
                    .situation("passport.ad.set-admins-manager")
                    .message(String.format("Set new manager [%s] for admin accounts", manager.getUser().getDn()))
                    .newValues(Stream.of(accountDto1, accountDto2).map(u -> u.getDn().toString()).collect(Collectors.joining("; ")))
                    .build();
            Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));


            List<Map<String, String>> serviceAccounts = Stream.of(accountDto1, accountDto2).map(account -> Map.of(
                    "uid", account.getUid(),
                    "domain", account.getDomain(),
                    "dn", account.getDn().toString(),
                    "manager", nextOktaUser.getDn().toString()
            )).collect(Collectors.toList());

            auditEvent = AuditEvent.generateEvent(event)
                    .module(ModuleEnum.ACTIVE_DIRECTORY)
                    .status("SUCCESS")
                    .situation("passport.ad.set-service-account-manager")
                    .message(String.format("Set new manager[%s] for service accounts", manager.getUser().getDn()))
                    .newValues(serviceAccounts.stream().map(map -> String.join("@", map.get("uid"), map.get("domain"))).collect(Collectors.joining("; ")))
                    .build();
            Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));

        }
    }

    @Test
    void onUpdateTXOTransfer() throws InvalidNameException {
        ActiveDirectoryProcessor instance = getInstance();

        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setEmployee(false);
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setEmployee(false);
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        prevOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));

        var eventBuilder = CoreEvent.builder()
                .target("passport")
                .stage("TXOTransfer")
                .scenario(ScenarioEnum.UPDATE)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .metrics(new ArrayList<>())
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser);

        var event = eventBuilder.build();

        var workerId = UUID.randomUUID().toString();
        nextOktaUser.setWorkerId(workerId);

        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        userDto.setManager(new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com"));

        userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        userDto.setManager(new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com"));

        String commonGroupName = "SVR_common";
        var wdUserHRBUConfig = getHrbuConfig(commonGroupName);
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(nextOktaUser.getHrbu()), Mockito.eq(nextOktaUser.getCity()), Mockito.eq(nextOktaUser.getStreetAddress()))).thenReturn(wdUserHRBUConfig);
        var adUserHRBUConfig = getHrbuConfig(commonGroupName);
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(prevOktaUser.getHrbu()), Mockito.eq(prevOktaUser.getCity()), Mockito.eq(prevOktaUser.getStreetAddress()))).thenReturn(adUserHRBUConfig);

        AdGroup commonGroup = LdapRepositorySpringTest.adGroupGenerator.apply(1).toBuilder()
                .displayName(commonGroupName)
                .cn(commonGroupName)
                .dn(new LdapName("CN=" + commonGroupName + ",OU=Test,DC=mshusontest,DC=com"))
                .build();
        GroupMappingDto commonGroupDto = new GroupMappingDto(1L, commonGroupName, new LdapName("CN=" + commonGroupName + ",OU=Test,DC=mshusontest,DC=com"), GroupMappingType.DEFAULT, "");
        Mockito.when(configurationClient.findGroupMappingsByType(Mockito.eq(GroupMappingType.DEFAULT))).thenReturn(Collections.singletonList(commonGroupDto));
        Mockito.when(configurationClient.findGroupMappingsByType(Mockito.eq(GroupMappingType.HRBU))).thenReturn(Collections.emptyList());
        Mockito.when(configurationClient.findGroupMappingsByNames(Mockito.any())).thenAnswer((Answer<List<GroupMappingDto>>) invocation -> ((Collection<String>) invocation.getArgument(0)).stream()
                .map(Object::toString)
                .map(this::toGroupModel)
                .map(model -> new GroupMappingDto(0L, model.getName(), model.getDn(), GroupMappingType.DEFAULT, ""))
                .collect(Collectors.toList()));

        Mockito.when(ldapService.findUserGroups(Mockito.eq(nextOktaUser.getDn()))).thenReturn(Collections.singletonList(commonGroup));

        instance.processEvent(event);

        Mockito.verify(ldapService).removeGroupMemberships(Mockito.eq(nextOktaUser.getDn().toString()), Mockito.any());
        var auditEvent = AuditEvent.generateEvent(event)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .status("SUCCESS")
                .situation("passport.ad.remove-service-groups")
                .message(String.format("Removing [%s] user from service groups", nextOktaUser.getDn()))
                .newValues(Stream.of(commonGroup).map(AdGroup::getDn).map(LdapName::toString).collect(Collectors.joining("; ")))
                .build();
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
    }

    @Test
    void onUpdateCommit() throws InvalidNameException {
        ActiveDirectoryProcessor instance = getInstance();

        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        prevOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));

        var eventBuilder = CoreEvent.builder()
                .target("passport")
                .stage("commit")
                .scenario(ScenarioEnum.UPDATE)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .metrics(new ArrayList<>())
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser);

        var event = eventBuilder.build();

        var workerId = UUID.randomUUID().toString();
        nextOktaUser.setWorkerId(workerId);

        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        userDto.setManager(new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com"));

        userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        userDto.setManager(new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com"));

        var wdUserHRBUConfig = new HrbuConfig();
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(nextOktaUser.getHrbu()), Mockito.eq(nextOktaUser.getCity()), Mockito.eq(nextOktaUser.getStreetAddress()))).thenReturn(wdUserHRBUConfig);
        var adUserHRBUConfig = new HrbuConfig();
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(prevOktaUser.getHrbu()), Mockito.eq(prevOktaUser.getCity()), Mockito.eq(prevOktaUser.getStreetAddress()))).thenReturn(adUserHRBUConfig);


        Mockito.when(ldapService.findUserByDNDirect(Mockito.eq(nextOktaUser.getDn().toString()))).thenReturn(null);
        Mockito.when(ldapService.findUserByWorkerId(Mockito.eq(workerId))).thenReturn(null);
        instance.processEvent(event);
        Assertions.assertTrue(event.isFailed());

        event = eventBuilder.build();
        Mockito.when(ldapService.findUserByDNDirect(Mockito.eq(nextOktaUser.getDn().toString()))).thenReturn(null);
        Mockito.when(ldapService.findUserByWorkerId(Mockito.eq(workerId))).thenReturn(null);
        instance.processEvent(event);
        Assertions.assertTrue(event.isFailed());

        event = eventBuilder.build();
        Mockito.when(ldapService.findUserByDNDirect(Mockito.eq(nextOktaUser.getDn().toString()))).thenReturn(userDto);

        var manager = new Manager();
        manager.setUser(LdapRepositorySpringTest.adUserGenerator.apply(11));
        Mockito.when(findManagerService.getManagerByDn(Mockito.eq(userDto.getManager()), Mockito.eq(adUserHRBUConfig),
                Mockito.any(), Mockito.eq(nextOktaUser.getExecutiveDirectorUserId()), Mockito.eq(nextOktaUser.getExecutiveDirectorHrbu()), Mockito.eq(true))
        ).thenReturn(manager);

        Mockito.when(findManagerService.getManagerByWorkerId(
                Mockito.eq(nextOktaUser.getManagerId()),
                Mockito.eq(wdUserHRBUConfig),
                Mockito.eq(nextOktaUser.getManagerUserId()),
                Mockito.eq(nextOktaUser.getManagerHrbu()),
                Mockito.any(),
                Mockito.eq(nextOktaUser.getExecutiveDirectorUserId()),
                Mockito.eq(nextOktaUser.getExecutiveDirectorHrbu())
        )).thenReturn(manager);

        var auditEvent = AuditEvent.generateEvent(event)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .status("SUCCESS")
                .situation("passport.ad.manager")
                .message(String.format("Calculated manager for [%s] user", nextOktaUser.getDn()))
                .newValues(manager.getManagerAsString())
                .build();

        instance.processEvent(event);


        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
        Assertions.assertEquals(manager.getUser().getDn(), nextOktaUser.getManager());
        Assertions.assertEquals(manager, nextOktaUser.getManagerObject());
        Assertions.assertEquals(manager.getUser().getDn(), prevOktaUser.getManager());
        Assertions.assertEquals(manager, prevOktaUser.getManagerObject());
        Assertions.assertFalse(manager.isLinked());
    }

    @Test
    void onTerminate() throws InvalidNameException {
        ActiveDirectoryProcessor instance = getInstance();

        var eventBuilder = CoreEvent.builder()
                .target("passport")
                .stage("test")
                .scenario(ScenarioEnum.TERMINATE)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .metrics(new ArrayList<>());
        instance.processEvent(eventBuilder.build());

        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.OKTA_CLIENT), Mockito.any(CoreEvent.class));
        Mockito.verifyNoMoreInteractions(messageBrokerPublisher, ldapService, findManagerService, configurationClient, auditService);


        var event = eventBuilder.build();
        event.setStage("start");
        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        prevOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        event.setNextOktaUser(nextOktaUser);
        event.setPrevOktaUser(prevOktaUser);

        prevOktaUser.setHrbu("HRBU");
        prevOktaUser.setCity("City");
        prevOktaUser.setStreetAddress("StreetAddress");

        var prevHRBUConfig = new HrbuConfig();
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(prevOktaUser.getHrbu()),
                Mockito.eq(prevOktaUser.getCity()), Mockito.eq(prevOktaUser.getStreetAddress()))).thenReturn(prevHRBUConfig);
        var prevDomainConfig = DomainConfig.builder().build();
        Mockito.when(configurationClient.findDomainConfigByOu(Mockito.eq(prevOktaUser.getDn()))).thenReturn(prevDomainConfig);

        var manager = new Manager();
        manager.setUser(LdapRepositorySpringTest.adUserGenerator.apply(11));
        prevOktaUser.setManager(new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com"));
        Mockito.when(findManagerService.getManagerByDn(Mockito.eq(prevOktaUser.getManager()), Mockito.eq(prevHRBUConfig),
                Mockito.any(), Mockito.eq(prevOktaUser.getExecutiveDirectorUserId()), Mockito.eq(prevOktaUser.getExecutiveDirectorHrbu()), Mockito.eq(false))
        ).thenReturn(manager);
        var cn = "User1";
        Mockito.when(ldapService.generateCn(Mockito.eq(prevOktaUser.getCn()), Mockito.eq(prevOktaUser.getDn()), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(cn);

        //TODO commonTermination(event, manager);

        var groupDto = LdapRepositorySpringTest.adGroupGenerator.apply(1);
        Mockito.when(ldapService.findUserGroups(Mockito.eq(prevOktaUser.getDn()))).thenReturn(List.of(groupDto));
        //TODO processOwnGroups(event, prevHRBUConfig, prev);

        instance.processEvent(event);
        Assertions.assertEquals(manager, prevOktaUser.getManagerObject());
        Assertions.assertEquals(cn, nextOktaUser.getCn());

        event = eventBuilder.build();
        event.setStage("prepare");
        event.setNextOktaUser(nextOktaUser);
        event.setPrevOktaUser(prevOktaUser);
        instance.processEvent(event);


        event.setModule(ModuleEnum.ACTIVE_DIRECTORY);
        event.setFailed(false);
        nextOktaUser.setWorkerId(null);
        instance.processEvent(event);
        Assertions.assertTrue(event.isFailed());

        var workerId = UUID.randomUUID().toString();
        nextOktaUser.setWorkerId(workerId);

        event.setModule(ModuleEnum.ACTIVE_DIRECTORY);
        event.setFailed(false);
        Mockito.when(ldapService.findUserByWorkerId(Mockito.eq(workerId))).thenReturn(null);
        instance.processEvent(event);
        Assertions.assertTrue(event.isFailed());

        event.setModule(ModuleEnum.ACTIVE_DIRECTORY);
        event.setFailed(false);
        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        userDto.setManager(new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com"));
        Mockito.when(ldapService.findUserByWorkerId(Mockito.eq(workerId))).thenReturn(userDto);

        instance.processEvent(event);
        Assertions.assertEquals(userDto.getDn(), nextOktaUser.getDn());
        Assertions.assertEquals(userDto.getDn().getRdn(userDto.getDn().size() - 1).getValue().toString(), nextOktaUser.getCn());
        Assertions.assertEquals(userDto.getManager(), nextOktaUser.getManager());
    }

    @Test
    void onRequest() throws InvalidNameException {
        ActiveDirectoryProcessor instance = getInstance();
        var eventBuilder = CoreEvent.builder()
                .target("passport")
                .stage("test")
                .scenario(ScenarioEnum.REQUEST)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .metrics(new ArrayList<>());
        instance.processEvent(eventBuilder.build());

        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.OKTA_CLIENT), Mockito.any(CoreEvent.class));
        Mockito.verifyNoMoreInteractions(messageBrokerPublisher, ldapService, findManagerService, configurationClient, auditService);

        var event = eventBuilder.build();
        event.setStage("adInfo");
        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        var adInfo = new AdInfo();
        nextOktaUser.setAdInfo(adInfo);
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        event.setNextOktaUser(nextOktaUser);
        event.setPrevOktaUser(prevOktaUser);
        nextOktaUser.setSamAccountName("samAccountName1");

        var userDto = LdapRepositorySpringTest.adUserGenerator.apply(1);
        var groupDto = LdapRepositorySpringTest.adGroupGenerator.apply(1);
        var expectedGroup = AdGroup.builder()
                .dn(groupDto.getDn())
                .cn(groupDto.getCn())
                .description(groupDto.getDescription())
                .build();
        adInfo.setRequested(true);
        adInfo.getCurrent().setRequested(true);
        adInfo.getOriginal().setRequested(true);

        Mockito.when(ldapService.findUserByDNDirect(Mockito.eq(nextOktaUser.getDn().toString()))).thenReturn(userDto);
        Mockito.when(ldapService.findUserGroups(Mockito.eq(nextOktaUser.getDn()))).thenReturn(Arrays.asList(groupDto));
        instance.processEvent(event);
        Assertions.assertFalse(nextOktaUser.getAdInfo().isRequested());
        Assertions.assertFalse(nextOktaUser.getAdInfo().getCurrent().isRequested());
        Assertions.assertTrue(nextOktaUser.getAdInfo().getCurrent().isSet());
        Assertions.assertTrue(nextOktaUser.getAdInfo().getOriginal().isRequested());
        Assertions.assertFalse(nextOktaUser.getAdInfo().getOriginal().isSet());
        Assertions.assertEquals(1, nextOktaUser.getAdInfo().getCurrent().getGroups().size());
        Assertions.assertEquals(expectedGroup, nextOktaUser.getAdInfo().getCurrent().getGroups().iterator().next());

        event.setModule(ModuleEnum.ACTIVE_DIRECTORY);
        adInfo.getCurrent().setRequested(false);
        adInfo.getOriginal().setRequested(true);

        instance.processEvent(event);
        Assertions.assertFalse(nextOktaUser.getAdInfo().isRequested());
        Assertions.assertFalse(nextOktaUser.getAdInfo().getCurrent().isRequested());
        Assertions.assertTrue(nextOktaUser.getAdInfo().getCurrent().isSet());
        Assertions.assertFalse(nextOktaUser.getAdInfo().getOriginal().isRequested());
        Assertions.assertTrue(nextOktaUser.getAdInfo().getOriginal().isSet());
        Assertions.assertEquals(1, nextOktaUser.getAdInfo().getOriginal().getGroups().size());
        Assertions.assertEquals(1, nextOktaUser.getAdInfo().getOriginal().getGroups().size());
        Assertions.assertEquals(expectedGroup, nextOktaUser.getAdInfo().getOriginal().getGroups().iterator().next());

        event.setModule(ModuleEnum.ACTIVE_DIRECTORY);
        adInfo.getCurrent().setRequested(false);
        adInfo.getCurrent().setSet(false);
        adInfo.getOriginal().setRequested(false);
        adInfo.getOriginal().setSet(false);

        instance.processEvent(event);
        Assertions.assertFalse(nextOktaUser.getAdInfo().isRequested());
        Assertions.assertFalse(nextOktaUser.getAdInfo().getCurrent().isRequested());
        Assertions.assertFalse(nextOktaUser.getAdInfo().getCurrent().isSet());
        Assertions.assertFalse(nextOktaUser.getAdInfo().getOriginal().isRequested());
        Assertions.assertFalse(nextOktaUser.getAdInfo().getOriginal().isSet());
    }

    @Test
    void onDeferred() throws InvalidNameException {
        ActiveDirectoryProcessor instance = getInstance();

        var eventBuilder = CoreEvent.builder()
                .target("passport")
                .stage("test")
                .scenario(ScenarioEnum.DEFERRED)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .metrics(new ArrayList<>());
        instance.processEvent(eventBuilder.build());

        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.OKTA_CLIENT), Mockito.any(CoreEvent.class));
        Mockito.verifyNoMoreInteractions(messageBrokerPublisher, ldapService, findManagerService, configurationClient, auditService);

        var event = eventBuilder.build();
        event.setStage("linkmanager");
        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        var adInfo = new AdInfo();
        nextOktaUser.setAdInfo(adInfo);
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        event.setNextOktaUser(nextOktaUser);
        event.setPrevOktaUser(prevOktaUser);

        var manager = new Manager();
        manager.setUser(LdapRepositorySpringTest.adUserGenerator.apply(11));
        Mockito.when(findManagerService.getManagerByWorkerId(Mockito.eq(nextOktaUser.getManagerId()), Mockito.any(), Mockito.any(),
                Mockito.eq(nextOktaUser.getManagerUserId()), Mockito.eq(nextOktaUser.getManagerHrbu()),
                Mockito.any(), Mockito.eq(nextOktaUser.getExecutiveDirectorUserId()), Mockito.eq(nextOktaUser.getExecutiveDirectorHrbu()))
        ).thenReturn(manager);

        instance.processEvent(event);
        Assertions.assertTrue(manager.isLinked());
        Assertions.assertEquals(manager, nextOktaUser.getManagerObject());
        Assertions.assertEquals(manager.getUser().getDn(), nextOktaUser.getManager());
        Mockito.verify(ldapService).updateObjectsManager(Mockito.any(),
                Mockito.eq(manager.getUser().getDn()), Mockito.eq(LdapEntryType.USER), Mockito.eq(LdapUtils.ACCOUNT_MANAGER));


        manager = new Manager();
        manager.setUser(LdapRepositorySpringTest.adUserGenerator.apply(11));
        nextOktaUser.setManager(manager.getUser().getDn());
        event = eventBuilder.build();
        event.setStage("getManagerForEMail");
        event.setNextOktaUser(nextOktaUser);
        event.setPrevOktaUser(prevOktaUser);

        Mockito.when(findManagerService.getManagerByDn(Mockito.eq(nextOktaUser.getManager()), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.eq(nextOktaUser.getExecutiveDirectorUserId()), Mockito.eq(nextOktaUser.getExecutiveDirectorHrbu()), Mockito.eq(false))
        ).thenReturn(manager);

        instance.processEvent(event);
        Assertions.assertTrue(manager.isForEMail());
        Assertions.assertEquals(manager, nextOktaUser.getManagerObject());
    }

    @Test
    void onSynchronize() throws InvalidNameException {
        ActiveDirectoryProcessor instance = getInstance();

        var eventBuilder = CoreEvent.builder()
                .target("passport")
                .stage("test")
                .scenario(ScenarioEnum.SYNCHRONIZE)
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .metrics(new ArrayList<>());
        instance.processEvent(eventBuilder.build());

        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.OKTA_CLIENT), Mockito.any(CoreEvent.class));
        Mockito.verifyNoMoreInteractions(messageBrokerPublisher, ldapService, findManagerService, configurationClient, auditService);

        var event = eventBuilder.build();
        event.setStage("start");
        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        var adInfo = new AdInfo();
        nextOktaUser.setAdInfo(adInfo);
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        event.setNextOktaUser(nextOktaUser);
        event.setPrevOktaUser(prevOktaUser);
        event.setFailed(false);


        nextOktaUser.setWorkerId(null);
        event.setFailed(false);
        instance.processEvent(event);
        Assertions.assertTrue(event.isFailed());


        var workerId = UUID.randomUUID().toString();
        nextOktaUser.setWorkerId(workerId);
        event.setModule(ModuleEnum.ACTIVE_DIRECTORY);

        Mockito.when(ldapService.findUserByWorkerId(Mockito.eq(workerId))).thenReturn(null);

        instance.processEvent(event);
        Assertions.assertTrue(event.isFailed());

        event.setModule(ModuleEnum.ACTIVE_DIRECTORY);
        event.setFailed(false);
        var worker = LdapRepositorySpringTest.adUserGenerator.apply(11);
        worker.setManager(null);
        Mockito.when(ldapService.findUserByWorkerId(Mockito.eq(workerId))).thenReturn(worker);

        instance.processEvent(event);

        Assertions.assertEquals(worker.getDn(), nextOktaUser.getDn());
        Assertions.assertEquals(worker.getDn().getRdn(worker.getDn().size() - 1).getValue().toString(), nextOktaUser.getCn());
        Assertions.assertEquals(worker.getManager(), nextOktaUser.getManager());

        Assertions.assertEquals(worker.getUserPrincipalName(), nextOktaUser.getUserPrincipalName());
        Assertions.assertEquals(worker.getSamAccountName(), nextOktaUser.getSamAccountName());
        Assertions.assertEquals(worker.getAccountExpires(), nextOktaUser.getAccountExpires());
        Assertions.assertEquals(worker.getEmailPrimary(), nextOktaUser.getEmailPrimary());
        Assertions.assertEquals(worker.getEmailSecondary(), nextOktaUser.getEmailSecondary());
        Assertions.assertEquals(worker.getEmailSecondaryAdditional(), nextOktaUser.getEmailSecondaryAdditional());
        Assertions.assertEquals(nextOktaUser.getEmailPrimary(), nextOktaUser.getMail());

        event.setModule(ModuleEnum.ACTIVE_DIRECTORY);
        event.setFailed(false);
        worker.setManager(new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com"));

        Mockito.when(ldapService.findUserByWorkerId(Mockito.eq(workerId))).thenReturn(worker);
        var manager = new Manager();
        manager.setUser(LdapRepositorySpringTest.adUserGenerator.apply(12));
        Mockito.when(findManagerService.getManagerByDn(Mockito.eq(worker.getManager()), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.eq(nextOktaUser.getExecutiveDirectorUserId()), Mockito.eq(nextOktaUser.getExecutiveDirectorHrbu()), Mockito.eq(true))
        ).thenReturn(manager);

        instance.processEvent(event);
        Assertions.assertEquals(worker.getDn(), nextOktaUser.getDn());
        Assertions.assertEquals(worker.getDn().getRdn(worker.getDn().size() - 1).getValue().toString(), nextOktaUser.getCn());
        Assertions.assertEquals(worker.getManager(), nextOktaUser.getManager());
        Assertions.assertEquals(manager.isReal(), manager.isLinked());
        Assertions.assertEquals(manager, nextOktaUser.getManagerObject());

        Assertions.assertEquals(worker.getUserPrincipalName(), nextOktaUser.getUserPrincipalName());
        Assertions.assertEquals(worker.getSamAccountName(), nextOktaUser.getSamAccountName());
        Assertions.assertEquals(worker.getAccountExpires(), nextOktaUser.getAccountExpires());
        Assertions.assertEquals(worker.getEmailPrimary(), nextOktaUser.getEmailPrimary());
        Assertions.assertEquals(worker.getEmailSecondary(), nextOktaUser.getEmailSecondary());
        Assertions.assertEquals(worker.getEmailSecondaryAdditional(), nextOktaUser.getEmailSecondaryAdditional());
        Assertions.assertEquals(nextOktaUser.getEmailPrimary(), nextOktaUser.getMail());
    }

    @Test
    void process() throws InvalidNameException {
        ActiveDirectoryProcessor instance = getInstance();

        var oktaUser = CommonUser.builder()
                .dn("DC=usoncologyuat,DC=com")
                .cn(UUID.randomUUID().toString())
                .workerId(UUID.randomUUID().toString())
                .logonHours(Hex.encodeHexString(new byte[21]))
                .proxyAddresses(Collections.emptyList())
                .showInAddressBook(Collections.emptyList())
                .memberOf(Arrays.asList(new CommonGroup("orgUnit", "DC=com")))
                .build();
        var messageBuilder = SyncCheck.builder()
                .oktaUserId(UUID.randomUUID().toString())
                .user(oktaUser);

        var adResponse = OktaUser.builder()
                .dn(new LdapName(oktaUser.getDn()))
                .cn(oktaUser.getCn())
                .workerId(oktaUser.getWorkerId())
                .proxyAddresses(Collections.emptySet())
                .showInAddressBook(Collections.emptySet())
                .memberOf(Collections.emptySet())
                .build();
        Mockito.when(ldapService.findUserByWorkerId(oktaUser.getWorkerId())).thenReturn(adResponse);

        instance.process(messageBuilder.build());
        Mockito.verifyNoInteractions(messageBrokerPublisher, findManagerService, configurationClient, auditService);

        Mockito.reset(ldapService, messageBrokerPublisher, findManagerService, configurationClient, auditService);
        Mockito.when(ldapService.findUserByWorkerId(oktaUser.getWorkerId())).thenReturn(null);
        var message = messageBuilder.build();
        instance.process(message);

        var auditEvent = AuditEvent.builder()
                .date(new Date())
                .app(AuditEvent.Application.PASSPORT)
                .oktaUserId(message.getOktaUserId())
                .message("Cannot find user by workerId: " + oktaUser.getWorkerId())
                .situation("Sync check")
                .status("ERROR")
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .build();

        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
        Mockito.verifyNoMoreInteractions(auditService);
        Mockito.verifyNoInteractions(messageBrokerPublisher, findManagerService);

        var adResponse2 = adResponse.toBuilder().city("citi2").build();
        Mockito.reset(ldapService, messageBrokerPublisher, findManagerService, configurationClient, auditService);
        Mockito.when(ldapService.findUserByWorkerId(oktaUser.getWorkerId())).thenReturn(adResponse2);
        instance.process(message);

        auditEvent = AuditEvent.builder()
                .date(new Date())
                .app(AuditEvent.Application.PASSPORT)
                .oktaUserId(message.getOktaUserId())
                .message("ERROR")
                .situation("Sync check")
                .status("ERROR")
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues(CommonUser.printDiff(oktaUser.toBuilder().city(adResponse2.getCity()).build(), oktaUser))
                .build();;

        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
        Mockito.verifyNoMoreInteractions(auditService);
        Mockito.verifyNoInteractions(messageBrokerPublisher, findManagerService);
    }
}