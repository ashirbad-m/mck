package com.mckesson.ad.entity.mapper;

import com.mckesson.common.ldap.LdapUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class UidUtilsTest {

    @Test
    void guid2String() {
        Assertions.assertNull(UidUtils.guid2String(null));
        var expected = "119d0d80-699d-4e81-8e4e-5477e22ac1b3";
        Assertions.assertEquals(expected, UidUtils.guid2String(LdapUtils.string2Guid(expected)));
    }

    @Test
    void string2Guid() {
        Assertions.assertNull(UidUtils.string2Guid(null));
        var expected = "119d0d80-699d-4e81-8e4e-5477e22ac1b3";
        Assertions.assertArrayEquals(LdapUtils.string2Guid(expected), UidUtils.string2Guid(expected));
    }
}