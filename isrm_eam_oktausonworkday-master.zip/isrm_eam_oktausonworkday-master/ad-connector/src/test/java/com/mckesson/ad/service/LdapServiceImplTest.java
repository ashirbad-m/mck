package com.mckesson.ad.service;

import com.mckesson.ad.config.LdapDomainConfiguration;
import com.mckesson.ad.config.LdapServer;
import com.mckesson.ad.repository.LdapEntryType;
import com.mckesson.ad.repository.LdapRepository;
import com.mckesson.ad.repository.LdapRepositorySpringTest;
import com.mckesson.common.domain.Manager;
import com.mckesson.common.domain.OktaUser;
import com.mckesson.common.imdg.TestImdgInstance;
import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.HrbuConfig;
import com.mckesson.common.model.WorkdayConfig;
import com.mckesson.common.workday.configuration.controller.ConfigurationClient;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.ldap.query.ContainerCriteria;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.*;
import java.util.function.BiFunction;

class LdapServiceImplTest {

    @Test
    void generateUID() {
        LdapServer ldapServer = new LdapServer();
        //ldapServer.getLdapRepository().find()
        /*
        String result = generateVerifiedValue(quadrupleStringValueGenerator(uidBase, "", ""), this::checkSamAccountNamePredicate);
        addKey(KEY_LOGINS, result);
        return result;

            private <E extends AdEntry, D extends OktaEntryDto> List<D> find(DomainConfig domainConfig, LdapQuery query, LdapEntryType<E, D> type) {
        LdapServer ldapServer = ldapDomainConfiguration.getServer(domainConfig.getName());
        LdapRepository ldapRepository = ldapServer.getLdapRepository();
        return ldapRepository.find(query, type);
    }
         */
    }

    @Test
    void removeGroupMemberships() {
        var imdgInstance = new TestImdgInstance();
        var configurationClient = Mockito.mock(ConfigurationClient.class);
        var ldapDomainConfiguration = Mockito.mock(LdapDomainConfiguration.class);
        var instance = new LdapServiceImpl(imdgInstance, configurationClient, ldapDomainConfiguration);

        instance.removeGroupMemberships("test", Collections.emptyList());
        Mockito.verifyNoInteractions(configurationClient, ldapDomainConfiguration);

        var adGroup = LdapRepositorySpringTest.adGroupGenerator.apply(1);

        var ldapServer = Mockito.mock(LdapServer.class);
        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(adGroup.getDomain()))).thenReturn(ldapServer);

        var ldapRepository = Mockito.mock(LdapRepository.class);
        Mockito.when(ldapServer.getLdapRepository()).thenReturn(ldapRepository);

        instance.removeGroupMemberships("test", List.of(adGroup));

        Mockito.verify(ldapRepository).modifyAttributes(Mockito.eq(adGroup), Mockito.any(), Mockito.eq(LdapEntryType.GROUP));
    }

    @Test
    void addGroupMemberships() {
        var imdgInstance = new TestImdgInstance();
        var configurationClient = Mockito.mock(ConfigurationClient.class);
        var ldapDomainConfiguration = Mockito.mock(LdapDomainConfiguration.class);
        var instance = new LdapServiceImpl(imdgInstance, configurationClient, ldapDomainConfiguration);

        var adGroup = LdapRepositorySpringTest.adGroupGenerator.apply(1);
        var domainConfig = DomainConfig.builder().name(adGroup.getDomain()).build();

        instance.addGroupMemberships(domainConfig, "test", Collections.emptyList());
        Mockito.verifyNoInteractions(configurationClient, ldapDomainConfiguration);

        var ldapServer = Mockito.mock(LdapServer.class);
        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);

        var ldapRepository = Mockito.mock(LdapRepository.class);
        Mockito.when(ldapServer.getLdapRepository()).thenReturn(ldapRepository);

        Mockito.when(ldapRepository.find(Mockito.any(ContainerCriteria.class), Mockito.eq(LdapEntryType.GROUP))).thenReturn(List.of(adGroup, adGroup));

        try {
            instance.addGroupMemberships(domainConfig, "test", List.of(adGroup.getCn()));
            Assertions.fail("Wrong behavor");
        } catch (IllegalStateException ex) {
            Assertions.assertEquals("More than 1 group found", ex.getMessage());
            Mockito.verify(ldapRepository, Mockito.never()).modifyAttributes(Mockito.eq(adGroup), Mockito.any(), Mockito.eq(LdapEntryType.GROUP));
        }

        Mockito.reset(ldapRepository);
        Mockito.when(ldapRepository.find(Mockito.any(ContainerCriteria.class), Mockito.eq(LdapEntryType.GROUP))).thenReturn(Collections.emptyList());
        instance.addGroupMemberships(domainConfig, "test", List.of(adGroup.getCn()));
        Mockito.verify(ldapRepository, Mockito.never()).modifyAttributes(Mockito.eq(adGroup), Mockito.any(), Mockito.eq(LdapEntryType.GROUP));

        Mockito.reset(ldapRepository);
        Mockito.when(ldapRepository.find(Mockito.any(ContainerCriteria.class), Mockito.eq(LdapEntryType.GROUP))).thenReturn(List.of(adGroup));

        instance.addGroupMemberships(domainConfig, "test", List.of(adGroup.getCn()));

        Mockito.verify(ldapRepository).modifyAttributes(Mockito.eq(adGroup), Mockito.any(), Mockito.eq(LdapEntryType.GROUP));
    }

    @Test
    void findUserByDNDirect() {
        var imdgInstance = new TestImdgInstance();
        var configurationClient = Mockito.mock(ConfigurationClient.class);
        var ldapDomainConfiguration = Mockito.mock(LdapDomainConfiguration.class);
        var instance = new LdapServiceImpl(imdgInstance, configurationClient, ldapDomainConfiguration);

        var domainConfig = DomainConfig.builder().name("domain").build();
        Mockito.when(configurationClient.allDomainConfigs()).thenReturn(List.of(domainConfig));

        var ldapServer = Mockito.mock(LdapServer.class);
        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);

        var ldapRepository = Mockito.mock(LdapRepository.class);
        Mockito.when(ldapServer.getLdapRepository()).thenReturn(ldapRepository);

        Mockito.when(ldapRepository.find(Mockito.any(ContainerCriteria.class), Mockito.eq(LdapEntryType.USER))).thenReturn(Collections.emptyList());
        Assertions.assertNull(instance.findUserByDNDirect("test"));

        var adUser = LdapRepositorySpringTest.adUserGenerator.apply(1);
        Mockito.when(ldapRepository.find(Mockito.any(ContainerCriteria.class), Mockito.eq(LdapEntryType.USER))).thenReturn(List.of(adUser));
        Assertions.assertEquals(adUser, instance.findUserByDNDirect("test"));
    }

    @Test
    void findUserByWorkerId() throws InvalidNameException {
        var imdgInstance = new TestImdgInstance();
        var configurationClient = Mockito.mock(ConfigurationClient.class);
        var ldapDomainConfiguration = Mockito.mock(LdapDomainConfiguration.class);
        var instance = new LdapServiceImpl(imdgInstance, configurationClient, ldapDomainConfiguration);

        Assertions.assertNull(instance.findUserByWorkerId(null));
        Assertions.assertNull(instance.findUserByWorkerId(""));
        Assertions.assertNull(instance.findUserByWorkerId(" "));

        var rootOU = new LdapName("OU=B2E_Workday,DC=mshusontest,DC=com");
        var domainConfig = DomainConfig.builder().name("domain").workersOu(Set.of(rootOU)).build();
        Mockito.when(configurationClient.allDomainConfigs()).thenReturn(List.of(domainConfig));

        var ldapServer = Mockito.mock(LdapServer.class);
        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);

        var ldapRepository = Mockito.mock(LdapRepository.class);
        Mockito.when(ldapServer.getLdapRepository()).thenReturn(ldapRepository);

        Mockito.when(ldapRepository.truncateOrNull(Mockito.eq(rootOU))).thenReturn(rootOU);
        var adUser = LdapRepositorySpringTest.adUserGenerator.apply(1);
        Mockito.when(ldapRepository.find(Mockito.any(ContainerCriteria.class), Mockito.eq(LdapEntryType.USER))).thenReturn(List.of(adUser));
        Assertions.assertEquals(adUser, instance.findUserByWorkerId("workerId"));
        //instance.findFirstUserInOUs(ldapRepository, domainConfig.getWorkersOu(), LdapUtils.WORKER_ID, workerId);
    }

    @Test
    void getManagerByDn() throws InvalidNameException {
        var imdgInstance = new TestImdgInstance();
        var configurationClient = Mockito.mock(ConfigurationClient.class);
        var ldapDomainConfiguration = Mockito.mock(LdapDomainConfiguration.class);
        var instance = new LdapServiceImpl(imdgInstance, configurationClient, ldapDomainConfiguration);

        var managerDn = new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com");

        var hrbu = "hrbu";
        var city = "city";
        var address = "address";
        var hrbuConfig = HrbuConfig.builder()
                .hrbu(hrbu)
                .city(city)
                .street(address)
                .ou(new LdapName("cn=xxx"))
                .vantageLookupStrategy(true)
                .build();

        var questOu = new LdapName("CN=Quest1,OU=Test,DC=mshusontest,DC=com");
        var workerOu = new LdapName("CN=Worker1,OU=Test,DC=mshusontest,DC=com");
        var terminatedOu = new LdapName("CN=TerminatedOu,OU=Test,DC=mshusontest,DC=com");
        var domainConfig = DomainConfig.builder()
                .name("domain")
                .defaultManager(Map.of(
                        "distinguishedName", "CN=Manager0,OU=Test,DC=mshusontest,DC=com",
                        "sAMAccountName", "Manager0@mshusontest.com",
                        "firstName", "firstName",
                        "lastName", "lastName",
                        "displayName", "displayName",
                        "mail", "Manager0@mshusontest.com",
                        "telephoneNumber", "telephoneNumber"
                ))
                .questOu(Set.of(questOu))
                .workersOu(Set.of(workerOu))
                .terminatedOu(terminatedOu)
                .build();

        var executiveDirectorWorkerId = "executiveDirectorWorkerId";
        var executiveDirectorUserId = "executiveDirectorUserId";
        var executiveDirectorHrbu = "executiveDirectorHrbu";
        var includeTerminations = true;

        var workdayConfig = WorkdayConfig.builder()
                .mckessonHrbu("mckessonHrbu").build();

        Mockito.when(configurationClient.findDomainConfig(Mockito.eq(hrbuConfig))).thenReturn(domainConfig);
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(hrbu), Mockito.eq(city), Mockito.eq(address))).thenReturn(hrbuConfig);
        Mockito.when(configurationClient.findGlobalConfig()).thenReturn(workdayConfig);

        BiFunction<OktaUser, Boolean, Manager> MANAGER_VALUE = (user, real) -> Manager.builder().user(Manager.truncateToManagerAttributes(user)).real(real).build();

        var ou = Manager.parseOktaUser(domainConfig.getDefaultManager(), OktaUser.builder(), "distinguishedName", "sAMAccountName", false);
        var defaultManager = MANAGER_VALUE.apply(ou, false);

        var manager = instance.getManagerByDn(null, hrbu, city, address, executiveDirectorWorkerId, executiveDirectorUserId, "", includeTerminations);
        Assertions.assertEquals(defaultManager, manager);

        manager = instance.getManagerByDn(null, hrbu, city, address, executiveDirectorWorkerId, "", "mckessonHrbu", includeTerminations);
        Assertions.assertEquals(defaultManager, manager);

        manager = instance.getManagerByDn(null, hrbu, city, address, "", "", executiveDirectorHrbu, includeTerminations);
        Assertions.assertEquals(defaultManager, manager);

        Mockito.when(configurationClient.allDomainConfigs()).thenReturn(List.of(domainConfig));
        var ldapServer = Mockito.mock(LdapServer.class);
        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);

        var ldapRepository = Mockito.mock(LdapRepository.class);
        Mockito.when(ldapServer.getLdapRepository()).thenReturn(ldapRepository);

        Mockito.when(ldapRepository.truncateOrNull(Mockito.eq(workerOu))).thenReturn(workerOu);
        var adUser = LdapRepositorySpringTest.adUserGenerator.apply(1);
        Mockito.when(ldapRepository.find(Mockito.any(), Mockito.eq(LdapEntryType.USER))).thenReturn(List.of(adUser));

        manager = instance.getManagerByDn(managerDn, hrbu, city, address, executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu, includeTerminations);
        Assertions.assertEquals(MANAGER_VALUE.apply(adUser, true), manager);

        manager = instance.getManagerByDn(managerDn, hrbuConfig, executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu, includeTerminations);
        Assertions.assertEquals(MANAGER_VALUE.apply(adUser, true), manager);

        manager = instance.getManagerByDn(managerDn, hrbuConfig, domainConfig, executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu, includeTerminations);
        Assertions.assertEquals(MANAGER_VALUE.apply(adUser, true), manager);
    }


    @Test
    void getManagerByWorkerId() throws InvalidNameException {
        var imdgInstance = new TestImdgInstance();
        var configurationClient = Mockito.mock(ConfigurationClient.class);
        var ldapDomainConfiguration = Mockito.mock(LdapDomainConfiguration.class);
        var instance = new LdapServiceImpl(imdgInstance, configurationClient, ldapDomainConfiguration);

        var hrbu = "hrbu";
        var city = "city";
        var address = "address";
        var hrbuConfig = HrbuConfig.builder()
                .hrbu(hrbu)
                .city(city)
                .street(address)
                .ou(new LdapName("cn=xxx"))
                .vantageLookupStrategy(true)
                .build();

        var questOU = new LdapName("CN=Quest1,OU=Test,DC=mshusontest,DC=com");
        var workerOu = new LdapName("CN=Worker1,OU=Test,DC=mshusontest,DC=com");
        var adDefaultManager = LdapRepositorySpringTest.adUserGenerator.apply(11);
        adDefaultManager.setDn(new LdapName("CN=Manager0,OU=Test,DC=mshusontest,DC=com"));
        var domainConfig = DomainConfig.builder()
                .name("domain")
                .defaultManager(Map.of(
                        "distinguishedName", "CN=Manager0,OU=Test,DC=mshusontest,DC=com",
                        "sAMAccountName", "Manager0@mshusontest.com",
                        "firstName", "firstName",
                        "lastName", "lastName",
                        "displayName", "displayName",
                        "mail", "Manager0@mshusontest.com",
                        "telephoneNumber", "telephoneNumber"
                ))
                .questOu(Set.of(questOU))
                .workersOu(Set.of(workerOu))
                .build();

        var managerWorkerId = "managerWorkerId";
        var managerUserId = "managerUserId";
        var managerHrbu = "managerHrbu";

        var executiveDirectorWorkerId = "executiveDirectorWorkerId";
        var executiveDirectorUserId = "executiveDirectorUserId";
        var executiveDirectorHrbu = "executiveDirectorHrbu";

        var workdayConfig = WorkdayConfig.builder()
                .mckessonHrbu("mckessonHrbu").build();

        Mockito.when(configurationClient.allDomainConfigs()).thenReturn(List.of(domainConfig));
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(hrbu), Mockito.eq(city), Mockito.eq(address))).thenReturn(hrbuConfig);
        Mockito.when(configurationClient.findDomainConfig(Mockito.eq(hrbuConfig))).thenReturn(domainConfig);
        Mockito.when(configurationClient.findGlobalConfig()).thenReturn(workdayConfig);

        BiFunction<OktaUser, Boolean, Manager> MANAGER_VALUE = (user, real) -> Manager.builder().user(Manager.truncateToManagerAttributes(user)).real(real).build();

        var ldapServer = Mockito.mock(LdapServer.class);
        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);

        var ldapRepository = Mockito.mock(LdapRepository.class);
        Mockito.when(ldapServer.getLdapRepository()).thenReturn(ldapRepository);

        Mockito.when(ldapRepository.truncateOrNull(Mockito.eq(questOU))).thenReturn(questOU);
        var adUser = LdapRepositorySpringTest.adUserGenerator.apply(1);
        Mockito.when(ldapRepository.find(Mockito.any(), Mockito.eq(LdapEntryType.USER))).thenReturn(List.of(adUser));

        var manager = instance.getManagerByWorkerId(null, hrbu, city, address, managerUserId, "mckessonHrbu", executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu);
        Assertions.assertEquals(MANAGER_VALUE.apply(adUser, true), manager);

        hrbuConfig = hrbuConfig.toBuilder().vantageLookupStrategy(false).build();
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(hrbu), Mockito.eq(city), Mockito.eq(address))).thenReturn(hrbuConfig);
        Mockito.when(configurationClient.findDomainConfig(Mockito.eq(hrbuConfig))).thenReturn(domainConfig);

        Mockito.reset(ldapRepository);
        Mockito.when(ldapRepository.find(Mockito.any(), Mockito.eq(LdapEntryType.USER))).thenReturn(List.of(adDefaultManager));
        manager = instance.getManagerByWorkerId(null, hrbu, city, address, managerUserId, managerHrbu, executiveDirectorWorkerId, executiveDirectorUserId, "");
        Assertions.assertEquals(MANAGER_VALUE.apply(Manager.parseOktaUser(domainConfig.getDefaultManager(), adDefaultManager.builder(), "distinguishedName", "sAMAccountName", false), false), manager);

        manager = instance.getManagerByWorkerId(null, hrbu, city, address, managerUserId, managerHrbu, executiveDirectorWorkerId, "", "mckessonHrbu");
        Assertions.assertEquals(MANAGER_VALUE.apply(Manager.parseOktaUser(domainConfig.getDefaultManager(), adDefaultManager.builder(), "distinguishedName", "sAMAccountName", false), false), manager);

        manager = instance.getManagerByWorkerId(null, hrbu, city, address, managerUserId, managerHrbu, "", "", executiveDirectorHrbu);
        Assertions.assertEquals(MANAGER_VALUE.apply(Manager.parseOktaUser(domainConfig.getDefaultManager(), adDefaultManager.builder(), "distinguishedName", "sAMAccountName", false), false), manager);

        Mockito.when(ldapRepository.truncateOrNull(Mockito.eq(questOU))).thenReturn(questOU);
        Mockito.when(ldapRepository.truncateOrNull(Mockito.eq(workerOu))).thenReturn(workerOu);
        Mockito.when(ldapRepository.find(Mockito.any(ContainerCriteria.class), Mockito.eq(LdapEntryType.USER))).thenReturn(List.of(adUser));

        manager = instance.getManagerByWorkerId(managerWorkerId, hrbu, city, address, managerUserId, managerHrbu, executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu);
        Assertions.assertEquals(MANAGER_VALUE.apply(adUser, true), manager);

        manager = instance.getManagerByWorkerId(managerWorkerId, hrbuConfig, managerUserId, managerHrbu, executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu);
        Assertions.assertEquals(MANAGER_VALUE.apply(adUser, true), manager);

        manager = instance.getManagerByWorkerId(managerWorkerId, hrbuConfig, domainConfig, managerUserId, managerHrbu, executiveDirectorWorkerId, executiveDirectorUserId, executiveDirectorHrbu);
        Assertions.assertEquals(MANAGER_VALUE.apply(adUser, true), manager);
    }

    @Test
    void findManager() throws InvalidNameException {
        var imdgInstance = new TestImdgInstance();
        var configurationClient = Mockito.mock(ConfigurationClient.class);
        var ldapDomainConfiguration = Mockito.mock(LdapDomainConfiguration.class);
        var instance = new LdapServiceImpl(imdgInstance, configurationClient, ldapDomainConfiguration);

        var hrbu = "hrbu";
        var city = "city";
        var address = "address";
        var wdHbuConfig = HrbuConfig.builder()
                .hrbu(hrbu)
                .city(city)
                .street(address)
                .ou(new LdapName("cn=xxx"))
                .vantageLookupStrategy(true)
                .build();
        var adHbuConfig = wdHbuConfig;

        var questOU = new LdapName("CN=Quest1,OU=Test,DC=mshusontest,DC=com");
        var workerOu = new LdapName("CN=Worker1,OU=Test,DC=mshusontest,DC=com");
        var adDefaultManager = LdapRepositorySpringTest.adUserGenerator.apply(11);
        adDefaultManager.setDn(new LdapName("CN=Manager0,OU=Test,DC=mshusontest,DC=com"));
        var domainConfig = DomainConfig.builder()
                .name("domain")
                .defaultManager(Map.of(
                        "distinguishedName", "CN=Manager0,OU=Test,DC=mshusontest,DC=com",
                        "sAMAccountName", "Manager0@mshusontest.com",
                        "firstName", "firstName",
                        "lastName", "lastName",
                        "displayName", "displayName",
                        "mail", "Manager0@mshusontest.com",
                        "telephoneNumber", "telephoneNumber"
                ))
                .questOu(Set.of(questOU))
                .workersOu(Set.of(workerOu))
                .build();

        var wdManagerWorkerId = "managerWorkerId";
        var wdManagerUserId = "managerUserId";
        var wdManagerHrbu = "managerHrbu";

        var wdExecutiveDirectorWorkerId = "executiveDirectorWorkerId";
        var wdExecutiveDirectorUserId = "executiveDirectorUserId";
        var wdExecutiveDirectorHrbu = "executiveDirectorHrbu";

        var workdayConfig = WorkdayConfig.builder()
                .mckessonHrbu("mckessonHrbu").build();

        Mockito.when(configurationClient.allDomainConfigs()).thenReturn(List.of(domainConfig));
        Mockito.when(configurationClient.findHrbuConfig(Mockito.eq(hrbu), Mockito.eq(city), Mockito.eq(address))).thenReturn(wdHbuConfig);
        Mockito.when(configurationClient.findDomainConfig(Mockito.eq(wdHbuConfig))).thenReturn(domainConfig);
        Mockito.when(configurationClient.findGlobalConfig()).thenReturn(workdayConfig);

        BiFunction<OktaUser, Boolean, Manager> MANAGER_VALUE = (user, real) -> Manager.builder().user(Manager.truncateToManagerAttributes(user)).real(real).build();

        var ldapServer = Mockito.mock(LdapServer.class);
        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);

        var ldapRepository = Mockito.mock(LdapRepository.class);
        Mockito.when(ldapServer.getLdapRepository()).thenReturn(ldapRepository);


        var adManagerDn = new LdapName("CN=Manager0,OU=Test,DC=mshusontest,DC=com");
        var includeTerminations = false;

        var findNewManager = false;
        Assertions.assertNull(instance.findManager(wdHbuConfig, adHbuConfig,
                wdManagerWorkerId, wdManagerUserId, wdManagerHrbu,
                "test",
                wdExecutiveDirectorWorkerId, wdExecutiveDirectorUserId, wdExecutiveDirectorHrbu,
                findNewManager, includeTerminations));

        Mockito.when(ldapRepository.truncateOrNull(Mockito.eq(workerOu))).thenReturn(workerOu);
        var adUser = LdapRepositorySpringTest.adUserGenerator.apply(1);
        Mockito.when(ldapRepository.find(Mockito.any(), Mockito.eq(LdapEntryType.USER))).thenReturn(List.of(adUser));
        Manager manager = instance.findManager(wdHbuConfig, adHbuConfig,
                wdManagerWorkerId, wdManagerUserId, wdManagerHrbu,
                adManagerDn.toString(),
                wdExecutiveDirectorWorkerId, wdExecutiveDirectorUserId, wdExecutiveDirectorHrbu,
                findNewManager, includeTerminations);
        Assertions.assertEquals(MANAGER_VALUE.apply(adUser, true), manager);

        findNewManager = true;
        Mockito.reset(ldapRepository);
        Mockito.when(ldapRepository.find(Mockito.any(), Mockito.eq(LdapEntryType.USER))).thenReturn(List.of(adDefaultManager));

        manager = instance.findManager(wdHbuConfig, adHbuConfig,
                wdManagerWorkerId, wdManagerUserId, wdManagerHrbu,
                adManagerDn.toString(),
                wdExecutiveDirectorWorkerId, wdExecutiveDirectorUserId, wdExecutiveDirectorHrbu,
                findNewManager, includeTerminations);
        Assertions.assertEquals(MANAGER_VALUE.apply(Manager.parseOktaUser(domainConfig.getDefaultManager(), adDefaultManager.builder(), "distinguishedName", "sAMAccountName", false), false), manager);
    }

    @Test
    void findManagedServers() throws InvalidNameException {
        var imdgInstance = new TestImdgInstance();
        var configurationClient = Mockito.mock(ConfigurationClient.class);
        var ldapDomainConfiguration = Mockito.mock(LdapDomainConfiguration.class);
        var instance = new LdapServiceImpl(imdgInstance, configurationClient, ldapDomainConfiguration);

        var terminatedOu = new LdapName("CN=Terminated1,OU=Test,DC=mshusontest,DC=com");
        var workerOu = new LdapName("CN=Worker1,OU=Test,DC=mshusontest,DC=com");
        var domainConfig = DomainConfig.builder()
                .name("domain")
                .terminatedOu(terminatedOu)
                .workersOu(Set.of(workerOu))
                .build();
        var dn = new LdapName("CN=Manager0,OU=Test,DC=mshusontest,DC=com");

        var ldapServer = Mockito.mock(LdapServer.class);
        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);

        var ldapRepository = Mockito.mock(LdapRepository.class);
        Mockito.when(ldapServer.getLdapRepository()).thenReturn(ldapRepository);

        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);
        Mockito.when(ldapRepository.truncateOrNull(Mockito.eq(terminatedOu))).thenReturn(terminatedOu);

        var adServer = LdapRepositorySpringTest.adServerGenerator.apply(1);
        adServer.setUid(UUID.randomUUID().toString());
        Mockito.when(ldapRepository.find(Mockito.any(), Mockito.eq(LdapEntryType.SERVER))).thenReturn(List.of(adServer));

        var servers = instance.findManagedServers(List.of(domainConfig), dn);
        Assertions.assertEquals(1, servers.size());
        Assertions.assertEquals(adServer, servers.get(0));
    }

    @Test
    void findAdminsManagedByDN() throws InvalidNameException {
        var imdgInstance = new TestImdgInstance();
        var configurationClient = Mockito.mock(ConfigurationClient.class);
        var ldapDomainConfiguration = Mockito.mock(LdapDomainConfiguration.class);
        var instance = new LdapServiceImpl(imdgInstance, configurationClient, ldapDomainConfiguration);

        var adminOu1 = new LdapName("CN=Admin1,OU=Test,DC=mshusontest,DC=com");
        var adminOu2 = new LdapName("CN=Admin2,OU=Test,DC=mshusontest,DC=com");
        var domainConfig = DomainConfig.builder()
                .name("domain")
                .adminsOu(Set.of(adminOu1, adminOu2))
                .build();
        var dn = new LdapName("CN=Manager0,OU=Test,DC=mshusontest,DC=com");

        var ldapServer = Mockito.mock(LdapServer.class);
        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);

        var ldapRepository = Mockito.mock(LdapRepository.class);
        Mockito.when(ldapServer.getLdapRepository()).thenReturn(ldapRepository);

        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);
        Mockito.when(ldapRepository.truncateOrNull(Mockito.eq(adminOu1))).thenReturn(adminOu1);
        Mockito.when(ldapRepository.truncateOrNull(Mockito.eq(adminOu2))).thenReturn(null);

        var adUser = LdapRepositorySpringTest.adUserGenerator.apply(1);
        adUser.setUid(UUID.randomUUID().toString());
        Mockito.when(ldapRepository.find(Mockito.any(), Mockito.eq(LdapEntryType.USER))).thenReturn(List.of(adUser));

        var result = instance.findAdminsManagedByDN(List.of(domainConfig), dn);
        Assertions.assertEquals(1, result.size());
        Assertions.assertTrue(result.containsKey(domainConfig));
        var users = result.get(domainConfig);
        Assertions.assertEquals(1, users.size());
        Assertions.assertEquals(adUser, users.get(0));
    }


    @Test
    void findServiceAccountsManagedByDN() throws InvalidNameException {
        var imdgInstance = new TestImdgInstance();
        var configurationClient = Mockito.mock(ConfigurationClient.class);
        var ldapDomainConfiguration = Mockito.mock(LdapDomainConfiguration.class);
        var instance = new LdapServiceImpl(imdgInstance, configurationClient, ldapDomainConfiguration);

        var terminatedOu = new LdapName("CN=Terminated1,OU=Test,DC=mshusontest,DC=com");
        var workerOu = new LdapName("CN=Worker1,OU=Test,DC=mshusontest,DC=com");
        var domainConfig = DomainConfig.builder()
                .name("domain")
                .terminatedOu(terminatedOu)
                .workersOu(Set.of(workerOu))
                .build();
        var dn = new LdapName("CN=Manager0,OU=Test,DC=mshusontest,DC=com");

        var ldapServer = Mockito.mock(LdapServer.class);
        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);

        var ldapRepository = Mockito.mock(LdapRepository.class);
        Mockito.when(ldapServer.getLdapRepository()).thenReturn(ldapRepository);

        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);
        Mockito.when(ldapRepository.truncateOrNull(Mockito.eq(terminatedOu))).thenReturn(terminatedOu);

        var adUser = LdapRepositorySpringTest.adUserGenerator.apply(1);
        adUser.setUid(UUID.randomUUID().toString());
        Mockito.when(ldapRepository.find(Mockito.any(), Mockito.eq(LdapEntryType.USER))).thenReturn(List.of(adUser));

        var users = instance.findServiceAccountsManagedByDN(List.of(domainConfig), dn);
        Assertions.assertEquals(1, users.size());
        Assertions.assertEquals(adUser, users.get(0));
    }

    @Test
    void findGroupsManagedByDN() throws InvalidNameException {
        var imdgInstance = new TestImdgInstance();
        var configurationClient = Mockito.mock(ConfigurationClient.class);
        var ldapDomainConfiguration = Mockito.mock(LdapDomainConfiguration.class);
        var instance = new LdapServiceImpl(imdgInstance, configurationClient, ldapDomainConfiguration);

        var terminatedOu = new LdapName("CN=Terminated1,OU=Test,DC=mshusontest,DC=com");
        var workerOu = new LdapName("CN=Worker1,OU=Test,DC=mshusontest,DC=com");
        var domainConfig = DomainConfig.builder()
                .name("domain")
                .terminatedOu(terminatedOu)
                .workersOu(Set.of(workerOu))
                .build();
        var dn = new LdapName("CN=Manager0,OU=Test,DC=mshusontest,DC=com");

        var ldapServer = Mockito.mock(LdapServer.class);
        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);

        var ldapRepository = Mockito.mock(LdapRepository.class);
        Mockito.when(ldapServer.getLdapRepository()).thenReturn(ldapRepository);

        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);
        Mockito.when(ldapRepository.truncateOrNull(Mockito.eq(terminatedOu))).thenReturn(terminatedOu);

        var adGroup = LdapRepositorySpringTest.adGroupGenerator.apply(1);
        adGroup.setUid(UUID.randomUUID().toString());
        Mockito.when(ldapRepository.find(Mockito.any(), Mockito.eq(LdapEntryType.GROUP))).thenReturn(List.of(adGroup));

        var groups = instance.findGroupsManagedByDN(List.of(domainConfig), dn);
        Assertions.assertEquals(1, groups.size());
        Assertions.assertEquals(adGroup, groups.get(0));
    }

    @Test
    void findUserGroups() throws InvalidNameException {
        var imdgInstance = new TestImdgInstance();
        var configurationClient = Mockito.mock(ConfigurationClient.class);
        var ldapDomainConfiguration = Mockito.mock(LdapDomainConfiguration.class);
        var instance = new LdapServiceImpl(imdgInstance, configurationClient, ldapDomainConfiguration);

        var terminatedOu = new LdapName("CN=Terminated1,OU=Test,DC=mshusontest,DC=com");
        var workerOu = new LdapName("CN=Worker1,OU=Test,DC=mshusontest,DC=com");
        var domainConfig = DomainConfig.builder()
                .name("domain")
                .terminatedOu(terminatedOu)
                .workersOu(Set.of(workerOu))
                .build();
        var dn = new LdapName("CN=Manager0,OU=Test,DC=mshusontest,DC=com");

        Mockito.when(configurationClient.allDomainConfigs()).thenReturn(List.of(domainConfig));

        var ldapServer = Mockito.mock(LdapServer.class);
        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);

        var ldapRepository = Mockito.mock(LdapRepository.class);
        Mockito.when(ldapServer.getLdapRepository()).thenReturn(ldapRepository);

        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);
        Mockito.when(ldapRepository.truncateOrNull(Mockito.eq(terminatedOu))).thenReturn(terminatedOu);

        var adGroup = LdapRepositorySpringTest.adGroupGenerator.apply(1);
        adGroup.setUid(UUID.randomUUID().toString());
        Mockito.when(ldapRepository.find(Mockito.any(), Mockito.eq(LdapEntryType.GROUP))).thenReturn(List.of(adGroup));

        var groups = instance.findUserGroups(dn);
        Assertions.assertEquals(1, groups.size());
        Assertions.assertEquals(adGroup, groups.get(0));
    }

    @Test
    void updateObjectsManager() throws InvalidNameException {
        var imdgInstance = new TestImdgInstance();
        var configurationClient = Mockito.mock(ConfigurationClient.class);
        var ldapDomainConfiguration = Mockito.mock(LdapDomainConfiguration.class);
        var instance = new LdapServiceImpl(imdgInstance, configurationClient, ldapDomainConfiguration);

        var domainConfig = DomainConfig.builder()
                .name("domain")
                .build();

        Mockito.when(configurationClient.allDomainConfigs()).thenReturn(List.of(domainConfig));

        var ldapServer = Mockito.mock(LdapServer.class);
        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);

        var ldapRepository = Mockito.mock(LdapRepository.class);
        Mockito.when(ldapServer.getLdapRepository()).thenReturn(ldapRepository);

        Mockito.when(ldapDomainConfiguration.getServer(Mockito.eq(domainConfig.getName()))).thenReturn(ldapServer);

        var dn = new LdapName("CN=Manager0,OU=Test,DC=mshusontest,DC=com");
        var adUser = LdapRepositorySpringTest.adUserGenerator.apply(1);
        adUser.setDomain(domainConfig.getName());
        instance.updateObjectsManager(Collections.emptyList(), dn, LdapEntryType.USER, "manager");
        Mockito.verifyNoMoreInteractions(ldapRepository);


        instance.updateObjectsManager(List.of(adUser), dn, LdapEntryType.USER, "manager");
        Mockito.verify(ldapRepository).modifyAttributes(Mockito.eq(adUser), Mockito.any(), Mockito.eq(LdapEntryType.USER));
    }
}