package com.mckesson.ad.entity.mapper;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.ldap.support.LdapUtils.convertStringSidToBinary;

class SidUtilsTest {

    @Test
    void sid2String() {
        Assertions.assertNull(SidUtils.sid2String(null));
        var expected = "S-1-5-21-1698188384-1693678267-1543859470-6637";
        Assertions.assertEquals(expected, SidUtils.sid2String(convertStringSidToBinary(expected)));
    }

    @Test
    void string2Sid() {
        Assertions.assertNull(SidUtils.string2Sid(null));
        var expected = "S-1-5-21-1698188384-1693678267-1543859470-6637";
        Assertions.assertArrayEquals(convertStringSidToBinary(expected), SidUtils.string2Sid(expected));
    }
}