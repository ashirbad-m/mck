package com.mckesson.ad.repository;

import com.mckesson.ad.entity.AdUserEntry;
import com.mckesson.common.domain.OktaUser;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.odm.core.ObjectDirectoryMapper;

import javax.naming.NamingException;

import static org.junit.jupiter.api.Assertions.*;

class LdapEntryTypeTest {

    @Test
    void getMapper() throws NamingException {
        var instance = LdapEntryType.USER;
        var objectDirectoryMapper = Mockito.mock(ObjectDirectoryMapper.class);
        var template =new LdapTemplate();
        template.setObjectDirectoryMapper(objectDirectoryMapper);

        var expected = new AdUserEntry();
        var ctx = Mockito.mock(DirContextOperations.class);
        Mockito.when(objectDirectoryMapper.mapFromLdapDataEntry(Mockito.eq(ctx), Mockito.eq(instance.getClazz())))
                .thenReturn(expected);
        Assertions.assertEquals(expected, instance.getMapper(template).mapFromContext(ctx));
    }
}