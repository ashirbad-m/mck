package com.mckesson.common.config;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class JacksonConfigTest {

    @Test
    void objectMapper() {
        var instance = new JacksonConfig();
        Assertions.assertNotNull(instance.objectMapper());
    }
}