package com.mckesson.common.config;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.cloud.stream.messaging.Source;

class StreamConfigurationTest {

    @Test
    void messageBrokerClient() {
        var instance = new StreamConfiguration();
        var source = Mockito.mock(Source.class);
        Assertions.assertNotNull(instance.messageBrokerClient(source));
    }
}