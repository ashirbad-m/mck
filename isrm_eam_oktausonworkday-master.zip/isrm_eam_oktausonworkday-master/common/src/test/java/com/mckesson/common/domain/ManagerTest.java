package com.mckesson.common.domain;

import com.mckesson.common.workday.converter.ConverterUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

class ManagerTest {

    @Test
    void getManagerAsString() {
        var instance = new Manager();
        instance.setReal(true);
        instance.setForEMail(true);
        instance.setLinked(true);


        var expected = new LinkedHashMap<String, Object>();
        expected.put("forEMail", instance.isForEMail());
        expected.put("real", instance.isReal());
        expected.put("linked", instance.isLinked());
        Assertions.assertEquals(ConverterUtils.writeValueAsString(expected), instance.getManagerAsString());

        var user = new OktaUser();
        user.setUserId(UUID.randomUUID().toString());
        instance.setUser(user);
        expected = new LinkedHashMap<>();
        expected.put("employee", user.isEmployee());
        expected.put("userId", user.getUserId());
        expected.put("active", user.isActive());
        expected.put("trm", user.isTrm());
        expected.put("leaveOfAbsence", user.isLeaveOfAbsence());
        expected.put("real", instance.isReal());
        expected.put("forEMail", instance.isForEMail());
        expected.put("linked", instance.isLinked());

        Assertions.assertEquals(ConverterUtils.writeValueAsString(expected), instance.getManagerAsString());
    }

    @Test
    void truncateToManagerAttributes() throws InvalidNameException {
        var dn = new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com");
        var user = OktaUser.builder()
                .dn(dn)
                .cn(dn.getRdn(dn.size() - 1).getValue().toString())
                .mail(UUID.randomUUID().toString())
                .samAccountName(UUID.randomUUID().toString())
                .displayName(UUID.randomUUID().toString())
                .lastName(UUID.randomUUID().toString())
                .firstName(UUID.randomUUID().toString())
                .telephoneNumber(UUID.randomUUID().toString())
                .build();

        var instance = Manager.truncateToManagerAttributes(user);

        Assertions.assertEquals(user.getDn(), instance.getDn());
        Assertions.assertEquals(user.getCn(), instance.getCn());
        Assertions.assertEquals(user.getMail(), instance.getMail());
        Assertions.assertEquals(user.getSamAccountName(), instance.getSamAccountName());
        Assertions.assertEquals(user.getDisplayName(), instance.getDisplayName());
        Assertions.assertEquals(user.getLastName(), instance.getLastName());
        Assertions.assertEquals(user.getFirstName(), instance.getFirstName());
        Assertions.assertEquals(user.getTelephoneNumber(), instance.getTelephoneNumber());
    }

    @Test
    void parseManager() throws InvalidNameException {
        Assertions.assertNull(Manager.parseManager("{}", UUID.randomUUID().toString(), true));

        var dn = new LdapName("CN=Manager1,OU=Test,DC=mshusontest,DC=com");
        var managerAsMap = new HashMap<String, Object>();
        managerAsMap.put("forEMail", true);
        managerAsMap.put("real", true);
        managerAsMap.put("linked", true);
        managerAsMap.put("dn", dn.toString());

        var samAccountName = UUID.randomUUID().toString();
        var firstName = UUID.randomUUID().toString();
        var lastName = UUID.randomUUID().toString();
        var displayName = UUID.randomUUID().toString();
        var mail = UUID.randomUUID().toString();
        var telephoneNumber = UUID.randomUUID().toString();

        managerAsMap.put("samAccountName", samAccountName);
        managerAsMap.put("firstName", firstName);
        managerAsMap.put("lastName", lastName);
        managerAsMap.put("displayName", displayName);
        managerAsMap.put("mail", mail);
        managerAsMap.put("telephoneNumber", telephoneNumber);


        var managerAsString = ConverterUtils.writeValueAsString(managerAsMap);

        var instance = Manager.parseManager(managerAsString, "samAccountName", true);
        Assertions.assertTrue(instance.isReal());
        Assertions.assertTrue(instance.isLinked());
        Assertions.assertTrue(instance.isForEMail());
        Assertions.assertNotNull(instance.getUser());

        Assertions.assertEquals(dn, instance.getUser().getDn());
        Assertions.assertEquals(dn.getRdn(dn.size() - 1).getValue().toString(), instance.getUser().getCn());
        Assertions.assertEquals(samAccountName, instance.getUser().getSamAccountName());
        Assertions.assertEquals(firstName, instance.getUser().getFirstName());
        Assertions.assertEquals(lastName, instance.getUser().getLastName());
        Assertions.assertEquals(displayName, instance.getUser().getDisplayName());
        Assertions.assertEquals(mail, instance.getUser().getMail());
        Assertions.assertEquals(telephoneNumber, instance.getUser().getTelephoneNumber());

    }

    @Test
    void parseOktaUser() {
        Assertions.assertNull(Manager.parseOktaUser(Map.of(), OktaUser.builder(), "dn", "samAccountName", true));
    }
}