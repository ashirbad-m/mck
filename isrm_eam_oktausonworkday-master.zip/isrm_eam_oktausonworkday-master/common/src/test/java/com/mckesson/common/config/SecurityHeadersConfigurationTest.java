package com.mckesson.common.config;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

class SecurityHeadersConfigurationTest {

    @Test
    void testSecurityHeadersFilter() throws ServletException, IOException {

        var instance = new SecurityHeadersConfiguration.SecurityHeadersFilter(true, true, true, true, true);

        var request = Mockito.mock(HttpServletRequest.class);
        var response = Mockito.mock(HttpServletResponse.class);
        var filterChain = Mockito.mock(FilterChain.class);

        instance.doFilterInternal(request, response, filterChain);

        //TODO
        Mockito.verify(filterChain).doFilter(request, response);
    }
}