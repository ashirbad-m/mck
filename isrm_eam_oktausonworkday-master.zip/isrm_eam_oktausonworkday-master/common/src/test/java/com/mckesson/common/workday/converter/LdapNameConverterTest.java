package com.mckesson.common.workday.converter;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;

class LdapNameConverterTest {

    @Test
    void convertToDatabaseColumn() throws InvalidNameException {
        LdapNameConverter instance = new LdapNameConverter();
        Assertions.assertNull(instance.convertToDatabaseColumn(null));
        Assertions.assertEquals("", instance.convertToDatabaseColumn(new LdapName("")));
        Assertions.assertEquals("OU=USON,OU=B2E_Workday_Okta_AD,DC=mshusontest,DC=com", instance.convertToDatabaseColumn(new LdapName("OU=USON,OU=B2E_Workday_Okta_AD,DC=mshusontest,DC=com")));
    }

    @Test
    void convertToEntityAttribute() throws InvalidNameException {
        LdapNameConverter instance = new LdapNameConverter();
        Assertions.assertEquals(null, instance.convertToEntityAttribute(null));
        LdapName ln = new LdapName("OU=USON,OU=B2E_Workday_Okta_AD,DC=mshusontest,DC=com");
        Assertions.assertEquals(ln, instance.convertToEntityAttribute(ln.toString()));
    }
}