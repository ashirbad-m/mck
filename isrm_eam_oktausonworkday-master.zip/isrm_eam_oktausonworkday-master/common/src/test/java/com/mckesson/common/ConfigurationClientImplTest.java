package com.mckesson.common;

import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.HrbuConfig;
import com.mckesson.common.model.WorkdayConfig;
import com.mckesson.common.workday.configuration.controller.ConfigurationControllerConstants;
import com.mckesson.common.workday.configuration.dto.GroupMappingDto;
import com.mckesson.common.workday.configuration.dto.GroupMappingType;
import com.mckesson.common.workday.configuration.dto.HrbuCityStreetDto;
import com.mckesson.common.workday.configuration.dto.HrbuDto;
import com.mckesson.common.workday.configuration.dto.request.GroupMappingRequest;
import com.mckesson.common.workday.configuration.dto.request.HrbuViewRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;

class ConfigurationClientImplTest {

    @Test
    void getAllGlobals() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var workdayConfig1 = WorkdayConfig.builder().id(1L).build();
        var workdayConfig2 = WorkdayConfig.builder().id(2L).build();
        var expected = List.of(workdayConfig1, workdayConfig2);

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/all-globals"), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(ConfigurationControllerConstants.RETURN_GLOBALS_LIST), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(expected));

        Assertions.assertEquals(expected, instance.getAllGlobals());
        Assertions.assertEquals(expected, instance.getAllGlobals(new HttpHeaders()));
    }

    @Test
    void findWorkdayConfig() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var workdayConfig = WorkdayConfig.builder().id(1L).build();

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/single-global"), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(WorkdayConfig.class), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(workdayConfig));

        Assertions.assertEquals(workdayConfig, instance.findGlobalConfig());
        Assertions.assertEquals(workdayConfig, instance.findWorkdayConfig(new HttpHeaders()));
    }

    @Test
    void findGlobalById() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var workdayConfig = WorkdayConfig.builder().id(1L).build();

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/get-global/" + workdayConfig.getId()), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(WorkdayConfig.class), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(workdayConfig));

        Assertions.assertEquals(workdayConfig, instance.findGlobalById(1L));
        Assertions.assertEquals(workdayConfig, instance.findGlobalById(new HttpHeaders(), 1L));
    }

    @Test
    void getAllGroupMappings() throws InvalidNameException {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var groupMappingDto1 = GroupMappingDto.builder()
                .id(1L)
                .type(GroupMappingType.DEFAULT)
                .name("group1")
                .dn(new LdapName("CN=group1,OU=Test2,DC=mshusontest,DC=com"))
                .build();
        var groupMappingDto2 = GroupMappingDto.builder()
                .id(2L)
                .type(GroupMappingType.DEFAULT)
                .name("group2")
                .dn(new LdapName("CN=group2,OU=Test2,DC=mshusontest,DC=com"))
                .build();
        var expected = List.of(groupMappingDto1, groupMappingDto2);

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/all-group-mappings"), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(ConfigurationControllerConstants.RETURN_GROUP_MAPPINGS_LIST), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(expected));

        Assertions.assertEquals(expected, instance.getAllGroupMappings());
        Assertions.assertEquals(expected, instance.getAllGroupMappings(new HttpHeaders()));
    }

    @Test
    void findGroupMappingById() throws InvalidNameException {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var groupMappingDto = GroupMappingDto.builder()
                .id(1L)
                .type(GroupMappingType.DEFAULT)
                .name("group1")
                .dn(new LdapName("CN=group1,OU=Test2,DC=mshusontest,DC=com"))
                .build();

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/get-group-mapping/" + groupMappingDto.getId()), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(GroupMappingDto.class), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(groupMappingDto));

        Assertions.assertEquals(groupMappingDto, instance.findGroupMappingById(groupMappingDto.getId()));
        Assertions.assertEquals(groupMappingDto, instance.findGroupMappingById(new HttpHeaders(), groupMappingDto.getId()));
    }

    @Test
    void findGroupMappingByName() throws InvalidNameException {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var groupMappingDto = GroupMappingDto.builder()
                .id(1L)
                .type(GroupMappingType.DEFAULT)
                .name("group1")
                .dn(new LdapName("CN=group1,OU=Test2,DC=mshusontest,DC=com"))
                .build();

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/get-group-mapping-by-name/{name}"),
                        Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(GroupMappingDto.class),
                        Mockito.eq(Map.of("name", groupMappingDto.getName()))))
                .thenReturn(ResponseEntity.ok(groupMappingDto));

        Assertions.assertEquals(groupMappingDto, instance.findGroupMappingByName(groupMappingDto.getName()));
        Assertions.assertEquals(groupMappingDto, instance.findGroupMappingByName(new HttpHeaders(), groupMappingDto.getName()));
    }

    @Test
    void findGroupMappingsByNames() throws InvalidNameException {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var groupMappingDto1 = GroupMappingDto.builder()
                .id(1L)
                .type(GroupMappingType.DEFAULT)
                .name("group1")
                .dn(new LdapName("CN=group1,OU=Test2,DC=mshusontest,DC=com"))
                .build();
        var groupMappingDto2 = GroupMappingDto.builder()
                .id(2L)
                .type(GroupMappingType.DEFAULT)
                .name("group2")
                .dn(new LdapName("CN=group2,OU=Test2,DC=mshusontest,DC=com"))
                .build();
        var expected = List.of(groupMappingDto1, groupMappingDto2);

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/find-group-mappings-by-names"), Mockito.eq(HttpMethod.POST),
                        Mockito.any(), Mockito.eq(ConfigurationControllerConstants.RETURN_GROUP_MAPPINGS_LIST), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(expected));

        Assertions.assertEquals(expected, instance.findGroupMappingsByNames(List.of(groupMappingDto1.getName(), groupMappingDto2.getName())));
        Assertions.assertEquals(expected, instance.findGroupMappingsByNames(new HttpHeaders(), List.of(groupMappingDto1.getName(), groupMappingDto2.getName())));
    }

    @Test
    void findGroupMappingsByOktaCns() throws InvalidNameException {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var groupMappingDto1 = GroupMappingDto.builder()
                .id(1L)
                .type(GroupMappingType.DEFAULT)
                .name("group1")
                .oktaCn("group1")
                .dn(new LdapName("CN=group1,OU=Test2,DC=mshusontest,DC=com"))
                .build();
        var groupMappingDto2 = GroupMappingDto.builder()
                .id(2L)
                .type(GroupMappingType.DEFAULT)
                .name("group2")
                .oktaCn("group2")
                .dn(new LdapName("CN=group2,OU=Test2,DC=mshusontest,DC=com"))
                .build();
        var expected = List.of(groupMappingDto1, groupMappingDto2);

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/find-group-mappings-by-okta-cns"), Mockito.eq(HttpMethod.POST),
                        Mockito.any(), Mockito.eq(ConfigurationControllerConstants.RETURN_GROUP_MAPPINGS_LIST), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(expected));

        Assertions.assertEquals(expected, instance.findGroupMappingsByOktaCns(List.of(groupMappingDto1.getOktaCn(), groupMappingDto2.getOktaCn())));
        Assertions.assertEquals(expected, instance.findGroupMappingsByOktaCns(new HttpHeaders(), List.of(groupMappingDto1.getOktaCn(), groupMappingDto2.getOktaCn())));
    }

    @Test
    void findGroupMappingsByType() throws InvalidNameException {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var groupMappingDto1 = GroupMappingDto.builder()
                .id(1L)
                .type(GroupMappingType.DEFAULT)
                .name("group1")
                .oktaCn("group1")
                .dn(new LdapName("CN=group1,OU=Test2,DC=mshusontest,DC=com"))
                .build();
        var groupMappingDto2 = GroupMappingDto.builder()
                .id(2L)
                .type(GroupMappingType.DEFAULT)
                .name("group2")
                .oktaCn("group2")
                .dn(new LdapName("CN=group2,OU=Test2,DC=mshusontest,DC=com"))
                .build();
        var expected = List.of(groupMappingDto1, groupMappingDto2);

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/find-group-mappings-by-type/{type}"), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(ConfigurationControllerConstants.RETURN_GROUP_MAPPINGS_LIST), Mockito.eq(Map.of("type", GroupMappingType.DEFAULT))))
                .thenReturn(ResponseEntity.ok(expected));

        Assertions.assertEquals(expected, instance.findGroupMappingsByType(GroupMappingType.DEFAULT));
        Assertions.assertEquals(expected, instance.findGroupMappingsByType(new HttpHeaders(), GroupMappingType.DEFAULT));
    }

    @Test
    void findGroupMappingsByNameInAndType() throws InvalidNameException {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var groupMappingDto1 = GroupMappingDto.builder()
                .id(1L)
                .type(GroupMappingType.DEFAULT)
                .name("group1")
                .oktaCn("group1")
                .dn(new LdapName("CN=group1,OU=Test2,DC=mshusontest,DC=com"))
                .build();
        var groupMappingDto2 = GroupMappingDto.builder()
                .id(2L)
                .type(GroupMappingType.DEFAULT)
                .name("group2")
                .oktaCn("group2")
                .dn(new LdapName("CN=group2,OU=Test2,DC=mshusontest,DC=com"))
                .build();
        var expected = List.of(groupMappingDto1, groupMappingDto2);

        var request = GroupMappingRequest.builder()
                .names(Set.of(groupMappingDto1.getName(), groupMappingDto2.getName()))
                .type(GroupMappingType.DEFAULT)
                .build();
        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/find-group-mappings-by-names-and-type"), Mockito.eq(HttpMethod.POST),
                        Mockito.any(), Mockito.eq(ConfigurationControllerConstants.RETURN_GROUP_MAPPINGS_LIST), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(expected));

        Assertions.assertEquals(expected, instance.findGroupMappingsByNameInAndType(request));
        Assertions.assertEquals(expected, instance.findGroupMappingsByNameInAndType(new HttpHeaders(), request));
    }

    @Test
    void allDomainConfigs() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var domainConfig1 = DomainConfig.builder().id(1L).build();
        var domainConfig2 = DomainConfig.builder().id(2L).build();
        var expected = List.of(domainConfig1, domainConfig2);

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/all-domains"), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(ConfigurationControllerConstants.RETURN_DOMAINS_LIST), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(expected));

        Assertions.assertEquals(expected, instance.allDomainConfigs());
        Assertions.assertEquals(expected, instance.allDomainConfigs(new HttpHeaders()));
    }

    @Test
    void findDomainConfigByOu() throws InvalidNameException {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var domainConfig1 = DomainConfig.builder().id(1L).build();

        var ou = new LdapName("CN=user,OU=Test2,DC=mshusontest,DC=com");
        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/find-domain"), Mockito.eq(HttpMethod.POST),
                        Mockito.any(), Mockito.eq(DomainConfig.class), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(domainConfig1));

        Assertions.assertEquals(domainConfig1, instance.findDomainConfigByOu(ou));
        Assertions.assertEquals(domainConfig1, instance.findDomainConfigByOu(new HttpHeaders(), ou));

        var config = HrbuConfig.builder().hrbu("hrbu").ou(ou).build();
        Assertions.assertEquals(domainConfig1, instance.findDomainConfig(config));
        Assertions.assertEquals(domainConfig1, instance.findDomainConfig(new HttpHeaders(), config));
    }

    @Test
    void findDomainConfigById() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var domainConfig1 = DomainConfig.builder().id(1L).build();

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/get-domain/" + domainConfig1.getId()), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(DomainConfig.class), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(domainConfig1));

        Assertions.assertEquals(domainConfig1, instance.findDomainConfigById(domainConfig1.getId()));
        Assertions.assertEquals(domainConfig1, instance.findDomainConfigById(new HttpHeaders(), domainConfig1.getId()));
    }

    @Test
    void findDomainConfigByName() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var domainConfig1 = DomainConfig.builder().id(1L).name("name").build();

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/get-domain-by-name/{name}"), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(DomainConfig.class), Mockito.eq(Map.of("name", domainConfig1.getName()))))
                .thenReturn(ResponseEntity.ok(domainConfig1));

        Assertions.assertEquals(domainConfig1, instance.findDomainConfigByName(domainConfig1.getName()));
        Assertions.assertEquals(domainConfig1, instance.findDomainConfigByName(new HttpHeaders(), domainConfig1.getName()));
    }

    @Test
    void getAllHrbu() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var hrbuDto1 = HrbuDto.builder().hrbu("0001").build();
        var hrbuDto2 = HrbuDto.builder().hrbu("0002").build();
        var expected = List.of(hrbuDto1, hrbuDto2);

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/all-hrbu"), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(ConfigurationControllerConstants.RETURN_HRBU_LIST), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(expected));

        Assertions.assertEquals(expected, instance.getAllHrbu());
        Assertions.assertEquals(expected, instance.getAllHrbu(new HttpHeaders()));
    }

    @Test
    void findHrbuByHrbu() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var hrbuDto1 = HrbuDto.builder().hrbu("0001").build();

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/get-hrbu/{hrbu}"), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(HrbuDto.class), Mockito.eq(Map.of("hrbu", hrbuDto1.getHrbu()))))
                .thenReturn(ResponseEntity.ok(hrbuDto1));

        Assertions.assertEquals(hrbuDto1, instance.findHrbuByHrbu(hrbuDto1.getHrbu()));
    }

    @Test
    void getAllHrbuCityStreet() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var hrbuCityStreetDto1 = HrbuCityStreetDto.builder().id(1L).build();
        var hrbuCityStreetDto2 = HrbuCityStreetDto.builder().id(2L).build();
        var expected = List.of(hrbuCityStreetDto1, hrbuCityStreetDto2);

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/all-hrbu-city-street"), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(ConfigurationControllerConstants.RETURN_HRBU_CITY_STREET_LIST), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(expected));

        Assertions.assertEquals(expected, instance.getAllHrbuCityStreet());
        Assertions.assertEquals(expected, instance.getAllHrbuCityStreet(new HttpHeaders()));
    }

    @Test
    void findHrbuCityStreetById() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var hrbuCityStreetDto1 = HrbuCityStreetDto.builder().id(1L).build();

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/get-hrbu-city-street/" + hrbuCityStreetDto1.getId()), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(HrbuCityStreetDto.class), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(hrbuCityStreetDto1));

        Assertions.assertEquals(hrbuCityStreetDto1, instance.findHrbuCityStreetById(hrbuCityStreetDto1.getId()));
        Assertions.assertEquals(hrbuCityStreetDto1, instance.findHrbuCityStreetById(new HttpHeaders(), hrbuCityStreetDto1.getId()));
    }

    @Test
    void getAllHrbuConfigs() throws InvalidNameException {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var hrbuConfig1 = HrbuConfig.builder().hrbu("hrbu1").ou(new LdapName("CN=user1,OU=Test2,DC=mshusontest,DC=com")).build();
        var hrbuConfig2 = HrbuConfig.builder().hrbu("hrbu2").ou(new LdapName("CN=user2,OU=Test2,DC=mshusontest,DC=com")).build();
        var expected = List.of(hrbuConfig1, hrbuConfig2);

        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/all-hrbu-configs"), Mockito.eq(HttpMethod.GET),
                        Mockito.any(), Mockito.eq(ConfigurationControllerConstants.RETURN_HRBU_VIEW_LIST), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(expected));

        Assertions.assertEquals(expected, instance.getAllHrbuConfigs());
        Assertions.assertEquals(expected, instance.getAllHrbuConfigs(new HttpHeaders()));
    }

    @Test
    void findHrbuConfig() throws InvalidNameException {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);


        var instance = new ConfigurationClientImpl("https://localhost/", restTemplateBuilder);
        var hrbuConfig1 = HrbuConfig.builder().hrbu("hrbu1").ou(new LdapName("CN=user1,OU=Test2,DC=mshusontest,DC=com")).build();
        var hrbuConfig2 = HrbuConfig.builder().hrbu("hrbu2").ou(new LdapName("CN=user2,OU=Test2,DC=mshusontest,DC=com")).build();
        var expected = List.of(hrbuConfig1, hrbuConfig2);

        var request = HrbuViewRequest.builder().hrbu("hrbu").city("city").street("street").build();
        Mockito.when(restTemplate.exchange(Mockito.eq("https://localhost/find-hrbu-config"), Mockito.eq(HttpMethod.POST),
                        Mockito.any(), Mockito.eq(ConfigurationControllerConstants.RETURN_HRBU_VIEW_LIST), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(expected));

        Assertions.assertEquals(expected, instance.findHrbuConfig(new HttpHeaders(), request.getHrbu(), request.getCity(), request.getStreet()));
        Assertions.assertEquals(expected, instance.findHrbuConfig(request));
        Assertions.assertEquals(expected, instance.findHrbuConfig(new HttpHeaders(), request));

        Assertions.assertEquals(hrbuConfig1, instance.findHrbuConfig(request.getHrbu(), request.getCity(), request.getStreet()));
    }
}