package com.mckesson.common.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.Set;
import java.util.UUID;

class HrbuConfigTest {

    @Test
    void testСonstructor() throws InvalidNameException {
        var instance = new HrbuConfig(
                new LdapName("OU=Test,DC=mshusontest,DC=com"),
                "homeDrive",
                "homeDir",
                "loginScript",
                Set.of("group"),
                Set.of("contractorGroup"),
                Set.of("outsideWorkerGroup"),
                Set.of("extGroup"),
                true,
                "itcMail",

                "hrbu",
                "mailSuffix",
                "secondaryMailSuffix",
                true,
                true,
                true,
                "city",
                "street",
                UUID.randomUUID().toString(),
                true
        );

        //TODO

        try {
            new HrbuConfig(
                    new LdapName("OU=Test,DC=mshusontest,DC=com"),
                    "homeDrive",
                    "homeDir",
                    "loginScript",
                    Set.of("group"),
                    Set.of("contractorGroup"),
                    Set.of("outsideWorkerGroup"),
                    Set.of("extGroup"),
                    true,
                    "itcMail",

                    null,
                    "mailSuffix",
                    "secondaryMailSuffix",
                    true,
                    true,
                    true,
                    "city",
                    "street",
                    UUID.randomUUID().toString(),
                    true
            );
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
        }
        try {
            new HrbuConfig(
                    null,
                    "homeDrive",
                    "homeDir",
                    "loginScript",
                    Set.of("group"),
                    Set.of("contractorGroup"),
                    Set.of("outsideWorkerGroup"),
                    Set.of("extGroup"),
                    true,
                    "itcMail",

                    "hrbu",
                    "mailSuffix",
                    "secondaryMailSuffix",
                    true,
                    true,
                    true,
                    "city",
                    "street",
                    UUID.randomUUID().toString(),
                    true
            );
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
        }
    }

    @Test
    void isUserIncluded() throws InvalidNameException {
        var instance = new HrbuConfig(
                new LdapName("OU=Test,DC=mshusontest,DC=com"),
                "homeDrive",
                "homeDir",
                "loginScript",
                Set.of("group"),
                Set.of("contractorGroup"),
                Set.of("outsideWorkerGroup"),
                Set.of("extGroup"),
                true,
                "itcMail",

                "hrbu",
                "mailSuffix",
                "secondaryMailSuffix",
                true,
                true,
                true,
                "city",
                "street",
                UUID.randomUUID().toString(),
                true
        );
        try {
            instance.isUserIncluded(new LdapName("OU=Test1,DC=mshusontest,DC=com"));
            Assertions.fail("Wrong behavior");
        } catch (UnsupportedOperationException ex) {
        }
    }

    @Test
    void homeDirectory() throws InvalidNameException {
        var instance = new HrbuConfig(
                new LdapName("OU=Test,DC=mshusontest,DC=com"),
                "homeDrive",
                "homeDir",
                "loginScript",
                Set.of("group"),
                Set.of("contractorGroup"),
                Set.of("outsideWorkerGroup"),
                Set.of("extGroup"),
                true,
                "itcMail",

                "hrbu",
                "mailSuffix",
                "secondaryMailSuffix",
                true,
                true,
                true,
                "city",
                "street",
                UUID.randomUUID().toString(),
                true
        );
        try {
            instance.homeDirectory("samAccountName");
            Assertions.fail("Wrong behavior");
        } catch (UnsupportedOperationException ex) {
        }
    }
}