package com.mckesson.common.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class PowerShellResultTest {

    @Test
    void testToString() {
        var result = new PowerShellResult(true, "output", true);
        Assertions.assertEquals("PowerShellResult(error=true, timeout=true, commandOutput='\noutput\n')", result.toString());

        result = new PowerShellResult(false, "output", false);
        Assertions.assertEquals("PowerShellResult(error=false, timeout=false, commandOutput='\noutput\n')", result.toString());
    }
}