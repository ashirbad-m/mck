package com.mckesson.common.domain;

import com.mckesson.common.model.ModuleEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.UUID;

class PassportActionTest {

    @Test
    void testEventTypeEnum_ValueByName() {
        for (var item : PassportAction.EventTypeEnum.values()) {
            Assertions.assertEquals(item, PassportAction.EventTypeEnum.valueByName(item.getName()));
        }
        try {
            PassportAction.EventTypeEnum.valueByName("test");
            Assertions.fail("Wrong behavior");
        } catch (IllegalArgumentException ex) {
            Assertions.assertEquals("Unknown event type name: test", ex.getMessage());
        }
    }

    @Test
    void testEventTypeEnum_getName() {
        Assertions.assertEquals("remedy", PassportAction.EventTypeEnum.REMEDY.getName());
        Assertions.assertEquals("powershell", PassportAction.EventTypeEnum.POWERSHELL.getName());
        Assertions.assertEquals("okta", PassportAction.EventTypeEnum.OKTA.getName());
        Assertions.assertEquals("audit", PassportAction.EventTypeEnum.AUDIT.getName());
    }

    @Test
    void testEventTypeEnum_getModule() {
        Assertions.assertEquals(ModuleEnum.REMEDY_FORCE, PassportAction.EventTypeEnum.REMEDY.getModule());
        Assertions.assertEquals(ModuleEnum.EXCHANGE, PassportAction.EventTypeEnum.POWERSHELL.getModule());
        Assertions.assertEquals(ModuleEnum.OKTA_CLIENT, PassportAction.EventTypeEnum.OKTA.getModule());
        Assertions.assertEquals(ModuleEnum.AUDIT, PassportAction.EventTypeEnum.AUDIT.getModule());
    }

    @Test
    void testOktaEventBody() {
        var instance = new PassportAction.OktaEventBody();
        Assertions.assertNull(instance.getIncidentData());
        Assertions.assertNull(instance.getEventId());
        Assertions.assertNull(instance.getBatchId());
        Assertions.assertNull(instance.getOwfFlowId());
        Assertions.assertNull(instance.getOwfExecutionId());
        Assertions.assertNull(instance.getOktaUserId());

        instance.setOktaUserId(UUID.randomUUID().toString());
        instance.setEventId(UUID.randomUUID().toString());
        instance.setBatchId(UUID.randomUUID().toString());
        instance.setOwfFlowId(UUID.randomUUID().toString());
        instance.setOwfExecutionId(UUID.randomUUID().toString());
        instance.setOktaUserId(UUID.randomUUID().toString());

        var instance2 = new PassportAction.OktaEventBody(instance);

        Assertions.assertEquals(instance.getEventId(), instance2.getEventId());
        Assertions.assertEquals(instance.getBatchId(), instance2.getBatchId());
        Assertions.assertEquals(instance.getOwfFlowId(), instance2.getOwfFlowId());
        Assertions.assertEquals(instance.getOwfExecutionId(), instance2.getOwfExecutionId());
        Assertions.assertEquals(instance.getOktaUserId(), instance2.getOktaUserId());
    }
}