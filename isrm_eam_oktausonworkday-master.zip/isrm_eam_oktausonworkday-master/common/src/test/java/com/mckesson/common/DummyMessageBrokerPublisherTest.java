package com.mckesson.common;

import com.mckesson.common.model.ModuleEnum;
import org.junit.jupiter.api.Test;

class DummyMessageBrokerPublisherTest {

    @Test
    void send() {
        new DummyMessageBrokerPublisher().send(ModuleEnum.GATEWAY, "");
    }
}