package com.mckesson.common.workday.converter;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.Collections;
import java.util.Set;

class SetOfLdapNameConverterTest {

    @Test
    void convertToDatabaseColumn() throws InvalidNameException {
        SetOfLdapNameConverter instance = new SetOfLdapNameConverter();
        Assertions.assertNull(instance.convertToDatabaseColumn(null));
        Assertions.assertEquals(null, instance.convertToDatabaseColumn(Set.of()));
        LdapName ln1 = new LdapName("DC=mshusontest1,DC=com");
        LdapName ln2 = new LdapName("DC=mshusontest2,DC=com");
        LdapName ln3 = new LdapName("DC=mshusontest3,DC=com");
        String value = instance.convertToDatabaseColumn(Set.of(ln1, ln2, ln3));
        Assertions.assertTrue(value.contains(ln1.toString()));
        Assertions.assertTrue(value.contains(ln2.toString()));
        Assertions.assertTrue(value.contains(ln3.toString()));
    }

    @Test
    void convertToEntityAttribute() throws InvalidNameException {
        SetOfLdapNameConverter instance = new SetOfLdapNameConverter();
        Assertions.assertEquals(Collections.emptySet(), instance.convertToEntityAttribute(null));
        LdapName ln1 = new LdapName("DC=mshusontest1,DC=com");
        LdapName ln2 = new LdapName("DC=mshusontest2,DC=com");
        LdapName ln3 = new LdapName("DC=mshusontest3,DC=com");
        Assertions.assertEquals(Set.of(ln1, ln2, ln3), instance.convertToEntityAttribute("[\"" + ln1 + "\", \"" + ln2 + "\", \"" + ln3 + "\"]"));
    }
}