package com.mckesson.common.actuate;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.actuate.health.Status;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

class MailServiceHealthIndicatorTest {
    @Test
    void doHealthCheck() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);

        try {
            new MailServiceHealthIndicator("http://localhost/", restTemplateBuilder);
        } catch (IllegalArgumentException ex) {
            Assertions.assertEquals("Service Url must use HTTPS scheme", ex.getMessage());
        }

        var serviceUrl = "https://localhost/";
        var response = new AbstractServiceHealthIndicator.HealthResponse();
        response.setStatus(Status.DOWN);
        Mockito.when(restTemplate.getForEntity(Mockito.eq(serviceUrl + "actuator/health"), Mockito.eq(AbstractServiceHealthIndicator.HealthResponse.class)))
                .thenReturn(ResponseEntity.ok(response));

        var instance = new MailServiceHealthIndicator(serviceUrl, restTemplateBuilder);

        var health = instance.health();
        Assertions.assertEquals(Status.DOWN, health.getStatus());
        Assertions.assertEquals(Map.of("serviceUrl", "https://localhost/"), health.getDetails());

        response.setStatus(Status.OUT_OF_SERVICE);
        health = instance.health();
        Assertions.assertEquals(Status.OUT_OF_SERVICE, health.getStatus());
        Assertions.assertEquals(Map.of("serviceUrl", "https://localhost/"), health.getDetails());

        response.setStatus(Status.UNKNOWN);
        health = instance.health();
        Assertions.assertEquals(Status.UNKNOWN, health.getStatus());
        Assertions.assertEquals(Map.of("serviceUrl", "https://localhost/"), health.getDetails());

        response.setStatus(Status.UP);
        health = instance.health();
        Assertions.assertEquals(Status.UP, health.getStatus());
        Assertions.assertEquals(Map.of("serviceUrl", "https://localhost/"), health.getDetails());
    }
}