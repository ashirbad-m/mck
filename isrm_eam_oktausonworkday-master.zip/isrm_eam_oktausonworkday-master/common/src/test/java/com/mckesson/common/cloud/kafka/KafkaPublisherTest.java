package com.mckesson.common.cloud.kafka;

import com.mckesson.common.model.ModuleEnum;
import com.mckesson.common.workday.converter.ConverterUtils;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.kafka.core.KafkaTemplate;

import java.util.UUID;

class KafkaPublisherTest {
    @Test
    void send() {
        var kafkaTemplate = Mockito.mock(KafkaTemplate.class);
        var topic = UUID.randomUUID().toString();

        var instance = new KafkaPublisher(kafkaTemplate);
        instance.setTopic(topic);

        var payload = UUID.randomUUID().toString();

        instance.send(ModuleEnum.GATEWAY, payload);
        Mockito.verify(kafkaTemplate).send(topic + "." + ModuleEnum.GATEWAY.name(), ConverterUtils.writeValueAsString(payload));

        instance.send(ModuleEnum.FINALIZER, payload);
        Mockito.verify(kafkaTemplate).send(topic + "." + ModuleEnum.FINALIZER.name(), ConverterUtils.writeValueAsString(payload));

        instance.send(ModuleEnum.EMAIL, payload);
        Mockito.verify(kafkaTemplate).send(topic + "." + ModuleEnum.EMAIL.name(), ConverterUtils.writeValueAsString(payload));
        Mockito.verify(kafkaTemplate).send(topic + "." + ModuleEnum.ALL.name(), ConverterUtils.writeValueAsString(payload));
    }
}