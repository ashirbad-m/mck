package com.mckesson.common.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;

class ExecutionMetricTest {

    @Test
    void testConstructor() {
        var instance = new ExecutionMetric(ModuleEnum.GATEWAY, String.class, new Date());
        Assertions.assertEquals("java.lang.String", instance.getClassName());
    }
}