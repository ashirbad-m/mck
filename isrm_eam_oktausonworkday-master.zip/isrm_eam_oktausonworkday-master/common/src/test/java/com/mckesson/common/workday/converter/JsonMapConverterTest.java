package com.mckesson.common.workday.converter;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Collections;
import java.util.Map;

class JsonMapConverterTest {

    @Test
    void convertToDatabaseColumn() {
        JsonMapConverter instance = new JsonMapConverter();
        Assertions.assertNull(instance.convertToDatabaseColumn(Collections.emptyMap()));
        Assertions.assertEquals("{\"key\":\"value\"}", instance.convertToDatabaseColumn(Map.of("key", "value")));
    }

    @Test
    void convertToEntityAttribute() {
        JsonMapConverter instance = new JsonMapConverter();
        Assertions.assertEquals(Collections.emptyMap(), instance.convertToEntityAttribute(null));
        Assertions.assertEquals(Map.of("key", "value"), instance.convertToEntityAttribute("{\"key\":\"value\"}"));
    }
}
