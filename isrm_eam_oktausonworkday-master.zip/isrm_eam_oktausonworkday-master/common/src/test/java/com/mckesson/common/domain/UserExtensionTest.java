package com.mckesson.common.domain;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Set;

class UserExtensionTest {
    @Test
    void createFake() {
        var instance = UserExtension.createFake();
        Assertions.assertEquals("ORGANIZATION", instance.getOrganization());
        Assertions.assertEquals("MARKET", instance.getMarket());
        Assertions.assertEquals("DEPARTMENT", instance.getDepartment());
        Assertions.assertEquals("MANAGER", instance.getManager());
        Assertions.assertEquals(Set.of("GROUP-1", "GROUP-2"), instance.getGroups());
        Assertions.assertEquals("INOU", instance.getInOU());
        Assertions.assertEquals("WASOU", instance.getWasOU());
        Assertions.assertEquals("ADMIN-ACCOUNT", instance.getAdminAccount());
        Assertions.assertEquals(Set.of("SERVICE-ACCOUNT-1", "SERVICE-ACCOUNT-2"), instance.getServiceAccounts());
        Assertions.assertEquals("SERVICE-ACCOUNT-MANAGER", instance.getServiceAccountsManager());
        Assertions.assertEquals(Set.of("OLD-GROUP-1", "OLD-GROUP-2"), instance.getOldGroups());
        Assertions.assertEquals("MANAGER-PHONE", instance.getManagerPhone());
        Assertions.assertEquals("MANAGER-EMAIL", instance.getManagerEmail());
        Assertions.assertEquals("MANAGER-CELL-PHONE", instance.getManagerCellPhone());
        Assertions.assertEquals("DEFAULT_GROUP", instance.getGroup());
    }
}