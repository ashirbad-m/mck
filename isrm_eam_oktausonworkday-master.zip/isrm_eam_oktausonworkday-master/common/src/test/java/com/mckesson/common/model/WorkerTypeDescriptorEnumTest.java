package com.mckesson.common.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class WorkerTypeDescriptorEnumTest {

    @Test
    void getValue() {
        Assertions.assertEquals("Employee", WorkerTypeDescriptorEnum.CWT_EMPLOYEE.getValue());
        Assertions.assertEquals("Contractor", WorkerTypeDescriptorEnum.CWT_CONTRACTOR.getValue());
        Assertions.assertEquals("Outside Company Worker", WorkerTypeDescriptorEnum.CWT_OUTSIDE.getValue());
        Assertions.assertEquals("Contracted Access (IT Use Only)", WorkerTypeDescriptorEnum.CWT_X.getValue());
    }

    @Test
    void findByValue() {
        for(var item: WorkerTypeDescriptorEnum.values()) {
            Assertions.assertEquals(item, WorkerTypeDescriptorEnum.findByValue(item.getValue()));
        }
        try {
            WorkerTypeDescriptorEnum.findByValue("test");
            Assertions.fail("Wrong behavior");
        } catch (IllegalArgumentException ex) {
            Assertions.assertEquals("Unknown value: test", ex.getMessage());
        }
    }


    @Test
    void getCwtValue() {
        Assertions.assertEquals(WorkerTypeDescriptorEnum.CWT_EMPLOYEE, WorkerTypeDescriptorEnum.getCwtValue("regular", false));
        Assertions.assertEquals(WorkerTypeDescriptorEnum.CWT_EMPLOYEE, WorkerTypeDescriptorEnum.getCwtValue("employee", true));

        Assertions.assertEquals(WorkerTypeDescriptorEnum.CWT_EMPLOYEE, WorkerTypeDescriptorEnum.getCwtValue("", true));
        Assertions.assertEquals(WorkerTypeDescriptorEnum.CWT_CONTRACTOR, WorkerTypeDescriptorEnum.getCwtValue("", false));

        Assertions.assertEquals(WorkerTypeDescriptorEnum.CWT_OUTSIDE, WorkerTypeDescriptorEnum.getCwtValue("Outside Company Worker", false));
        Assertions.assertEquals(WorkerTypeDescriptorEnum.CWT_X, WorkerTypeDescriptorEnum.getCwtValue("Contracted Access (IT Use Only)", false));
        Assertions.assertEquals(WorkerTypeDescriptorEnum.CWT_CONTRACTOR, WorkerTypeDescriptorEnum.getCwtValue("Contractor", false));

    }
}