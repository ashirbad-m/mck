package com.mckesson.common.cloud.stream;

import com.mckesson.common.PassportActionProcessor;
import com.mckesson.common.cloud.rabbit.RabbitPassportActionListener;
import com.mckesson.common.domain.PassportAction;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

class StreamPassportActionListenerTest {

    @Test
    void processPassportAction() {
        var actionProcessor = Mockito.mock(PassportActionProcessor.class);
        var instance = new StreamPassportActionListener(actionProcessor);

        var passportAction = new PassportAction();
        passportAction.setEventType(PassportAction.EventTypeEnum.POWERSHELL);

        instance.processPassportAction(passportAction);
        Mockito.verify(actionProcessor).processAction(passportAction);
        Mockito.verifyNoMoreInteractions(actionProcessor);
    }
}