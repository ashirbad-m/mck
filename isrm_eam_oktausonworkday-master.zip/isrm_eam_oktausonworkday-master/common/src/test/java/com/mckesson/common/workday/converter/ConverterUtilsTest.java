package com.mckesson.common.workday.converter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.Map;

public class ConverterUtilsTest {

    @Test
    void ldapNameTest() {
        Exception exception = Assertions.assertThrows(InvalidNameException.class, () -> {
            ConverterUtils.nullableLdapName("broken");
        });

        String expectedMessage = "Invalid name: broken";
        String actualMessage = exception.getMessage();

        Assertions.assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void nullableLdapNameTest() throws InvalidNameException {
        Assertions.assertNull(ConverterUtils.nullableLdapName(null));
        Assertions.assertNull(ConverterUtils.nullableLdapName("null"));
        LdapName ln = new LdapName("OU=USON,OU=B2E_Workday_Okta_AD,DC=mshusontest,DC=com");
        Assertions.assertEquals(ln, ConverterUtils.nullableLdapName(ln.toString()));
    }


    @Test
    void nullSafeBooleanTest() {
        Assertions.assertFalse(ConverterUtils.nullSafeBoolean(null));
        Assertions.assertFalse(ConverterUtils.nullSafeBoolean(false));
        Assertions.assertTrue(ConverterUtils.nullSafeBoolean(true));
    }

    @Test
    void map2NullableObjectTest() {
        Assertions.assertNull(ConverterUtils.map2NullableObject(null, TestBean.class));
        Assertions.assertNull(ConverterUtils.map2NullableObject(Map.of(), TestBean.class));
        Assertions.assertEquals(new TestBean("key", 123), ConverterUtils.map2NullableObject(Map.of("key", "key", "value", 123), TestBean.class));
    }

    @Test
    void object2NullableMapTest() {
        TestBean bean = null;
        Assertions.assertNull(ConverterUtils.object2NullableMap(bean));
        Assertions.assertNull(ConverterUtils.object2NullableMap(new TestBean()));
        Assertions.assertEquals(Map.of("key", "key", "value", 123), ConverterUtils.object2NullableMap(new TestBean("key", 123)));
    }

    @Test
    void writeValueAsStringTest() {
        Assertions.assertEquals("null", ConverterUtils.writeValueAsString(null));
        Assertions.assertEquals("{}", ConverterUtils.writeValueAsString(new TestBean()));
        Assertions.assertEquals("{\"key\":\"key\",\"value\":123}", ConverterUtils.writeValueAsString(new TestBean("key", 123)));
    }


    @Test
    void object2JsonTest() {
        TestBean bean = null;
        Assertions.assertNull(ConverterUtils.object2Json(bean));
        Assertions.assertEquals("{}", ConverterUtils.object2Json(new TestBean()));
        Assertions.assertEquals("{\"key\":\"key\",\"value\":123}", ConverterUtils.object2Json(new TestBean("key", 123)));
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    private static class TestBean {
        private String key;
        private Integer value;
    }
}
