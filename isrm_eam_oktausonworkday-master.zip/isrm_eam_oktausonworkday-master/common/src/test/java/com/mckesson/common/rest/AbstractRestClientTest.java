package com.mckesson.common.rest;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Supplier;

class AbstractRestClientTest {

    private final Consumer<Exception> onError = (ex) -> {
    };

    @Test
    void httpClientBuilder() {
        Assertions.assertNotNull(AbstractRestClient.httpClientBuilder(100));
    }

    @Test
    void processRequestWithRetry() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);

        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);

        var instance = new TestAbstractRestClient("https://localhost", restTemplateBuilder);

        var retryTemplate = new RetryTemplate();
        SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy();
        retryPolicy.setMaxAttempts(1);
        retryTemplate.setRetryPolicy(retryPolicy);

        String response = UUID.randomUUID().toString();
        Assertions.assertEquals(response, instance.processRequestWithRetry(retryTemplate, () -> response, onError));

        try {
            instance.processRequestWithRetry(retryTemplate, () -> {
                throw new RuntimeException("Test");
            }, onError);
            Assertions.fail("Wrong behavior");
        } catch (RuntimeException ex) {
            Assertions.assertEquals("java.lang.RuntimeException: Test", ex.getMessage());
        }
    }

    @Test
    void processRequest() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);

        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);

        var serviceUrl = "https://localhost";
        var instance = new TestAbstractRestClient(serviceUrl, restTemplateBuilder);

        var path = "/path";
        var method = HttpMethod.POST;
        var requestBody = new Object();
        var requestHeaders = new HttpHeaders();
        var responseType = String.class;
        Mockito.when(restTemplate.exchange(Mockito.eq(serviceUrl + path), Mockito.eq(method), Mockito.any(), Mockito.eq(responseType), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok().build());
        instance.processRequest(path, method, requestBody, requestHeaders, responseType);
        Mockito.verify(restTemplate).exchange(Mockito.eq(serviceUrl + path), Mockito.eq(method), Mockito.any(), Mockito.eq(responseType), Mockito.eq(Collections.emptyMap()));

        Mockito.reset(restTemplate);
        ParameterizedTypeReference<List<String>> RETURN_LIST = new ParameterizedTypeReference<>() {
        };
        Mockito.when(restTemplate.exchange(Mockito.eq(serviceUrl + path), Mockito.eq(method), Mockito.any(), Mockito.eq(RETURN_LIST), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok().build());
        instance.processRequest(path, method, requestBody, requestHeaders, RETURN_LIST);
        Mockito.verify(restTemplate).exchange(Mockito.eq(serviceUrl + path), Mockito.eq(method), Mockito.any(), Mockito.eq(RETURN_LIST), Mockito.eq(Collections.emptyMap()));
    }

    private static class TestAbstractRestClient extends AbstractRestClient {

        protected TestAbstractRestClient(String serviceUrl, RestTemplateBuilder restTemplateBuilder) {
            super(serviceUrl, restTemplateBuilder);
        }
    }
}