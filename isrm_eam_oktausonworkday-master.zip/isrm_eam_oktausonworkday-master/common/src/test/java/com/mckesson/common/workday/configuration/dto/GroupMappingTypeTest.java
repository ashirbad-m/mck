package com.mckesson.common.workday.configuration.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.UUID;

class GroupMappingTypeTest {

    @Test
    void valueOfIgnoreCase() {
        for (var item : GroupMappingType.values()) {
            Assertions.assertEquals(item, GroupMappingType.valueOfIgnoreCase(item.name()));
            Assertions.assertEquals(item, GroupMappingType.valueOfIgnoreCase(item.name().toLowerCase()));
        }
        Assertions.assertEquals(null, GroupMappingType.valueOfIgnoreCase(null));
        var value = UUID.randomUUID().toString();
        try {
            Assertions.assertEquals(null, GroupMappingType.valueOfIgnoreCase(value));
        } catch (IllegalArgumentException ex) {
            Assertions.assertEquals("No enum constant " + GroupMappingType.class.getCanonicalName() + "." + value.toUpperCase(), ex.getMessage());
        }
    }
}