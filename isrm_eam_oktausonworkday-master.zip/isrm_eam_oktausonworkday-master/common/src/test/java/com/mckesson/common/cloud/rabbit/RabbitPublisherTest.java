package com.mckesson.common.cloud.rabbit;

import com.mckesson.common.model.ModuleEnum;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.MessageConverter;

import java.util.UUID;

class RabbitPublisherTest {

    @Test
    void send() {
        var rabbitTemplate = Mockito.mock(RabbitTemplate.class);
        var exchange = UUID.randomUUID().toString();

        var instance = new RabbitPublisher(rabbitTemplate);
        instance.setExchange(exchange);

        var payload = UUID.randomUUID().toString();

        var messageConverter = Mockito.mock(MessageConverter.class);
        var message = Mockito.mock(Message.class);
        Mockito.when(rabbitTemplate.getMessageConverter()).thenReturn(messageConverter);
        Mockito.when(messageConverter.toMessage(Mockito.eq(payload), Mockito.any())).thenReturn(message);

        instance.send(ModuleEnum.GATEWAY, payload);
        Mockito.verify(rabbitTemplate).send(Mockito.eq(exchange), Mockito.eq(ModuleEnum.GATEWAY.name()), Mockito.eq(message));

        instance.send(ModuleEnum.FINALIZER, payload);
        Mockito.verify(rabbitTemplate).send(Mockito.eq(exchange), Mockito.eq("module." + ModuleEnum.FINALIZER.name()), Mockito.eq(message));

        instance.send(ModuleEnum.EMAIL, payload);
        Mockito.verify(rabbitTemplate).send(Mockito.eq(exchange), Mockito.eq("module." + ModuleEnum.EMAIL.name()), Mockito.eq(message));
    }
}