package com.mckesson.common.cloud.stream;

import com.mckesson.common.model.ModuleEnum;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.messaging.MessageChannel;
import org.springframework.integration.support.MessageBuilder;

import java.util.UUID;

class StreamPublisherTest {

    @Test
    void send() {
        var output = Mockito.mock(MessageChannel.class);
        var source = Mockito.mock(Source.class);
        Mockito.when(source.output()).thenReturn(output);

        var instance = new StreamPublisher(source);
        var payload = UUID.randomUUID().toString();


        var messageBuilder = MessageBuilder
                .withPayload(payload)
                .setHeader("module", ModuleEnum.GATEWAY.name())
                .setHeader("class", payload.getClass().getCanonicalName());
        instance.send(ModuleEnum.GATEWAY, payload);
        Mockito.verify(output).send(Mockito.refEq(messageBuilder.build(), "headers"));


        Mockito.reset(output);
        payload = UUID.randomUUID().toString();
        messageBuilder = MessageBuilder
                .withPayload(payload)
                .setHeader("module", ModuleEnum.FINALIZER.name())
                .setHeader("class", payload.getClass().getCanonicalName());
        instance.send(ModuleEnum.FINALIZER, payload);
        Mockito.verify(output).send(Mockito.refEq(messageBuilder.build(), "headers"));


        Mockito.reset(output);
        payload = UUID.randomUUID().toString();
        messageBuilder = MessageBuilder
                .withPayload(payload)
                .setHeader("module", ModuleEnum.EMAIL.name())
                .setHeader("class", payload.getClass().getCanonicalName());
        instance.send(ModuleEnum.EMAIL, payload);
        Mockito.verify(output, Mockito.times(2)).send(Mockito.refEq(messageBuilder.build(), "headers"));

        messageBuilder = MessageBuilder
                .withPayload(payload)
                .setHeader("module", ModuleEnum.ALL.name())
                .setHeader("class", payload.getClass().getCanonicalName());
        instance.send(ModuleEnum.ALL, payload);
        //Mockito.verify(output).send(Mockito.refEq(messageBuilder.build(), "headers"));
    }
}