package com.mckesson.common.actuate;

import com.mckesson.common.rest.OAuth2RestClient;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.actuate.health.Status;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

class OAuth2HealthIndicatorTest {

    @Test
    void doHealthCheck() {
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);

        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);
        var retryTemplate = new RetryTemplate();

        String accessTokenUri = "http://localhost/";
        String clientId = UUID.randomUUID().toString();
        String clientSecret = UUID.randomUUID().toString();
        String scope = UUID.randomUUID().toString();
        int connectTimeout = 5000;

        try {
            new OAuth2HealthIndicator(restTemplateBuilder, accessTokenUri, clientId, clientSecret, scope, connectTimeout, retryTemplate);
        } catch (IllegalArgumentException ex) {
            Assertions.assertEquals("Service Url must use HTTPS scheme", ex.getMessage());
        }

        accessTokenUri = "https://localhost/";
        Mockito.when(restTemplate.exchange(Mockito.eq(accessTokenUri), Mockito.eq(HttpMethod.POST), Mockito.any(),
                        Mockito.eq(OAuth2RestClient.Oauth2Response.class), Mockito.eq(Collections.emptyMap())))
                .thenThrow(new RuntimeException("Test"));

        var instance = new OAuth2HealthIndicator(restTemplateBuilder, accessTokenUri, clientId, clientSecret, scope, connectTimeout, retryTemplate);
        var health = instance.health();
        Assertions.assertEquals(Status.DOWN, health.getStatus());
        Assertions.assertEquals(Map.of("accessTokenUri", accessTokenUri,
                "error", "java.lang.RuntimeException: Test"), health.getDetails());


        var tokenResponse = new OAuth2RestClient.Oauth2Response();
        tokenResponse.setAccessToken(UUID.randomUUID().toString());
        tokenResponse.setExpiresIn(100);//TODO
        Mockito.when(restTemplate.exchange(Mockito.eq(accessTokenUri), Mockito.eq(HttpMethod.POST), Mockito.any(),
                        Mockito.eq(OAuth2RestClient.Oauth2Response.class), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(tokenResponse));

        health = instance.health();
        Assertions.assertEquals(Status.UP, health.getStatus());
        Assertions.assertEquals(Map.of("accessTokenUri", accessTokenUri), health.getDetails());
    }
}