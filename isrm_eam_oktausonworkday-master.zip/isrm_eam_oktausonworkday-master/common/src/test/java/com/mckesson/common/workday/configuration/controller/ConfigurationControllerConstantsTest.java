package com.mckesson.common.workday.configuration.controller;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ConfigurationControllerConstantsTest {

    @Test
    void testConstants() {
        Assertions.assertEquals("java.util.List<com.mckesson.common.model.DomainConfig>", ConfigurationControllerConstants.RETURN_DOMAINS_LIST.getType().toString());
        Assertions.assertEquals("java.util.List<com.mckesson.common.model.HrbuConfig>", ConfigurationControllerConstants.RETURN_HRBU_VIEW_LIST.getType().toString());
        Assertions.assertEquals("java.util.List<com.mckesson.common.model.WorkdayConfig>", ConfigurationControllerConstants.RETURN_GLOBALS_LIST.getType().toString());
        Assertions.assertEquals("java.util.List<com.mckesson.common.workday.configuration.dto.GroupMappingDto>", ConfigurationControllerConstants.RETURN_GROUP_MAPPINGS_LIST.getType().toString());
        Assertions.assertEquals("java.util.List<com.mckesson.common.workday.configuration.dto.HrbuCityStreetDto>", ConfigurationControllerConstants.RETURN_HRBU_CITY_STREET_LIST.getType().toString());
        Assertions.assertEquals("java.util.List<com.mckesson.common.workday.configuration.dto.HrbuDto>", ConfigurationControllerConstants.RETURN_HRBU_LIST.getType().toString());
    }

}