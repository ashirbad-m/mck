package com.mckesson.common.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ScenarioEnumTest {

    @Test
    void valueByName() {
        for (ScenarioEnum value : ScenarioEnum.values()) {
            Assertions.assertEquals(value, ScenarioEnum.valueByName(value.getName()));
        }
        try {
            ScenarioEnum.valueByName("-test-");
        } catch (IllegalArgumentException ex) {
            Assertions.assertEquals("Unknown scenario name: -test-", ex.getMessage());
        }
    }

    @Test
    void getName() {
        Assertions.assertEquals("create", ScenarioEnum.CREATE.getName());
        Assertions.assertEquals("update", ScenarioEnum.UPDATE.getName());
        Assertions.assertEquals("crossdomain", ScenarioEnum.CROSSDOMAIN.getName());
        Assertions.assertEquals("terminate", ScenarioEnum.TERMINATE.getName());
        Assertions.assertEquals("request", ScenarioEnum.REQUEST.getName());
        Assertions.assertEquals("deferred", ScenarioEnum.DEFERRED.getName());
        Assertions.assertEquals("synchronize", ScenarioEnum.SYNCHRONIZE.getName());
    }
}