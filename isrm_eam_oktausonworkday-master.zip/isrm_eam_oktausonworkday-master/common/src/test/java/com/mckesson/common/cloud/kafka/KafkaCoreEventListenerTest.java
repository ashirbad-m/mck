package com.mckesson.common.cloud.kafka;

import com.mckesson.common.CoreEventProcessor;
import com.mckesson.common.model.CoreEvent;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.UUID;

class KafkaCoreEventListenerTest {

    @Test
    void processEvent() {
        var coreEventProcessor = Mockito.mock(CoreEventProcessor.class);
        var instance = new KafkaCoreEventListener(coreEventProcessor);

        CoreEvent coreEvent = new CoreEvent();
        coreEvent.setId(UUID.randomUUID().toString());

        instance.processEvent(coreEvent);
        Mockito.verify(coreEventProcessor).processEvent(coreEvent);
        Mockito.verifyNoMoreInteractions(coreEventProcessor);
    }
}