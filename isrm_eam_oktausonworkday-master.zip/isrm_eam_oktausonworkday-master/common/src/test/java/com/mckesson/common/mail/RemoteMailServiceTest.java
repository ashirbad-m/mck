package com.mckesson.common.mail;

import com.mckesson.common.model.EmailMessage;
import com.mckesson.common.rest.OAuth2RestClient;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Supplier;

class RemoteMailServiceTest {

    private Consumer<Exception> onError = (ex) -> {
    };

    @Test
    void send() {
        String serviceUrl = "https://localhost/mail-service/";
        String accessTokenUri = UUID.randomUUID().toString();
        String clientId = UUID.randomUUID().toString();
        String clientSecret = UUID.randomUUID().toString();
        String scope = UUID.randomUUID().toString();
        int connectTimeout = 3000;

        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);

        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);

        var instance = new RemoteMailService(serviceUrl, restTemplateBuilder,
                accessTokenUri, clientId, clientSecret, scope, connectTimeout,
                new RetryTemplate());

        var tokenResponse = new OAuth2RestClient.Oauth2Response();
        tokenResponse.setAccessToken(UUID.randomUUID().toString());
        tokenResponse.setExpiresIn(100);//TODO

        Mockito.when(restTemplate.exchange(Mockito.eq(accessTokenUri), Mockito.eq(HttpMethod.POST), Mockito.any(HttpEntity.class),
                        Mockito.eq(OAuth2RestClient.Oauth2Response.class), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(tokenResponse));

        Mockito.when(restTemplate.exchange(Mockito.eq(serviceUrl + "email/send"), Mockito.eq(HttpMethod.POST), Mockito.any(HttpEntity.class),
                Mockito.eq(Object.class), Mockito.eq(Collections.emptyMap()))).thenReturn(ResponseEntity.ok().build());

        var message = EmailMessage.builder()
                .to(Set.of("to1@labad.com", "to2@labad.com"))
                .subject(UUID.randomUUID().toString())
                .body(UUID.randomUUID().toString())
                .build();

        instance.send(message, onError);

        Mockito.verify(restTemplate).exchange(Mockito.eq(serviceUrl + "email/send"), Mockito.eq(HttpMethod.POST), Mockito.any(HttpEntity.class),
                Mockito.eq(Object.class), Mockito.eq(Collections.emptyMap()));
    }
}