package com.mckesson.common.cloud.stream;

import com.mckesson.common.SyncCheckProcessor;
import com.mckesson.common.model.SyncCheck;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.UUID;

class StreamSyncCheckListenerTest {

    @Test
    void process() {
        var syncCheckProcessor = Mockito.mock(SyncCheckProcessor.class);
        var instance = new StreamSyncCheckListener(syncCheckProcessor);

        SyncCheck syncCheck = SyncCheck.builder()
                .oktaUserId(UUID.randomUUID().toString())
                .build();

        instance.process(syncCheck);
        Mockito.verify(syncCheckProcessor).process(syncCheck);
        Mockito.verifyNoMoreInteractions(syncCheckProcessor);
    }
}