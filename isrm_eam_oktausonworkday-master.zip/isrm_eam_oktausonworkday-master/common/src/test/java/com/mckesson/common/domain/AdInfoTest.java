package com.mckesson.common.domain;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.Collections;
import java.util.Set;

class AdInfoTest {

    @Test
    void storeOriginalGroups() throws InvalidNameException {
        var instance = new AdInfo();
        String dn1 = "CN=group1,OU=Test,DC=mshusontest,DC=com";
        AdGroup group1 = new AdGroup("uid", "domain",
                new LdapName(dn1), dn1, Collections.emptySet(), "description", null, null, "group1", null);
        String dn2 = "CN=group2,OU=Test,DC=mshusontest,DC=com";
        AdGroup group2 = new AdGroup("uid", "domain",
                new LdapName(dn2), dn2, Collections.emptySet(), "description", null, null, "group2", null);

        instance.setOriginal(null);
        Assertions.assertNotNull(instance.getOriginal());

        instance.storeOriginalGroups(Set.of(group1, group2));
        Assertions.assertEquals(2, instance.getOriginal().getGroups().size());
    }

    @Test
    void storeCurrentGroups() throws InvalidNameException {
        var instance = new AdInfo();
        String dn1 = "CN=group1,OU=Test,DC=mshusontest,DC=com";
        AdGroup group1 = new AdGroup("uid", "domain",
                new LdapName(dn1), dn1, Collections.emptySet(), "description", null, null, "group1", null);
        String dn2 = "CN=group2,OU=Test,DC=mshusontest,DC=com";
        AdGroup group2 = new AdGroup("uid", "domain",
                new LdapName(dn2), dn2, Collections.emptySet(), "description", null, null, "group2", null);

        instance.setCurrent(null);
        Assertions.assertNotNull(instance.getCurrent());

        instance.storeCurrentGroups(Set.of(group1, group2));
        Assertions.assertEquals(2, instance.getCurrent().getGroups().size());
    }
}