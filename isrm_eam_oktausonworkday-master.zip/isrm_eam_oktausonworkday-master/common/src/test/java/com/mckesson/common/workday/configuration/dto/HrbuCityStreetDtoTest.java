package com.mckesson.common.workday.configuration.dto;

import org.junit.jupiter.api.Test;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.Set;
import java.util.UUID;

class HrbuCityStreetDtoTest {

    @Test
    void testСonstructor() throws InvalidNameException {
        var instance = new HrbuCityStreetDto(
                new LdapName("OU=Test,DC=mshusontest,DC=com"),
                UUID.randomUUID().toString(),
                UUID.randomUUID().toString(),
                UUID.randomUUID().toString(),
                Set.of(UUID.randomUUID().toString()),
                Set.of(UUID.randomUUID().toString()),
                Set.of(UUID.randomUUID().toString()),
                Set.of(UUID.randomUUID().toString()),
                false,
                UUID.randomUUID().toString(),
                1L,
                UUID.randomUUID().toString(),
                UUID.randomUUID().toString()
        );
        //TODO
    }
}