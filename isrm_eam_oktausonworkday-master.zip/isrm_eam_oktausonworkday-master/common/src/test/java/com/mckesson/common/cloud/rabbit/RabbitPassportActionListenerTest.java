package com.mckesson.common.cloud.rabbit;

import com.mckesson.common.PassportActionProcessor;
import com.mckesson.common.cloud.kafka.KafkaPassportActionListener;
import com.mckesson.common.domain.PassportAction;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

class RabbitPassportActionListenerTest {

    @Test
    void processPassportAction() {
        var actionProcessor = Mockito.mock(PassportActionProcessor.class);
        var instance = new RabbitPassportActionListener(actionProcessor);

        var passportAction = new PassportAction();
        passportAction.setEventType(PassportAction.EventTypeEnum.POWERSHELL);

        instance.processPassportAction(passportAction);
        Mockito.verify(actionProcessor).processAction(passportAction);
        Mockito.verifyNoMoreInteractions(actionProcessor);
    }
}