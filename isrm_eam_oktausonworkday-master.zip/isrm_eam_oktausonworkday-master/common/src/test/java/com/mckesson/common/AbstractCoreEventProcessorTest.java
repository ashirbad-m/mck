package com.mckesson.common;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.model.ModuleEnum;
import com.mckesson.common.model.ScenarioEnum;
import com.mckesson.common.scenario.ScenarioProvider;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.ArrayList;

class AbstractCoreEventProcessorTest {

    @Test
    void processEvent() {
    }

    @Test
    void getProcessors() {
        var messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
        var instance = new AbstractCoreEventProcessor(new ScenarioProvider(), messageBrokerPublisher, ModuleEnum.GATEWAY);

        Assertions.assertTrue(instance.getProcessors().isEmpty());
    }

    @Test
    void getModule() {
        var messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
        var instance = new AbstractCoreEventProcessor(new ScenarioProvider(), messageBrokerPublisher, ModuleEnum.GATEWAY);

        Assertions.assertEquals(ModuleEnum.GATEWAY, instance.getModule());
    }

    @Test
    void doProcessEvent() {
        var messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
        var instance = new AbstractCoreEventProcessor(new ScenarioProvider(), messageBrokerPublisher, ModuleEnum.GATEWAY);

        var updated = System.currentTimeMillis();
        var eventBuilder = CoreEvent.builder()
                .module(ModuleEnum.AUDIT)
                .scenario(ScenarioEnum.CREATE)
                .stage("test")
                .updated(updated)
                .metrics(new ArrayList<>());

        try {
            instance.doProcessEvent(eventBuilder.build());
            Assertions.fail("Wrong behavior");
        } catch (IllegalStateException ex) {
            Assertions.assertEquals("Wrong event listener, expected module " + ModuleEnum.GATEWAY, ex.getMessage());
        }

        var event = eventBuilder
                .module(ModuleEnum.GATEWAY)
                .failed(true)
                .build();
        instance.doProcessEvent(event);
        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.ACTIVE_DIRECTORY), Mockito.refEq(event, "updated"));
        Mockito.verifyNoMoreInteractions(messageBrokerPublisher);

        Mockito.reset(messageBrokerPublisher);
        event = eventBuilder
                .module(ModuleEnum.GATEWAY)
                .build();
        instance.processEvent(event);
        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.ACTIVE_DIRECTORY), Mockito.refEq(event, "updated"));
        Mockito.verifyNoMoreInteractions(messageBrokerPublisher);
    }

    @Test
    void registerError() {
        var messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
        var instance = new AbstractCoreEventProcessor(new ScenarioProvider(), messageBrokerPublisher, ModuleEnum.GATEWAY);

        instance.registerError(new CoreEvent());
        Mockito.verifyNoInteractions(messageBrokerPublisher);
    }

    @Test
    void doNextStep() {
        var messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
        var instance = new AbstractCoreEventProcessor(new ScenarioProvider(), messageBrokerPublisher, ModuleEnum.GATEWAY);

        var updated = System.currentTimeMillis();
        var event = CoreEvent.builder()
                .module(ModuleEnum.GATEWAY)
                .scenario(ScenarioEnum.CREATE)
                .stage("test")
                .updated(updated)
                .build();

        instance.doNextStep(event);

        Assertions.assertTrue(event.getUpdated() >= updated);
        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.ACTIVE_DIRECTORY), Mockito.refEq(event, "updated"));
        Mockito.verifyNoMoreInteractions(messageBrokerPublisher);
    }
}