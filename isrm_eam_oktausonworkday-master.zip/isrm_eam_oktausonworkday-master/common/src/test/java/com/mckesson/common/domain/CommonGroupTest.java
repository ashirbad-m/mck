package com.mckesson.common.domain;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.UUID;

public class CommonGroupTest {

    @Test
    void hashCodeTest() {
        var dn = UUID.randomUUID().toString();
        var instance = new CommonGroup("", dn);
        Assertions.assertEquals(dn.hashCode(), instance.hashCode());
    }

    @Test
    void equalsTest() {
        var dn = UUID.randomUUID().toString();
        var instance1 = new CommonGroup("instance1", dn);
        var instance2 = new CommonGroup("instance2", dn);
        Assertions.assertEquals(instance1, instance2);
        var instance22 = new CommonGroup("instance2", dn);
        Assertions.assertEquals(instance2, instance22);
        var instance3 = new CommonGroup("instance1", UUID.randomUUID().toString());
        Assertions.assertNotEquals(instance1, instance3);
    }
}
