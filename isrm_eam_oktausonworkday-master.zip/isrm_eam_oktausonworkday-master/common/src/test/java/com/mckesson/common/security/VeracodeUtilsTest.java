package com.mckesson.common.security;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.owasp.encoder.Encode;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

class VeracodeUtilsTest {

    @Test
    void encode() {
        var msg = UUID.randomUUID().toString();
        Assertions.assertEquals(Encode.forHtml(msg), VeracodeUtils.encode(msg));
    }

    @Test
    void encode4java() {
        var msg = UUID.randomUUID().toString();
        Assertions.assertEquals(Encode.forJava(msg), VeracodeUtils.encode4java(msg));
    }

    @Test
    void encode4url() {
        var msg = UUID.randomUUID().toString();
        Assertions.assertEquals(URLEncoder.encode(msg, StandardCharsets.UTF_8), VeracodeUtils.encode4url(msg));
    }

    @Test
    void stackTrace2String() {
        var ex = new Exception();
        Assertions.assertEquals(ExceptionUtils.getStackTrace(ex), VeracodeUtils.stackTrace2String(ex));
    }
}