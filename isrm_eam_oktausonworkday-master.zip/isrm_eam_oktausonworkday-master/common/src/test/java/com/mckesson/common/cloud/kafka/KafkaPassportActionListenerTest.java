package com.mckesson.common.cloud.kafka;

import com.mckesson.common.PassportActionProcessor;
import com.mckesson.common.domain.PassportAction;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class KafkaPassportActionListenerTest {

    @Test
    void processPassportAction() {
        var actionProcessor = Mockito.mock(PassportActionProcessor.class);
        var instance = new KafkaPassportActionListener(actionProcessor);

        var passportAction = new PassportAction();
        passportAction.setEventType(PassportAction.EventTypeEnum.POWERSHELL);

        instance.processPassportAction(passportAction);
        Mockito.verify(actionProcessor).processAction(passportAction);
        Mockito.verifyNoMoreInteractions(actionProcessor);
    }
}