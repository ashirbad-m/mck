package com.mckesson.common.ldap;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.UUID;

class LdapUtilsTest {

    @Test
    void string2B16le() {
        try {
            LdapUtils.string2B16le(null);
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
            //ignore
        }
        Assertions.assertArrayEquals("\"\"".getBytes(StandardCharsets.UTF_16LE), LdapUtils.string2B16le(""));
        Assertions.assertArrayEquals("\"12_ab\"".getBytes(StandardCharsets.UTF_16LE), LdapUtils.string2B16le("12_ab"));
    }

    @Test
    void b16le2String() {
        try {
            LdapUtils.b16le2String(null);
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
            //ignore
        }
        Assertions.assertEquals("", LdapUtils.b16le2String("\"\"".getBytes(StandardCharsets.UTF_16LE)));
        Assertions.assertEquals("12_ab", LdapUtils.b16le2String("\"12_ab\"".getBytes(StandardCharsets.UTF_16LE)));
        Assertions.assertNull(LdapUtils.b16le2String("12_ab".getBytes(StandardCharsets.UTF_16LE)));
    }

    @Test
    void string2Guid() {
        try {
            LdapUtils.string2Guid(null);
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
            //ignore
        }
        var guid = UUID.randomUUID().toString();
        Assertions.assertEquals(guid, LdapUtils.guid2String(LdapUtils.string2Guid(guid)));
    }

    @Test
    void getGuidForSearch() {
        try {
            LdapUtils.getGuidForSearch(null);
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
            //ignore
        }
        Assertions.assertEquals("\\b7\\e8\\8c\\87\\13\\27\\a9\\41\\a7\\65\\5e\\39\\05\\ab\\5e\\f2",
                LdapUtils.getGuidForSearch("878ce8b7-2713-41a9-a765-5e3905ab5ef2"));
    }

    @Test
    void getParentDN() throws InvalidNameException {
        Assertions.assertEquals("OU=Test,DC=mshusontest,DC=com", LdapUtils.getParentDN(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com")));
        Assertions.assertNull(LdapUtils.getParentDN(new LdapName(Collections.emptyList())));
    }

    @Test
    void normalizeCN() {
        Assertions.assertEquals(" _User123_ ", LdapUtils.normalizeCN(" _User123_ "));
    }

    @Test
    void appendToLdapName() throws InvalidNameException {
        Assertions.assertEquals(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"), LdapUtils.appendToLdapName("OU=Test,DC=mshusontest,DC=com", "cn", "User1"));
        Assertions.assertNull(LdapUtils.appendToLdapName("wrong", "cn", "User1"));
    }

    @Test
    void dnToRDNValue() throws InvalidNameException {
        Assertions.assertEquals("User1", LdapUtils.dnToRDNValue((new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"))));
        Assertions.assertNull(LdapUtils.dnToRDNValue(new LdapName(Collections.emptyList())));
    }
}