package com.mckesson.common.scenario;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ScenarioProviderTest {

    @Test
    void getScenario() {
        Assertions.assertEquals("HardCodedScenario", new ScenarioProvider().getScenario().getClass().getSimpleName());
    }

}