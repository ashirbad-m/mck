package com.mckesson.common.dao;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.model.ScenarioEnum;
import org.junit.jupiter.api.Test;

import java.util.UUID;

class JpaCoreEventDaoTest {

    @Test
    void create() {
        CoreEvent coreEvent = new CoreEvent();
        coreEvent.setId(UUID.randomUUID().toString());
        coreEvent.setBatchId(UUID.randomUUID().toString());
        coreEvent.setTarget("passport");
        coreEvent.setScenario(ScenarioEnum.UPDATE);
        coreEvent.setStage("activate");

        var instance = new JpaCoreEventDao();
        instance.create(coreEvent);
    }

    @Test
    void update() {
        CoreEvent coreEvent = new CoreEvent();
        coreEvent.setId(UUID.randomUUID().toString());
        coreEvent.setBatchId(UUID.randomUUID().toString());
        coreEvent.setTarget("passport");
        coreEvent.setScenario(ScenarioEnum.UPDATE);
        coreEvent.setStage("activate");

        var instance = new JpaCoreEventDao();
        instance.update(coreEvent);
    }

    @Test
    void delete() {
        CoreEvent coreEvent = new CoreEvent();
        coreEvent.setId(UUID.randomUUID().toString());
        coreEvent.setBatchId(UUID.randomUUID().toString());
        coreEvent.setTarget("passport");
        coreEvent.setScenario(ScenarioEnum.UPDATE);
        coreEvent.setStage("activate");

        var instance = new JpaCoreEventDao();
        instance.delete(coreEvent);
    }
}