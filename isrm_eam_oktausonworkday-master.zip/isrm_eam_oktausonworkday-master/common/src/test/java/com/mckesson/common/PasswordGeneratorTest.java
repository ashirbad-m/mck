package com.mckesson.common;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class PasswordGeneratorTest {

    @Test
    void generate() {
        var instance = new PasswordGenerator();
        for (int ii = 1; ii < 20; ii++) {
            Assertions.assertTrue(instance.generate(ii).length() >= ii);
        }
    }
}