package com.mckesson.common.scenario;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.model.ModuleEnum;
import com.mckesson.common.model.ScenarioEnum;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.stream.Stream;

class HardCodedScenarioTest {

    @Test
    void nextEvent() {
        var instance = new HardCodedScenario();
        Stream.of(
                Pair.of(ScenarioEnum.CREATE, new HardCodedScenario.ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER)),
                Pair.of(ScenarioEnum.UPDATE, new HardCodedScenario.ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER)),
                Pair.of(ScenarioEnum.CROSSDOMAIN, new HardCodedScenario.ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER)),
                Pair.of(ScenarioEnum.TERMINATE, new HardCodedScenario.ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER)),
                Pair.of(ScenarioEnum.REQUEST, new HardCodedScenario.ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER)),
                Pair.of(ScenarioEnum.DEFERRED, new HardCodedScenario.ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER)),
                Pair.of(ScenarioEnum.SYNCHRONIZE, new HardCodedScenario.ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER))
        ).forEach(pair -> {
            var scenario = pair.getLeft();
            var moduleScenario = pair.getRight();
            var event = new CoreEvent();
            event.setScenario(scenario);

            instance.nextEvent(event);
            Assertions.assertEquals(moduleScenario.getNextModule(null), event.getModule());
            for (var module : moduleScenario.map.keySet()) {
                event = new CoreEvent();
                event.setScenario(scenario);
                event.setModule(module);
                instance.nextEvent(event);
                Assertions.assertEquals(moduleScenario.getNextModule(module), event.getModule());
            }
        });
    }
}