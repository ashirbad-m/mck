package com.mckesson.common.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Set;

class WorkdayConfigTest {

    @Test
    void isHrbuChangeSuppressed() {
        var instance = WorkdayConfig.builder()
                .suppressHrbuTransfer(Set.of("oldHrbu", ""))
                .build();
        Assertions.assertTrue(instance.isHrbuChangeSuppressed("oldHrbu", "newHrbu"));

        instance = WorkdayConfig.builder()
                .suppressHrbuTransfer(Set.of("newHrbu", ""))
                .build();
        Assertions.assertTrue(instance.isHrbuChangeSuppressed("oldHrbu", "newHrbu"));

        instance = WorkdayConfig.builder()
                .suppressHrbuTransfer(Set.of("hrbu1", "hrbu2", ""))
                .build();
        Assertions.assertFalse(instance.isHrbuChangeSuppressed("oldHrbu", "newHrbu"));

        try {
            instance.isHrbuChangeSuppressed(null, "newHrbu");
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
        }
        try {
            instance.isHrbuChangeSuppressed("oldHrbu", null);
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
        }
    }

    @Test
    void isClinicalTransferSuppressed() {
        var instance = WorkdayConfig.builder()
                .suppressClinicalTransfer(Set.of("oldCompanyId", ""))
                .build();
        Assertions.assertTrue(instance.isClinicalTransferSuppressed("oldCompanyId", "newCompanyId"));

        instance = WorkdayConfig.builder()
                .suppressClinicalTransfer(Set.of("newCompanyId", ""))
                .build();
        Assertions.assertTrue(instance.isClinicalTransferSuppressed("oldCompanyId", "newCompanyId"));

        instance = WorkdayConfig.builder()
                .suppressClinicalTransfer(Set.of("CompanyId1", "CompanyId2", ""))
                .build();
        Assertions.assertFalse(instance.isClinicalTransferSuppressed("oldCompanyId", "newCompanyId"));

        try {
            instance.isClinicalTransferSuppressed(null, "newCompanyId");
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
        }
        try {
            instance.isClinicalTransferSuppressed("oldCompanyId", null);
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
        }
    }


    @Test
    void isTexasHrbu() {
        var instance = WorkdayConfig.builder()
                .texasHrbus(Set.of("hrbu", ""))
                .build();
        Assertions.assertTrue(instance.isTexasHrbu("hrbu"));

        instance = WorkdayConfig.builder()
                .texasHrbus(Set.of("hrbu1", "hrbu2", ""))
                .build();
        Assertions.assertFalse(instance.isTexasHrbu("hrbu"));

        try {
            instance.isTexasHrbu(null);
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
        }
    }

    @Test
    void isMcKessonHRBU() {
        var instance = WorkdayConfig.builder()
                .mckessonHrbu("hrbu")
                .build();
        Assertions.assertTrue(instance.isMcKessonHRBU("Hrbu"));

        Assertions.assertFalse(instance.isMcKessonHRBU("_hrbu"));
        Assertions.assertFalse(instance.isMcKessonHRBU("ab"));

        try {
            instance.isMcKessonHRBU(null);
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
        }
    }

    @Test
    void isNotifyOnAbsence() {
        var instance = WorkdayConfig.builder()
                .preventLoaJobCodes(Set.of("code1:", "code2:", ""))
                .build();
        Assertions.assertFalse(instance.isNotifyOnAbsence("code1-"));
        Assertions.assertFalse(instance.isNotifyOnAbsence("code2-"));

        Assertions.assertTrue(instance.isNotifyOnAbsence("code3-"));

        try {
            instance.isNotifyOnAbsence(null);
            Assertions.fail("Wrong behavior");
        } catch (NullPointerException ex) {
        }
    }

    /*


    public boolean isNotifyOnAbsence(@NonNull String jobFamily) {
        final String prefix = jobFamily.split("-")[0] + ":";
        return Objects.requireNonNull(preventLoaJobCodes)
            .stream()
            .filter(StringUtils::isNotBlank)
            .noneMatch(s -> s.startsWith(prefix));
    }

     */
}