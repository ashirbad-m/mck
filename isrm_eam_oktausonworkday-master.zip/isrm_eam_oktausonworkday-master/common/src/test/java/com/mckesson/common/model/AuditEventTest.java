package com.mckesson.common.model;

import com.mckesson.common.domain.OktaUser;
import com.mckesson.common.domain.PassportAction;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.UUID;

class AuditEventTest {

    @Test
    void generateEvent() {
        var event = new CoreEvent();
        event.setBatchId(UUID.randomUUID().toString());
        event.setId(UUID.randomUUID().toString());
        event.setOwfFlowId(UUID.randomUUID().toString());
        event.setOwfExecutionId(UUID.randomUUID().toString());

        var nextUser = new OktaUser();
        nextUser.setUserId(UUID.randomUUID().toString());
        event.setNextOktaUser(nextUser);

        var result = AuditEvent.generateEvent(event).build();

        Assertions.assertEquals(AuditEvent.Application.PASSPORT, result.getApp());
        Assertions.assertEquals(event.getBatchId(), result.getBatchId());
        Assertions.assertEquals(event.getOwfFlowId(), result.getOwfFlowId());
        Assertions.assertEquals(event.getOwfExecutionId(), result.getOwfExecutionId());
        Assertions.assertEquals(event.getId(), result.getOktaEventId());
        Assertions.assertEquals(nextUser.getUserId(), result.getOktaUserId());
    }

    @Test
    void testGenerateEvent() {
        var eventBody = new PassportAction.CommonEventBody();
        eventBody.setBatchId(UUID.randomUUID().toString());
        eventBody.setOwfFlowId(UUID.randomUUID().toString());
        eventBody.setOwfExecutionId(UUID.randomUUID().toString());
        eventBody.setEventId(UUID.randomUUID().toString());
        eventBody.setOktaUserId(UUID.randomUUID().toString());

        var result = AuditEvent.generateEvent(eventBody).build();
        Assertions.assertEquals(AuditEvent.Application.PASSPORT, result.getApp());
        Assertions.assertEquals(eventBody.getBatchId(), result.getBatchId());
        Assertions.assertEquals(eventBody.getOwfFlowId(), result.getOwfFlowId());
        Assertions.assertEquals(eventBody.getOwfExecutionId(), result.getOwfExecutionId());
        Assertions.assertEquals(eventBody.getEventId(), result.getOktaEventId());
        Assertions.assertEquals(eventBody.getOktaUserId(), result.getOktaUserId());
    }
}