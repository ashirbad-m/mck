package com.mckesson.common.workday.converter;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mckesson.common.config.JacksonConfig;
import org.junit.jupiter.api.Test;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class LdapNameJsonComponentTest {

    private ObjectMapper objectMapper = new JacksonConfig().objectMapper();

    @Test
    public void testLdapNameSerializer() throws IOException {
        LdapNameJsonComponent.LdapNameSerializer instance = new LdapNameJsonComponent.LdapNameSerializer();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        JsonGenerator jsonGenerator = objectMapper.createGenerator(baos);
        instance.serialize(null, jsonGenerator, null);
        assertEquals("", new String(baos.toByteArray()));
    }

    @Test
    public void testSerialization() throws JsonProcessingException, InvalidNameException {
        assertEquals("null", objectMapper.writeValueAsString(null));

        LdapName value = new LdapName("OU=USON,OU=B2E_Workday_Okta_AD,DC=mshusontest,DC=com");
        String json = objectMapper.writeValueAsString(value);

        assertEquals("\"OU=USON,OU=B2E_Workday_Okta_AD,DC=mshusontest,DC=com\"", json);
    }

    @Test
    public void testDeserialization() throws JsonProcessingException, InvalidNameException {
        LdapName expected = new LdapName("OU=USON,OU=B2E_Workday_Okta_AD,DC=mshusontest,DC=com");
        LdapName actual = objectMapper.readValue('"' + expected.toString() + '"', LdapName.class);

        assertEquals(expected, actual);
    }

}