package com.mckesson.common.workday;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;

public abstract class CommonTest {


    private static boolean initialized;

    @BeforeEach
    void beforeEach() {
        if (!initialized) {
            init0();
            initialized = true;
        }
    }

    protected abstract void init0();

    @AfterAll
    static void clean() {
        initialized = false;
    }

}
