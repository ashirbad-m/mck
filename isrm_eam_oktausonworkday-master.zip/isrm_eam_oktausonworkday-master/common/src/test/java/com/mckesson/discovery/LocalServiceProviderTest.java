package com.mckesson.discovery;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class LocalServiceProviderTest {

    @Test
    void getServiceUri() {
        var instance = new LocalServiceProvider();
        Assertions.assertEquals("http://localhost:7710", instance.getServiceUrl("global-mfa-remedyforce", ""));
        Assertions.assertEquals("http://localhost:7720", instance.getServiceUrl("global-mfa-exchange", ""));
        Assertions.assertEquals("http://localhost:7730", instance.getServiceUrl("global-mfa-ad", ""));
        Assertions.assertEquals("http://localhost:7740", instance.getServiceUrl("global-mfa-mail", ""));
        Assertions.assertEquals("http://localhost:7750", instance.getServiceUrl("global-mfa-core", ""));
        Assertions.assertEquals("http://localhost:7760/test", instance.getServiceUrl("global-mfa-configuration", "/test"));
        try {
            instance.getServiceUrl("global-mfa-test", "");
            Assertions.fail("Wrong behavior");
        } catch (UnsupportedOperationException ex) {
            Assertions.assertEquals("Unsupported operation", ex.getMessage());

        }
    }
}