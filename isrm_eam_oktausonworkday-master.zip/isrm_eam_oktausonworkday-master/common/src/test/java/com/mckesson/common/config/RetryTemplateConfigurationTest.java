package com.mckesson.common.config;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class RetryTemplateConfigurationTest {

    @Test
    void retryTemplate() {
        var instance = new RetryTemplateConfiguration();
        Assertions.assertNotNull(instance.retryTemplate());
    }
}