package com.mckesson.common.rest;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;

import java.io.ByteArrayInputStream;
import java.io.IOException;

class Slf4jExceptionHandlerTest {

    @Test
    void handleError() throws IOException {
        var instance = new Slf4jExceptionHandler();

        var response = Mockito.mock(ClientHttpResponse.class);
        Mockito.when(response.getStatusCode()).thenReturn(HttpStatus.ACCEPTED);
        Mockito.when(response.getBody()).thenReturn(new ByteArrayInputStream("".getBytes()));
        instance.handleError(response);
        //TODO
    }
}