package com.mckesson.common.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class UsonUtilTest {

    @Test
    void generateArchivedHomeDirectory() {
        Assertions.assertEquals("\\prefix\\2ARCHIVENETSEC\\username", UsonUtil.generateArchivedHomeDirectory("\\prefix\\username"));
        Assertions.assertEquals("\\2ARCHIVENETSEC\\username", UsonUtil.generateArchivedHomeDirectory("\\username"));
        Assertions.assertEquals(null, UsonUtil.generateArchivedHomeDirectory(null));
        Assertions.assertEquals("", UsonUtil.generateArchivedHomeDirectory(""));
        Assertions.assertEquals(" ", UsonUtil.generateArchivedHomeDirectory(" "));
    }
}