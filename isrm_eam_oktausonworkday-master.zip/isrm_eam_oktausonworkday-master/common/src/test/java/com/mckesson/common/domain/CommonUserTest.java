package com.mckesson.common.domain;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.UUID;

public class CommonUserTest {
    @Test
    void same() {
        var instance1 = CommonUser.builder()
                .dn(UUID.randomUUID().toString())
                .build();
        Assertions.assertTrue(instance1.same(instance1));
        Assertions.assertFalse(instance1.same(null));

        var instance2 = instance1.toBuilder()
                .build();
        Assertions.assertTrue(instance1.same(instance2));
        instance2 = instance1.toBuilder()
                .dn(UUID.randomUUID().toString())
                .build();
        Assertions.assertFalse(instance1.same(instance2));
    }

    @Test
    void printDiff() {
        var instance1 = CommonUser.builder()
                .dn(UUID.randomUUID().toString())
                .userPrincipalName(UUID.randomUUID().toString())
                .build();
        Assertions.assertEquals("", CommonUser.printDiff(instance1, instance1));

        var instance2 = instance1.toBuilder().build();
        Assertions.assertEquals("", CommonUser.printDiff(instance1, instance2));

        instance2 = CommonUser.builder()
                .dn(UUID.randomUUID().toString())
                .userPrincipalName(UUID.randomUUID().toString())
                .build();
        var expected = "dn ad: `" + instance1.getDn() + "` okta: `" + instance2.getDn() + "`\n"+
                "userPrincipalName ad: `" + instance1.getUserPrincipalName() + "` okta: `" + instance2.getUserPrincipalName() + "`";
        Assertions.assertEquals(expected, CommonUser.printDiff(instance1, instance2));
    }
}
