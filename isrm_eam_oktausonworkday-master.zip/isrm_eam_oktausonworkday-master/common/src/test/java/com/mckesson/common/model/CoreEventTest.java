package com.mckesson.common.model;

import com.mckesson.common.domain.OktaUser;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.UUID;

class CoreEventTest {

    @Test
    void getOktaUser() throws InvalidNameException {
        var prevOktaUser = new OktaUser();
        prevOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        prevOktaUser.setCn("User1");
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        var nextOktaUser = new OktaUser();
        nextOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        nextOktaUser.setCn("User1");
        nextOktaUser.setUserId(UUID.randomUUID().toString());

        var event = new CoreEvent();
        Assertions.assertNull(event.getOktaUser());
        event.setPrevOktaUser(prevOktaUser);
        Assertions.assertEquals(prevOktaUser, event.getOktaUser());
        Assertions.assertEquals(prevOktaUser, event.getNextOktaUser());

        event.setNextOktaUser(nextOktaUser);
        Assertions.assertEquals(nextOktaUser, event.getOktaUser());
    }

    @Test
    void onError() {
        var event = new CoreEvent();
        event.onError(new RuntimeException(), ModuleEnum.GATEWAY, ScenarioEnum.CREATE, "test");
        Assertions.assertTrue(event.isFailed());
        var error = event.getError();
        Assertions.assertNotNull(error);
        Assertions.assertEquals(ModuleEnum.GATEWAY, error.getModule());
        Assertions.assertEquals(ScenarioEnum.CREATE, error.getScenario());
        Assertions.assertEquals("test", error.getStage());
    }
}