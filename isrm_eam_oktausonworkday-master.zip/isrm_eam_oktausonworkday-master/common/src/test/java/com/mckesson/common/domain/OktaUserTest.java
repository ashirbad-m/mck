package com.mckesson.common.domain;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.UUID;

class OktaUserTest {

    @Test
    void getUserName() {
        var instance = new OktaUser();
        instance.setDomain("domain");
        instance.setSamAccountName("samAccountName");
        Assertions.assertEquals("domain\\samAccountName", instance.getUserName());
    }

    @Test
    void isEnabled() {
        var instance = new OktaUser();
        instance.setUserAccountControl(2L);
        Assertions.assertFalse(instance.isEnabled());

        instance.setUserAccountControl(4L);
        Assertions.assertTrue(instance.isEnabled());
    }

    @Test
    void getAccountStatus() {
        var instance = new OktaUser();
        instance.setUserAccountControl(2L);
        Assertions.assertEquals("disabled", instance.getAccountStatus());

        instance.setUserAccountControl(4L);
        Assertions.assertEquals("enabled", instance.getAccountStatus());
    }

    @Test
    void getEmails() {
        var mail = UUID.randomUUID().toString();
        var emailPrimary = UUID.randomUUID().toString();
        var emailSecondary = UUID.randomUUID().toString();
        var emailSecondaryAdditional = UUID.randomUUID().toString();

        var instance = new OktaUser();
        instance.setMail(mail);
        instance.setEmailPrimary(emailPrimary);
        instance.setEmailSecondary(emailSecondary);
        instance.setEmailSecondaryAdditional(emailSecondaryAdditional);
        Assertions.assertEquals(Arrays.asList(mail, emailPrimary, emailSecondary, emailSecondaryAdditional), instance.getEmails());
    }

    @Test
    void getMailNickname() {
        var instance = new OktaUser();

        instance.setMail("test@localhost");
        Assertions.assertEquals("test", instance.getMailNickname());

        instance.setMail("test");
        Assertions.assertNull(instance.getMailNickname());
    }

    @Test
    void getBaseCn() {
        var instance = new OktaUser();

        instance.setLastName("LastName");
        instance.setFirstName("FirstName");
        Assertions.assertEquals("LastName, FirstName", instance.getBaseCn());

        instance.setMiddleName("MiddleName");
        Assertions.assertEquals("LastName, FirstName M", instance.getBaseCn());
    }
}