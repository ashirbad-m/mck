package com.mckesson.common.workday.converter;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Stream;

class SetOfStringConverterTest {

    @Test
    void joinToString() {
        SetOfStringConverter instance = new SetOfStringConverter();
        Assertions.assertEquals("", instance.joinToString(Stream.of()));
        Assertions.assertEquals("value1,value2", instance.joinToString(Stream.of("value1", "value2")));
    }

    @Test
    void convertToDatabaseColumn() {
        SetOfStringConverter instance = new SetOfStringConverter();
        Assertions.assertNull(instance.convertToDatabaseColumn(null));
        Assertions.assertEquals(null, instance.convertToDatabaseColumn(Set.of()));
        Assertions.assertEquals(Set.of("key1", "key2"), Set.of(instance.convertToDatabaseColumn(Set.of("key1", "key2")).split(",")));
    }

    @Test
    void convertToEntityAttribute() {
        SetOfStringConverter instance = new SetOfStringConverter();
        Assertions.assertEquals(Collections.emptySet(), instance.convertToEntityAttribute(null));
        Assertions.assertEquals(Set.of("key1", "key2"), instance.convertToEntityAttribute("key1,key2"));
    }
}