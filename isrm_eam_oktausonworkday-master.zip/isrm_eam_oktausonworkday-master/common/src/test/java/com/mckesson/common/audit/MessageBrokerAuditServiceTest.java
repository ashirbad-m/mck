package com.mckesson.common.audit;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.model.ModuleEnum;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

import java.util.Date;
import java.util.UUID;

class MessageBrokerAuditServiceTest {

    @Test
    void audit() {
        var messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
        var retryTemplate = new RetryTemplate();
        SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy();
        retryPolicy.setMaxAttempts(1);
        retryTemplate.setRetryPolicy(retryPolicy);

        var instance = new MessageBrokerAuditService(messageBrokerPublisher, retryTemplate);

        var auditEvent = AuditEvent.builder()
                .date(new Date())
                .app(AuditEvent.Application.OKTA)
                .oktaUserId(UUID.randomUUID().toString())
                .message(UUID.randomUUID().toString())
                .situation(UUID.randomUUID().toString())
                .build();

        instance.audit(auditEvent);
        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.AUDIT), Mockito.eq(auditEvent));

        Mockito.reset(messageBrokerPublisher);
        Mockito.doThrow(new RuntimeException()).when(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.AUDIT), Mockito.eq(auditEvent));
        instance.audit(auditEvent);
    }
}