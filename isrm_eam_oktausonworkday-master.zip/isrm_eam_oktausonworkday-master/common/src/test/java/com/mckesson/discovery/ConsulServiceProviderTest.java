package com.mckesson.discovery;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;

import java.net.URI;
import java.util.List;
import java.util.UUID;

class ConsulServiceProviderTest {

    @Test
    void getServiceUri() {
        var discoveryClient = Mockito.mock(DiscoveryClient.class);
        var instance = new ConsulServiceProvider(discoveryClient);

        var serviceId = UUID.randomUUID().toString();

        Mockito.when(discoveryClient.getInstances(Mockito.eq(serviceId))).thenReturn(List.of());
        try {
            instance.getServiceUri(serviceId, "");
            Assertions.fail("Wrong behavior");
        } catch (RuntimeException ex) {
            Assertions.assertEquals("Service unavailable for: " + serviceId, ex.getMessage());
        }

        var serviceInstance1 = Mockito.mock(ServiceInstance.class);
        Mockito.when(serviceInstance1.getUri()).thenReturn(URI.create("https://localhost:7001"));
        Mockito.when(discoveryClient.getInstances(Mockito.eq(serviceId))).thenReturn(List.of(serviceInstance1));
        Assertions.assertEquals("https://localhost:7001/test", instance.getServiceUrl(serviceId, "/test"));

        var serviceInstance2 = Mockito.mock(ServiceInstance.class);
        Mockito.when(serviceInstance2.getUri()).thenReturn(URI.create("https://localhost:7002"));
        Mockito.when(discoveryClient.getInstances(Mockito.eq(serviceId))).thenReturn(List.of(serviceInstance1, serviceInstance2));
        var url = instance.getServiceUri(serviceId, "").toString();
        Assertions.assertTrue(url.equals("https://localhost:7001") || url.equals("https://localhost:7002"));
    }
}