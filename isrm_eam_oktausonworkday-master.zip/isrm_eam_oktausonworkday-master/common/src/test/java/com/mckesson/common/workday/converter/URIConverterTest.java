package com.mckesson.common.workday.converter;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.net.URI;

class URIConverterTest {

    @Test
    void convertToDatabaseColumn() {
        URIConverter instance = new URIConverter();
        Assertions.assertNull(instance.convertToDatabaseColumn(null));
        Assertions.assertEquals("https://google.com", instance.convertToDatabaseColumn(URI.create("https://google.com")));
    }

    @Test
    void convertToEntityAttribute() {
        URIConverter instance = new URIConverter();
        Assertions.assertEquals(null, instance.convertToEntityAttribute(null));
        Assertions.assertEquals(URI.create("https://google.com"), instance.convertToEntityAttribute("https://google.com"));
    }
}