package com.mckesson.common.mail;

import com.mckesson.common.model.EmailMessage;

import java.util.function.Consumer;

public interface MailService {
    /**
     * Sends email message
     *
     * @param message email message
     * @param onError handle error
     */
    void send(EmailMessage message, Consumer<Exception> onError);
}
