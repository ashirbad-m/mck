package com.mckesson.common.workday.configuration.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;
import org.springframework.validation.annotation.Validated;

import javax.naming.ldap.LdapName;
import javax.validation.constraints.Size;

@Value
@Builder(toBuilder = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@Validated
public class GroupMappingDto {

    Long id;

    @Size(max = 255)
    @NonNull
    String name;

    @Size(max = 255)
    @NonNull
    LdapName dn;

    @NonNull
    GroupMappingType type;

    @Size(max = 255)
    String oktaCn;

}
