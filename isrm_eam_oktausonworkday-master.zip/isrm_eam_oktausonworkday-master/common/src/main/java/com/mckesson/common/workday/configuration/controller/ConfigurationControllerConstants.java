package com.mckesson.common.workday.configuration.controller;

import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.HrbuConfig;
import com.mckesson.common.model.WorkdayConfig;
import com.mckesson.common.workday.configuration.dto.GroupMappingDto;
import com.mckesson.common.workday.configuration.dto.HrbuCityStreetDto;
import com.mckesson.common.workday.configuration.dto.HrbuDto;
import org.springframework.core.ParameterizedTypeReference;

import java.util.List;

public interface ConfigurationControllerConstants {

    String ALL_GLOBALS = "all-globals";
    String SINGLE_GLOBAL = "single-global";
    String GET_GLOBAL = "get-global/";
    String SAVE_GLOBAL = "save-global";
    String DELETE_GLOBAL = "delete-global/";

    String ALL_GROUP_MAPPINGS = "all-group-mappings";
    String GET_GROUP_MAPPING = "get-group-mapping/";
    String GET_GROUP_MAPPING_BY_NAME = "get-group-mapping-by-name/{name}";
    String FIND_GROUP_MAPPINGS_BY_NAMES = "find-group-mappings-by-names";
    String FIND_GROUP_MAPPINGS_BY_OKTA_CNS = "find-group-mappings-by-okta-cns";
    String FIND_GROUP_MAPPINGS_BY_TYPE = "find-group-mappings-by-type/{type}";
    String FIND_GROUP_MAPPINGS_BY_NAMES_AND_TYPE = "find-group-mappings-by-names-and-type";
    String SAVE_GROUP_MAPPING = "save-group-mapping";
    String DELETE_GROUP_MAPPING = "delete-group-mapping/";

    String ALL_DOMAINS = "all-domains";
    String GET_DOMAIN = "get-domain/";
    String FIND_DOMAIN = "find-domain";
    String GET_DOMAIN_BY_NAME = "get-domain-by-name/{name}";
    String SAVE_DOMAIN = "save-domain";
    String DELETE_DOMAIN = "delete-domain/";

    String ALL_HRBU = "all-hrbu";
    String GET_HRBU = "get-hrbu/{hrbu}";
    String SAVE_HRBU = "save-hrbu";
    String DELETE_HRBU = "delete-hrbu/";

    String ALL_HRBU_CITY_STREET = "all-hrbu-city-street";
    String GET_HRBU_CITY_STREET = "get-hrbu-city-street/";
    String SAVE_HRBU_CITY_STREET = "save-hrbu-city-street";
    String DELETE_HRBU_CITY_STREET = "delete-hrbu-city-street/";

    String FIND_HRBU_CONFIG = "find-hrbu-config";
    String ALL_HRBU_CONFIGS = "all-hrbu-configs";

    ParameterizedTypeReference<List<WorkdayConfig>> RETURN_GLOBALS_LIST = new ParameterizedTypeReference<>() {
    };
    ParameterizedTypeReference<List<GroupMappingDto>> RETURN_GROUP_MAPPINGS_LIST = new ParameterizedTypeReference<>() {
    };
    ParameterizedTypeReference<List<DomainConfig>> RETURN_DOMAINS_LIST = new ParameterizedTypeReference<>() {
    };
    ParameterizedTypeReference<List<HrbuDto>> RETURN_HRBU_LIST = new ParameterizedTypeReference<>() {
    };
    ParameterizedTypeReference<List<HrbuCityStreetDto>> RETURN_HRBU_CITY_STREET_LIST = new ParameterizedTypeReference<>() {
    };
    ParameterizedTypeReference<List<HrbuConfig>> RETURN_HRBU_VIEW_LIST = new ParameterizedTypeReference<>() {
    };
}
