package com.mckesson.common.actuate;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * Checks status of mail service (health indicator)
 */
@ConditionalOnClass(RestTemplate.class)
@ConditionalOnProperty("services.mail.service-host")
@Component
public class MailServiceHealthIndicator extends AbstractServiceHealthIndicator {
    public MailServiceHealthIndicator(@Value("${services.mail.service-host}") String serviceUrl, RestTemplateBuilder restTemplateBuilder) {
        super("Mail Service health check failed", serviceUrl, restTemplateBuilder);
    }
}
