package com.mckesson.common.workday.configuration.dto.request;

import com.mckesson.common.workday.configuration.dto.GroupMappingType;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.experimental.FieldDefaults;
import org.springframework.validation.annotation.Validated;

import java.util.Set;

@Value
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@Validated
public class GroupMappingRequest {
    @NonNull
    Set<String> names;
    @NonNull
    GroupMappingType type;
}
