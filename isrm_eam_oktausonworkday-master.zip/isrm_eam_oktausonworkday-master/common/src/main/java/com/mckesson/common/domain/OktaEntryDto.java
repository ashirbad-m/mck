package com.mckesson.common.domain;

import javax.naming.ldap.LdapName;

public interface OktaEntryDto extends AdEntryData<LdapName, String> {
}
