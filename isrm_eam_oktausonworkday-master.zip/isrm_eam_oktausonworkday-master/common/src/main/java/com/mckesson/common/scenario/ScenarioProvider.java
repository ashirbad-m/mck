package com.mckesson.common.scenario;

import org.springframework.stereotype.Service;

@Service
public class ScenarioProvider {
    public Scenario getScenario() {
        return new HardCodedScenario();
    }
}
