package com.mckesson.common.model;

import com.mckesson.common.domain.OktaUser;
import com.mckesson.common.domain.PassportAction;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Value;
import lombok.experimental.FieldDefaults;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

@Validated
@Value
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AuditEvent implements Serializable {

    public enum Application {
        PASSPORT, OKTA
    }

    @NotNull
    Date date;
    @NotNull
    Application app;
    @NotNull
    String oktaUserId;
    String batchId;
    String oktaEventId;
    String owfFlowId;
    String owfExecutionId;

    ModuleEnum module;
    String status;
    @NotNull
    String message;
    @NotNull
    String situation;
    String action;
    String subAction;
    String oldValues;
    String newValues;
    Long duration;

    public static AuditEvent.AuditEventBuilder generateEvent(CoreEvent event) {
        final OktaUser oktaUser = event.getOktaUser();
        return AuditEvent.builder()
                .date(new Date())
                .app(AuditEvent.Application.PASSPORT)
                .batchId(event.getBatchId())
                .oktaEventId(event.getId())
                .oktaUserId(oktaUser.getUserId())
                .action("DispatchEvent")
                .subAction(event.getAction())
                .owfFlowId(event.getOwfFlowId())
                .owfExecutionId(event.getOwfExecutionId());
    }

    public static AuditEvent.AuditEventBuilder generateEvent(PassportAction.CommonEventBody eventBody) {
        return AuditEvent.builder()
                .date(new Date())
                .app(AuditEvent.Application.PASSPORT)
                .batchId(eventBody.getBatchId())
                .oktaEventId(eventBody.getEventId())
                .oktaUserId(eventBody.getOktaUserId())
                .owfFlowId(eventBody.getOwfFlowId())
                .owfExecutionId(eventBody.getOwfExecutionId());
    }
}
