package com.mckesson.common.model;

public enum ModuleEnum {
    GATEWAY,
    SCIM,
    ACTIVE_DIRECTORY,
    EXCHANGE,
    REMEDY_FORCE,
    EMAIL,
    OKTA_CLIENT,
    AUDIT,
    FINALIZER,
    ALL
}
