package com.mckesson.common.workday.converter;

import javax.persistence.AttributeConverter;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.mckesson.common.workday.converter.ConverterUtils.nullSafeSet;
import static com.mckesson.common.workday.converter.ConverterUtils.nullableString;

public abstract class SetOfStringValuedConverter<T> implements AttributeConverter<Set<T>, String> {

    @Override
    public String convertToDatabaseColumn(final Set<T> s) {
        return nullableString(joinToString(nullSafeSet(s).stream().filter(Objects::nonNull).map(T::toString)));
    }

    @Override
    public Set<T> convertToEntityAttribute(final String s) {
        return getStreamConstructor()
            .apply(s)
            .map(this.getStringValuedConstructor()).collect(Collectors.toSet());
    }

    protected abstract Function<String, T> getStringValuedConstructor();

    protected abstract Function<String, Stream<String>> getStreamConstructor();

    protected abstract String joinToString(Stream<String> stream);

}
