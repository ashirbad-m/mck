package com.mckesson.common.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mckesson.common.workday.converter.ConverterUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.text.SimpleDateFormat;

/**
 * Jackson configuration
 */
@Configuration
@ConditionalOnClass(ObjectMapper.class)
public class JacksonConfig {
    /**
     * Configure object mapper
     * 1. disable fail on empty beans
     * 2. define json date format
     *
     * @return configured object mapper
     */
    @Bean
    @Primary
    public ObjectMapper objectMapper() {
        ObjectMapper result = ConverterUtils.configuredMapper();
        result.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        result.setDateFormat(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ"));
        return result;
    }
}
