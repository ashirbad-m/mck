package com.mckesson.common.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.mckesson.common.workday.converter.ConverterUtils;
import lombok.*;

import javax.naming.ldap.LdapName;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Manager {

    public static OktaUser parseOktaUser(
            @NonNull final Map<String, Object> map,
            @NonNull final OktaUser.OktaUserBuilder targetBuilder,
            @NonNull final String dnName,
            @NonNull final String sanName,
            boolean nullsAllowed
    ) {
        if (nullsAllowed && map.size() == 0) {
            return null;
        }
        LdapName dn = Objects.requireNonNull(ConverterUtils.nullableLdapName(ConverterUtils.STRING_GETTER.apply(map, dnName)));
        return targetBuilder
                .dn(dn)
                .cn(dn.getRdn(dn.size() - 1).getValue().toString())
                .samAccountName(ConverterUtils.REQUIRED_STRING_GETTER.apply(map, sanName))
                .firstName(ConverterUtils.REQUIRED_STRING_GETTER.apply(map, "firstName"))
                .lastName(ConverterUtils.REQUIRED_STRING_GETTER.apply(map, "lastName"))
                .displayName(ConverterUtils.REQUIRED_STRING_GETTER.apply(map, "displayName"))
                .mail(ConverterUtils.REQUIRED_STRING_GETTER.apply(map, "mail"))
                .telephoneNumber(ConverterUtils.STRING_GETTER.apply(map, "telephoneNumber"))
                .build();
    }

    public static Manager parseManager(final String managerAsString, final String sanName, final boolean nullsAllowed) {
        Map<String, Object> map = ConverterUtils.json2NullSafeMap(managerAsString);
        if (nullsAllowed && map.size() == 0) {
            return null;
        }
        return Manager.builder()
                .user(parseOktaUser(map, OktaUser.builder(), "dn", sanName, nullsAllowed))
                .real(ConverterUtils.BOOLEAN_GETTER.test(map, "real"))
                .forEMail(ConverterUtils.BOOLEAN_GETTER.test(map, "forEMail"))
                .linked(ConverterUtils.BOOLEAN_GETTER.test(map, "linked"))
                .build();
    }

    public static @NonNull OktaUser truncateToManagerAttributes(@NonNull final OktaUser ou) {
        final LdapName dn = ou.getDn();
        return OktaUser.builder()
                .dn(dn)
                .cn(dn.getRdn(dn.size() - 1).getValue().toString())
                .mail(ou.getMail())
                .samAccountName(ou.getSamAccountName())
                .displayName(ou.getDisplayName())
                .lastName(ou.getLastName())
                .firstName(ou.getFirstName())
                .telephoneNumber(ou.getTelephoneNumber())
                .build();
    }

    private OktaUser user;
    private boolean real;
    private boolean forEMail;
    private boolean linked;

    @JsonIgnore
    public String getManagerAsString() {
        Map<String, Object> map = Optional.ofNullable(ConverterUtils.object2NullableMap(getUser())).orElse(new HashMap<>());
        map.put("real", real);
        map.put("forEMail", forEMail);
        map.put("linked", linked);
        return ConverterUtils.writeValueAsString(map);
    }
}
