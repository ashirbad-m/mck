package com.mckesson.common;

import com.mckesson.common.model.SyncCheck;

public interface SyncCheckProcessor {
    void process(SyncCheck message);
}
