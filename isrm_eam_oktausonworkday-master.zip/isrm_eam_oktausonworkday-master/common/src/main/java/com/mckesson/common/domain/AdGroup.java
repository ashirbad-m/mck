package com.mckesson.common.domain;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NonNull;
import lombok.experimental.FieldDefaults;

import javax.naming.ldap.LdapName;
import java.util.Set;

@Builder(toBuilder = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@Data
public class AdGroup implements OktaEntryDto {

    String uid;

    String domain;

    @NonNull
    LdapName dn;

    @NonNull
    String cn;

    Set<LdapName> member;

    String description;

    Long groupType;

    LdapName managedBy;

    String displayName;

    String adSid;
}
