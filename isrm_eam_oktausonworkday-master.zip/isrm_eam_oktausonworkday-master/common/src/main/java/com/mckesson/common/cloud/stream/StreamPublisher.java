package com.mckesson.common.cloud.stream;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.model.ModuleEnum;
import org.springframework.cloud.stream.messaging.Source;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class StreamPublisher extends AbstractStreamPublisher implements MessageBrokerPublisher {

    public StreamPublisher(Source source) {
        super(source);
    }

    @Override
    public void send(ModuleEnum module, Serializable payload) {
        Map<String, String> headers = new HashMap<>();
        headers.put("module", module.name());
        headers.put("class", payload.getClass().getCanonicalName());
        send(headers, payload);

        if (module != ModuleEnum.GATEWAY && module != ModuleEnum.FINALIZER ) {
            headers.put("module", ModuleEnum.ALL.name());
            send(headers, payload);
        }
    }
}
