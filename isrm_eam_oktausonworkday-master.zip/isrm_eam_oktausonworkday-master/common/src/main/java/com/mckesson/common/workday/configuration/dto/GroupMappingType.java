package com.mckesson.common.workday.configuration.dto;

import java.util.Optional;

public enum GroupMappingType {
    CSA,
    HRBU,
    DEFAULT;

    public static GroupMappingType valueOfIgnoreCase(String sType) {
        return Optional.ofNullable(sType).map(String::toUpperCase).map(GroupMappingType::valueOf).orElse(null);
    }

}
