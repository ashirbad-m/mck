package com.mckesson.common.actuate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

/**
 * Implements base health indicator that checks status of REST service
 */
public class AbstractServiceHealthIndicator extends AbstractHealthIndicator {

    private final String serviceUrl;
    private final RestTemplate restTemplate;

    /**
     * Constructor
     * @param healthCheckFailedMessage message for failed check
     * @param serviceUrl URL of REST service location (host + application path)
     * @param restTemplateBuilder preconfigured instance
     */
    public AbstractServiceHealthIndicator(String healthCheckFailedMessage, String serviceUrl, RestTemplateBuilder restTemplateBuilder) {
        super(healthCheckFailedMessage);
        Assert.notNull(serviceUrl, "Service Url must not be null");
        //Remove HTTPS inspection for non-production deployment
        //Assert.isTrue("https".equalsIgnoreCase(URI.create(serviceUrl).getScheme()), "Service Url must use HTTPS scheme");
        this.serviceUrl = serviceUrl;
        restTemplate = restTemplateBuilder.build();
    }

    @Override
    protected void doHealthCheck(Health.Builder builder) {
        builder.withDetail("serviceUrl", serviceUrl);
        ResponseEntity<HealthResponse> response = restTemplate.getForEntity(serviceUrl + "actuator/health", HealthResponse.class);
        builder.status(response.getBody().getStatus());
    }

    /**
     * Wrapper for health endpoint response
     */
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class HealthResponse {
        private Status status;
    }
}