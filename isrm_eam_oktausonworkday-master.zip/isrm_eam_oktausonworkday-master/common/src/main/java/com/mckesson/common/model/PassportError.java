package com.mckesson.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PassportError {
    String uuid;
    String errorInfo;
    ModuleEnum module;
    ScenarioEnum scenario;
    String stage;
}
