package com.mckesson.common.actuate;

import com.mckesson.common.rest.OAuth2RestClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * Checks status of oAuth provider (health indicator)
 */
@ConditionalOnClass(RestTemplate.class)
@ConditionalOnProperty({
        "security.oauth2.token-uri",
        "security.oauth2.client.client-id",
        "security.oauth2.client.client-secret",
        "security.oauth2.client.scope",
        "security.oauth2.client.connect-timeout"
})
@Component
public class OAuth2HealthIndicator extends AbstractHealthIndicator {

    private final InternalOAuth2RestClient oAuth2RestClient;

    public OAuth2HealthIndicator(RestTemplateBuilder restTemplateBuilder,
                                 @Value("${security.oauth2.token-uri}") String accessTokenUri,
                                 @Value("${security.oauth2.client.client-id}") String clientId,
                                 @Value("${security.oauth2.client.client-secret}") String clientSecret,
                                 @Value("${security.oauth2.client.scope}") String scope,
                                 @Value("${security.oauth2.client.connect-timeout}") int connectTimeout,
                                 RetryTemplate retryTemplate) {
        super("OAuth2 health check failed");
        this.oAuth2RestClient = new InternalOAuth2RestClient(restTemplateBuilder, accessTokenUri, clientId, clientSecret, scope, connectTimeout, retryTemplate);
    }

    @Override
    protected void doHealthCheck(Health.Builder builder) {
        builder.withDetail("accessTokenUri", oAuth2RestClient.getAccessTokenUri());
        oAuth2RestClient.requestOauth2Token();
        builder.up();
    }

    private static class InternalOAuth2RestClient extends OAuth2RestClient {
        private final String accessTokenUri;

        public InternalOAuth2RestClient(
                RestTemplateBuilder restTemplateBuilder,
                @Value("${security.oauth2.token-uri}") String accessTokenUri,
                @Value("${security.oauth2.client.client-id}") String clientId,
                @Value("${security.oauth2.client.client-secret}") String clientSecret,
                @Value("${security.oauth2.client.scope}") String scope,
                @Value("${security.oauth2.client.connect-timeout}") int connectTimeout,
                RetryTemplate retryTemplate
        ) {
            super(null, restTemplateBuilder, accessTokenUri, clientId, clientSecret, scope, connectTimeout, retryTemplate);
            this.accessTokenUri = accessTokenUri;
        }

        public String getAccessTokenUri() {
            return accessTokenUri;
        }

        public String requestOauth2Token() {
            return getOauth2Token();
        }
    }
}
