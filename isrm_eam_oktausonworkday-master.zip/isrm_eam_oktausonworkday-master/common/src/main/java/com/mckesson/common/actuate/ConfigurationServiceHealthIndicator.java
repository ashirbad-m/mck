package com.mckesson.common.actuate;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * Checks status of configuration service (health indicator)
 */
@ConditionalOnClass(RestTemplate.class)
@ConditionalOnProperty("services.configuration.service-host")
@Component
public class ConfigurationServiceHealthIndicator extends AbstractServiceHealthIndicator {
    public ConfigurationServiceHealthIndicator(@Value("${services.configuration.service-host}") String serviceUrl, RestTemplateBuilder restTemplateBuilder) {
        super("Configuration Service health check failed", serviceUrl, restTemplateBuilder);
    }
}
