package com.mckesson.common;

import com.mckesson.common.domain.PassportAction;

public interface PassportActionProcessor {
    void processAction(PassportAction action);
}
