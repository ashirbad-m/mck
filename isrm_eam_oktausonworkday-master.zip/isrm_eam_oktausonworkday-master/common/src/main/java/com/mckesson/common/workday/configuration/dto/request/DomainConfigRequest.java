package com.mckesson.common.workday.configuration.dto.request;

import lombok.*;
import lombok.experimental.FieldDefaults;
import org.springframework.validation.annotation.Validated;

import javax.naming.ldap.LdapName;

@Value
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@Validated
public class DomainConfigRequest {
    @NonNull
    LdapName ou;
}
