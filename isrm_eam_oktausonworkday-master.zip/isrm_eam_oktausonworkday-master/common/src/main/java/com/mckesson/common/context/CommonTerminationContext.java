package com.mckesson.common.context;

import com.mckesson.common.domain.AdGroup;
import com.mckesson.common.domain.OktaUser;
import lombok.Data;

import java.util.List;

@Data
public abstract class CommonTerminationContext {
    private boolean hrbuUpdated;
    private boolean companyIdUpdated;
    private boolean hrbuChangeSupressed;

    private List<OktaUser> adminAccounts;
    private List<AdGroup> serviceGroups;
    private List<OktaUser> serviceAccounts;
}
