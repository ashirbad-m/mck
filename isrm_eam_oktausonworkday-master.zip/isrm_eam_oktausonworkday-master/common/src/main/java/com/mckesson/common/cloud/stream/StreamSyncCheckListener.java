package com.mckesson.common.cloud.stream;

import com.mckesson.common.SyncCheckProcessor;
import com.mckesson.common.model.SyncCheck;
import com.mckesson.common.workday.converter.ConverterUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.context.annotation.Profile;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@Profile("stream")
@ConditionalOnSingleCandidate(SyncCheckProcessor.class)
@ConditionalOnProperty("module")
@RequiredArgsConstructor
public class StreamSyncCheckListener {
    private final SyncCheckProcessor syncCheckProcessor;

    @StreamListener(target = Processor.INPUT, condition = "headers['module']==T(com.mckesson.common.model.ModuleEnum).${module}.name() && headers['class']=='com.mckesson.common.model.SyncCheck'")
    public void process(@Payload SyncCheck message) {
        log.debug("Incoming event: {}", ConverterUtils.writeValueAsString(message));
        syncCheckProcessor.process(message);
    }
}
