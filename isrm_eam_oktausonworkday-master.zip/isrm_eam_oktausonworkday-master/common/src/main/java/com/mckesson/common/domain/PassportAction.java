package com.mckesson.common.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mckesson.common.model.ExecutionMetric;
import com.mckesson.common.model.ModuleEnum;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NonNull;
import lombok.experimental.FieldDefaults;

import javax.naming.ldap.LdapName;
import java.io.Serializable;
import java.util.*;

@Data
public class PassportAction implements Serializable {
    private EventTypeEnum eventType;
    private String eventBody;
    private List<ExecutionMetric> metrics = new ArrayList<>();

    public enum EventTypeEnum {

        REMEDY("remedy", ModuleEnum.REMEDY_FORCE),
        POWERSHELL("powershell", ModuleEnum.EXCHANGE),
        OKTA("okta", ModuleEnum.OKTA_CLIENT),
        AUDIT("audit", ModuleEnum.AUDIT);

        EventTypeEnum(@NonNull String name, @NonNull ModuleEnum module) {
            this.name = name;
            this.module = module;
        }

        public static EventTypeEnum valueByName(String name) {
            for (EventTypeEnum value : values()) {
                if (value.name.equals(name)) {
                    return value;
                }
            }
            throw new IllegalArgumentException("Unknown event type name: " + name);
        }

        private final String name;
        private final ModuleEnum module;

        public String getName() {
            return name;
        }

        public ModuleEnum getModule() {
            return module;
        }
    }

    @Data
    @FieldDefaults(level = AccessLevel.PRIVATE)
    public static class CommonEventBody {
        String eventId;
        String batchId;
        String owfFlowId;
        String owfExecutionId;
        String oktaUserId;
    }

    @Data
    @FieldDefaults(level = AccessLevel.PRIVATE)
    public static class PowerShellEventBody extends CommonEventBody {
        @NonNull
        String domain;
        /**
         * Possible values
         * <li>leaveOfAbsence</li>
         * <li>createMailAndHome</li>
         * <li>createHome</li>
         * <li>updateMail</li>
         * <li>archiveHomeAndDeleteTSP</li>
         * <li>terminateMailAndASD</li>
         * <li>setCAS</li>
         */
        String action;
        String userName;
        String userSamAccountName;
        String userPrincipalName;
        String userMailNickname;
        String userHomeDirectory;
        String userArchivedHomeDirectory;
        String emailPrimary;
        String emailSecondary;
        String emailSecondaryAdditional;
        String ldapHostName;
        Boolean logon;
        Long msExchRecipientTypeDetails;
        Set<String> exchangeServers;
        String office365Url;
        String office365CredentialsAddress;
        /**
         * "profiles\\" + userSamAccountName.charAt(0);
         */
        String dfsLinkName;
        Set<String> dfsServers;
        GroupMembershipEventBody groupMembershipEventBody;
        /**
         * Event Body part for Update Workday User Id action
         */
        BackToWorkdayEventBody backToWorkdayEventBody;
    }

    @Data
    @FieldDefaults(level = AccessLevel.PRIVATE)
    public static class GroupMembershipEventBody {
        @NonNull
        LdapName userDn;
        Set<String> oktaCnsToAdd;
        Set<String> oktaCnsToRemove;
    }

    /**
     * Event Body part for Update Workday User Id action
     */
    @Data
    @FieldDefaults(level = AccessLevel.PRIVATE)
    public static class BackToWorkdayEventBody {
        /**
         * Action. Now only updateUserId is supported
         */
        @NonNull
        String workdayAction;

        /**
         * Map of action parameters
         */
        @NonNull
        Map<String, String> parameters;
    }

    @Data
    @FieldDefaults(level = AccessLevel.PRIVATE)
    public static class AdsiInfo {
        @NonNull
        LdapName dn;
        @NonNull
        String server;
    }

    @Data
    @FieldDefaults(level = AccessLevel.PRIVATE)
    public static class RemedyForceEventBody extends CommonEventBody {
        String type;
        String ownerId;
        String body;
        List<RemedyForceIncident> adminIncidents;
        List<RemedyForceTask> tasks;
    }

    @Data
    @FieldDefaults(level = AccessLevel.PRIVATE)
    public static class RemedyForceIncident extends CommonEventBody {
        String body;
    }

    @Data
    @FieldDefaults(level = AccessLevel.PRIVATE)
    public static class RemedyForceTask extends CommonEventBody {
        String body;
        String taskType;
    }

    @Data
    @FieldDefaults(level = AccessLevel.PRIVATE)
    public static class OktaEventBody extends CommonEventBody {
        String incidentData;

        public OktaEventBody() {
        }

        public OktaEventBody(CommonEventBody parent) {
            this.setEventId(parent.getEventId());
            this.setBatchId(parent.getBatchId());
            this.setOwfFlowId(parent.getOwfFlowId());
            this.setOwfExecutionId(parent.getOwfExecutionId());
            this.setOktaUserId(parent.getOktaUserId());
        }
    }

    @Data
    @FieldDefaults(level = AccessLevel.PRIVATE)
    public static class AuditEventBody extends CommonEventBody {
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSSXXX")
        Date eventDate;
        String situation;
        String action;
        String subAction;
        String status;
        String message;
        String target;
    }
}
