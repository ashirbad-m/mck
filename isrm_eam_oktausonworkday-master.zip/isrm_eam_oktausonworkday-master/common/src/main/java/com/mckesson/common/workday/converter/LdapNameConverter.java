package com.mckesson.common.workday.converter;


import javax.naming.ldap.LdapName;
import javax.persistence.AttributeConverter;

import static com.mckesson.common.workday.converter.ConverterUtils.nullableLdapName;
import static com.mckesson.common.workday.converter.ConverterUtils.object2NullableString;

public class LdapNameConverter implements AttributeConverter<LdapName, String> {

    @Override
    public String convertToDatabaseColumn(LdapName ldapName) {
        return object2NullableString(ldapName);
    }

    @Override
    public LdapName convertToEntityAttribute(String s) {
        return nullableLdapName(s);
    }
}
