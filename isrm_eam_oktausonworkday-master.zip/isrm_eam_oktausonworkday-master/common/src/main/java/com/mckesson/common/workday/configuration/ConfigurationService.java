package com.mckesson.common.workday.configuration;

import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.HrbuConfig;
import com.mckesson.common.model.WorkdayConfig;
import com.mckesson.common.workday.configuration.dto.GroupMappingDto;
import com.mckesson.common.workday.configuration.dto.GroupMappingType;
import com.mckesson.common.workday.configuration.dto.HrbuCityStreetDto;
import com.mckesson.common.workday.configuration.dto.HrbuDto;
import com.mckesson.common.workday.configuration.dto.request.GroupMappingRequest;
import com.mckesson.common.workday.configuration.dto.request.HrbuViewRequest;

import javax.naming.ldap.LdapName;
import java.util.Collection;
import java.util.List;

public interface ConfigurationService {
    //<editor-fold desc="global">

    /**
     * Provides all global(workday) configs
     *
     * @return all existing global(workday) configs
     */
    List<WorkdayConfig> getAllGlobals();

    /**
     * Provides first config from all existing global(workday) configs
     *
     * @return first global(workday) configs or null
     */
    WorkdayConfig findGlobalConfig();

    /**
     * Provides global(workday) config by ID
     *
     * @return global(workday) configs or null
     */
    WorkdayConfig findGlobalById(Long id);

    /**
     * Saves global config
     * @param globalDto global config DTO
     * @return update object
     */
    //WorkdayConfig saveGlobal(WorkdayConfig globalDto);

    /**
     * Deletes global config by ID
     * @param id global config ID
     * @return true for deleted, otherwise false
     */
    //boolean deleteGlobal(Long id);

    //<editor-fold desc="group_mapping">

    /**
     * Provides all group mappings
     *
     * @return all group mappings
     */
    List<GroupMappingDto> getAllGroupMappings();

    /**
     * Finds group mapping by ID
     *
     * @param id group mapping ID
     * @return found group mapping or null
     */
    GroupMappingDto findGroupMappingById(Long id);

    /**
     * Finds group mapping by name
     *
     * @param name group mapping name
     * @return found group mapping or null
     */
    GroupMappingDto findGroupMappingByName(String name);

    /**
     * Finds all group mappings by given names
     *
     * @param names group mapping names
     * @return found group mappings
     */
    List<GroupMappingDto> findGroupMappingsByNames(Collection<String> names);

    /**
     * Finds all group mappings by given OKTA CNs
     *
     * @param oktaCns group mapping OKTA CNs
     * @return found group mappings
     */
    List<GroupMappingDto> findGroupMappingsByOktaCns(Collection<String> oktaCns);

    /**
     * Finds all group mappings by type
     *
     * @param type group mapping type
     * @return found group mappings
     */
    List<GroupMappingDto> findGroupMappingsByType(GroupMappingType type);

    /**
     * Finds all group mappings by names and type
     *
     * @param groupMappingRequest group mapping request
     * @return found group mappings
     */
    List<GroupMappingDto> findGroupMappingsByNameInAndType(GroupMappingRequest groupMappingRequest);

    /**
     * Saves group mapping
     * @param groupMappingDto group mapping DTO
     * @return updated object
     */
    //GroupMappingDto saveGroupMapping(GroupMappingDto groupMappingDto);

    /**
     * Delete group mapping
     * @param id group mapping ID
     * @return true for deleted, otherwise false
     */
    //boolean deleteGroupMapping(Long id);

    //<editor-fold desc="domains">

    /**
     * Provides all domain configs
     *
     * @return all domain configs
     */
    List<DomainConfig> allDomainConfigs();

    /**
     * Finds domain config by ID
     *
     * @param id domain config ID
     * @return found domain config or null
     */
    DomainConfig findDomainConfigById(Long id);

    /**
     * Finds domain config by name
     *
     * @param name domain config name
     * @return found domain config or null
     */
    DomainConfig findDomainConfigByName(String name);

    /**
     * Finds domain config by OU
     *
     * @param ou domain config OU
     * @return found domain config or null
     */
    DomainConfig findDomainConfigByOu(LdapName ou);

    /**
     * Saves domain config
     * @param domainDto domain config DTO
     * @return updated object
     */
    //DomainConfig saveDomainConfig(DomainConfig domainDto);

    /**
     * Deletes domain config by ID
     * @param id domain config ID
     * @return true for deleted, otherwise false
     */
    //boolean deleteDomainConfig(Long id);

    //<editor-fold desc="hrbu">

    /**
     * Provides all HRBU DTOs
     *
     * @return all HRBU DTOs
     */
    List<HrbuDto> getAllHrbu();

    /**
     * Provides HRBU DTO by hrbu
     *
     * @param hrbu hrbu value
     * @return found HRBU DTO or null
     */
    HrbuDto findHrbuByHrbu(String hrbu);

    /**
     * Saves HRBU DTO
     * @param hrbuDto HRBU DTO
     * @return update object
     */
    //HrbuDto saveHrbu(HrbuDto hrbuDto);

    /**
     * Deletes HRBU DTO by hrbu
     * @param hrbu hrbu value
     * @return true for deleted, otherwise false
     */
    //boolean deleteHrbuByHrbu(String hrbu);
    //</editor-fold>

    //<editor-fold desc="hrbu_city_street">

    /**
     * Provides all HrbuCityStreetDtos
     *
     * @return all HrbuCityStreetDto
     */
    List<HrbuCityStreetDto> getAllHrbuCityStreet();

    /**
     * FInds HrbuCityStreetDto by ID
     *
     * @param id HrbuCityStreetDto ID
     * @return found HrbuCityStreetDto or null
     */
    HrbuCityStreetDto findHrbuCityStreetById(Long id);

    /**
     * Saves HrbuCityStreetDto
     * @param hrbuCityStreetDto HrbuCityStreetDto
     * @return updated object
     */
    //HrbuCityStreetDto saveHrbuCityStreet(HrbuCityStreetDto hrbuCityStreetDto);

    /**
     * Deletes HrbuCityStreetDto by ID
     * @param id HrbuCityStreetDto ID
     * @return true for deleted, otherwise false
     */
    //boolean deleteHrbuCityStreet(Long id);
    //</editor-fold>

    /**
     * Finds HrbuConfig by request
     *
     * @param hrbuViewRequest requet
     * @return found HrbuConfig or null
     */
    List<HrbuConfig> findHrbuConfig(HrbuViewRequest hrbuViewRequest);

    /**
     * Provides all HrbuConfigs
     *
     * @return all HrbuConfigs
     */
    List<HrbuConfig> getAllHrbuConfigs();
}
