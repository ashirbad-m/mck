package com.mckesson.common.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.cloud.rabbit.RabbitPublisher;
import com.mckesson.common.model.ModuleEnum;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.util.ArrayList;
import java.util.Collection;

@EnableRabbit
@Configuration(proxyBeanMethods = false)
@ConditionalOnClass(RabbitTemplate.class)
@Profile("rabbit")
public class RabbitConfiguration {
    @Value("${rabbit.exchange}")
    private String exchange;

    @Bean
    public MessageConverter jsonMessageConverter(ObjectProvider<ObjectMapper> objectMapper) {
        return new Jackson2JsonMessageConverter(objectMapper.getIfUnique());
    }

    @Bean
    public MessageBrokerPublisher messageBrokerPublisher(ObjectProvider<RabbitTemplate> rabbitTemplate) {
        return new RabbitPublisher(rabbitTemplate.getIfUnique());
    }

    @Bean
    public Declarables topicBindings() {
        Collection<Declarable> declarables = new ArrayList();
        TopicExchange topicExchange = new TopicExchange(exchange);
        declarables.add(topicExchange);
        for (ModuleEnum module : ModuleEnum.values()) {
            Queue queue = new Queue(exchange + "." + module.name(), false);
            declarables.add(queue);
            if (module == ModuleEnum.GATEWAY || module == ModuleEnum.FINALIZER ) {
                declarables.add(BindingBuilder.bind(queue).to(topicExchange).with(module.name()));
            } else if (module == ModuleEnum.ALL ) {
                declarables.add(BindingBuilder.bind(queue).to(topicExchange).with("module.*"));
            } else {
                declarables.add(BindingBuilder.bind(queue).to(topicExchange).with("module." + module.name()));
            }
        }
        return new Declarables(declarables);
    }
}
