package com.mckesson.common;

import com.mckesson.common.model.ModuleEnum;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingClass;
import org.springframework.stereotype.Component;

import java.io.Serializable;

@Component
@ConditionalOnMissingClass({"org.springframework.cloud.stream.annotation.EnableBinding", "org.springframework.kafka.core.KafkaTemplate"})
public class DummyMessageBrokerPublisher implements MessageBrokerPublisher {

    @Override
    public void send(ModuleEnum module, Serializable payload) {
    }
}
