package com.mckesson.common;

import com.google.common.collect.ImmutableMap;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.*;

public class PasswordGenerator {
    private final static List<Character> SPECIAL_SYMBOLS = Arrays.asList('!', '@', '~', '$', '%', '#', '*', '?', '-', '=', '+');
    private final static Map<String, List<Character>> SYMBOLS = ImmutableMap.of(
            "lower", Arrays.asList('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k'/*,'l'*/, 'm', 'n'/*,'o'*/, 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'),
            "upper", Arrays.asList('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'/*,'I'*/, 'J', 'K', 'L', 'M', 'N'/*,'O'*/, 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'),
            "numbers", Arrays.asList(/*'1',*/'2', '3', '4', '5', '6', '7', '8', '9'/*,'0'*/));

    private final SecureRandom secureRandom;

    public PasswordGenerator() {
        try {
            secureRandom = SecureRandom.getInstance("SHA1PRNG");
        } catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException(ex);
        }
    }

    private char getRandomCharFormArray(List<Character> symbols) {
        return symbols.get(secureRandom.nextInt(symbols.size()));
    }

    public String generate(int length) {
        StringBuilder newPassword = new StringBuilder();

        Map<String, Integer> categoryUsage = new HashMap<>();

        List<String> categoryNames = new ArrayList<>(SYMBOLS.keySet());
        for (String categoryName : categoryNames) {
            categoryUsage.put(categoryName, 0);
        }

        // Generate alphanumeric password
        for (int i = 0; i < length; i++) {
            String randomCategoryName = categoryNames.get(secureRandom.nextInt(categoryNames.size()));
            newPassword.append(getRandomCharFormArray(SYMBOLS.get(randomCategoryName)));
            categoryUsage.put(randomCategoryName, categoryUsage.get(randomCategoryName) + 1);
        }

        // Check for symbol categories usage
        for (String categoryName : categoryNames) {
            if (categoryUsage.get(categoryName) == 0) {
                newPassword.append(getRandomCharFormArray(SYMBOLS.get(categoryName)));
            }
        }

        // Insert special symbol randomly
        if (secureRandom.nextInt(2) == 1) {
            int ssPos = secureRandom.nextInt(newPassword.length() - 1) + 1; // Not the first and not the last character of the password
            char symbol = newPassword.charAt(ssPos);
            newPassword.setCharAt(ssPos, getRandomCharFormArray(SPECIAL_SYMBOLS));
            newPassword.append(symbol);
        }

        return newPassword.toString();
    }
}
