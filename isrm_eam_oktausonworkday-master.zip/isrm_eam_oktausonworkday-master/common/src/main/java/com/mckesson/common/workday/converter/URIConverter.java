package com.mckesson.common.workday.converter;

import javax.persistence.AttributeConverter;
import java.net.URI;

import static com.mckesson.common.workday.converter.ConverterUtils.nullableUri;
import static com.mckesson.common.workday.converter.ConverterUtils.object2NullableString;

public class URIConverter implements AttributeConverter<URI, String> {

    @Override
    public String convertToDatabaseColumn(URI uri) {
        return object2NullableString(uri);
    }

    @Override
    public URI convertToEntityAttribute(String s) {
        return nullableUri(s);
    }
}
