package com.mckesson.common.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdInfoGroupsSet {

    private static final UnaryOperator<AdGroup> MINIMAL = (group) ->
        AdGroup.builder()
            .dn(group.getDn())
            .cn(group.getCn())
            .description(group.getDescription())
            .build();

    boolean requested;

    boolean set;

    Set<AdGroup> groups;

    @JsonIgnore
    public void storeGroups(Collection<AdGroup> newGroups) {
        requested = false;
        set = true;
        groups = Optional.ofNullable(newGroups).orElse(Collections.emptySet()).stream()
            .map(MINIMAL).collect(Collectors.toSet());
    }
}
