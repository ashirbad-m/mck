package com.mckesson.common.cloud.rabbit;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.core.MessagePropertiesBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.util.Date;
import java.util.UUID;

/**
 * Common RabbitMQ publisher
 */
public class AbstractRabbitPublisher {
    private final RabbitTemplate rabbitTemplate;

    public AbstractRabbitPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    protected void send(String exchange, String routingKey, Object payload) {
        MessageProperties messageProperties = MessagePropertiesBuilder.newInstance()
                .setMessageId(UUID.randomUUID().toString())
                .setTimestamp(new Date())
                .build();
        Message message = rabbitTemplate.getMessageConverter().toMessage(payload, messageProperties);
        rabbitTemplate.send(exchange, routingKey, message);
    }
}
