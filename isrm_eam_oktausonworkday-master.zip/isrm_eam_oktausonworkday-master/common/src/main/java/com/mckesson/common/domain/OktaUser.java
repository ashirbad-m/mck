package com.mckesson.common.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import lombok.experimental.FieldDefaults;
import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.annotation.Validated;

import javax.naming.ldap.LdapName;
import javax.validation.constraints.Size;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Builder(toBuilder = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
@Validated
@Data
public class OktaUser implements OktaEntryDto {

    private static final String DATE_FMT = "yyyy-MM-dd";

    Long id;

    @Size(max = 38)
    String uid;

    @Size(max = 100)
    String domain;

    @NonNull
    LdapName dn;

    @Size(max = 255)
    @NonNull
    String cn;

    String ou;

    @Size(max = 100)
    String mail;

    @Size(max = 100)
    String samAccountName;

    @Size(max = 100)
    String userPrincipalName;

    @Size(max = 255)
    String middleName;

    @Size(max = 255)
    String company;

    @Size(max = 100)
    String usnChanged;

    @Size(max = 255)
    String division;

    @Size(max = 255)
    String displayName;

    @Size(max = 255)
    String homeDirectory;

    @Size(max = 255)
    String city;

    @Size(max = 255)
    String streetAddress;

    @Size(max = 255)
    String postalCode;

    @Size(max = 255)
    String state;

    @Size(max = 255)
    String st;

    LdapName manager;

    @Size(max = 255)
    String department;

    // TODO Just in case: length in AD is essentially restricted
    @Size(max = 255)
    String initials;

    @Size(max = 255)
    String lastName;

    @Size(max = 255)
    String firstName;

    String workerId;

    @Size(max = 255)
    String country;

    @Size(max = 255)
    String telephoneNumber;

    @Size(max = 255)
    String title;

    @Size(max = 100)
    String workerType;

    @Size(max = 255)
    String postalAddress;

    @Size(max = 255)
    String homeDrive;

    @Size(max = 255)
    String mobile;

    Long primaryGroupId;

    @Size(max = 255)
    String street;

    @Size(max = 255)
    String scriptPath;

    Long accountExpires;

    // TODO Absent in mshusontest
    @Size(max = 255)
    String terminalServicesProfilePath;

    Long userAccountControl;

    Long msExchRecipientTypeDetails;

    String physicalDeliveryOfficeName;

    Set<String> proxyAddresses;

    String description;

    String info;
    Manager managerObject;

    Set<LdapName> showInAddressBook;

    Set<LdapName> memberOf;
    Set<String> groups;

    Set<String> serverNames;
    String associatedAccountsTermination;

    byte[] logonHours;

    // FIXME It is not AD attribute! It is attribute from WorkDay. This decision is controversial
    boolean employee;

    IncidentData incidentData;

    AdInfo adInfo;

    /**
     * Generates user name
     * @return user name (prefix notation)
     */
    @JsonIgnore
    public String getUserName() {
        return domain + '\\' + samAccountName;
    }

    /**
     * Check user enable status from userAccountControl field
     * @return true, if user is enabled
     */
    @JsonIgnore
    public boolean isEnabled() {
        return (userAccountControl & 2) == 0;
    }
    //<editor-fold defaultstate="collapsed" desc="WorkdayUser">

    Date addressLastModified;

    @Size(max = 255)
    String legalName;

    /**
     * Okta User ID
     */
    @Size(max = 100)
    String userId;

    String managerId;

    @Size(max = 30)
    String hrbu;

    boolean active;

    @Size(max = 255)
    String fax;

    boolean trm;

    Date dateActivated;

    @JsonFormat(pattern = DATE_FMT)
    Date positionEffectiveDate;

    @Size(max = 255)
    String legalPrefix;

    @Size(max = 255)
    String legalSuffix;

    @Size(max = 255)
    String preferredFirstName;

    @Size(max = 255)
    String preferredLastName;

    @Size(max = 255)
    String preferredPrefix;

    @Size(max = 255)
    String preferredSuffix;

    Long hrPartner;

    boolean leaveOfAbsence;

    Long executiveDirector;

    @Size(max = 255)
    String jobFamily;

    @Size(max = 255)
    String homePostalCode;

    @Size(max = 38)
    String companyId;

    @Size(max = 255)
    String workerTypeDescriptor;

    @Size(max = 5)
    String glPayType;

    Date hireDate;

    String ssn;

    @Size(max = 38)
    String managerUserId;

    @Size(max = 30)
    String managerHrbu;

    @Size(max = 38)
    String executiveDirectorUserId;

    @Size(max = 30)
    String executiveDirectorHrbu;

    private String userName;
    private String mobilePhone;
    private String honorificPrefix;
    private String honorificSuffix;
    private String nickName;
    private String primaryPhone;
    private String countryCode;
    private String preferredLanguage;
    private String locale;
    private String timezone;
    private String userType;
    private String employeeNumber;
    private String costCenter;
    private String organization;
    private Boolean terminated;
    private String HRBUName;
    private String preferredName;
    private String profileUrl;
    private String workflowContexts;
    private String adGuid;

    private String emailPrimary;
    private String emailSecondaryAdditional;
    private String emailSecondary;
    private Boolean mailboxCreated;
    //</editor-fold>

    /**
     * Returns text representation of user enabled status
     * @return
     */
    @JsonIgnore
    public String getAccountStatus() {
        return isEnabled() ? "enabled" : "disabled";
    }

    /**
     * Provides base CN for user
     * @return base CN
     */
    @JsonIgnore
    public String getBaseCn() {
        StringBuilder uid = new StringBuilder();
        uid.append(getLastName()).append(", ").append(getFirstName());
        if (StringUtils.isNotBlank(getMiddleName())) {
            uid.append(" ").append(getMiddleName().charAt(0));
        }
        return uid.toString();
    }

    /**
     * Creates mail nickname from mail field
     * @return
     */
    @JsonIgnore
    public String getMailNickname() {
        String[] parts = StringUtils.split(mail, '@');
        if (parts.length == 2) {
            return parts[0];
        } else {
            return null;
        }
    }

    /**
     * Provides list of user e-mails
     * @return list with user e-mails
     */
    @JsonIgnore
    public List<String> getEmails() {
        return Arrays.asList(mail, emailPrimary, emailSecondary, emailSecondaryAdditional);
    }
}
