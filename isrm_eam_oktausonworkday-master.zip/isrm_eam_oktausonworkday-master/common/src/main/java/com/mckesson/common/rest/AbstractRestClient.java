package com.mckesson.common.rest;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.NoConnectionReuseStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Supplier;

@Slf4j
public abstract class AbstractRestClient {

    private final static String USER_AGENT = "MicroService";
    private final RestTemplate restTemplate;
    private final String serviceUrl;

    protected AbstractRestClient(String serviceUrl, RestTemplateBuilder restTemplateBuilder) {
        this.serviceUrl = serviceUrl;
        restTemplate = restTemplateBuilder.build();
    }

    protected static RestTemplateBuilder configure(RestTemplateBuilder restTemplateBuilder, int connectTimeout) {
        return restTemplateBuilder.requestFactory(() -> new HttpComponentsClientHttpRequestFactory(httpClientBuilder(connectTimeout).build()));
    }

    protected static HttpClientBuilder httpClientBuilder(int connectTimeout) {
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(connectTimeout)
                .setSocketTimeout(connectTimeout)
                .setCookieSpec(CookieSpecs.IGNORE_COOKIES)
                .build();
        return HttpClients.custom()
                .setDefaultRequestConfig(requestConfig)
                //.setConnectionTimeToLive(1, TimeUnit.MINUTES);//set maximum time to live for connection in pool
                .setConnectionReuseStrategy(NoConnectionReuseStrategy.INSTANCE);
    }

    protected String getEndpointUrl(String path) {
        return serviceUrl + path;
    }

    protected <T> T processRequestWithRetry(RetryTemplate retryTemplate, Supplier<T> method, Consumer<Exception> onError) {
        return retryTemplate.execute(
                retryContext -> {
                    try {
                        log.debug("Execute request: retryCount {}", retryContext.getRetryCount());
                        return method.get();
                    } catch (Exception ex) {
                        log.error("Unexpected exception", ex);
                        onError.accept(ex);
                        throw ex;
                    }
                },
                recoveryContext -> {
                    log.error("Cannot execute request after {} attempts", recoveryContext.getRetryCount());
                    if (recoveryContext.getLastThrowable() != null) {
                        log.error("Last Throwable ==>", recoveryContext.getLastThrowable());
                    }
                    throw new RuntimeException(recoveryContext.getLastThrowable());
                }
        );
    }

    protected <T, R> ResponseEntity<R> processRequest(
            String path,
            HttpMethod method,
            @Nullable T requestBody,
            @Nullable HttpHeaders requestHeaders,
            Class<R> responseType
    ) {
        return processRequest(path, method, requestBody, requestHeaders, responseType, Collections.emptyMap());
    }

    protected <T, R> ResponseEntity<R> processRequest(
            String path,
            HttpMethod method,
            @Nullable T requestBody,
            @Nullable HttpHeaders requestHeaders,
            Class<R> responseType,
            Map<String, ?> uriVariables
    ) {
        return exchange(serviceUrl + path, method, requestBody, requestHeaders, responseType, uriVariables);
    }

    protected <T, R> ResponseEntity<R> exchange(
            String url,
            HttpMethod method,
            @Nullable T requestBody,
            @Nullable HttpHeaders requestHeaders,
            Class<R> responseType,
            Map<String, ?> uriVariables
    ) {
        HttpEntity<T> httpEntity = createRequestEntity(requestBody, requestHeaders);
        ResponseEntity<R> response = restTemplate.exchange(url, method, httpEntity, responseType, uriVariables);
        return new ResponseEntity<>(response.getBody(), copy(response.getHeaders()), response.getStatusCode());
    }

    protected <T, R> ResponseEntity<R> processRequest(
            String path,
            HttpMethod method,
            @Nullable T requestBody,
            @Nullable HttpHeaders requestHeaders,
            ParameterizedTypeReference<R> responseType
    ) {
        return processRequest(path, method, requestBody, requestHeaders, responseType, Collections.emptyMap());
    }

    protected <T, R> ResponseEntity<R> processRequest(
            String path,
            HttpMethod method,
            @Nullable T requestBody,
            @Nullable HttpHeaders requestHeaders,
            ParameterizedTypeReference<R> responseType,
            Map<String, ?> uriVariables
    ) {
        HttpEntity<T> httpEntity = createRequestEntity(requestBody, requestHeaders);
        ResponseEntity<R> response = restTemplate.exchange(serviceUrl + path, method, httpEntity, responseType, uriVariables);
        return new ResponseEntity<>(response.getBody(), copy(response.getHeaders()), response.getStatusCode());
    }

    private <T> HttpEntity<T> createRequestEntity(@Nullable T requestBody, @Nullable HttpHeaders requestHeaders) {
        HttpHeaders headers = copy(requestHeaders);
        MediaType contentType = headers.getContentType();
        if (contentType == null && requestBody != null) {
            headers.setContentType(MediaType.APPLICATION_JSON);
        }
        headers.set(HttpHeaders.USER_AGENT, USER_AGENT);
        return new HttpEntity<>(requestBody, headers);
    }

    protected static HttpHeaders copy(@Nullable HttpHeaders headers) {
        HttpHeaders copy = new HttpHeaders();
        if (headers != null) {
            headers.forEach(copy::addAll);
        }
        return copy;
    }
}
