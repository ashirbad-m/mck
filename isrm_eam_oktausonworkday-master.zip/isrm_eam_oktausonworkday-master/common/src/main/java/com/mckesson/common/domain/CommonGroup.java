package com.mckesson.common.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;

import java.io.Serializable;

@Value
@Builder
@AllArgsConstructor
public class CommonGroup implements Serializable {
    String name;
    String dn;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CommonGroup that = (CommonGroup) o;

        return dn.equals(that.dn);
    }

    @Override
    public int hashCode() {
        return dn.hashCode();
    }
}
