package com.mckesson.common.cloud.rabbit;

import com.mckesson.common.PassportActionProcessor;
import com.mckesson.common.domain.PassportAction;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@Profile("rabbit")
@ConditionalOnSingleCandidate(PassportActionProcessor.class)
@ConditionalOnProperty("module")
@RequiredArgsConstructor
public class RabbitPassportActionListener {

    private final PassportActionProcessor actionProcessor;

    @RabbitListener(queues = "${rabbit.exchange}.${module}")
    public void processPassportAction(PassportAction action) {
        actionProcessor.processAction(action);
    }
}
