package com.mckesson.common.workday.converter;

import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SetOfStringConverter extends SetOfStringValuedConverter<String> {
    @Override
    protected Function<String, String> getStringValuedConstructor() {
        return String::new;
    }

    @Override
    protected Function<String, Stream<String>> getStreamConstructor() {
        return ConverterUtils::commaString2Stream;
    }

    @Override
    protected String joinToString(Stream<String> stream) {
        return stream.collect(Collectors.joining(","));
    }
}
