package com.mckesson.discovery;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.util.List;
import java.util.Random;

@Service
@ConditionalOnClass(DiscoveryClient.class)
public class ConsulServiceProvider implements ServiceProvider {

    private final Random random = new Random();
    private DiscoveryClient discoveryClient;

    public ConsulServiceProvider(DiscoveryClient discoveryClient) {
        this.discoveryClient = discoveryClient;
    }

    public URI getServiceUri(String serviceId, String path) {
        List<ServiceInstance> instances = discoveryClient.getInstances(serviceId);
        ServiceInstance instance;
        int count = instances.size();
        if (count == 1) {
            instance = instances.get(0);
        } else if (count > 1) {
            instance = instances.get(random.nextInt(count));
        } else {
            throw new RuntimeException("Service unavailable for: " + serviceId);
        }
        if (StringUtils.isNotBlank(path)) {
            return instance.getUri().resolve(path);
        } else {
            return instance.getUri();
        }
    }
}
