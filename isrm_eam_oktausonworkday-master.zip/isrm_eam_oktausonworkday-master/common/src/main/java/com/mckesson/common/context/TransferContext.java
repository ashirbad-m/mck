package com.mckesson.common.context;

import com.mckesson.common.domain.OktaUser;
import lombok.Data;

@Data
public class TransferContext extends CommonTerminationContext {
    private boolean clinicalTransferSuppressed;
    private boolean clinicalTransfer;
    private boolean txoTransfer;
    private OktaUser manager;
}
