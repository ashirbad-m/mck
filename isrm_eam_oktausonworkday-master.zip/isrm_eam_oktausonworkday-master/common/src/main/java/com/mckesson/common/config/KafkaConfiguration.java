package com.mckesson.common.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.cloud.kafka.KafkaPublisher;
import com.mckesson.common.model.ModuleEnum;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.converter.JsonMessageConverter;

import java.util.ArrayList;
import java.util.Collection;

@EnableKafka
@Configuration
@ConditionalOnClass(KafkaTemplate.class)
@Profile("kafka")
public class KafkaConfiguration {
    @Value("${kafka.topic.prefix}")
    private String topicPrefix;

    @Autowired(required = false)
    private KafkaAdmin kafkaAdmin;

    @Bean
    public JsonMessageConverter jsonMessageConverter(ObjectProvider<ObjectMapper> objectMapper) {
        return new JsonMessageConverter(objectMapper.getIfUnique());
    }

    @Bean
    public MessageBrokerPublisher messageBrokerPublisher(ObjectProvider<KafkaTemplate<Object, Object>> kafkaTemplate) {
        return new KafkaPublisher(kafkaTemplate.getIfUnique());
    }

    @Bean
    public Collection<NewTopic> createTopics() {
        if (kafkaAdmin != null) {
            AdminClient adminClient = AdminClient.create(kafkaAdmin.getConfigurationProperties());
            Collection<NewTopic> newTopics = new ArrayList<>();
            for (ModuleEnum module : ModuleEnum.values()) {
                newTopics.add(TopicBuilder.name(topicPrefix + "." + module.name()).build());
            }
            adminClient.createTopics(newTopics);
            return newTopics;
        } else {
            return null;
        }
    }
}
