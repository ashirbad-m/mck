package com.mckesson.common.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GroupAliases {
    private List<String> employee;
    private List<String> contractors;
    private List<String> outsideWorker;
    private List<String> xWorker;
}
