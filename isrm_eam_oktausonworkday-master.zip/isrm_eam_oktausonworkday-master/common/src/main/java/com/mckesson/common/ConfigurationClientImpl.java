package com.mckesson.common;

import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.HrbuConfig;
import com.mckesson.common.model.WorkdayConfig;
import com.mckesson.common.rest.AbstractRestClient;
import com.mckesson.common.security.VeracodeUtils;
import com.mckesson.common.workday.configuration.controller.ConfigurationClient;
import com.mckesson.common.workday.configuration.dto.GroupMappingDto;
import com.mckesson.common.workday.configuration.dto.GroupMappingType;
import com.mckesson.common.workday.configuration.dto.HrbuCityStreetDto;
import com.mckesson.common.workday.configuration.dto.HrbuDto;
import com.mckesson.common.workday.configuration.dto.request.DomainConfigRequest;
import com.mckesson.common.workday.configuration.dto.request.GroupMappingRequest;
import com.mckesson.common.workday.configuration.dto.request.HrbuViewRequest;
import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.naming.ldap.LdapName;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.mckesson.common.workday.configuration.controller.ConfigurationControllerConstants.*;

@ConditionalOnClass(RestTemplate.class)
@ConditionalOnProperty("services.configuration.service-host")
@Service
public class ConfigurationClientImpl extends AbstractRestClient implements ConfigurationClient {

    @Autowired
    public ConfigurationClientImpl(@Value("${services.configuration.service-host}") String serviceUrl, RestTemplateBuilder restTemplateBuilder) {
        super(serviceUrl, restTemplateBuilder);
    }

    //<editor-fold desc="globals">
    @Override
    public List<WorkdayConfig> getAllGlobals() {
        return getAllGlobals(null);
    }

    @Override
    public List<WorkdayConfig> getAllGlobals(HttpHeaders requestHeaders) {
        return processRequest(ALL_GLOBALS, HttpMethod.GET, null, requestHeaders, RETURN_GLOBALS_LIST).getBody();
    }


    @Override
    public WorkdayConfig findGlobalConfig() {
        return findWorkdayConfig(null);
    }

    @Override
    public WorkdayConfig findWorkdayConfig(HttpHeaders requestHeaders) {
        return processRequest(SINGLE_GLOBAL, HttpMethod.GET, null, requestHeaders, WorkdayConfig.class).getBody();
    }

    @Override
    public WorkdayConfig findGlobalById(Long id) {
        return findGlobalById(null, id);
    }

    @Override
    public WorkdayConfig findGlobalById(HttpHeaders requestHeaders, Long id) {
        return processRequest(GET_GLOBAL + id, HttpMethod.GET, requestHeaders, null, WorkdayConfig.class).getBody();
    }

    /*@Override
    public WorkdayConfig saveGlobal(HttpHeaders requestHeaders, WorkdayConfig globalDto) {
        return processRequest(SAVE_GLOBAL, HttpMethod.PUT, globalDto, requestHeaders, WorkdayConfig.class).getBody();
    }

    @Override
    public WorkdayConfig saveGlobal(WorkdayConfig globalDto) {
        return processRequest(SAVE_GLOBAL, HttpMethod.PUT, globalDto, null, WorkdayConfig.class).getBody();
    }

    @Override
    public boolean deleteGlobal(HttpHeaders requestHeaders, Long id) {
        return nullSafeBoolean(
                processRequest(DELETE_GLOBAL + id, HttpMethod.DELETE, null, requestHeaders, Boolean.class).getBody()
        );
    }

    @Override
    public boolean deleteGlobal(Long id) {
        return nullSafeBoolean(
                processRequest(DELETE_GLOBAL + id, HttpMethod.DELETE, null, null, Boolean.class).getBody()
        );
    }*/
    //</editor-fold>

    //<editor-fold desc="group_mapping">
    @Override
    public List<GroupMappingDto> getAllGroupMappings() {
        return getAllGroupMappings(null);
    }

    @Override
    public List<GroupMappingDto> getAllGroupMappings(HttpHeaders requestHeaders) {
        return processRequest(ALL_GROUP_MAPPINGS, HttpMethod.GET, null, requestHeaders, RETURN_GROUP_MAPPINGS_LIST).getBody();
    }

    @Override
    public GroupMappingDto findGroupMappingById(Long id) {
        return findGroupMappingById(null, id);
    }

    @Override
    public GroupMappingDto findGroupMappingById(HttpHeaders requestHeaders, Long id) {
        return processRequest(GET_GROUP_MAPPING + id, HttpMethod.GET, null, requestHeaders, GroupMappingDto.class).getBody();
    }

    @Override
    public GroupMappingDto findGroupMappingByName(String name) {
        return findGroupMappingByName(null, name);
    }

    @Override
    public GroupMappingDto findGroupMappingByName(HttpHeaders requestHeaders, String name) {
        return processRequest(GET_GROUP_MAPPING_BY_NAME, HttpMethod.GET, null, requestHeaders,
                GroupMappingDto.class, Map.of("name", VeracodeUtils.encode4url(name))).getBody();
    }

    @Override
    public List<GroupMappingDto> findGroupMappingsByNames(HttpHeaders requestHeaders, Collection<String> names) {
        return processRequest(FIND_GROUP_MAPPINGS_BY_NAMES, HttpMethod.POST, names, requestHeaders, RETURN_GROUP_MAPPINGS_LIST).getBody();
    }

    @Override
    public List<GroupMappingDto> findGroupMappingsByNames(Collection<String> names) {
        return findGroupMappingsByNames(null, names);
    }

    @Override
    public List<GroupMappingDto> findGroupMappingsByOktaCns(Collection<String> oktaCns) {
        return findGroupMappingsByOktaCns(null, oktaCns);
    }

    @Override
    public List<GroupMappingDto> findGroupMappingsByOktaCns(HttpHeaders requestHeaders, Collection<String> oktaCns) {
        return processRequest(FIND_GROUP_MAPPINGS_BY_OKTA_CNS, HttpMethod.POST, oktaCns, requestHeaders, RETURN_GROUP_MAPPINGS_LIST).getBody();
    }


    @Override
    public List<GroupMappingDto> findGroupMappingsByType(GroupMappingType type) {
        return findGroupMappingsByType(null, type);
    }

    @Override
    public List<GroupMappingDto> findGroupMappingsByType(HttpHeaders requestHeaders, GroupMappingType type) {
        return processRequest(FIND_GROUP_MAPPINGS_BY_TYPE, HttpMethod.GET, null, requestHeaders,
                RETURN_GROUP_MAPPINGS_LIST, Map.of("type", type)).getBody();
    }

    @Override
    public List<GroupMappingDto> findGroupMappingsByNameInAndType(GroupMappingRequest request) {
        return findGroupMappingsByNameInAndType(null, request);
    }

    @Override
    public List<GroupMappingDto> findGroupMappingsByNameInAndType(HttpHeaders requestHeaders, GroupMappingRequest request) {
        return processRequest(FIND_GROUP_MAPPINGS_BY_NAMES_AND_TYPE, HttpMethod.POST, request, requestHeaders, RETURN_GROUP_MAPPINGS_LIST).getBody();
    }


    /*@Override
    public GroupMappingDto saveGroupMapping(HttpHeaders requestHeaders, GroupMappingDto groupMappingDto) {
        return processRequest(SAVE_GROUP_MAPPING, HttpMethod.PUT, groupMappingDto, requestHeaders, GroupMappingDto.class).getBody();
    }

    @Override
    public GroupMappingDto saveGroupMapping(GroupMappingDto groupMappingDto) {
        return processRequest(SAVE_GROUP_MAPPING, HttpMethod.PUT, groupMappingDto, null, GroupMappingDto.class).getBody();
    }

    @Override
    public boolean deleteGroupMapping(HttpHeaders requestHeaders, Long id) {
        return nullSafeBoolean(
                processRequest(DELETE_GROUP_MAPPING + id, HttpMethod.DELETE, null, requestHeaders, Boolean.class).getBody()
        );
    }

    @Override
    public boolean deleteGroupMapping(Long id) {
        return nullSafeBoolean(
                processRequest(DELETE_GROUP_MAPPING + id, HttpMethod.DELETE, null, null, Boolean.class).getBody()
        );
    }*/
    //</editor-fold>

    //<editor-fold desc="domains">
    @Override
    public List<DomainConfig> allDomainConfigs() {
        return allDomainConfigs(null);
    }

    @Override
    public List<DomainConfig> allDomainConfigs(HttpHeaders requestHeaders) {
        return processRequest(ALL_DOMAINS, HttpMethod.GET, null, requestHeaders, RETURN_DOMAINS_LIST).getBody();
    }

    @Override
    public DomainConfig findDomainConfigByOu(@NonNull LdapName ou) {
        return findDomainConfigByOu(null, ou);
    }

    @Override
    public DomainConfig findDomainConfigByOu(HttpHeaders requestHeaders, @NonNull LdapName ou) {
        return processRequest(FIND_DOMAIN, HttpMethod.POST,
                DomainConfigRequest.builder().ou(ou).build(),
                requestHeaders,
                DomainConfig.class
        ).getBody();
    }

    @Override
    public DomainConfig findDomainConfig(@NonNull HrbuConfig config) {
        return findDomainConfig(null, config);
    }

    @Override
    public DomainConfig findDomainConfig(HttpHeaders requestHeaders, @NonNull HrbuConfig config) {
        return findDomainConfigByOu(requestHeaders, config.getOu());
    }

    @Override
    public DomainConfig findDomainConfigById(Long id) {
        return findDomainConfigById(null, id);
    }

    @Override
    public DomainConfig findDomainConfigById(HttpHeaders requestHeaders, Long id) {
        return processRequest(GET_DOMAIN + id, HttpMethod.GET, null, requestHeaders, DomainConfig.class).getBody();
    }

    @Override
    public DomainConfig findDomainConfigByName(String name) {
        return findDomainConfigByName(null, name);
    }

    @Override
    public DomainConfig findDomainConfigByName(HttpHeaders requestHeaders, String name) {
        return processRequest(GET_DOMAIN_BY_NAME, HttpMethod.GET, null, requestHeaders, DomainConfig.class,
                Map.of("name", VeracodeUtils.encode4url(name))).getBody();
    }

    /*@Override
    public DomainConfig saveDomainConfig(HttpHeaders requestHeaders, DomainConfig domainsDto) {
        return processRequest(SAVE_DOMAIN, HttpMethod.PUT, domainsDto, requestHeaders, DomainConfig.class).getBody();
    }

    @Override
    public DomainConfig saveDomainConfig(DomainConfig domainsDto) {
        return processRequest(SAVE_DOMAIN, HttpMethod.PUT, domainsDto, null, DomainConfig.class).getBody();
    }

    @Override
    public boolean deleteDomainConfig(HttpHeaders requestHeaders, Long id) {
        return nullSafeBoolean(
                processRequest(DELETE_DOMAIN + id, HttpMethod.DELETE, requestHeaders, null, Boolean.class).getBody()
        );
    }

    @Override
    public boolean deleteDomainConfig(Long id) {
        return nullSafeBoolean(
                processRequest(DELETE_DOMAIN + id, HttpMethod.DELETE, null, null, Boolean.class).getBody()
        );
    }*/
    //</editor-fold>

    //<editor-fold desc="hrbu">
    @Override
    public List<HrbuDto> getAllHrbu() {
        return getAllHrbu(null);
    }

    @Override
    public List<HrbuDto> getAllHrbu(HttpHeaders requestHeaders) {
        return processRequest(ALL_HRBU, HttpMethod.GET, requestHeaders, null, RETURN_HRBU_LIST).getBody();
    }

    @Override
    public HrbuDto findHrbuByHrbu(String hrbu) {
        return processRequest(GET_HRBU, HttpMethod.GET, null, null, HrbuDto.class,
                Map.of("hrbu", VeracodeUtils.encode4url(hrbu))).getBody();
    }

    /*@Override
    public HrbuDto saveHrbu(HttpHeaders requestHeaders, HrbuDto hrbuDto) {
        return processRequest(SAVE_HRBU, HttpMethod.PUT, hrbuDto, requestHeaders, HrbuDto.class).getBody();
    }

    @Override
    public HrbuDto saveHrbu(HrbuDto hrbuDto) {
        return processRequest(SAVE_HRBU, HttpMethod.PUT, hrbuDto, null, HrbuDto.class).getBody();
    }

    @Override
    public boolean deleteHrbuByHrbu(String hrbu) {
        return nullSafeBoolean(
                processRequest(DELETE_HRBU + "{hrbu}", HttpMethod.DELETE, null, null, Boolean.class,
                        Map.of("hrbu", VeracodeUtils.encode4url(hrbu))).getBody()
        );
    }*/
    //</editor-fold>

    //<editor-fold desc="hrbu_city_street">
    @Override
    public List<HrbuCityStreetDto> getAllHrbuCityStreet() {
        return getAllHrbuCityStreet(null);
    }

    @Override
    public List<HrbuCityStreetDto> getAllHrbuCityStreet(HttpHeaders requestHeaders) {
        return processRequest(ALL_HRBU_CITY_STREET, HttpMethod.GET, null, requestHeaders, RETURN_HRBU_CITY_STREET_LIST).getBody();
    }

    @Override
    public HrbuCityStreetDto findHrbuCityStreetById(Long id) {
        return findHrbuCityStreetById(null, id);
    }

    @Override
    public HrbuCityStreetDto findHrbuCityStreetById(HttpHeaders requestHeaders, Long id) {
        return processRequest(GET_HRBU_CITY_STREET + id, HttpMethod.GET, null, requestHeaders, HrbuCityStreetDto.class).getBody();
    }

    /*@Override
    public HrbuCityStreetDto saveHrbuCityStreet(HttpHeaders requestHeaders, HrbuCityStreetDto hrbuCityStreetDto) {
        return processRequest(SAVE_HRBU_CITY_STREET, HttpMethod.PUT, hrbuCityStreetDto, requestHeaders, HrbuCityStreetDto.class).getBody();
    }

    @Override
    public HrbuCityStreetDto saveHrbuCityStreet(HrbuCityStreetDto hrbuCityStreetDto) {
        return processRequest(SAVE_HRBU_CITY_STREET, HttpMethod.PUT, hrbuCityStreetDto, null, HrbuCityStreetDto.class).getBody();
    }

    @Override
    public boolean deleteHrbuCityStreet(HttpHeaders requestHeaders, Long id) {
        return nullSafeBoolean(
                processRequest(DELETE_HRBU_CITY_STREET + id, HttpMethod.DELETE, null, requestHeaders, Boolean.class).getBody()
        );
    }

    @Override
    public boolean deleteHrbuCityStreet(Long id) {
        return nullSafeBoolean(
                processRequest(DELETE_HRBU_CITY_STREET + id, HttpMethod.DELETE, null, null, Boolean.class).getBody()
        );
    }*/
    //</editor-fold>

    //<editor-fold desc="hrbu_view">
    @Override
    public List<HrbuConfig> getAllHrbuConfigs() {
        return getAllHrbuConfigs(null);
    }

    @Override
    public List<HrbuConfig> getAllHrbuConfigs(HttpHeaders requestHeaders) {
        return processRequest(ALL_HRBU_CONFIGS, HttpMethod.GET, null, requestHeaders, RETURN_HRBU_VIEW_LIST).getBody();
    }

    @Override
    public List<HrbuConfig> findHrbuConfig(HttpHeaders requestHeaders, String hrbu, String city, String street) {
        return findHrbuConfig(requestHeaders, HrbuViewRequest.builder().hrbu(hrbu).city(city).street(street).build());
    }

    @Override
    public List<HrbuConfig> findHrbuConfig(HrbuViewRequest request) {
        return findHrbuConfig(null, request);
    }

    @Override
    public List<HrbuConfig> findHrbuConfig(HttpHeaders requestHeaders, HrbuViewRequest request) {
        return processRequest(FIND_HRBU_CONFIG, HttpMethod.POST, request, requestHeaders, RETURN_HRBU_VIEW_LIST).getBody();
    }

    @Override
    public HrbuConfig findHrbuConfig(String hrbu, String city, String street) {
        return Objects.requireNonNull(findHrbuConfig(null, HrbuViewRequest.builder().hrbu(hrbu).city(city).street(street).build())).get(0);
    }
    //</editor-fold>
}
