package com.mckesson.common.config;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.cloud.stream.StreamPublisher;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@EnableBinding(Processor.class)
@ConditionalOnClass(EnableBinding.class)
@Profile("stream")
public class StreamConfiguration {

    @Bean
    MessageBrokerPublisher messageBrokerClient(Source source) {
        return new StreamPublisher(source);
    }
}
