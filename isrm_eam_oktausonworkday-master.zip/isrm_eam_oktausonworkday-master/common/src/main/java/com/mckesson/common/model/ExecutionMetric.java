package com.mckesson.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExecutionMetric {
    private ModuleEnum module;
    private String className;
    private Date start;
    private Date end;

    public ExecutionMetric(ModuleEnum module, Class<?> clazz, Date start) {
        this(module, clazz.getName(), start, new Date());
    }
}
