package com.mckesson.common.cloud.kafka;

import com.mckesson.common.CoreEventProcessor;
import com.mckesson.common.model.CoreEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@Profile("kafka")
@ConditionalOnSingleCandidate(CoreEventProcessor.class)
@ConditionalOnProperty("module")
@RequiredArgsConstructor
public class KafkaCoreEventListener {

    private final CoreEventProcessor coreEventProcessor;

    @KafkaListener(topics = "${kafka.topic.prefix}.${module}")
    public void processEvent(@Payload CoreEvent event) {
        coreEventProcessor.processEvent(event);
    }
}