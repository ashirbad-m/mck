package com.mckesson.common.model;

import com.mckesson.common.domain.CommonUser;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@Builder
public class SyncCheck implements Serializable {
    String oktaUserId;
    private CommonUser user;
}
