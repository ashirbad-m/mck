package com.mckesson.common.workday.configuration.dto.request;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.experimental.FieldDefaults;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.Size;

@Value
@Builder(toBuilder = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@Validated
public class HrbuViewRequest {
    @NonNull
    @Size(min = 5)
    String hrbu;

    String city;

    String street;

    @Builder.Default
    boolean firstOnly = true;
}
