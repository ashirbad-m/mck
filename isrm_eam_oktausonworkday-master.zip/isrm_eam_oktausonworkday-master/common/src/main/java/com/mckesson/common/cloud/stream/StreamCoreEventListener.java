package com.mckesson.common.cloud.stream;

import com.mckesson.common.CoreEventProcessor;
import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.workday.converter.ConverterUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.context.annotation.Profile;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@Profile("stream")
@ConditionalOnSingleCandidate(CoreEventProcessor.class)
@ConditionalOnProperty("module")
@RequiredArgsConstructor
public class StreamCoreEventListener {
    private final CoreEventProcessor coreEventProcessor;

    @StreamListener(target = Processor.INPUT, condition = "headers['module']==T(com.mckesson.common.model.ModuleEnum).${module}.name() && headers['class']=='com.mckesson.common.model.CoreEvent'")
    public void processEvent(@Payload CoreEvent event) {
        log.debug("Incoming event: {}", ConverterUtils.writeValueAsString(event));
        coreEventProcessor.processEvent(event);
    }
}
