package com.mckesson.common.workday.converter;

import javax.naming.ldap.LdapName;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.mckesson.common.workday.converter.ConverterUtils.object2Json;

public class SetOfLdapNameConverter extends SetOfStringValuedConverter<LdapName> {

    @Override
    protected Function<String, LdapName> getStringValuedConstructor() {
        return ConverterUtils::nullableLdapName;
    }

    @Override
    protected Function<String, Stream<String>> getStreamConstructor() {
        return ConverterUtils::jsonArray2Stream;
    }

    @Override
    protected String joinToString(Stream<String> stream) {
        return object2Json(stream.collect(Collectors.toList()), List::isEmpty, "");
    }
}
