package com.mckesson.common.domain;

import lombok.AccessLevel;
import lombok.Value;
import lombok.experimental.FieldDefaults;

@Value
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class PassportUser {
    OktaUser okta;
    UserExtension userExtension;
}
