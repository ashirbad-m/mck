package com.mckesson.common.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.mckesson.common.domain.OktaUser;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoreEvent implements Serializable, PassportErrorSupport {

    private Long created;
    private Long updated;

    private HrbuConfig hrbuConfig;
    private DomainConfig domainConfig;

    private ModuleEnum module;
    private String target;
    private ScenarioEnum scenario;
    private String stage;
    private String passportTrigger;
    private String context;
    private String id;
    private String batchId;
    private String owfFlowId;
    private String owfExecutionId;
    private Boolean importCompleted;
    private OktaUser prevOktaUser;
    private OktaUser nextOktaUser;

    private boolean failed;
    private PassportError error;
    private List<ExecutionMetric> metrics = new ArrayList<>();

    @JsonIgnore
    public OktaUser getOktaUser() {
        OktaUser user = getNextOktaUser();
        if (user == null && getPrevOktaUser() != null) {
            user = getPrevOktaUser().toBuilder().build();
            setNextOktaUser(user);
        }
        return user;
    }

    @JsonIgnore
    public String getAction() {
        return getTarget() + "/" + getStage() + "/" + getScenario();
    }
}
