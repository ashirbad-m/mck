package com.mckesson.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

import static java.lang.Math.E;
import static java.lang.Math.pow;

/**
 * Configure retry template
 */
@Configuration
public class RetryTemplateConfiguration {
    @Value("${retry.max-attempts:5}")
    private int retryMaxAttempts;

    @Value("${retry.max-delay:2000}")
    private long backoff;

    @Bean
    public RetryTemplate retryTemplate() {
        RetryTemplate retryTemplate = new RetryTemplate();

        ExponentialBackOffPolicy exponentialBackOffPolicy = new ExponentialBackOffPolicy();
        exponentialBackOffPolicy.setInitialInterval(backoff);
        exponentialBackOffPolicy.setMultiplier(E);
        exponentialBackOffPolicy.setMaxInterval(backoff * (long)pow(E, retryMaxAttempts - 1.0));
        retryTemplate.setBackOffPolicy(exponentialBackOffPolicy);

        SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy();
        retryPolicy.setMaxAttempts(retryMaxAttempts);
        retryTemplate.setRetryPolicy(retryPolicy);
        return retryTemplate;
    }
}
