package com.mckesson.common.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import lombok.experimental.FieldDefaults;
import org.springframework.validation.annotation.Validated;

import javax.naming.ldap.LdapName;
import javax.validation.constraints.Size;
import java.net.URI;
import java.util.Map;
import java.util.Set;

@Value
@Builder(toBuilder = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@Validated
public class DomainConfig {

    Long id;

    @Size(max = 100)
    String name;

    LdapName rootOu;

    @Size(max = 100)
    String fullName;

    @Size(max = 100)
    String ldapHostName;

    Set<String> exchangeServers;

    @Size(max = 100)
    String defaultMailDomain;

    @Size(max = 100)
    String office365AddressSuffix;

    URI office365Url;

    @Size(max = 255)
    String office365CredentialsAddress;

    LdapName terminatedOu;

    Set<LdapName> defaultAddressBook;

    Map<String, Object> defaultManager;

    @Size(max = 255)
    String terminalServicesProfileRoot;

    @Size(max = 100)
    String company;

    LdapName stagingOu;

    LdapName terminatedUsersGroup;

    Set<LdapName> workersOu;

    Set<LdapName> questOu;

    Set<LdapName> adminsOu;

    Long primaryGroupId;

    Long terminatedUsersPrimaryGroupId;

    Set<String> dfsServers;
}
