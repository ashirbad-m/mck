package com.mckesson.common.workday.configuration.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;
import org.springframework.validation.annotation.Validated;

import javax.naming.ldap.LdapName;
import javax.validation.constraints.Size;
import java.util.Set;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@Validated
public class HrbuCityStreetDto extends AbstractHrbuDto {

    @Builder(toBuilder = true)
    public HrbuCityStreetDto(
            //<editor-fold desc="super">
            LdapName ou,
            @Size(max = 255) String homeDrive,
            @Size(max = 255) String homeDir,
            @Size(max = 255) String loginScript,
            Set<String> groups,
            Set<String> contractorGroups,
            Set<String> outsideWorkerGroups,
            Set<String> extGroups,
            boolean activeSync,
            @Size(max = 255) String itcMail,
            //</editor-fold>

            //<editor-fold desc="this">
            Long id,
            @Size(max = 38) String city,
            @Size(max = 38) String street
            //</editor-fold>
    ) {
        super(
                ou, homeDrive, homeDir, loginScript,
                groups, contractorGroups, outsideWorkerGroups, extGroups,
                activeSync, itcMail
        );
        this.id = id;
        this.city = city;
        this.street = street;
    }

    Long id;

    @Size(max = 38)
    String city;

    @Size(max = 38)
    String street;

}
