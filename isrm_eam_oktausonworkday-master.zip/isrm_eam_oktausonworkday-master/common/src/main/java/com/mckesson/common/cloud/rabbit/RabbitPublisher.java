package com.mckesson.common.cloud.rabbit;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.model.ModuleEnum;
import lombok.NonNull;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;

import java.io.Serializable;

public class RabbitPublisher extends AbstractRabbitPublisher implements MessageBrokerPublisher {
    @Value("${rabbit.exchange}")
    private String exchange;

    public RabbitPublisher(@NonNull RabbitTemplate rabbitTemplate) {
        super(rabbitTemplate);
    }

    @Override
    public void send(ModuleEnum module, Serializable payload) {
        if (module == ModuleEnum.GATEWAY) {
            send(exchange, module.name(), payload);
        } else {
            send(exchange, "module." + module.name(), payload);
        }
    }

    protected void setExchange(String exchange) {
        this.exchange = exchange;
    }
}
