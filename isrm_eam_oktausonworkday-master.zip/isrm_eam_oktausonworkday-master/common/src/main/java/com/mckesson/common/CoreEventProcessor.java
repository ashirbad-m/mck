package com.mckesson.common;

import com.mckesson.common.model.CoreEvent;

public interface CoreEventProcessor {
    void processEvent(CoreEvent event);
}
