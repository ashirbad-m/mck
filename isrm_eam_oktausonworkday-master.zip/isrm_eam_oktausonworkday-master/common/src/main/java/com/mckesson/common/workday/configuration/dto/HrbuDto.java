package com.mckesson.common.workday.configuration.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;
import org.springframework.validation.annotation.Validated;

import javax.naming.ldap.LdapName;
import javax.validation.constraints.Size;
import java.util.Set;

@Value
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
@Validated
public class HrbuDto extends AbstractHrbuDto {

    @Builder(toBuilder = true)
    public HrbuDto(
            //<editor-fold desc="super">
            LdapName ou,
            @Size(max = 255) String homeDrive,
            @Size(max = 255) String homeDir,
            @Size(max = 255) String loginScript,
            Set<String> groups,
            Set<String> contractorGroups,
            Set<String> outsideWorkerGroups,
            Set<String> extGroups,
            boolean activeSync,
            @Size(max = 255) String itcMail,
            //</editor-fold>

            //<editor-fold desc="this">
            @Size(max = 38) @NonNull String hrbu,
            boolean city,
            @Size(max = 255) String mailSuffix,
            @Size(max = 255) String secondaryMailSuffix,
            boolean enabled,
            boolean vantageLookupStrategy,
            boolean o365
            //</editor-fold>
    ) {
        super(
                ou, homeDrive, homeDir, loginScript,
                groups, contractorGroups, outsideWorkerGroups, extGroups,
                activeSync, itcMail
        );
        this.hrbu = hrbu;
        this.city = city;
        this.mailSuffix = mailSuffix;
        this.secondaryMailSuffix = secondaryMailSuffix;
        this.enabled = enabled;
        this.vantageLookupStrategy = vantageLookupStrategy;
        this.o365 = o365;
    }

    @Size(max = 38)
    @NonNull
    String hrbu;

    boolean city;

    @Size(max = 255)
    String mailSuffix;

    @Size(max = 255)
    String secondaryMailSuffix;

    boolean enabled;

    boolean vantageLookupStrategy;

    boolean o365;

}
