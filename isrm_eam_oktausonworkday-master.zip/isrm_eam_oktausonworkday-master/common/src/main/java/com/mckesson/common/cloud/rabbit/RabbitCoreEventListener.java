package com.mckesson.common.cloud.rabbit;

import com.mckesson.common.CoreEventProcessor;
import com.mckesson.common.model.CoreEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@Profile("rabbit")
@ConditionalOnSingleCandidate(CoreEventProcessor.class)
@ConditionalOnProperty("module")
@RequiredArgsConstructor
public class RabbitCoreEventListener {

    private final CoreEventProcessor coreEventProcessor;

    @RabbitListener(queues = "${rabbit.exchange}.${module}")
    public void processEvent(CoreEvent event) {
        coreEventProcessor.processEvent(event);
    }
}
