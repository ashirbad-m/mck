package com.mckesson.common.ldap;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import org.apache.commons.lang3.RegExUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import javax.naming.ldap.Rdn;
import java.nio.charset.StandardCharsets;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class LdapUtils {
    public static final int DEF_PAGE_SIZE = 1000;

    public static final String OBJECT_GUID = "objectGUID";
    public static final String USER_PRINCIPAL_NAME = "userPrincipalName";
    public static final String MAIL = "mail";
    public static final String PROXY_ADDRESSES = "proxyAddresses";
    public static final String SMTP_PREFIX = "smtp:";
    public static final String WORKER_ID_NATIVE = "extensionAttribute8";
    public static final String PWD_NATIVE = "unicodePwd";
    public static final String OBJECT_SID = "objectSid";
    public static final String LOGON_HOURS = "logonHours";
    public static final String USER_ACCOUNT_CONTROL = "userAccountControl";
    public static final String SAM_ACCOUNT_NAME = "sAMAccountName";
    public static final String ACCOUNT_MANAGER = "manager";
    public static final String GROUP_COMPUTER_MANAGER = "managedBy";
    public static final String COMPUTER_OS = "operatingSystem";
    public static final String COMPONENT_MEMBER = "memberOf";
    public static final String CONTAINER_MEMBER = "member";
    public static final String DISTINGUISHED_NAME = "distinguishedName";
    public static final String WORKER_ID = "ExtensionAttribute8";
    public static final String CN = "cn";

    private static final Logger log = LoggerFactory.getLogger(LdapUtils.class);
    //                                                         1                 3                   3
    //                                       01  23  45  67 8 90  12 3 45  67 8 90  12 3 45  67  89  01  23  45
    private static final String GUID_FMT = "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x";
    //                                       3   2   1   0    5   4    7   6    8   9    10  11  12  13  14  15

    private static final String SEARCH_GUID_FMT = "\\%02x\\%02x\\%02x\\%02x\\%02x\\%02x\\%02x\\%02x\\%02x\\%02x\\%02x\\%02x\\%02x\\%02x\\%02x\\%02x";

    public static byte[] string2B16le(@NonNull String s) {
        return ("\"" + s + "\"").getBytes(StandardCharsets.UTF_16LE);
    }

    public static String b16le2String(@NonNull byte[] b) {
        String s = new String(b, StandardCharsets.UTF_16LE);
        if (s.startsWith("\"") && s.endsWith("\"")) {
            return s.substring(1, s.length() - 1);
        }
        return null;
    }

    public static String guid2String(@NonNull final byte[] guid) {
        return String.format(GUID_FMT, guid[3] & 255, guid[2] & 255, guid[1] & 255, guid[0] & 255, guid[5] & 255, guid[4] & 255, guid[7] & 255,
                guid[6] & 255, guid[8] & 255, guid[9] & 255, guid[10] & 255, guid[11] & 255, guid[12] & 255, guid[13] & 255, guid[14] & 255,
                guid[15] & 255);
    }

    public static byte[] string2Guid(@NonNull final String guid) {
        return new byte[]{
                (byte) Integer.parseInt(guid.substring(6, 8), 16),
                (byte) Integer.parseInt(guid.substring(4, 6), 16),
                (byte) Integer.parseInt(guid.substring(2, 4), 16),
                (byte) Integer.parseInt(guid.substring(0, 2), 16),
                (byte) Integer.parseInt(guid.substring(11, 13), 16),
                (byte) Integer.parseInt(guid.substring(9, 11), 16),
                (byte) Integer.parseInt(guid.substring(16, 18), 16),
                (byte) Integer.parseInt(guid.substring(14, 16), 16),
                (byte) Integer.parseInt(guid.substring(19, 21), 16),
                (byte) Integer.parseInt(guid.substring(21, 23), 16),
                (byte) Integer.parseInt(guid.substring(24, 26), 16),
                (byte) Integer.parseInt(guid.substring(26, 28), 16),
                (byte) Integer.parseInt(guid.substring(28, 30), 16),
                (byte) Integer.parseInt(guid.substring(30, 32), 16),
                (byte) Integer.parseInt(guid.substring(32, 34), 16),
                (byte) Integer.parseInt(guid.substring(34, 36), 16)
        };
    }

    public static String getGuidForSearch(@NonNull final String sGid) {
        byte[] guid = string2Guid(sGid);
        return String.format(SEARCH_GUID_FMT,
                guid[0] & 255, guid[1] & 255, guid[2] & 255, guid[3] & 255, guid[4] & 255, guid[5] & 255, guid[6] & 255,
                guid[7] & 255, guid[8] & 255, guid[9] & 255, guid[10] & 255, guid[11] & 255, guid[12] & 255, guid[13] & 255, guid[14] & 255,
                guid[15] & 255
        );
    }

    public static String getParentDN(LdapName name) {
        if (name.size() == 0) {
            return null;
        }

        return name.getPrefix(name.size() - 1).toString();
    }

    public static String normalizeCN(String cn) {
        return RegExUtils.replacePattern(cn, " ?[0-9]+$", "");
    }

    public static LdapName appendToLdapName(String dn, String type, Object value) {
        try {
            LdapName name = new LdapName(dn);
            name.add(new Rdn(type, value));
            return name;
        } catch (InvalidNameException e) {
            log.error("Unexpected error", e);
            return null;
        }
    }

    public static String dnToRDNValue(LdapName ldapName) {
        if (ldapName.size() == 0) {
            return null;
        } else {
            return ldapName.getRdn(ldapName.size() - 1).getValue().toString();
        }
    }
}
