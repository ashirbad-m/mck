package com.mckesson.common.scenario;

import com.mckesson.common.model.CoreEvent;

/**
 * Defines secenario of core events processing
 */
public interface Scenario {
    CoreEvent nextEvent(CoreEvent event);
}
