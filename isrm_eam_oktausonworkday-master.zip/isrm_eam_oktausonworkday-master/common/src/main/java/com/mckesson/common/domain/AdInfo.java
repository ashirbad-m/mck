package com.mckesson.common.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collection;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdInfo {
    boolean requested;
    String department;
    String additionalAction;
    AdInfoGroupsSet current = new AdInfoGroupsSet();
    AdInfoGroupsSet original = new AdInfoGroupsSet();

    @JsonIgnore
    public void storeOriginalGroups (Collection<AdGroup> newGroups) {
        getOriginal().storeGroups(newGroups);
    }

    @JsonIgnore
    public void storeCurrentGroups (Collection<AdGroup> newGroups) {
        getCurrent().storeGroups(newGroups);
    }

    public AdInfoGroupsSet getOriginal() {
        if (original ==  null) {
            original = new AdInfoGroupsSet();
        }
        return original;
    }

    public AdInfoGroupsSet getCurrent() {
        if (current ==  null) {
            current = new AdInfoGroupsSet();
        }
        return current;
    }
}
