package com.mckesson.common.mail;

import com.mckesson.common.model.EmailMessage;
import com.mckesson.common.rest.OAuth2RestClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpMethod;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.function.Consumer;

@ConditionalOnClass(RestTemplate.class)
@ConditionalOnProperty("services.mail.service-host")
@Service
public class RemoteMailService extends OAuth2RestClient implements MailService {

    @Autowired
    public RemoteMailService(
            @Value("${services.mail.service-host}") String serviceUrl,
            RestTemplateBuilder restTemplateBuilder,
            @Value("${security.oauth2.token-uri}") String accessTokenUri,
            @Value("${security.oauth2.client.client-id}") String clientId,
            @Value("${security.oauth2.client.client-secret}") String clientSecret,
            @Value("${security.oauth2.client.scope}") String scope,
            @Value("${security.oauth2.client.connect-timeout}") int connectTimeout,
            RetryTemplate retryTemplate
    ) {
        super(serviceUrl, restTemplateBuilder, accessTokenUri, clientId, clientSecret, scope, connectTimeout, retryTemplate);
    }

    @Override
    public void send(EmailMessage message, Consumer<Exception> onError) {
        processRequestWithOAuth("email/send", HttpMethod.POST, message, null, Object.class, onError);
    }
}
