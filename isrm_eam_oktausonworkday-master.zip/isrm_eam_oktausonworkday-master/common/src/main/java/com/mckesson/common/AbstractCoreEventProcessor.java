package com.mckesson.common;

import com.mckesson.common.model.*;
import com.mckesson.common.scenario.ScenarioProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Collections;
import java.util.Date;
import java.util.Map;
import java.util.function.Consumer;

@Slf4j
@RequiredArgsConstructor
public class AbstractCoreEventProcessor implements CoreEventProcessor {

    private final ScenarioProvider scenarioProvider;
    private final MessageBrokerPublisher messageBrokerPublisher;
    private final ModuleEnum module;

    @Override
    public void processEvent(CoreEvent event) {
        doProcessEvent(event);
    }

    protected Map<ScenarioEnum, Consumer<CoreEvent>> getProcessors() {
        return Collections.emptyMap();
    }

    protected ModuleEnum getModule() {
        return module;
    }

    protected void doProcessEvent(CoreEvent event) {
        if (event.getModule() != module) {
            throw new IllegalStateException("Wrong event listener, expected module " + module);
        }
        Date startTime = new Date();

        if (event.isFailed()) {
            registerError(event);
        } else {
            Consumer<CoreEvent> processor = getProcessors().get(event.getScenario());
            if (processor != null) {
                log.info("Process scenario: {}", event.getScenario());
                try {
                    processor.accept(event);
                } catch (Throwable th) {
                    PassportError pe = event.onError(th, event.getModule(), event.getScenario(), event.getStage());
                    log.error("Passport event - error: {}", pe);
                    registerError(event);
                }
            } else {
                log.warn("Unknown scenario: {}", event.getScenario());
            }
        }

        event.getMetrics().add(new ExecutionMetric(module, getClass(), startTime));

        doNextStep(event);
    }

    protected void registerError(CoreEvent event) {
    }

    protected void doNextStep(CoreEvent event) {
        CoreEvent nextEvent = scenarioProvider.getScenario().nextEvent(event);
        nextEvent.setUpdated(System.currentTimeMillis());
        messageBrokerPublisher.send(nextEvent.getModule(), nextEvent);
    }
}
