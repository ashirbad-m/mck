package com.mckesson.discovery;

import java.net.URI;

/**
 * Describes service provider
 */
public interface ServiceProvider {

    /**
     * Gets service URL
     *
     * @param serviceId service ID
     * @param path      path on server
     * @return string URL
     */
    default String getServiceUrl(String serviceId, String path) {
        return getServiceUri(serviceId, path).toString();
    }

    /**
     * Gets service URI
     *
     * @param serviceId service ID
     * @param path      path on server
     * @return service URI
     */
    URI getServiceUri(String serviceId, String path);
}