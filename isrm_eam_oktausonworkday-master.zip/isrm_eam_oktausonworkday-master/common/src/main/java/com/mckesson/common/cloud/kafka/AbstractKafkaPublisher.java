package com.mckesson.common.cloud.kafka;

import com.mckesson.common.workday.converter.ConverterUtils;
import org.springframework.kafka.core.KafkaTemplate;

/**
 * Common Kafka publisher
 */
public class AbstractKafkaPublisher {

    private final KafkaTemplate kafkaTemplate;

    public AbstractKafkaPublisher(KafkaTemplate kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    /**
     * Sends message to kafka topic
     *
     * @param topic   topic name
     * @param payload object
     */
    protected void send(String topic, Object payload) {
        kafkaTemplate.send(topic, ConverterUtils.writeValueAsString(payload));
    }
}
