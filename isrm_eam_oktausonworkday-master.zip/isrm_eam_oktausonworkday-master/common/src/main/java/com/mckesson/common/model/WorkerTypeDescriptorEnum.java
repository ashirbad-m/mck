package com.mckesson.common.model;

import org.apache.commons.lang3.StringUtils;

public enum WorkerTypeDescriptorEnum {

    CWT_EMPLOYEE("Employee"),
    CWT_CONTRACTOR("Contractor"),
    CWT_OUTSIDE("Outside Company Worker"),
    CWT_X("Contracted Access (IT Use Only)");

    private final String value;

    WorkerTypeDescriptorEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static final String CWT_REGULAR = "Regular";

    public static WorkerTypeDescriptorEnum findByValue(String value) {
        for (WorkerTypeDescriptorEnum item : WorkerTypeDescriptorEnum.values()) {
            if (StringUtils.equalsIgnoreCase(item.value, value)) {
                return item;
            }
        }
        throw new IllegalArgumentException("Unknown value: "+ value);
    }

    public static WorkerTypeDescriptorEnum getCwtValue(String workerTypeDescriptor, boolean employee) {
        if (employee || CWT_REGULAR.equalsIgnoreCase(workerTypeDescriptor)) {
            return WorkerTypeDescriptorEnum.CWT_EMPLOYEE;
        }
        if (StringUtils.isNotEmpty(workerTypeDescriptor)) {
            if (WorkerTypeDescriptorEnum.CWT_OUTSIDE.getValue().equalsIgnoreCase(workerTypeDescriptor)) {
                return WorkerTypeDescriptorEnum.CWT_OUTSIDE;
            } else if (WorkerTypeDescriptorEnum.CWT_X.getValue().equalsIgnoreCase(workerTypeDescriptor)) {
                return WorkerTypeDescriptorEnum.CWT_X;
            }
        }
        return WorkerTypeDescriptorEnum.CWT_CONTRACTOR;
    }
}
