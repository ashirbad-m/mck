package com.mckesson.common.domain;

import lombok.Builder;
import lombok.Value;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

@Value
@Builder(toBuilder = true)
public class CommonUser implements Serializable {
    String dn;
    String userPrincipalName;
    String samAccountName;
    String city;
    String firstName;
    Long primaryGroupId;
    String mail;
    List<String> proxyAddresses;
    String physicalDeliveryOfficeName;
    String country;
    String lastName;
    String cn;
    String description;
    String displayName;
    String fax;
    String middleName;
    String address;
    String postalCode;
    String mobile;
    String telephoneNumber;
    String state;
    String workerType;
    String title;
    String workerId;
    String postalAddress;
    String homeDrive;
    String scriptPath;
    String homeDirectory;
    Long msExchRecipientTypeDetails;
    String company;
    Long accountExpires;
    String terminalServicesProfilePath;
    List<String> showInAddressBook;
    String info;
    String manager;
    String logonHours;
    Boolean active;
    List<CommonGroup> memberOf;

    public boolean same(CommonUser other) {
        if (this == other) return true;
        if (other == null) return false;

        if (!StringUtils.equalsIgnoreCase(dn, other.dn)) return false;
        if (!StringUtils.equals(userPrincipalName, other.userPrincipalName)) return false;
        if (!StringUtils.equals(samAccountName, other.samAccountName)) return false;
        if (!StringUtils.equals(city, other.city)) return false;
        if (!StringUtils.equals(firstName, other.firstName)) return false;
        if (!StringUtils.equals(mail, other.mail)) return false;
        if (!StringUtils.equals(physicalDeliveryOfficeName, other.physicalDeliveryOfficeName)) return false;
        if (!StringUtils.equals(country, other.country)) return false;
        if (!StringUtils.equals(lastName, other.lastName)) return false;
        if (!StringUtils.equals(cn, other.cn)) return false;
        if (!StringUtils.equals(description, other.description)) return false;
        if (!StringUtils.equals(displayName, other.displayName)) return false;
        if (!StringUtils.equals(fax, other.fax)) return false;
        if (!StringUtils.equals(middleName, other.middleName)) return false;
        if (!StringUtils.equals(address, other.address)) return false;
        if (!StringUtils.equals(postalCode, other.postalCode)) return false;
        if (!StringUtils.equals(mobile, other.mobile)) return false;
        if (!StringUtils.equals(telephoneNumber, other.telephoneNumber)) return false;
        if (!StringUtils.equals(state, other.state)) return false;
        if (!StringUtils.equals(workerType, other.workerType)) return false;
        if (!StringUtils.equals(title, other.title)) return false;
        if (!StringUtils.equals(workerId, other.workerId)) return false;
        if (!StringUtils.equals(postalAddress, other.postalAddress)) return false;
        if (!StringUtils.equals(homeDrive, other.homeDrive)) return false;
        if (!StringUtils.equals(scriptPath, other.scriptPath)) return false;
        if (!StringUtils.equals(homeDirectory, other.homeDirectory)) return false;
        if (!StringUtils.equals(company, other.company)) return false;
        if (!StringUtils.equals(terminalServicesProfilePath, other.terminalServicesProfilePath)) return false;
        if (!StringUtils.equals(info, other.info)) return false;
        if (!StringUtils.equals(manager, other.manager)) return false;
        if (!Objects.equals(msExchRecipientTypeDetails, other.msExchRecipientTypeDetails)) return false;
        if (!Objects.equals(showInAddressBook, other.showInAddressBook)) return false;
        if (!Objects.equals(accountExpires, other.accountExpires)) return false;
        if (!Objects.equals(logonHours, other.logonHours)) return false;
        if (!Objects.equals(active, other.active)) return false;
        if (!Objects.equals(primaryGroupId, other.primaryGroupId)) return false;
        if (!Objects.equals(proxyAddresses, other.proxyAddresses)) return false;
        return Objects.equals(memberOf, other.memberOf);
    }

    public static String printDiff(CommonUser adUser, CommonUser oktaUser) {
        var sb = new StringBuilder();
        if (!adUser.equals(oktaUser)) {
            addDiff(sb, "dn", adUser.getDn(), oktaUser.getDn());
            addDiff(sb, "userPrincipalName", adUser.getUserPrincipalName(), oktaUser.getUserPrincipalName());
            addDiff(sb, "samAccountName", adUser.getSamAccountName(), oktaUser.getSamAccountName());
            addDiff(sb, "city", adUser.getCity(), oktaUser.getCity());
            addDiff(sb, "firstName", adUser.getFirstName(), oktaUser.getFirstName());
            addDiff(sb, "primaryGroupId", adUser.getPrimaryGroupId(), oktaUser.getPrimaryGroupId());
            addDiff(sb, "mail", adUser.getMail(), oktaUser.getMail());
            addDiff(sb, "physicalDeliveryOfficeName", adUser.getPhysicalDeliveryOfficeName(), oktaUser.getPhysicalDeliveryOfficeName());
            addDiff(sb, "country", adUser.getCountry(), oktaUser.getCountry());
            addDiff(sb, "lastName", adUser.getLastName(), oktaUser.getLastName());
            addDiff(sb, "cn", adUser.getCn(), oktaUser.getCn());
            addDiff(sb, "description", adUser.getDescription(), oktaUser.getDescription());
            addDiff(sb, "displayName", adUser.getDisplayName(), oktaUser.getDisplayName());
            addDiff(sb, "fax", adUser.getFax(), oktaUser.getFax());
            addDiff(sb, "middleName", adUser.getMiddleName(), oktaUser.getMiddleName());
            addDiff(sb, "address", adUser.getAddress(), oktaUser.getAddress());
            addDiff(sb, "postalCode", adUser.getPostalCode(), oktaUser.getPostalCode());
            addDiff(sb, "mobile", adUser.getMobile(), oktaUser.getMobile());
            addDiff(sb, "telephoneNumber", adUser.getTelephoneNumber(), oktaUser.getTelephoneNumber());
            addDiff(sb, "state", adUser.getState(), oktaUser.getState());
            addDiff(sb, "workerType", adUser.getWorkerType(), oktaUser.getWorkerType());
            addDiff(sb, "title", adUser.getTitle(), oktaUser.getTitle());
            addDiff(sb, "workerId", adUser.getWorkerId(), oktaUser.getWorkerId());
            addDiff(sb, "postalAddress", adUser.getPostalAddress(), oktaUser.getPostalAddress());
            addDiff(sb, "homeDrive", adUser.getHomeDrive(), oktaUser.getHomeDrive());
            addDiff(sb, "scriptPath", adUser.getScriptPath(), oktaUser.getScriptPath());
            addDiff(sb, "homeDirectory", adUser.getHomeDirectory(), oktaUser.getHomeDirectory());
            addDiff(sb, "msExchRecipientTypeDetails", adUser.getMsExchRecipientTypeDetails(), oktaUser.getMsExchRecipientTypeDetails());
            addDiff(sb, "company", adUser.getCompany(), oktaUser.getCompany());
            addDiff(sb, "accountExpires", adUser.getAccountExpires(), oktaUser.getAccountExpires());
            addDiff(sb, "terminalServicesProfilePath", adUser.getTerminalServicesProfilePath(), oktaUser.getTerminalServicesProfilePath());
            addDiff(sb, "info", adUser.getInfo(), oktaUser.getInfo());
            addDiff(sb, "manager", adUser.getManager(), oktaUser.getManager());
            addDiff(sb, "logonHours", adUser.getLogonHours(), oktaUser.getLogonHours());
            addDiff(sb, "active", adUser.getActive(), oktaUser.getActive());
            addDiff(sb, "proxyAddresses", StringUtils.join(adUser.getProxyAddresses()), StringUtils.join(oktaUser.getProxyAddresses()));
            addDiff(sb, "showInAddressBook", StringUtils.join(adUser.getShowInAddressBook()), StringUtils.join(oktaUser.getShowInAddressBook()));
            addDiff(sb, "memberOf", StringUtils.join(adUser.getMemberOf()), StringUtils.join(oktaUser.getMemberOf()));
        }
        return sb.toString();
    }

    private static void addDiff(StringBuilder sb, String field, Object adValue, Object oktaValue) {
        if (!Objects.equals(adValue, oktaValue)) {
            if (sb.length() > 0) sb.append("\n");
            sb.append(field).append(" ad: `").append(adValue).append("` okta: `").append(oktaValue).append("`");
        }
    }
}
