package com.mckesson.common.workday.converter;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;

import javax.naming.NamingException;
import javax.naming.ldap.LdapName;
import java.net.URI;
import java.util.*;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class ConverterUtils {

    private ConverterUtils() {
    }

    private static final ObjectMapper MAPPER = configuredMapper();

    private static final TypeReference<Map<String, Object>> STRING_OBJECT_MAP_REF = new TypeReference<>() {};

    public static final BiFunction<Map<String, Object>, String, String> STRING_GETTER = (map, key) -> nullableString((String)map.get(key));
    public static final BiFunction<Map<String, Object>, String, String> REQUIRED_STRING_GETTER = (map, key) -> Objects.requireNonNull(STRING_GETTER.apply(map, key));

    public static final BiPredicate<Map<String, Object>, String> BOOLEAN_GETTER = (map, key) -> nullSafeBoolean((Boolean)map.get(key));

    @SneakyThrows(NamingException.class)
    private static LdapName ldapName(final String s) {
        return new LdapName(s);
    }

    @SneakyThrows(JsonProcessingException.class)
    public static byte[] writeValueAsBytes(final Object obj) {
        return MAPPER.writeValueAsBytes(obj);
    }

    public static String writeValueAsString(final Object obj) {
        return write(obj);
    }

    @SneakyThrows(JsonProcessingException.class)
    private static String write(final Object obj) {
        return MAPPER.writeValueAsString(obj);
    }

    @SneakyThrows(JsonProcessingException.class)
    private static <T> T read(final String value, final Class<T> clazz) {
        return MAPPER.readValue(value, clazz);
    }

    @SneakyThrows(JsonProcessingException.class)
    private static <T> T read(final String value, final TypeReference<T> type) {
        return MAPPER.readValue(value, type);
    }

    private static <T> Map<String, Object> write2Map(final T value) {
        return MAPPER.convertValue(value, STRING_OBJECT_MAP_REF);
    }

    private static <T> T readFromMap(final Map<String, Object> value, final Class<T> clazz) {
        return MAPPER.convertValue(value, clazz);
    }

    private static <T> Optional<T> blankFilteredObject(final T t, final Predicate<T> emptyChecker) {
        return Optional.ofNullable(t).filter(o -> !emptyChecker.test(o));
    }

    private static Optional<String> blankFilteredString(final String s) {
        return blankFilteredObject(s, StringUtils::isBlank);
    }

    public static ObjectMapper configuredMapper() {
        ObjectMapper result = new ObjectMapper();
        result.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        result.enable(JsonParser.Feature.ALLOW_SINGLE_QUOTES);
        result.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        result.registerModule(
                new SimpleModule("LdapName")
                        .addSerializer(LdapName.class, new LdapNameJsonComponent.LdapNameSerializer())
                        .addDeserializer(LdapName.class, new LdapNameJsonComponent.LdapNameDeserializer())
        );
        return result;
    }

    public static <T> String object2NullableString(final T o) {
        return Optional.ofNullable(o).map(T::toString).orElse(null);
    }

    public static String nullSafeString(final String s) {
        return blankFilteredString(s).orElse("");
    }

    public static boolean nullSafeBoolean(final Boolean b) {
        return Optional.ofNullable(b).orElse(false);
    }

    public static String nullableString(final String s) {
        return blankFilteredString(s).orElse(null);
    }

    public static <T> T nullSafeValue(final T value, final Predicate<T> emptyChecker, final T defaultValue) {
        return blankFilteredObject(value, emptyChecker).orElse(defaultValue);
    }

    public static <T> Set<T> nullSafeSet(final Set<T> value) {
        return nullSafeValue(value, Set::isEmpty, new HashSet<>());
    }

    public static <T> T nullableObjectFromString(final String s, final Function<String, T> generator) {
        return blankFilteredString(s).map(generator).orElse(null);
    }

    public static LdapName nullableLdapName(String s) {
        if("null".equalsIgnoreCase(s)){
            s = null;
        }
        return nullableObjectFromString(s, ConverterUtils::ldapName);
    }

    public static URI nullableUri(final String s) {
        return nullableObjectFromString(s, URI::create);
    }

    public static <T> T map2NullableObject(final Map<String, Object> m, final Class<T> clazz) {
        return blankFilteredObject(m, Map::isEmpty).map(m0 -> readFromMap(m0, clazz)).orElse(null);
    }

    public static <T> Map<String, Object> object2NullableMap(T value) {
        return Optional.ofNullable(value).map(ConverterUtils::write2Map).filter(m -> !m.isEmpty()).orElse(null);
    }

    public static <T> String object2Json(final T obj, final Predicate<T> emptyChecker, final String defaultValue) {
        return blankFilteredObject(obj, emptyChecker).map(ConverterUtils::write).orElse(defaultValue);
    }

    public static <T> String object2Json(final T obj) {
        return Optional.ofNullable(obj).map(ConverterUtils::write).orElse(null);
    }

    public static <T> T readValue(final String value, final Function<String, T> mapper, final T defaultValue) {
        return blankFilteredString(value).map(mapper).orElse(defaultValue);
    }

    public static <T> T readSimpleJson(final String value, final Class<T> clazz, final T defaultValue) {
        return readValue(value, v -> read(v, clazz), defaultValue);
    }

    public static <T> T readTypeRefJson(final String value, final TypeReference<T> type, final T defaultValue) {
        return readValue(value, v -> read(v, type), defaultValue);
    }

    public static Map<String, Object> json2NullSafeMap(final String value) {
        return readTypeRefJson(value, STRING_OBJECT_MAP_REF, new HashMap<>());
    }

    public static Stream<String> string2Stream(final String value, final Function<String, String[]> nullSafeReader) {
        return Stream.of(nullSafeReader.apply(value)).filter(StringUtils::isNotBlank);
    }

    public static Stream<String> jsonArray2Stream(final String jsonStringArray) {
        return string2Stream(jsonStringArray, v -> readSimpleJson(v, String[].class, new String[0]));
    }

    public static Stream<String> commaString2Stream(final String s) {
        return string2Stream(s, v -> nullSafeString(v).split(","));
    }
}
