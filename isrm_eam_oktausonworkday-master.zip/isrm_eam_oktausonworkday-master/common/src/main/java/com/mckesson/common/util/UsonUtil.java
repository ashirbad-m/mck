package com.mckesson.common.util;

import org.apache.commons.lang3.StringUtils;

public interface UsonUtil {

    /**
     * Generates home directory,
     * inserts 2ARCHIVENETSEC before the last segment of home directory path
     *
     * @param homeDirectory home directory value
     * @return updated value or original value
     */
    static String generateArchivedHomeDirectory(String homeDirectory) {
        if (StringUtils.isNotBlank(homeDirectory)) {
            //generate home directory, insert 2ARCHIVENETSEC before the last segment of home directory path
            return homeDirectory.replaceFirst("\\\\([^\\\\]+)$", "\\\\2ARCHIVENETSEC\\\\$1");
        } else {
            return homeDirectory;
        }
    }
}
