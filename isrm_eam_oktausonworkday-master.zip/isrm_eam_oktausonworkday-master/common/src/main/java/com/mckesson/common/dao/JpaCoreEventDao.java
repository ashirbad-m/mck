package com.mckesson.common.dao;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.workday.converter.ConverterUtils;
import com.mckesson.common.security.VeracodeUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

@Repository
@Slf4j
public class JpaCoreEventDao implements CoreEventDao {
    @Override
    public void create(CoreEvent event) {
        log.debug("Create event by ID {}: {}", VeracodeUtils.encode4java(event.getId()), ConverterUtils.writeValueAsString(event));
    }

    @Override
    public void update(CoreEvent event) {
        log.debug("Update event by ID {}: {}", VeracodeUtils.encode4java(event.getId()), ConverterUtils.writeValueAsString(event));
    }

    @Override
    public void delete(CoreEvent event) {
        log.debug("Delete event by ID {}: {}", VeracodeUtils.encode4java(event.getId()), ConverterUtils.writeValueAsString(event));
    }
}
