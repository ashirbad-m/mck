package com.mckesson.common.model;

public enum ScenarioEnum {

    CREATE("create"),
    UPDATE("update"),
    CROSSDOMAIN("crossdomain"),
    TERMINATE("terminate"),
    REQUEST("request"),
    DEFERRED("deferred"),
    SYNCHRONIZE("synchronize");

    ScenarioEnum(String name) {
        this.name = name;
    }

    public static ScenarioEnum valueByName(String name) {
        for (ScenarioEnum value : values()) {
            if (value.name.equals(name)) {
                return value;
            }
        }
        throw new IllegalArgumentException("Unknown scenario name: " + name);
    }

    private final String name;

    public String getName() {
        return name;
    }
}
