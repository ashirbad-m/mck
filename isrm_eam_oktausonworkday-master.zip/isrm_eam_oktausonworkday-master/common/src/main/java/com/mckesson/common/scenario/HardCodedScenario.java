package com.mckesson.common.scenario;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.model.ModuleEnum;
import com.mckesson.common.model.ScenarioEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
public class HardCodedScenario implements Scenario {
    private static Map<ScenarioEnum, ModuleScenario> scenarios = Stream.of(
            Pair.of(ScenarioEnum.CREATE, new ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER)),
            Pair.of(ScenarioEnum.UPDATE, new ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER)),
            Pair.of(ScenarioEnum.CROSSDOMAIN, new ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER)),
            Pair.of(ScenarioEnum.TERMINATE, new ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER)),
            Pair.of(ScenarioEnum.REQUEST, new ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER)),
            Pair.of(ScenarioEnum.DEFERRED, new ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER)),
            Pair.of(ScenarioEnum.SYNCHRONIZE, new ModuleScenario(ModuleEnum.GATEWAY, ModuleEnum.ACTIVE_DIRECTORY, ModuleEnum.OKTA_CLIENT, ModuleEnum.FINALIZER))
    ).collect(Collectors.toMap(Pair::getLeft, Pair::getRight));

    @Override
    public CoreEvent nextEvent(CoreEvent event) {
        ModuleScenario moduleScenario = scenarios.get(event.getScenario());
        if (moduleScenario != null) {
            event.setModule(moduleScenario.getNextModule(event.getModule()));
            return event;
        } else {
            throw new IllegalStateException();
        }
    }

    protected static class ModuleScenario implements Serializable {
        private final ModuleEnum defaultValue;
        protected final Map<ModuleEnum, ModuleEnum> map;

        public ModuleScenario(ModuleEnum... steps) {
            if (steps.length > 1) {
                this.defaultValue = steps[0];
                map = new HashMap<>();
                for (int ii = 1; ii < steps.length; ii++) {
                    map.put(steps[ii - 1], steps[ii]);
                }
            } else {
                throw new IllegalArgumentException();
            }
        }

        protected ModuleEnum getNextModule(ModuleEnum module) {
            if (module != null) {
                ModuleEnum next = map.get(module);
                if (next == null) {
                    throw new IllegalStateException();
                }
                return next;
            } else {
                return defaultValue;
            }
        }
    }
}
