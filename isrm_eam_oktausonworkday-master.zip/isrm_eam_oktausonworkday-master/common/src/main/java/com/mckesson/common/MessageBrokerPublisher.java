package com.mckesson.common;

import com.mckesson.common.model.ModuleEnum;

import java.io.Serializable;

/**
 * Message broker publisher
 */
public interface MessageBrokerPublisher {

    /**
     * Sends message(payload) to module
     *
     * @param module  destination
     * @param payload message
     */
    void send(ModuleEnum module, Serializable payload);

}
