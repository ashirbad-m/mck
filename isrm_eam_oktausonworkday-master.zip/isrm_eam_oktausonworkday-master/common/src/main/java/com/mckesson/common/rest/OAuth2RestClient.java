package com.mckesson.common.rest;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

@Slf4j
public abstract class OAuth2RestClient extends AbstractRestClient {
    private final String accessTokenUri;
    private final String clientId;
    private final String clientSecret;
    private final String scope;
    private final RetryTemplate retryTemplate;
    private final int connectTimeout;

    private String oauth2Token;
    private long oauth2TokenExpiration = 0;//timestamp

    public OAuth2RestClient(String serviceUrl, RestTemplateBuilder restTemplateBuilder,
                            String accessTokenUri, String clientId, String clientSecret, String scope,
                            int connectTimeout, RetryTemplate retryTemplate) {
        super(serviceUrl, configure(restTemplateBuilder, connectTimeout));
        this.accessTokenUri = accessTokenUri;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.scope = scope;
        this.retryTemplate = retryTemplate;
        this.connectTimeout = connectTimeout;
    }

    protected synchronized String getOauth2Token() {
        if (System.currentTimeMillis() >= oauth2TokenExpiration) {
            log.debug("Request oauth2 token");
            var now = System.currentTimeMillis();
            HttpHeaders requestHeaders = new HttpHeaders();
            requestHeaders.setBasicAuth(clientId, clientSecret);
            requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

            MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
            params.add("grant_type", "client_credentials");
            params.add("scope", scope);
            var response = Objects.requireNonNull(exchange(accessTokenUri, HttpMethod.POST, params, requestHeaders, Oauth2Response.class, Collections.emptyMap()).getBody());
            oauth2TokenExpiration = now + TimeUnit.SECONDS.toMillis(response.getExpiresIn());
            oauth2Token = response.getAccessToken();
        }
        return oauth2Token;
    }

    private String getOauth2Token(Consumer<Exception> onError) {
        return processRequestWithRetry(retryTemplate, this::getOauth2Token, onError);
    }

    protected <T, R> ResponseEntity<R> processRequestWithOAuth(
            String path,
            HttpMethod method,
            @Nullable T requestBody,
            @Nullable HttpHeaders requestHeaders,
            Class<R> responseType,
            Consumer<Exception> onError
    ) {
        return processRequestWithOAuth(path, method, requestBody, requestHeaders, responseType, Collections.emptyMap(), onError);
    }

    protected <T, R> ResponseEntity<R> processRequestWithOAuth(
            String path,
            HttpMethod method,
            @Nullable T requestBody,
            @Nullable HttpHeaders requestHeaders,
            Class<R> responseType,
            Map<String, ?> uriVariables,
            Consumer<Exception> onError
    ) {
        if (requestHeaders == null) {
            requestHeaders = new HttpHeaders();
        }
        requestHeaders.setBearerAuth(Objects.requireNonNull(getOauth2Token(onError)));
        try {
            return super.processRequest(path, method, requestBody, requestHeaders, responseType, uriVariables);
        } catch (Exception ex) {
            log.error("Unexpected exception, connectTimeout: " + connectTimeout + "ms", ex);
            onError.accept(ex);
            throw ex;
        }
    }

    @Data
    public static class Oauth2Response {
        @JsonProperty("access_token")
        private String accessToken;
        @JsonProperty("expires_in")
        private int expiresIn;
        @JsonProperty("scope")
        private String customScope;
        @JsonProperty("token_type")
        private String tokenType;
    }
}
