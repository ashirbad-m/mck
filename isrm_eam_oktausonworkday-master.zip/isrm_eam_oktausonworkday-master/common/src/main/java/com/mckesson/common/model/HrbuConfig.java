package com.mckesson.common.model;

import com.mckesson.common.workday.configuration.dto.AbstractHrbuDto;
import lombok.*;
import lombok.experimental.FieldDefaults;
import org.springframework.validation.annotation.Validated;

import javax.naming.ldap.LdapName;
import javax.validation.constraints.Size;
import java.util.Set;

@Value
@AllArgsConstructor
@NoArgsConstructor(force = true)
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
@Validated
public class HrbuConfig extends AbstractHrbuDto {

    @Builder(toBuilder = true)
    public HrbuConfig(
            //<editor-fold desc="super">
            @NonNull LdapName ou,
            @Size(max = 255) String homeDrive,
            @Size(max = 255) String homeDir,
            @Size(max = 255) String loginScript,
            Set<String> groups,
            Set<String> contractorGroups,
            Set<String> outsideWorkerGroups,
            Set<String> extGroups,
            boolean activeSync,
            @Size(max = 255) String itcMail,
            //</editor-fold>

            //<editor-fold desc="hrbu">
            @Size(max = 38) @NonNull String hrbu,
            @Size(max = 255) String mailSuffix,
            @Size(max = 255) String secondaryMailSuffix,
            boolean enabled,
            boolean vantageLookupStrategy,
            boolean o365,
            //</editor-fold>

            //<editor-fold desc="hrbu_city_street">
            @Size(max = 38) String city,
            @Size(max = 38) String street,
            //</editor-fold>

            //<editor-fold desc="calculated">
            String id,
            boolean notifyManager
            //</editor-fold>
    ) {
        super(
                ou, homeDrive, homeDir, loginScript,
                groups, contractorGroups, outsideWorkerGroups, extGroups,
                activeSync, itcMail
        );

        this.hrbu = hrbu;
        this.mailSuffix = mailSuffix;
        this.secondaryMailSuffix = secondaryMailSuffix;
        this.enabled = enabled;
        this.vantageLookupStrategy = vantageLookupStrategy;
        this.o365 = o365;

        this.city = city;
        this.street = street;

        this.id = id;
        this.notifyManager = notifyManager;
    }

    @Size(max = 38)
    @NonNull
    String hrbu;

    @Size(max = 255)
    String mailSuffix;

    @Size(max = 255)
    String secondaryMailSuffix;

    boolean enabled;

    boolean vantageLookupStrategy;

    boolean o365;

    @Size(max = 38)
    String city;

    @Size(max = 38)
    String street;

    @Size(max = 38)
    String id;

    boolean notifyManager;

    public boolean isUserIncluded(LdapName dn) {
        throw new UnsupportedOperationException();//FIXME
    }

    public String homeDirectory(String samAccountName) {
        //return home + samAccountName;
        throw new UnsupportedOperationException();//FIXME
    }
}
