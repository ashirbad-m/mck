package com.mckesson.discovery;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Service;

import java.net.URI;

@Service
@ConditionalOnMissingBean(DiscoveryClient.class)
@Slf4j
public class LocalServiceProvider implements ServiceProvider {

    @Override
    public URI getServiceUri(String serviceId, String path) {
        int port = 0;
        switch (serviceId) {
            case "global-mfa-remedyforce":
                port = 7710;
                break;
            case "global-mfa-exchange":
                port = 7720;
                break;
            case "global-mfa-ad":
                port = 7730;
                break;
            case "global-mfa-mail":
                port = 7740;
                break;
            case "global-mfa-core":
                port = 7750;
                break;
            case "global-mfa-configuration":
                port = 7760;
                break;
            default:
                throw new UnsupportedOperationException("Unsupported operation");
        }
        URI uri = URI.create("http://localhost:" + port);
        if (StringUtils.isNotBlank(path)) {
            return uri.resolve(path);
        } else {
            return uri;
        }
    }
}
