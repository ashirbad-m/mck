package com.mckesson.common.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.naming.ldap.LdapName;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkdayManagedUser {
    private LdapName adManagerDN;
    private OktaUser oktaUser;
}
