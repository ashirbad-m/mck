package com.mckesson.common.domain;

import javax.naming.Name;

public interface AdEntryData<N extends Name, I> {
    void setDomain(String domain);
    String getDomain();
    void setDn(N dn);
    N getDn();
    void setUid(I uid);
    I getUid();
}
