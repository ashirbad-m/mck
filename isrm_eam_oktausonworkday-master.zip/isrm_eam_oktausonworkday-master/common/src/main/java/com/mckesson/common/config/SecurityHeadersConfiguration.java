package com.mckesson.common.config;

import lombok.NonNull;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.web.header.writers.*;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Adds security headers to response
 */
@Configuration
public class SecurityHeadersConfiguration {

    @Bean
    public FilterRegistrationBean<SecurityHeadersFilter> servletRegistrationBean() {
        final SecurityHeadersFilter filter = new SecurityHeadersFilter(true, true, true, true, true);
        final FilterRegistrationBean<SecurityHeadersFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(filter);
        registrationBean.setOrder(2);
        return registrationBean;
    }

    public static class SecurityHeadersFilter extends OncePerRequestFilter {
        private final XContentTypeOptionsHeaderWriter contentTypeOptionsHeaderWriter;
        private final XXssProtectionHeaderWriter xssProtectionHeaderWriter;
        private final CacheControlHeadersWriter cacheControlHeadersWriter;
        private final HstsHeaderWriter hstsHeaderWriter;
        private final ContentSecurityPolicyHeaderWriter contentSecurityPolicyHeaderWriter;

        public SecurityHeadersFilter(boolean contentTypeOptions, boolean xssProtection, boolean cacheControl, boolean httpStrictTransportSecurity, boolean contentSecurityPolicy) {
            contentTypeOptionsHeaderWriter = contentTypeOptions ? new XContentTypeOptionsHeaderWriter() : null;
            xssProtectionHeaderWriter = xssProtection ? new XXssProtectionHeaderWriter() : null;
            cacheControlHeadersWriter = cacheControl ? new CacheControlHeadersWriter() : null;
            hstsHeaderWriter = httpStrictTransportSecurity ? new HstsHeaderWriter() : null;
            contentSecurityPolicyHeaderWriter = contentSecurityPolicy ? new ContentSecurityPolicyHeaderWriter("script-src 'self'") : null;
        }

        @Override
        protected void doFilterInternal(final @NonNull HttpServletRequest request, final @NonNull HttpServletResponse response, final @NonNull FilterChain filterChain) throws ServletException, IOException {
            if (contentTypeOptionsHeaderWriter != null) {
                contentTypeOptionsHeaderWriter.writeHeaders(request, response);
            }
            if (xssProtectionHeaderWriter != null) {
                xssProtectionHeaderWriter.writeHeaders(request, response);
            }
            if (cacheControlHeadersWriter != null) {
                cacheControlHeadersWriter.writeHeaders(request, response);
            }
            if (hstsHeaderWriter != null) {
                hstsHeaderWriter.writeHeaders(request, response);
            }
            if (contentSecurityPolicyHeaderWriter != null) {
                contentSecurityPolicyHeaderWriter.writeHeaders(request, response);
            }

            filterChain.doFilter(request, response);
        }
    }
}