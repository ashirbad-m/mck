package com.mckesson.common.workday.configuration.controller;

import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.HrbuConfig;
import com.mckesson.common.model.WorkdayConfig;
import com.mckesson.common.workday.configuration.ConfigurationService;
import com.mckesson.common.workday.configuration.dto.GroupMappingDto;
import com.mckesson.common.workday.configuration.dto.GroupMappingType;
import com.mckesson.common.workday.configuration.dto.HrbuCityStreetDto;
import com.mckesson.common.workday.configuration.dto.HrbuDto;
import com.mckesson.common.workday.configuration.dto.request.GroupMappingRequest;
import com.mckesson.common.workday.configuration.dto.request.HrbuViewRequest;
import org.springframework.http.HttpHeaders;

import javax.naming.ldap.LdapName;
import java.util.Collection;
import java.util.List;

public interface ConfigurationClient extends ConfigurationService {
    //<editor-fold desc="globals">
    List<WorkdayConfig> getAllGlobals(HttpHeaders requestHeaders);

    WorkdayConfig findWorkdayConfig(HttpHeaders requestHeaders);

    WorkdayConfig findGlobalById(HttpHeaders requestHeaders, Long id);

    //WorkdayConfig saveGlobal(HttpHeaders requestHeaders, WorkdayConfig globalDto);

    //boolean deleteGlobal(HttpHeaders requestHeaders, Long id);
    //</editor-fold>

    //<editor-fold desc="group_mapping">
    List<GroupMappingDto> getAllGroupMappings(HttpHeaders requestHeaders);

    GroupMappingDto findGroupMappingById(HttpHeaders requestHeaders, Long id);

    GroupMappingDto findGroupMappingByName(HttpHeaders requestHeaders, String name);

    List<GroupMappingDto> findGroupMappingsByNames(HttpHeaders requestHeaders, Collection<String> names);

    List<GroupMappingDto> findGroupMappingsByOktaCns(HttpHeaders requestHeaders, Collection<String> oktaCns);

    List<GroupMappingDto> findGroupMappingsByType(HttpHeaders requestHeaders, GroupMappingType type);

    List<GroupMappingDto> findGroupMappingsByNameInAndType(HttpHeaders requestHeaders, GroupMappingRequest request);

    //GroupMappingDto saveGroupMapping(HttpHeaders requestHeaders, GroupMappingDto groupMappingDto);

    //boolean deleteGroupMapping(HttpHeaders requestHeaders, Long id);
    //</editor-fold>

    //<editor-fold desc="domains">
    List<DomainConfig> allDomainConfigs(HttpHeaders requestHeaders);

    DomainConfig findDomainConfig(HrbuConfig config);
    DomainConfig findDomainConfig(HttpHeaders requestHeaders, HrbuConfig config);

    DomainConfig findDomainConfigById(HttpHeaders requestHeaders, Long id);

    DomainConfig findDomainConfigByName(HttpHeaders requestHeaders, String name);

    DomainConfig findDomainConfigByOu(HttpHeaders requestHeaders, LdapName ou);

    //DomainConfig saveDomainConfig(HttpHeaders requestHeaders, DomainConfig domainsDto);

    //boolean deleteDomainConfig(HttpHeaders requestHeaders, Long id);
    //</editor-fold>

    //<editor-fold desc="hrbu">
    List<HrbuDto> getAllHrbu(HttpHeaders requestHeaders);

    //HrbuDto saveHrbu(HttpHeaders requestHeaders, HrbuDto hrbuDto);
    //</editor-fold>

    //<editor-fold desc="hrbu_city_street">
    List<HrbuCityStreetDto> getAllHrbuCityStreet(HttpHeaders requestHeaders);

    HrbuCityStreetDto findHrbuCityStreetById(HttpHeaders requestHeaders, Long id);

    //HrbuCityStreetDto saveHrbuCityStreet(HttpHeaders requestHeaders, HrbuCityStreetDto hrbuDto);

    //boolean deleteHrbuCityStreet(HttpHeaders requestHeaders, Long id);
    //</editor-fold>

    //<editor-fold desc="hrbu_view">
    List<HrbuConfig> findHrbuConfig(HttpHeaders requestHeaders, HrbuViewRequest request);
    List<HrbuConfig> findHrbuConfig(HttpHeaders requestHeaders, String hrbu, String city, String street);
    HrbuConfig findHrbuConfig(String hrbu, String city, String street);
    List<HrbuConfig> getAllHrbuConfigs(HttpHeaders requestHeaders);
    //</editor-fold>

}
