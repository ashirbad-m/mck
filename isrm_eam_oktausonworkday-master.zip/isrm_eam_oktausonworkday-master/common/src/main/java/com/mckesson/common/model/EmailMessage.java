package com.mckesson.common.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmailMessage {
    Set<String> to;
    String subject;
    String body;
    List<EmailMessageAttachment> attachments;
}

