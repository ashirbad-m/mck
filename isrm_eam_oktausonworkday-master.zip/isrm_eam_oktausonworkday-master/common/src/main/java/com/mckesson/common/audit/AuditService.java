package com.mckesson.common.audit;

import com.mckesson.common.model.AuditEvent;

/**
 * Audit service to handle audit evens
 */
public interface AuditService {
    /**
     * Handles audit events
     *
     * @param auditEvent audit events
     */
    void audit(AuditEvent auditEvent);
}
