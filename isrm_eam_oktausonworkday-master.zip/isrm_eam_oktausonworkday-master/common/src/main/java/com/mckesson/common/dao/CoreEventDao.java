package com.mckesson.common.dao;

import com.mckesson.common.model.CoreEvent;

public interface CoreEventDao {
    void create(CoreEvent event);

    void update(CoreEvent event);

    void delete(CoreEvent event);
}
