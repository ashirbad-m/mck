package com.mckesson.common.audit;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.model.ModuleEnum;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;

/**
 * Audit service implementation puts audit event to message broker
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class MessageBrokerAuditService implements AuditService {
    private final MessageBrokerPublisher messageBrokerPublisher;
    private final RetryTemplate retryTemplate;

    @Override
    public void audit(AuditEvent auditEvent) {
        retryTemplate.execute(context -> {
            log.debug("submit audit record: retryCount {}", context.getRetryCount());
            messageBrokerPublisher.send(ModuleEnum.AUDIT, auditEvent);
            return null;
        }, context -> {
            log.error("Cannot submit audit record after {} attempts", context.getRetryCount());
            return null;
        });
    }
}
