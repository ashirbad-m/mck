package com.mckesson.common.cloud.kafka;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.model.ModuleEnum;
import lombok.NonNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;

import java.io.Serializable;

public class KafkaPublisher extends AbstractKafkaPublisher implements MessageBrokerPublisher {
    @Value("${kafka.topic.prefix}")
    private String topic;

    public KafkaPublisher(@NonNull KafkaTemplate kafkaTemplate) {
        super(kafkaTemplate);
    }

    @Override
    public void send(ModuleEnum module, Serializable payload) {
        send(topic + "." + module.name(), payload);
        if (module != ModuleEnum.GATEWAY && module != ModuleEnum.FINALIZER) {
            send(topic + "." + ModuleEnum.ALL.name(), payload);
        }
    }

    protected void setTopic(String topic) {
        this.topic = topic;
    }
}
