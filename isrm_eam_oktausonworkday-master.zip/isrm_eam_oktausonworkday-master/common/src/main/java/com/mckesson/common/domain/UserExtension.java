package com.mckesson.common.domain;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.Accessors;
import lombok.experimental.FieldDefaults;

@Accessors(chain = true)
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserExtension {
    private static final String ORG_DEFAULT = "ORGANIZATION";
    private static final String MARKET_DEFAULT = "MARKET";
    private static final String DEPARTMENT_DEFAULT = "DEPARTMENT";
    private static final String MANAGER_DEFAULT = "MANAGER";
    private static final String GROUP_1 = "GROUP-1";
    private static final String GROUP_2 = "GROUP-2";
    private static final Set<String> GROUPS_DEFAULT = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(GROUP_1, GROUP_2)));
    private static final String INOU_DEFAULT = "INOU";
    private static final String WASOU_DEFAULT = "WASOU";
    private static final String ADMIN_ACCOUNT_DEFAULT = "ADMIN-ACCOUNT";
    private static final String SERVICE_ACCOUNT_1 = "SERVICE-ACCOUNT-1";
    private static final String SERVICE_ACCOUNT_2 = "SERVICE-ACCOUNT-2";
    private static final Set<String> SERVICE_ACCOUNTS_DEFAULT = Collections
            .unmodifiableSet(new HashSet<>(Arrays.asList(SERVICE_ACCOUNT_1, SERVICE_ACCOUNT_2)));
    private static final String SERVICE_ACCOUNT_MANAGER_DEFAULT = "SERVICE-ACCOUNT-MANAGER";
    private static final String OLD_GROUP_1 = "OLD-GROUP-1";
    private static final String OLD_GROUP_2 = "OLD-GROUP-2";
    private static final Set<String> OLD_GROUPS_DEFAULT = Collections
            .unmodifiableSet(new HashSet<>(Arrays.asList(OLD_GROUP_1, OLD_GROUP_2)));
    private static final String MANAGER_PHONE_DEFAULT = "MANAGER-PHONE";
    private static final String MANAGER_EMAIL_DEFAULT = "MANAGER-EMAIL";
    private static final String MANAGER_CELL_PHONE_DEFAULT = "MANAGER-CELL-PHONE";
    private static final String GROUP_DEFAULT = "DEFAULT_GROUP";

    public static UserExtension createFake() {
        final UserExtension ext = new UserExtension();
        ext.setOrganization(ORG_DEFAULT);
        ext.setMarket(MARKET_DEFAULT).setDepartment(DEPARTMENT_DEFAULT).setManager(MANAGER_DEFAULT).setGroups(GROUPS_DEFAULT)
                .setInOU(INOU_DEFAULT);
        ext.setWasOU(WASOU_DEFAULT).setAdminAccount(ADMIN_ACCOUNT_DEFAULT).setServiceAccounts(SERVICE_ACCOUNTS_DEFAULT)
                .setServiceAccountsManager(SERVICE_ACCOUNT_MANAGER_DEFAULT).setOldGroups(OLD_GROUPS_DEFAULT);
        ext.setManagerPhone(MANAGER_PHONE_DEFAULT).setManagerEmail(MANAGER_EMAIL_DEFAULT).setManagerCellPhone(MANAGER_CELL_PHONE_DEFAULT);
        ext.setGroup(GROUP_DEFAULT);
        return ext;
    }

    // for create-user
    String organization;
    String market;
    String department;
    String manager;
    Set<String> groups;
    String inOU;
    // for terminate-user
    String wasOU;
    String adminAccount;
    Set<String> serviceAccounts;
    String serviceAccountsManager;
    Set<String> oldGroups;
    // for account-expired
    String managerPhone;
    String managerEmail;
    String managerCellPhone;

    // for tasks
    String group;
    String incidentId;
}
