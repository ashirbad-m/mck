package com.mckesson.common.workday.converter;

import javax.persistence.AttributeConverter;
import java.util.Map;

import static com.mckesson.common.workday.converter.ConverterUtils.object2Json;
import static com.mckesson.common.workday.converter.ConverterUtils.json2NullSafeMap;

public class JsonMapConverter implements AttributeConverter<Map<String, Object>, String> {

    @Override
    public String convertToDatabaseColumn(Map<String, Object> stringStringMap) {
        return object2Json(stringStringMap, Map::isEmpty, null);
    }

    @Override
    public Map<String, Object> convertToEntityAttribute(String s) {
        return json2NullSafeMap(s);
    }
}
