package com.mckesson.common.workday.configuration.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;
import org.springframework.validation.annotation.Validated;

import javax.naming.ldap.LdapName;
import javax.validation.constraints.Size;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@FieldDefaults(level = AccessLevel.PROTECTED)
@ToString
@EqualsAndHashCode
@Validated
public abstract class AbstractHrbuDto {

    @Getter LdapName ou;

    @Size(max = 255)
    @Getter String homeDrive;

    @Size(max = 255)
    @Getter String homeDir;

    @Size(max = 255)
    @Getter String loginScript;

    @Getter Set<String> groups;

    @Getter Set<String> contractorGroups;

    @Getter Set<String> outsideWorkerGroups;

    @Getter Set<String> extGroups;

    @Getter boolean activeSync;

    @Size(max = 255)
    @Getter String itcMail;

}
