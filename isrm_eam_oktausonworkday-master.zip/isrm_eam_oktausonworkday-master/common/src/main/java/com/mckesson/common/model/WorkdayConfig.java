package com.mckesson.common.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.experimental.FieldDefaults;
import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.Size;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Value
@Builder(toBuilder = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@Validated
public class WorkdayConfig {

    private boolean containsIgnoreCase(Set<String> data, @NonNull String... values) {
        final Set<String> up =
            Stream.of(values)
            .filter(StringUtils::isNotBlank)
            .map(String::toUpperCase)
            .collect(Collectors.toSet());
        return Objects.requireNonNull(data)
            .stream()
            .filter(StringUtils::isNotBlank)
            .anyMatch(s-> up.contains(s.toUpperCase()));
    }

    Long id;

    Set<String> preventLoaJobCodes;

    Set<String> suppressHrbuTransfer;

    Set<String> suppressClinicalTransfer;

    @Size(max = 255)
    String mckessonHrbu;

    Set<String> texasHrbus;

    public boolean isNotifyOnAbsence(@NonNull String jobFamily) {
        final String prefix = jobFamily.split("-")[0] + ":";
        return Objects.requireNonNull(preventLoaJobCodes)
            .stream()
            .filter(StringUtils::isNotBlank)
            .noneMatch(s -> s.startsWith(prefix));
    }

    public boolean isHrbuChangeSuppressed(@NonNull String oldHrbu, @NonNull String newHrbu) {
        return containsIgnoreCase(suppressHrbuTransfer, oldHrbu, newHrbu);
    }

    public boolean isClinicalTransferSuppressed(@NonNull String oldCompanyId, @NonNull String newCompanyId) {
        return containsIgnoreCase(suppressClinicalTransfer, oldCompanyId, newCompanyId);
    }

    public boolean isTexasHrbu(@NonNull String hrbu) {
        return containsIgnoreCase(texasHrbus, hrbu);
    }

    public boolean isMcKessonHRBU (@NonNull String hrbu) {
        return hrbu.length() >= mckessonHrbu.length() && StringUtils.startsWithIgnoreCase(hrbu, mckessonHrbu);
    }
}
