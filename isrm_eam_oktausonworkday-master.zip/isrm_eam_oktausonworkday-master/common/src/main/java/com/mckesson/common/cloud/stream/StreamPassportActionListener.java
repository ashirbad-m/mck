package com.mckesson.common.cloud.stream;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.context.annotation.Profile;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.mckesson.common.PassportActionProcessor;
import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.workday.converter.ConverterUtils;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Profile("stream")
@ConditionalOnSingleCandidate(PassportActionProcessor.class)
@ConditionalOnProperty("module")
@RequiredArgsConstructor
public class StreamPassportActionListener {
    private final PassportActionProcessor actionProcessor;

    @StreamListener(target = Processor.INPUT, condition = "headers['module']==T(com.mckesson.common.model.ModuleEnum).${module}.name() && headers['class']=='com.mckesson.common.domain.PassportAction'")
    public void processPassportAction(@Payload PassportAction action) {
        log.debug("Incoming passport action: {}", ConverterUtils.writeValueAsString(action));
        actionProcessor.processAction(action);
    }
}
