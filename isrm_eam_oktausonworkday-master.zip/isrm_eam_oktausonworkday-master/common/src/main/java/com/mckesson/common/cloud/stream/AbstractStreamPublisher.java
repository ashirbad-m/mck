package com.mckesson.common.cloud.stream;

import com.mckesson.common.workday.converter.ConverterUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.integration.support.MessageBuilder;

import java.util.Map;

/**
 * Common stream publisher
 */
@Slf4j
public class AbstractStreamPublisher {

    private final Source source;

    public AbstractStreamPublisher(Source source) {
        this.source = source;
    }

    protected void send(Map<String, String> headers, Object payload) {
        MessageBuilder<Object> messageBuilder = MessageBuilder.withPayload(payload);

        for (Map.Entry<String, String> entry : headers.entrySet()) {
            messageBuilder.setHeader(entry.getKey(), entry.getValue());
        }
        log.debug("Send message headers: {}, payload: {}", headers, ConverterUtils.writeValueAsString(payload));
        if (!source.output().send(messageBuilder.build())) {
            log.error("Cannot send message headers: {}, payload: {}", headers, ConverterUtils.writeValueAsString(payload));
        }
    }

}
