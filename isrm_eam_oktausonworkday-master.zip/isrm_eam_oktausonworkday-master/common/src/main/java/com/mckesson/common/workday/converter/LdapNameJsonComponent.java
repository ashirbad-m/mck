package com.mckesson.common.workday.converter;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.springframework.boot.jackson.JsonComponent;

import javax.naming.ldap.LdapName;
import java.io.IOException;

import static com.mckesson.common.workday.converter.ConverterUtils.nullableLdapName;

@JsonComponent
public class LdapNameJsonComponent {

    public static class LdapNameSerializer extends JsonSerializer<LdapName> {

        @Override
        public void serialize(LdapName ldapName, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
            if (ldapName == null) {
                jsonGenerator.writeNull();
            } else {
                jsonGenerator.writeString(ldapName.toString());
            }
        }
    }

    public static class LdapNameDeserializer extends JsonDeserializer<LdapName> {

        @Override
        public LdapName deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
            return nullableLdapName(jsonParser.getCodec().readValue(jsonParser, String.class));
        }
    }

}
