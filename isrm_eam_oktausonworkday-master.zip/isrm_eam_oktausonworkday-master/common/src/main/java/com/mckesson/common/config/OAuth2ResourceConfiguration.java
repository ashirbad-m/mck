package com.mckesson.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;

/**
 * oAuth2 provider configuration
 */
@ConditionalOnClass(OAuth2ResourceServerConfigurer.class)
@Configuration
@EnableWebSecurity
public class OAuth2ResourceConfiguration extends WebSecurityConfigurerAdapter {

    @Value("${security.oauth2.resource.token-info-uri}")
    private String introspectionUri;
    @Value("${security.oauth2.client.client-id}")
    private String clientId;
    @Value("${security.oauth2.client.client-secret}")
    private String clientSecret;
    @Value("${security.oauth2.scope}")
    private String scope;

    public String getScope() {
        return scope;
    }

    /**
     * Configure http security
     * 1. exclude actuator from security check
     * 2. add access with oAuth token for other urls
     *
     * @param http the {@link HttpSecurity} to modify
     * @throws Exception
     */
    @Override
    public void configure(HttpSecurity http) throws Exception {
        http
                .authorizeRequests(configurer -> configurer
                        .antMatchers(HttpMethod.GET, "/actuator/**").permitAll()
                        .anyRequest().access("authenticated and hasAuthority('SCOPE_" + scope + "')")
                )
                .oauth2ResourceServer(oauth2 ->
                        oauth2.opaqueToken(token -> token.introspectionUri(introspectionUri).introspectionClientCredentials(clientId, clientSecret))
                );
    }
}
