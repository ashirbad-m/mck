package com.mckesson.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PowerShellResult {
    private boolean error;
    private String commandOutput;
    private boolean timeout;

    @Override
    public String toString() {
        return "PowerShellResult(error=" + error + ", timeout=" + timeout + ", commandOutput='\n" + commandOutput + "\n')";
    }
}
