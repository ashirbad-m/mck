package com.mckesson.common.rest;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.DefaultResponseErrorHandler;

import java.io.IOException;
import java.nio.charset.Charset;

@Slf4j
public class Slf4jExceptionHandler extends DefaultResponseErrorHandler {
    @Override
    public void handleError(final ClientHttpResponse response) throws IOException {
        final HttpStatus code = response.getStatusCode();
        log.error("Response error. code = {}, body:\n{}", code, IOUtils.toString(response.getBody(), Charset.defaultCharset()));
    }
}