package com.mckesson.common.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.apache.commons.lang3.exception.ExceptionUtils;

import java.util.UUID;

public interface PassportErrorSupport {
    void setFailed(boolean failed);

    void setError(PassportError error);

    @JsonIgnore
    default PassportError onError(Throwable th, ModuleEnum module, ScenarioEnum scenario, String stage) {
        setFailed(true);
        final PassportError error = new PassportError(UUID.randomUUID().toString(), ExceptionUtils.getStackTrace(th), module, scenario, stage);
        setError(error);
        return error;
    }
}
