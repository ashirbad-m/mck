package com.mckesson.common.cloud.kafka;

import com.mckesson.common.PassportActionProcessor;
import com.mckesson.common.domain.PassportAction;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@Profile("kafka")
@ConditionalOnSingleCandidate(PassportActionProcessor.class)
@ConditionalOnProperty("module")
@RequiredArgsConstructor
public class KafkaPassportActionListener {

    private final PassportActionProcessor actionProcessor;

    @KafkaListener(topics = "${kafka.topic.prefix}.${module}")
    public void processPassportAction(@Payload PassportAction action) {
        actionProcessor.processAction(action);
    }
}