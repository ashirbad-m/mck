$exportCommands = @("StartHttpListener", "sample1", "sample2", "quit") 

function StartHttpListener {
	param (
		# Port to listen
		[Parameter(Mandatory = $true, Position = 0)]
		[ValidateNotNullOrEmpty()]
		[int] $Port,

		# Base URL
		[Parameter(Mandatory = $false, Position = 1)]
		[String] $Url = ""
	)

	Process {
		Write-Verbose "Load complete"
		
		$ErrorActionPreference = "Stop"

		if ($Url.Length -gt 0 -and -not $Url.EndsWith('/')) {
			$Url += "/"
		}

		$listener = New-Object System.Net.HttpListener
		#		$prefix = "http://*:$Port/$Url" # require admin rights
		$prefix = "http://127.0.0.1:$Port/$Url"
		$listener.Prefixes.Add($prefix)
		$listener.AuthenticationSchemes = [System.Net.AuthenticationSchemes]::Basic 
		$stopped = $false

		try {
			$listener.Start()
			while (!$stopped) {
				$statusCode = 417
				$context = $listener.GetContext()
				$request = $context.Request
				# $request | Format-List * | Out-String | Write-Verbose

				if (!$request.IsAuthenticated) {
					# will never be executed
					$statusCode = 403
					$commandOutput = "Unauthorized"
				}
				else {
					if (IsAuthorized($context.User.Identity)) {
						$statusCode = 200
						$commandOutput = "Authorized"

						$command = $request.QueryString.Item("command")
						if ($Null -eq $command) {
							$command = "help"
						}

						if ($command -eq "quit") {
							$stopped = $true
							$statusCode = 200
							$commandOutput = "Service has been stopped"
							Write-Verbose $commandOutput
				}
						else {	
							if ($command -notin $exportCommands) {
								$statusCode = 417
								$commandOutput = "Unknown command: " + $command	
							}
							else {
								$exp = $request.QueryString.Item("params") -split "," -join " "
								if (ForwardCommand -Command $command -Params $exp ) {
									$statusCode = 200
									$commandOutput = "Processed"
								}
								else {
									$statusCode = 500
									$commandOutput = "Execution error: " + $command	
								}
							}
						}
					}
					else {
						$statusCode = 403
						$commandOutput = "Forbidden"
					}			
				}

				Write-Response -Response $context.Response -Body $commandOutput -StatusCode $statusCode
			}
		}
		finally {
			$listener.Stop()
		}
	}
}
function Write-Response {
	[CmdletBinding()]
	param (
		[Parameter(Mandatory = $true, Position = 0)]
		[System.Net.HttpListenerResponse] $Response, 
		[Parameter(Mandatory = $true, Position = 1)]
		[ValidateNotNullOrEmpty()] 
		[string] $Body, 
		[Parameter(Mandatory = $true, Position = 2)]
		[int] $StatusCode
	)
	Process {
		$Response.StatusCode = $StatusCode
		$buffer = [System.Text.Encoding]::UTF8.GetBytes($Body)
	
		$Response.ContentLength64 = $buffer.Length
		$output = $Response.OutputStream
		$output.Write($buffer, 0, $buffer.Length)
		$output.Close()	
	}
}

function IsAuthorized ($identity) {
	$name = $identity.Name
	$password = $identity.Password

	return  $name -eq "usr" -and $password -eq "pass"
}

function ForwardCommand($Command, $Params) {
	$exp = "$Command $Params"
	Write-Verbose "Executing: $exp"
	try {
		Invoke-Expression $exp -ErrorAction Stop
		return $true
	}
 catch {
		Write-Verbose $_
		return $false
	}
}

$modulePath = "ps-modules"

# function LoadModules() {
# 	Write-Verbose "Importing functions"

# 	$root = Join-Path -Path $PSScriptRoot -ChildPath $modulePath
# 	if (Test-Path -Path $root) {
# 		Write-Verbose "processing folder $root"
# 		$files = Get-ChildItem -Path $root -Filter *.ps1

# 		# dot source each file
# 		$files | where-Object { $_.name -NotLike '*.Tests.ps1' } | 
# 		ForEach-Object { Write-Verbose $_.name; . $_.FullName }
# 	}
# 	Export-ModuleMember -Function (Get-ChildItem -Path "$PSScriptRoot\$modulePath\*.ps1").basename
# }				
# LoadModules

. .\$modulePath\sample1.ps1
. .\$modulePath\sample2.ps1

function quit {
	Write-Verbose "Closing"
}

# Can be removed if 'FunctionsToExport' has been declared in manifest
Export-ModuleMember -Function $exportCommands
