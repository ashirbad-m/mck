package com.mckesson.exchange.service;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.audit.AuditService;
import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.ModuleEnum;
import com.mckesson.common.workday.configuration.controller.ConfigurationClient;
import com.mckesson.common.workday.configuration.dto.GroupMappingDto;
import com.mckesson.common.workday.configuration.dto.GroupMappingType;
import com.mckesson.common.workday.converter.ConverterUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

class ExchangeProcessorTest {
    private final MessageBrokerPublisher messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
    private final ExchangeService exchangeService = Mockito.mock(ExchangeService.class);
    private final AuditService auditService = Mockito.mock(AuditService.class);
    private final ConfigurationClient configurationClient = Mockito.mock(ConfigurationClient.class);

    @BeforeEach
    public void beforeEach() {
        reset(exchangeService, configurationClient, messageBrokerPublisher, auditService);
        doNothing().when(auditService).audit(any(AuditEvent.class));
    }

    @Test
    public void testLeaveOfAbsence() {
        PassportAction.PowerShellEventBody eventBody = new PassportAction.PowerShellEventBody("domain");
        eventBody.setAction("leaveOfAbsence");
        eventBody.setUserName("Domain\\SamAccountName");
        eventBody.setUserSamAccountName("SamAccountName");
        eventBody.setLdapHostName("LdapHostName");
        eventBody.setExchangeServers(new HashSet<>(Arrays.asList("exchangeServer1", "exchangeServer2")));
        eventBody.setEmailPrimary("EmailPrimary");

        eventBody.setLogon(true);
        eventBody.setMsExchRecipientTypeDetails(2_147_483_648L);
        process(eventBody);
        verify(exchangeService).setLogonHours(eq("domain"), eq(eventBody.getUserSamAccountName()), eq(eventBody.getLdapHostName()), eq(true), any());
        verify(exchangeService).manageMailbox(eq("domain"), eq("showInAddressListsRemote"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());

        reset(exchangeService);
        eventBody.setMsExchRecipientTypeDetails(0L);
        process(eventBody);
        verify(exchangeService).setLogonHours(eq("domain"), eq(eventBody.getUserSamAccountName()), eq(eventBody.getLdapHostName()), eq(true), any());
        verify(exchangeService).manageMailbox(eq("domain"), eq("showInAddressLists"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());


        eventBody.setLogon(false);
        eventBody.setMsExchRecipientTypeDetails(2_147_483_648L);
        process(eventBody);
        verify(exchangeService).setLogonHours(eq("domain"), eq(eventBody.getUserSamAccountName()), eq(eventBody.getLdapHostName()), eq(false), any());
        verify(exchangeService).manageMailbox(eq("domain"), eq("hideFromAddressListsRemote"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());

        reset(exchangeService);
        eventBody.setMsExchRecipientTypeDetails(0L);
        process(eventBody);
        verify(exchangeService).setLogonHours(eq("domain"), eq(eventBody.getUserSamAccountName()), eq(eventBody.getLdapHostName()), eq(false), any());
        verify(exchangeService).manageMailbox(eq("domain"), eq("hideFromAddressLists"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());

    }

    @Test
    public void testCreateMail() {
        PassportAction.PowerShellEventBody eventBody = new PassportAction.PowerShellEventBody("domain");
        eventBody.setAction("createMail");
        eventBody.setExchangeServers(new HashSet<>(Arrays.asList("exchangeServer1", "exchangeServer2")));
        eventBody.setUserName("UserName");
        eventBody.setEmailPrimary("EmailPrimary");
        eventBody.setUserHomeDirectory("UserHomeDirectory");
        eventBody.setLdapHostName("LdapHostName");
        eventBody.setEmailSecondary("EmailSecondary");
        eventBody.setEmailSecondaryAdditional(null);

        List<String> mails = Stream.of(eventBody.getEmailSecondary(), eventBody.getEmailSecondaryAdditional())
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        eventBody.setMsExchRecipientTypeDetails(2_147_483_648L);
        process(eventBody);
        verify(exchangeService).manageMailbox(eq("domain"), eq("enableRemote"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());
        verify(exchangeService).manageMailbox(eq("domain"), eq("setSecondaryEmailRemote"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(null), eq(mails), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());

        reset(exchangeService);
        eventBody.setMsExchRecipientTypeDetails(0L);
        process(eventBody);
        verify(exchangeService).manageMailbox(eq("domain"), eq("enable"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());
        verify(exchangeService).manageMailbox(eq("domain"), eq("setSecondaryEmail"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(null), eq(mails), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());
    }

    @Test
    public void testCreateHome() {
        PassportAction.PowerShellEventBody eventBody = new PassportAction.PowerShellEventBody("domain");
        eventBody.setAction("createHome");
        eventBody.setUserName("UserName");
        eventBody.setUserHomeDirectory("UserHomeDirectory");

        process(eventBody);
        verify(exchangeService).setupHomeDirectory(eq("domain"), eq(eventBody.getUserName()), eq(eventBody.getUserHomeDirectory()), any());
    }

    @Test
    public void testCreateMailAndHome() {
        PassportAction.PowerShellEventBody eventBody = new PassportAction.PowerShellEventBody("domain");
        eventBody.setAction("createMailAndHome");
        eventBody.setExchangeServers(new HashSet<>(Arrays.asList("exchangeServer1", "exchangeServer2")));
        eventBody.setUserName("UserName");
        eventBody.setEmailPrimary("EmailPrimary");
        eventBody.setUserHomeDirectory("UserHomeDirectory");
        eventBody.setLdapHostName("LdapHostName");
        eventBody.setEmailSecondary("EmailSecondary");
        eventBody.setEmailSecondaryAdditional(null);

        List<String> mails = Stream.of(eventBody.getEmailSecondary(), eventBody.getEmailSecondaryAdditional())
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        eventBody.setMsExchRecipientTypeDetails(2_147_483_648L);
        process(eventBody);
        verify(exchangeService).manageMailbox(eq("domain"), eq("enableRemote"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());
        verify(exchangeService).manageMailbox(eq("domain"), eq("setSecondaryEmailRemote"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(null), eq(mails), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());
        verify(exchangeService).setupHomeDirectory(eq("domain"), eq(eventBody.getUserName()), eq(eventBody.getUserHomeDirectory()), any());

        reset(exchangeService);
        eventBody.setMsExchRecipientTypeDetails(0L);
        process(eventBody);
        verify(exchangeService).manageMailbox(eq("domain"), eq("enable"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());
        verify(exchangeService).manageMailbox(eq("domain"), eq("setSecondaryEmail"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(null), eq(mails), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());
        verify(exchangeService).setupHomeDirectory(eq("domain"), eq(eventBody.getUserName()), eq(eventBody.getUserHomeDirectory()), any());
    }

    @Test
    public void testUpdateMail() {
        PassportAction.PowerShellEventBody eventBody = new PassportAction.PowerShellEventBody("domain");
        eventBody.setAction("updateMail");
        eventBody.setExchangeServers(new HashSet<>(Arrays.asList("exchangeServer1", "exchangeServer2")));
        eventBody.setUserName("UserName");
        eventBody.setEmailPrimary("EmailPrimary");
        eventBody.setLdapHostName("LdapHostName");
        eventBody.setEmailSecondary("EmailSecondary");
        eventBody.setEmailSecondaryAdditional(null);

        List<String> mails = Stream.of(eventBody.getEmailSecondary(), eventBody.getEmailSecondaryAdditional())
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        eventBody.setMsExchRecipientTypeDetails(2_147_483_648L);
        process(eventBody);
        verify(exchangeService).manageMailbox(eq("domain"), eq("setPrimaryEmailRemote"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());
        verify(exchangeService).manageMailbox(eq("domain"), eq("setSecondaryEmailRemote"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(null), eq(mails), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());

        reset(exchangeService);
        eventBody.setMsExchRecipientTypeDetails(0L);
        process(eventBody);
        verify(exchangeService).manageMailbox(eq("domain"), eq("setPrimaryEmail"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());
        verify(exchangeService).manageMailbox(eq("domain"), eq("setSecondaryEmail"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(null), eq(mails), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());
    }

    @Test
    public void testArchiveHomeAndDeleteTSP() {
        PassportAction.PowerShellEventBody eventBody = new PassportAction.PowerShellEventBody("domain");
        eventBody.setAction("archiveHomeAndDeleteTSP");
        eventBody.setUserHomeDirectory("UserHomeDirectory");
        eventBody.setUserArchivedHomeDirectory("UserArchivedHomeDirectory");
        eventBody.setUserSamAccountName("UserSamAccountName");
        eventBody.setUserName("UserName");
        eventBody.setDfsLinkName("profiles\\" + eventBody.getUserSamAccountName().charAt(0));
        eventBody.setDfsServers(new HashSet<>(Arrays.asList("dfsServer1", "dfsServer2")));

        String linkName = eventBody.getDfsLinkName();

        String archivedHomeDirectory = eventBody.getUserArchivedHomeDirectory();

        process(eventBody);
        verify(exchangeService).moveItem(eq("domain"), eq(eventBody.getUserHomeDirectory()), eq(archivedHomeDirectory), any());
        verify(exchangeService).deleteDfsDirectories(eq("domain"), eq(eventBody.getUserSamAccountName()), eq(linkName), eq(new ArrayList<>(eventBody.getDfsServers())), any());
    }

    @Test
    public void testTerminateMailAndASD() {

        PassportAction.PowerShellEventBody eventBody = new PassportAction.PowerShellEventBody("domain");
        eventBody.setAction("terminateMailAndASD");
        eventBody.setUserPrincipalName("UserPrincipalName");
        eventBody.setOffice365Url("Office365Url");
        eventBody.setLdapHostName("LdapHostName");
        eventBody.setExchangeServers(new HashSet<>(Arrays.asList("exchangeServer1", "exchangeServer2")));
        eventBody.setUserName("UserName");
        eventBody.setUserMailNickname("UserMailNickname");
        eventBody.setEmailPrimary("EmailPrimary");

        eventBody.setMsExchRecipientTypeDetails(2_147_483_648L);
        process(eventBody);
        verify(exchangeService).manageO365Mailbox(eq("domain"), eq("disableActiveSyncDeviceInO365"), eq(eventBody.getUserPrincipalName()), eq(eventBody.getOffice365Url()), eq(null), any());
        verify(exchangeService).manageMailbox(eq("domain"), eq("disableRemote"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());

        reset(exchangeService);
        eventBody.setMsExchRecipientTypeDetails(0L);
        process(eventBody);
        verify(exchangeService).manageMailbox(eq("domain"), eq("disableActiveSyncDevice"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(null), eq(null), eq(eventBody.getLdapHostName()), eq(eventBody.getUserMailNickname()), eq(null), any());
        verify(exchangeService).manageMailbox(eq("domain"), eq("disable"), eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null), eq(eventBody.getLdapHostName()), eq(null), eq(null), any());
    }

    @Test
    public void testSetCAS() {
        PassportAction.PowerShellEventBody eventBody = new PassportAction.PowerShellEventBody("domain");
        eventBody.setAction("setCAS");
        eventBody.setOffice365Url("Office365Url");
        eventBody.setOffice365CredentialsAddress("Office365CredentialsAddress");
        eventBody.setUserPrincipalName("UserPrincipalName");

        process(eventBody);
        verify(exchangeService).manageO365Mailbox(eq("domain"), eq("setCAS"), eq(eventBody.getUserPrincipalName()), eq(eventBody.getOffice365Url()), eq(eventBody.getOffice365CredentialsAddress()), any());
    }

    @Test
    void updateHrbu() {
        PassportAction.PowerShellEventBody eventBody = new PassportAction.PowerShellEventBody("domain");
        eventBody.setAction("updateHrbu");
        eventBody.setUserHomeDirectory("UserHomeDirectory");
        eventBody.setUserArchivedHomeDirectory("UserArchivedHomeDirectory");
        eventBody.setUserSamAccountName("UserSamAccountName");
        eventBody.setUserPrincipalName("UserPrincipalName");
        eventBody.setUserName("UserName");
        eventBody.setDfsLinkName("profiles\\" + eventBody.getUserSamAccountName().charAt(0));
        eventBody.setDfsServers(new HashSet<>(Arrays.asList("dfsServer1", "dfsServer2")));
        eventBody.setExchangeServers(new HashSet<>(Arrays.asList("exchangeServer1", "exchangeServer2")));

        String linkName = eventBody.getDfsLinkName();

        String archivedHomeDirectory = eventBody.getUserArchivedHomeDirectory();

        process(eventBody);
        verify(exchangeService).moveItem(eq("domain"), eq(eventBody.getUserHomeDirectory()), eq(archivedHomeDirectory), any());
        verify(exchangeService).deleteDfsDirectories(eq("domain"), eq(eventBody.getUserSamAccountName()), eq(linkName), eq(new ArrayList<>(eventBody.getDfsServers())), any());

        verify(exchangeService).manageMailbox(eq("domain"), eq("disableActiveSyncDevice"),
                eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(null), eq(null),
                eq(eventBody.getLdapHostName()), eq(eventBody.getUserMailNickname()), eq(null), any());

        var auditEvent = AuditEvent.generateEvent(eventBody)
                .module(ModuleEnum.EXCHANGE)
                .status("SUCCESS")
                .duration(Instant.now().getEpochSecond())
                .situation("passport.exchange.termination.disable-device")
                .newValues(ConverterUtils.writeValueAsString(eventBody))
                .message("Disabled active-sync device for: " + eventBody.getUserPrincipalName()).build();
        verify(auditService).audit(refEq(auditEvent, "date", "duration"));

        auditEvent = AuditEvent.generateEvent(eventBody)
                .module(ModuleEnum.EXCHANGE)
                .status("SUCCESS")
                .duration(Instant.now().getEpochSecond())
                .situation("passport.events.update-hrbu")
                .newValues(ConverterUtils.writeValueAsString(eventBody))
                .message("HRBU has been updated for:" + eventBody.getUserName()).build();
        verify(auditService).audit(refEq(auditEvent, "date", "duration"));

        verify(exchangeService).manageMailbox(eq("domain"), eq("disable"),
                eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null),
                eq(eventBody.getLdapHostName()), eq(null), eq(null), any());
        auditEvent = AuditEvent.generateEvent(eventBody)
                .module(ModuleEnum.EXCHANGE)
                .status("SUCCESS")
                .duration(Instant.now().getEpochSecond())
                .situation("passport.exchange.termination.disable-device")
                .newValues(ConverterUtils.writeValueAsString(eventBody))
                .message("Disabled mailbox for: " + eventBody.getUserName()).build();
        verify(auditService).audit(refEq(auditEvent, "date", "duration"));


        Mockito.reset(exchangeService, auditService);
        eventBody.setMsExchRecipientTypeDetails(2_147_483_648L);//isO365Mailbox
        process(eventBody);
        verify(exchangeService).moveItem(eq("domain"), eq(eventBody.getUserHomeDirectory()), eq(archivedHomeDirectory), any());
        verify(exchangeService).deleteDfsDirectories(eq("domain"), eq(eventBody.getUserSamAccountName()), eq(linkName), eq(new ArrayList<>(eventBody.getDfsServers())), any());

        verify(exchangeService).manageO365Mailbox(eq("domain"), eq("disableActiveSyncDeviceInO365"),
                eq(eventBody.getUserPrincipalName()), eq(eventBody.getOffice365Url()), eq(null), any());

        auditEvent = AuditEvent.generateEvent(eventBody)
                .module(ModuleEnum.EXCHANGE)
                .status("SUCCESS")
                .duration(Instant.now().getEpochSecond())
                .situation("passport.exchange.termination.disable-o365-device")
                .newValues(ConverterUtils.writeValueAsString(eventBody))
                .message("Disabled active-sync device in o365 for: " + eventBody.getUserPrincipalName()).build();
        verify(auditService).audit(refEq(auditEvent, "date", "duration"));

        auditEvent = AuditEvent.generateEvent(eventBody)
                .module(ModuleEnum.EXCHANGE)
                .status("SUCCESS")
                .duration(Instant.now().getEpochSecond())
                .situation("passport.events.update-hrbu")
                .newValues(ConverterUtils.writeValueAsString(eventBody))
                .message("HRBU has been updated for:" + eventBody.getUserName()).build();
        verify(auditService).audit(refEq(auditEvent, "date", "duration"));

        verify(exchangeService).manageMailbox(eq("domain"), eq("disableRemote"),
                eq(eventBody.getExchangeServers()), eq(eventBody.getUserName()), eq(eventBody.getEmailPrimary()), eq(null),
                eq(eventBody.getLdapHostName()), eq(null), eq(null), any());
        auditEvent = AuditEvent.generateEvent(eventBody)
                .module(ModuleEnum.EXCHANGE)
                .status("SUCCESS")
                .duration(Instant.now().getEpochSecond())
                .situation("passport.exchange.termination.disable-device")
                .newValues(ConverterUtils.writeValueAsString(eventBody))
                .message("Disabled o365 mailbox for: " + eventBody.getUserName()).build();
        verify(auditService).audit(refEq(auditEvent, "date", "duration"));
    }

    @Test
    void modifyGroupMembership() throws InvalidNameException {
        PassportAction.PowerShellEventBody eventBody = new PassportAction.PowerShellEventBody("domain");
        eventBody.setAction("modifyGroupMembership");
        var groupMembershipEventBody = new PassportAction.GroupMembershipEventBody(new LdapName("CN=group1,OU=Test1,DC=mshusontest,DC=com"));
        groupMembershipEventBody.setUserDn(new LdapName("CN=user1,OU=Test1,DC=mshusontest,DC=com"));
        groupMembershipEventBody.setOktaCnsToAdd(Set.of("oktaCnToAdd"));
        groupMembershipEventBody.setOktaCnsToRemove(Set.of("oktaCnToRemove"));
        eventBody.setGroupMembershipEventBody(groupMembershipEventBody);

        when(configurationClient.allDomainConfigs()).thenReturn(Collections.emptyList());
        process(eventBody);
        var auditEvent = AuditEvent.generateEvent(eventBody)
                .module(ModuleEnum.EXCHANGE)
                .status("SUCCESS")
                .duration(Instant.now().getEpochSecond())
                .situation("passport.exchange.error")
                .newValues(ConverterUtils.writeValueAsString(eventBody))
                .status("ERROR").message("Unexpected error: Domain Configurations not found")
                .build();
        verify(auditService).audit(refEq(auditEvent, "date", "newValues", "oldValues"));

        Mockito.reset(configurationClient, exchangeService, auditService);
        var domainConfig1 = DomainConfig.builder()
                .rootOu(new LdapName("OU=Test1,DC=mshusontest,DC=com"))
                .ldapHostName("LdapHostName1")
                .build();
        var domainConfig2 = DomainConfig.builder()
                .rootOu(new LdapName("OU=Test2,DC=mshusontest,DC=com"))
                .ldapHostName("LdapHostName2")
                .build();
        when(configurationClient.allDomainConfigs()).thenReturn(List.of(domainConfig1, domainConfig2));
        PassportAction.AdsiInfo userInfo = new PassportAction.AdsiInfo(groupMembershipEventBody.getUserDn(), domainConfig1.getLdapHostName());

        when(configurationClient.findGroupMappingsByOktaCns(eq(groupMembershipEventBody.getOktaCnsToAdd()))).thenReturn(List.of());
        when(configurationClient.findGroupMappingsByOktaCns(eq(groupMembershipEventBody.getOktaCnsToRemove()))).thenReturn(List.of());
        process(eventBody);
        verify(exchangeService, never()).modifyGroupMembership(eq(eventBody.getDomain()), eq(userInfo.getDn()), eq(userInfo.getServer()), any(), any(), any());
        verify(auditService, never()).audit(any());


        reset(exchangeService, auditService);
        var groupMappingDto21 = GroupMappingDto.builder().id(315L)
                .name(UUID.randomUUID().toString())
                .dn(new LdapName("CN=group1,OU=Test2,DC=mshusontest,DC=com"))
                .type(GroupMappingType.DEFAULT)
                .build();
        var groupMappingDto22 = GroupMappingDto.builder().id(315L)
                .name(UUID.randomUUID().toString())
                .dn(new LdapName("CN=group2,OU=Test2,DC=mshusontest,DC=com"))
                .type(GroupMappingType.DEFAULT)
                .build();
        when(configurationClient.findGroupMappingsByOktaCns(eq(groupMembershipEventBody.getOktaCnsToAdd()))).thenReturn(List.of(groupMappingDto21));
        when(configurationClient.findGroupMappingsByOktaCns(eq(groupMembershipEventBody.getOktaCnsToRemove()))).thenReturn(List.of(groupMappingDto22));

        process(eventBody);
        List<PassportAction.AdsiInfo> groupsToAdd = List.of(new PassportAction.AdsiInfo(groupMappingDto21.getDn(), domainConfig2.getLdapHostName()));
        List<PassportAction.AdsiInfo> groupsToRemove = List.of(new PassportAction.AdsiInfo(groupMappingDto22.getDn(), domainConfig2.getLdapHostName()));

        verify(exchangeService).modifyGroupMembership(eq(eventBody.getDomain()), eq(userInfo.getDn()), eq(userInfo.getServer()), eq(groupsToAdd), eq(groupsToRemove), any());
        auditEvent = AuditEvent.generateEvent(eventBody)
                .module(ModuleEnum.EXCHANGE)
                .status("SUCCESS")
                .duration(Instant.now().getEpochSecond())
                .situation("passport.exchange.active-directory.modify-group-membership")
                .newValues(ConverterUtils.writeValueAsString(eventBody))
                .message("modifyGroupMembership for: " + userInfo.getDn().getRdn(userInfo.getDn().size() - 1))
                .oldValues(ConverterUtils.writeValueAsString(groupsToRemove))
                .newValues(ConverterUtils.writeValueAsString(groupsToAdd))
                .build();
        verify(auditService).audit(refEq(auditEvent, "date", "duration"));
    }

    private void process(PassportAction.PowerShellEventBody eventBody) {
        PassportAction passportAction = new PassportAction();
        passportAction.setEventType(PassportAction.EventTypeEnum.POWERSHELL);
        passportAction.setEventBody(ConverterUtils.writeValueAsString(eventBody));

        try {
            new ExchangeProcessor(messageBrokerPublisher, exchangeService, auditService, configurationClient).processActionInternal(passportAction).get();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}