package com.mckesson.exchange.service;

import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.PowerShellResult;
import com.mckesson.common.rest.OAuth2RestClient;
import com.mckesson.common.workday.converter.ConverterUtils;
import com.mckesson.exchange.config.PowerShellDomainConfiguration;
import com.mckesson.exchange.config.PowerShellServer;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

class ExchangeServiceTest {

    private Consumer<Exception> onError = (ex) -> {
    };

    private void testMethod(String domain, String path, HttpMethod method, MultiValueMap<String, Object> params, Function<ExchangeService, PowerShellResult> call) {
        String accessTokenUri = UUID.randomUUID().toString();
        String clientId = UUID.randomUUID().toString();
        String clientSecret = UUID.randomUUID().toString();
        String scope = UUID.randomUUID().toString();
        int connectTimeout = 3000;

        var node1 = new PowerShellServer();
        node1.setEnabled(true);
        node1.setDomain(domain);
        node1.setUrl("https://host1/");
        var configuration = new PowerShellDomainConfiguration();
        configuration.setNodes(List.of(node1));

        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);

        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);

        var instance = new ExchangeService(configuration, restTemplateBuilder,
                accessTokenUri, clientId, clientSecret, scope, connectTimeout,
                new RetryTemplate());

        var tokenResponse = new OAuth2RestClient.Oauth2Response();
        tokenResponse.setAccessToken(UUID.randomUUID().toString());
        tokenResponse.setExpiresIn(100);//TODO

        Mockito.when(restTemplate.exchange(Mockito.eq(accessTokenUri), Mockito.eq(HttpMethod.POST), Mockito.any(HttpEntity.class),
                        Mockito.eq(OAuth2RestClient.Oauth2Response.class), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(tokenResponse));

        var requestUuid = UUID.randomUUID().toString();
        Mockito.when(restTemplate.exchange(Mockito.eq(node1.getUrl() + path), Mockito.eq(method), Mockito.any(HttpEntity.class),
                        Mockito.eq(String.class), Mockito.eq(Collections.emptyMap())))
                .thenReturn(ResponseEntity.ok(requestUuid));

        var uriVariables = Map.of("uuid", requestUuid);
        Mockito.when(restTemplate.exchange(Mockito.eq(node1.getUrl() + "ps/request/{uuid}"), Mockito.eq(HttpMethod.HEAD), Mockito.any(HttpEntity.class),
                        Mockito.eq(String.class), Mockito.eq(uriVariables)))
                .thenReturn(ResponseEntity.noContent().build());

        var expected = new PowerShellResult(false, "test", false);
        Mockito.when(restTemplate.exchange(Mockito.eq(node1.getUrl() + "ps/request/{uuid}"), Mockito.eq(HttpMethod.GET), Mockito.any(HttpEntity.class),
                        Mockito.eq(PowerShellResult.class), Mockito.eq(uriVariables)))
                .thenReturn(ResponseEntity.ok(expected));

        //restTemplate.exchange(node1.getUrl() + "ps/request/{uuid}", HttpMethod.HEAD, new HttpEntity(), PowerShellResult.class, Map.of("uuid", requestUuid))
        Assertions.assertEquals(expected, call.apply(instance));
    }

    @Test
    void getHost() {
        var domain = UUID.randomUUID().toString();
        testMethod(domain, "ps/get-host", HttpMethod.GET, null, (service) -> service.getHost(domain, onError));
    }

    @Test
    void version() {
        var domain = UUID.randomUUID().toString();
        testMethod(domain, "ps/version", HttpMethod.POST, null, (service) -> service.version(domain, onError));
    }

    @Test
    void getRecipient() {
        var domain = UUID.randomUUID().toString();
        var userName = UUID.randomUUID().toString();
        var server = UUID.randomUUID().toString();
        var exchangeServers = List.of(UUID.randomUUID().toString());

        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("userName", userName);
        params.addAll("exchangeServers", exchangeServers);
        params.add("server", server);
        testMethod(domain, "ps/get-recipient", HttpMethod.POST, params,
                (service) -> service.getRecipient(domain, userName, exchangeServers, server, onError));
    }

    @Test
    void deleteDfsDirectories() {
        var domain = UUID.randomUUID().toString();
        var userName = UUID.randomUUID().toString();
        var linkName = UUID.randomUUID().toString();
        var computerNames = List.of(UUID.randomUUID().toString());

        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("userName", userName);
        params.add("linkName", linkName);
        params.addAll("computerNames", computerNames);
        testMethod(domain, "ps/delete-dfs-directories", HttpMethod.POST, params,
                (service) -> service.deleteDfsDirectories(domain, userName, linkName, computerNames, onError));
    }

    @Test
    void listDfsDirectories() {
        var domain = UUID.randomUUID().toString();
        var userName = UUID.randomUUID().toString();
        var linkName = UUID.randomUUID().toString();
        var computerNames = List.of(UUID.randomUUID().toString());

        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("userName", userName);
        params.add("linkName", linkName);
        params.addAll("computerNames", computerNames);
        testMethod(domain, "ps/list-dfs-directories", HttpMethod.POST, params,
                (service) -> service.listDfsDirectories(domain, userName, linkName, computerNames, onError));
    }

    @Test
    void manageMailbox() {
        var domain = UUID.randomUUID().toString();
        var action = UUID.randomUUID().toString();
        var userName = UUID.randomUUID().toString();
        var mail = UUID.randomUUID().toString();
        var server = UUID.randomUUID().toString();
        var mailNickname = UUID.randomUUID().toString();
        var office365AddressSuffix = UUID.randomUUID().toString();
        var exchangeServers = List.of(UUID.randomUUID().toString());
        var mails = List.of(UUID.randomUUID().toString());

        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("office365AddressSuffix", office365AddressSuffix);
        params.addAll("exchangeServers", exchangeServers);
        params.add("action", action);
        params.add("userName", userName);
        params.add("mailNickname", mailNickname);
        params.add("mail", mail);
        params.addAll("mails", mails);
        params.add("server", server);
        testMethod(domain, "ps/manage-mailbox", HttpMethod.POST, params,
                (service) -> service.manageMailbox(domain, action, exchangeServers, userName, mail, mails, server, mailNickname, office365AddressSuffix, onError));
    }

    @Test
    void manageO365Mailbox() {
        var domain = UUID.randomUUID().toString();
        var url = UUID.randomUUID().toString();
        var credentialAddress = UUID.randomUUID().toString();
        var action = UUID.randomUUID().toString();
        var userPrincipalName = UUID.randomUUID().toString();

        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("url", url);
        params.add("credentialAddress", credentialAddress);
        params.add("action", action);
        params.add("userPrincipalName", userPrincipalName);
        testMethod(domain, "ps/manage-o365-mailbox", HttpMethod.POST, params,
                (service) -> service.manageO365Mailbox(domain, action, userPrincipalName, url, credentialAddress, onError));
    }

    @Test
    void modifyGroupMembership() throws InvalidNameException {
        var domain = UUID.randomUUID().toString();
        var user = new LdapName("CN=user1,OU=Test1,DC=mshusontest,DC=com");
        var server = UUID.randomUUID().toString();
        var groupsToAdd = List.of(new PassportAction.AdsiInfo(new LdapName("CN=group1,OU=Test2,DC=mshusontest,DC=com"), "LdapHostName"));
        var groupsToRemove = List.of(new PassportAction.AdsiInfo(new LdapName("CN=group2,OU=Test2,DC=mshusontest,DC=com"), "LdapHostName"));

        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("user", user);
        params.add("server", server);
        params.add("groupsToAdd", ConverterUtils.writeValueAsString(groupsToAdd));
        params.add("groupsToRemove", ConverterUtils.writeValueAsString(groupsToRemove));
        testMethod(domain, "ps/modify-group-membership", HttpMethod.POST, params,
                (service) -> service.modifyGroupMembership(domain, user, server, groupsToAdd, groupsToRemove, onError));
    }

    @Test
    void moveItem() {
        var domain = UUID.randomUUID().toString();
        var source = UUID.randomUUID().toString();
        var target = UUID.randomUUID().toString();

        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("source", source);
        params.add("target", target);
        testMethod(domain, "ps/move-item", HttpMethod.POST, params,
                (service) -> service.moveItem(domain, source, target, onError));
    }


    @Test
    void changeName() {
        var domain = UUID.randomUUID().toString();
        var distinguishedName = UUID.randomUUID().toString();
        var newName = UUID.randomUUID().toString();
        var server = UUID.randomUUID().toString();

        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("identity", distinguishedName);
        params.add("newName", newName);
        params.add("server", server);
        testMethod(domain, "ps/change-name", HttpMethod.POST, params,
                (service) -> service.changeName(domain, distinguishedName, newName, server, onError));
    }

    @Test
    void setLogonHours() {
        var domain = UUID.randomUUID().toString();
        var identity = UUID.randomUUID().toString();
        var server = UUID.randomUUID().toString();
        var logon = true;

        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("identity", identity);
        params.add("server", server);
        params.add("logon", logon);
        testMethod(domain, "ps/set-logon-hours", HttpMethod.POST, params,
                (service) -> service.setLogonHours(domain, identity, server, logon, onError));
    }


    @Test
    void setupHomeDirectory() {
        var domain = UUID.randomUUID().toString();
        var userName = UUID.randomUUID().toString();
        var target = UUID.randomUUID().toString();

        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("userName", userName);
        params.add("target", target);
        testMethod(domain, "ps/setup-home-directory", HttpMethod.POST, params,
                (service) -> service.setupHomeDirectory(domain, userName, target, onError));
    }
}