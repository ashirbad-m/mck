package com.mckesson.exchange.rest;

import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.PowerShellResult;
import com.mckesson.exchange.service.ExchangeProcessor;
import com.mckesson.exchange.service.ExchangeService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.stubbing.Answer;
import org.springframework.http.HttpStatus;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

class ExchangeControllerTest {

    private final ExchangeService exchangeService = Mockito.mock(ExchangeService.class);
    private final ExchangeProcessor exchangeProcessor = Mockito.mock(ExchangeProcessor.class);

    @BeforeEach
    void setUp() {
        Mockito.reset(exchangeService, exchangeProcessor);
    }

    @Test
    void processAction() {
        var instance = new ExchangeController(exchangeService, exchangeProcessor);

        var task = Mockito.mock(PassportAction.class);
        var actual = instance.processAction(task);

        Assertions.assertEquals(HttpStatus.OK, actual.getStatusCode());
        Mockito.verify(exchangeProcessor).processAction(Mockito.eq(task));
        Mockito.verifyNoMoreInteractions(exchangeService, exchangeProcessor);
    }


    @Test
    void getHost() {
        var instance = new ExchangeController(exchangeService, exchangeProcessor);

        var domain = UUID.randomUUID().toString();
        var expected = new PowerShellResult(false, "test", false);
        Mockito.when(exchangeService.getHost(Mockito.eq(domain), Mockito.any()))
                //.thenReturn(expected);
                .thenAnswer((Answer<PowerShellResult>) invocation -> {
                    ((Consumer<Exception>) invocation.getArgument(1)).accept(new RuntimeException());
                    return expected;
                });

        Assertions.assertEquals(expected, instance.getHost(domain));
        Mockito.verify(exchangeService).getHost(Mockito.eq(domain), Mockito.any());
        Mockito.verifyNoMoreInteractions(exchangeService, exchangeProcessor);
    }

    @Test
    void deleteDfsDirectories() {
        var instance = new ExchangeController(exchangeService, exchangeProcessor);

        var domain = UUID.randomUUID().toString();
        var userName = UUID.randomUUID().toString();
        var linkName = UUID.randomUUID().toString();
        var computerNames = List.of(UUID.randomUUID().toString());
        var expected = new PowerShellResult(false, "test", false);
        Mockito.when(exchangeService.deleteDfsDirectories(Mockito.eq(domain), Mockito.eq(userName), Mockito.eq(linkName), Mockito.eq(computerNames), Mockito.any()))
                //.thenReturn(expected);
                .thenAnswer((Answer<PowerShellResult>) invocation -> {
                    ((Consumer<Exception>) invocation.getArgument(4)).accept(new RuntimeException());
                    return expected;
                });

        Assertions.assertEquals(expected, instance.deleteDfsDirectories(domain, userName, linkName, computerNames));
        Mockito.verify(exchangeService).deleteDfsDirectories(Mockito.eq(domain), Mockito.eq(userName), Mockito.eq(linkName), Mockito.eq(computerNames), Mockito.any());
        Mockito.verifyNoMoreInteractions(exchangeService, exchangeProcessor);
    }

    @Test
    void listDfsDirectories() {
        var instance = new ExchangeController(exchangeService, exchangeProcessor);

        var domain = UUID.randomUUID().toString();
        var userName = UUID.randomUUID().toString();
        var linkName = UUID.randomUUID().toString();
        var computerNames = List.of(UUID.randomUUID().toString());
        var expected = new PowerShellResult(false, "test", false);
        Mockito.when(exchangeService.listDfsDirectories(Mockito.eq(domain), Mockito.eq(userName), Mockito.eq(linkName), Mockito.eq(computerNames), Mockito.any()))
                //.thenReturn(expected);
                .thenAnswer((Answer<PowerShellResult>) invocation -> {
                    ((Consumer<Exception>) invocation.getArgument(4)).accept(new RuntimeException());
                    return expected;
                });

        Assertions.assertEquals(expected, instance.listDfsDirectories(domain, userName, linkName, computerNames));
        Mockito.verify(exchangeService).listDfsDirectories(Mockito.eq(domain), Mockito.eq(userName), Mockito.eq(linkName), Mockito.eq(computerNames), Mockito.any());
        Mockito.verifyNoMoreInteractions(exchangeService, exchangeProcessor);
    }

    @Test
    void manageMailbox() {
        var instance = new ExchangeController(exchangeService, exchangeProcessor);

        var domain = UUID.randomUUID().toString();
        var userName = UUID.randomUUID().toString();
        var action = UUID.randomUUID().toString();
        var exchangeServers = List.of(UUID.randomUUID().toString());
        var mail = UUID.randomUUID().toString();
        var mails = List.of(UUID.randomUUID().toString());
        var server = UUID.randomUUID().toString();
        var mailNickname = UUID.randomUUID().toString();
        var office365AddressSuffix = UUID.randomUUID().toString();
        var expected = new PowerShellResult(false, "test", false);
        Mockito.when(exchangeService.manageMailbox(Mockito.eq(domain), Mockito.eq(action), Mockito.eq(exchangeServers), Mockito.eq(userName),
                        Mockito.eq(mail), Mockito.eq(mails), Mockito.eq(server), Mockito.eq(mailNickname), Mockito.eq(office365AddressSuffix), Mockito.any()))
                //.thenReturn(expected);
                .thenAnswer((Answer<PowerShellResult>) invocation -> {
                    ((Consumer<Exception>) invocation.getArgument(9)).accept(new RuntimeException());
                    return expected;
                });

        Assertions.assertEquals(expected, instance.manageMailbox(domain, office365AddressSuffix, exchangeServers, action, userName, mailNickname, mail, mails, server));
        Mockito.verify(exchangeService).manageMailbox(Mockito.eq(domain), Mockito.eq(action), Mockito.eq(exchangeServers), Mockito.eq(userName),
                Mockito.eq(mail), Mockito.eq(mails), Mockito.eq(server), Mockito.eq(mailNickname), Mockito.eq(office365AddressSuffix), Mockito.any());
        Mockito.verifyNoMoreInteractions(exchangeService, exchangeProcessor);
    }

    @Test
    void manageO365Mailbox() {
        var instance = new ExchangeController(exchangeService, exchangeProcessor);

        var domain = UUID.randomUUID().toString();
        var url = UUID.randomUUID().toString();
        var credentialAddress = UUID.randomUUID().toString();
        var action = UUID.randomUUID().toString();
        var userPrincipalName = UUID.randomUUID().toString();
        var expected = new PowerShellResult(false, "test", false);
        Mockito.when(exchangeService.manageO365Mailbox(Mockito.eq(domain), Mockito.eq(action), Mockito.eq(userPrincipalName), Mockito.eq(url),
                        Mockito.eq(credentialAddress), Mockito.any()))
                //.thenReturn(expected);
                .thenAnswer((Answer<PowerShellResult>) invocation -> {
                    ((Consumer<Exception>) invocation.getArgument(5)).accept(new RuntimeException());
                    return expected;
                });

        Assertions.assertEquals(expected, instance.manageO365Mailbox(domain, url, credentialAddress, action, userPrincipalName));
        Mockito.verify(exchangeService).manageO365Mailbox(Mockito.eq(domain), Mockito.eq(action), Mockito.eq(userPrincipalName),
                Mockito.eq(url), Mockito.eq(credentialAddress), Mockito.any());
        Mockito.verifyNoMoreInteractions(exchangeService, exchangeProcessor);
    }

    @Test
    void modifyGroupMembership() throws InvalidNameException {
        var instance = new ExchangeController(exchangeService, exchangeProcessor);

        var domain = UUID.randomUUID().toString();
        var user = new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com");
        var server = UUID.randomUUID().toString();
        var groupToAdd = new PassportAction.AdsiInfo(new LdapName("CN=group1,OU=Test,DC=mshusontest,DC=com"), UUID.randomUUID().toString());
        var groupsToAdd = List.of(groupToAdd);
        var groupToRemove = new PassportAction.AdsiInfo(new LdapName("CN=group2,OU=Test,DC=mshusontest,DC=com"), UUID.randomUUID().toString());
        var groupsToRemove = List.of(groupToRemove);
        var expected = new PowerShellResult(false, "test", false);
        Mockito.when(exchangeService.modifyGroupMembership(Mockito.eq(domain), Mockito.eq(user), Mockito.eq(server), Mockito.eq(groupsToAdd),
                        Mockito.eq(groupsToRemove), Mockito.any()))
                //.thenReturn(expected);
                .thenAnswer((Answer<PowerShellResult>) invocation -> {
                    ((Consumer<Exception>) invocation.getArgument(5)).accept(new RuntimeException());
                    return expected;
                });

        Assertions.assertEquals(expected, instance.modifyGroupMembership(domain, user, server, groupsToAdd, groupsToRemove));
        Mockito.verify(exchangeService).modifyGroupMembership(Mockito.eq(domain), Mockito.eq(user), Mockito.eq(server),
                Mockito.eq(groupsToAdd), Mockito.eq(groupsToRemove), Mockito.any());
        Mockito.verifyNoMoreInteractions(exchangeService, exchangeProcessor);
    }

    @Test
    void moveItem() {
        var instance = new ExchangeController(exchangeService, exchangeProcessor);

        var domain = UUID.randomUUID().toString();
        var source = UUID.randomUUID().toString();
        var target = UUID.randomUUID().toString();
        var expected = new PowerShellResult(false, "test", false);
        Mockito.when(exchangeService.moveItem(Mockito.eq(domain), Mockito.eq(source), Mockito.eq(target), Mockito.any()))
                //.thenReturn(expected);
                .thenAnswer((Answer<PowerShellResult>) invocation -> {
                    ((Consumer<Exception>) invocation.getArgument(3)).accept(new RuntimeException());
                    return expected;
                });

        Assertions.assertEquals(expected, instance.moveItem(domain, source, target));
        Mockito.verify(exchangeService).moveItem(Mockito.eq(domain), Mockito.eq(source), Mockito.eq(target), Mockito.any());
        Mockito.verifyNoMoreInteractions(exchangeService, exchangeProcessor);
    }

    @Test
    void changeName() {
        var instance = new ExchangeController(exchangeService, exchangeProcessor);

        var domain = UUID.randomUUID().toString();
        var distinguishedName = UUID.randomUUID().toString();
        var newName = UUID.randomUUID().toString();
        var server = UUID.randomUUID().toString();
        var expected = new PowerShellResult(false, "test", false);
        Mockito.when(exchangeService.changeName(Mockito.eq(domain), Mockito.eq(distinguishedName), Mockito.eq(newName), Mockito.eq(server), Mockito.any()))
                //.thenReturn(expected);
                .thenAnswer((Answer<PowerShellResult>) invocation -> {
                    ((Consumer<Exception>) invocation.getArgument(4)).accept(new RuntimeException());
                    return expected;
                });

        Assertions.assertEquals(expected, instance.changeName(domain, distinguishedName, newName, server));
        Mockito.verify(exchangeService).changeName(Mockito.eq(domain), Mockito.eq(distinguishedName), Mockito.eq(newName), Mockito.eq(server), Mockito.any());
        Mockito.verifyNoMoreInteractions(exchangeService, exchangeProcessor);
    }

    @Test
    void setLogonHours() {
        var instance = new ExchangeController(exchangeService, exchangeProcessor);

        var domain = UUID.randomUUID().toString();
        var identity = UUID.randomUUID().toString();
        var server = UUID.randomUUID().toString();
        var logon = true;
        var expected = new PowerShellResult(false, "test", false);
        Mockito.when(exchangeService.setLogonHours(Mockito.eq(domain), Mockito.eq(identity), Mockito.eq(server), Mockito.eq(logon), Mockito.any()))
                //.thenReturn(expected);
                .thenAnswer((Answer<PowerShellResult>) invocation -> {
                    ((Consumer<Exception>) invocation.getArgument(4)).accept(new RuntimeException());
                    return expected;
                });

        Assertions.assertEquals(expected, instance.setLogonHours(domain, identity, server, logon));
        Mockito.verify(exchangeService).setLogonHours(Mockito.eq(domain), Mockito.eq(identity), Mockito.eq(server), Mockito.eq(logon), Mockito.any());
        Mockito.verifyNoMoreInteractions(exchangeService, exchangeProcessor);
    }

    @Test
    void setupHomeDirectory() {
        var instance = new ExchangeController(exchangeService, exchangeProcessor);

        var domain = UUID.randomUUID().toString();
        var userName = UUID.randomUUID().toString();
        var target = UUID.randomUUID().toString();
        var expected = new PowerShellResult(false, "test", false);
        Mockito.when(exchangeService.setupHomeDirectory(Mockito.eq(domain), Mockito.eq(userName), Mockito.eq(target), Mockito.any()))
                //.thenReturn(expected);
                .thenAnswer((Answer<PowerShellResult>) invocation -> {
                    ((Consumer<Exception>) invocation.getArgument(3)).accept(new RuntimeException());
                    return expected;
                });
        Assertions.assertEquals(expected, instance.setupHomeDirectory(domain, userName, target));
        Mockito.verify(exchangeService).setupHomeDirectory(Mockito.eq(domain), Mockito.eq(userName), Mockito.eq(target), Mockito.any());
        Mockito.verifyNoMoreInteractions(exchangeService, exchangeProcessor);


    }
}