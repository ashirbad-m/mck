package com.mckesson.exchange.config;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;

class PowerShellDomainConfigurationTest {

    @Test
    void getServer() {
        var node1 = new PowerShellServer();
        node1.setEnabled(true);
        node1.setDomain("domain1");
        node1.setUrl("https://host1/");
        var node2 = new PowerShellServer();
        node2.setEnabled(false);
        node2.setDomain("domain2");
        node2.setUrl("https://host2/");

        var configuration = new PowerShellDomainConfiguration();
        configuration.setNodes(List.of(node1, node2));

        Assertions.assertEquals(node1, configuration.getServer("domain1"));

        try {
            configuration.getServer("domain2");
            Assertions.fail("Wrong behavior");
        } catch (RuntimeException ex) {
            Assertions.assertEquals("PowerShell Server Configuration not found for domain = domain2, please check configuration service", ex.getMessage());
        }

        try {
            configuration.getServer("domain3");
            Assertions.fail("Wrong behavior");
        } catch (RuntimeException ex) {
            Assertions.assertEquals("PowerShell Server Configuration not found for domain = domain3, please check configuration service", ex.getMessage());
        }
    }
}