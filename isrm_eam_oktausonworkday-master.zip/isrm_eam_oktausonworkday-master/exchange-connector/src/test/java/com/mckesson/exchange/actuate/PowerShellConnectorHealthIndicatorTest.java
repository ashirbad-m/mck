package com.mckesson.exchange.actuate;

import com.mckesson.common.actuate.AbstractServiceHealthIndicator;
import com.mckesson.exchange.config.PowerShellDomainConfiguration;
import com.mckesson.exchange.config.PowerShellServer;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.actuate.health.Status;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

class PowerShellConnectorHealthIndicatorTest {

    @Test
    void doHealthCheck() {
        var powerShellDomainConfiguration = Mockito.mock(PowerShellDomainConfiguration.class);
        var restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        var restTemplate = Mockito.mock(RestTemplate.class);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);

        var node1 = new PowerShellServer();
        node1.setEnabled(true);
        node1.setDomain("domain1");
        node1.setUrl("https://host1/");
        var node2 = new PowerShellServer();
        node2.setEnabled(true);
        node2.setDomain("domain2");
        node2.setUrl("https://host2/");
        var node3 = new PowerShellServer();
        node3.setEnabled(true);
        node3.setDomain("domain3");
        node3.setUrl("https://host3/");
        Mockito.when(powerShellDomainConfiguration.getNodes()).thenReturn(Arrays.asList(node1, node2, node3));

        var response1 = new AbstractServiceHealthIndicator.HealthResponse();
        response1.setStatus(Status.DOWN);
        var response2 = new AbstractServiceHealthIndicator.HealthResponse();
        response2.setStatus(Status.UNKNOWN);
        var response3 = new AbstractServiceHealthIndicator.HealthResponse();
        response3.setStatus(Status.OUT_OF_SERVICE);
        Mockito.when(restTemplate.getForEntity(Mockito.eq(node1.getUrl() + "actuator/health"), Mockito.eq(AbstractServiceHealthIndicator.HealthResponse.class)))
                .thenReturn(ResponseEntity.ok(response1));
        Mockito.when(restTemplate.getForEntity(Mockito.eq(node2.getUrl() + "actuator/health"), Mockito.eq(AbstractServiceHealthIndicator.HealthResponse.class)))
                .thenReturn(ResponseEntity.ok(response2));
        Mockito.when(restTemplate.getForEntity(Mockito.eq(node3.getUrl() + "actuator/health"), Mockito.eq(AbstractServiceHealthIndicator.HealthResponse.class)))
                .thenReturn(ResponseEntity.ok(response3));


        var instance = new PowerShellConnectorHealthIndicator(powerShellDomainConfiguration, restTemplateBuilder);

        var health = instance.health();
        Assertions.assertEquals(Status.DOWN, health.getStatus());
        var details = health.getDetails();
        Assertions.assertEquals(3, details.size());
        Assertions.assertEquals("DOWN {serviceUrl=https://host1/}", details.get("domain1").toString());
        Assertions.assertEquals("UNKNOWN {serviceUrl=https://host2/}", details.get("domain2").toString());
        Assertions.assertEquals("OUT_OF_SERVICE {serviceUrl=https://host3/}", details.get("domain3").toString());


        response1.setStatus(Status.UP);
        health = instance.health();
        Assertions.assertEquals(Status.DOWN, health.getStatus());
        details = health.getDetails();
        Assertions.assertEquals(3, details.size());
        Assertions.assertEquals("UP {serviceUrl=https://host1/}", details.get("domain1").toString());
        Assertions.assertEquals("UNKNOWN {serviceUrl=https://host2/}", details.get("domain2").toString());
        Assertions.assertEquals("OUT_OF_SERVICE {serviceUrl=https://host3/}", details.get("domain3").toString());

        response1.setStatus(Status.UP);
        response2.setStatus(Status.UP);
        node3.setEnabled(false);
        instance = new PowerShellConnectorHealthIndicator(powerShellDomainConfiguration, restTemplateBuilder);
        health = instance.health();
        Assertions.assertEquals(Status.UP, health.getStatus());
        details = health.getDetails();
        Assertions.assertEquals(2, details.size());
        Assertions.assertEquals("UP {serviceUrl=https://host1/}", details.get("domain1").toString());
        Assertions.assertEquals("UP {serviceUrl=https://host2/}", details.get("domain2").toString());
        Assertions.assertNull(details.get("domain3"));

        node1.setEnabled(false);
        node2.setEnabled(false);
        node3.setEnabled(false);
        instance = new PowerShellConnectorHealthIndicator(powerShellDomainConfiguration, restTemplateBuilder);
        health = instance.health();
        Assertions.assertEquals(Status.OUT_OF_SERVICE, health.getStatus());
        Assertions.assertTrue(health.getDetails().isEmpty());
    }
}