package com.mckesson.exchange.actuate;

import com.mckesson.common.actuate.AbstractServiceHealthIndicator;
import com.mckesson.exchange.config.PowerShellDomainConfiguration;
import com.mckesson.exchange.config.PowerShellServer;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.HashMap;
import java.util.Map;

/**
 * Checks status of PowerShell connector (REST API)
 */
@Component
public class PowerShellConnectorHealthIndicator extends AbstractHealthIndicator {
    private final Map<String, PowerShellServerHealthIndicator> healthIndicators;

    public PowerShellConnectorHealthIndicator(PowerShellDomainConfiguration powerShellDomainConfiguration, RestTemplateBuilder restTemplateBuilder) {
        super("Power Shell Connector health check failed");
        Assert.notNull(powerShellDomainConfiguration, "PowerShellDomainConfiguration must not be null");
        healthIndicators = new HashMap<>();
        for (PowerShellServer powerShellServer : powerShellDomainConfiguration.getNodes()) {
            if (powerShellServer.isEnabled()) {
                healthIndicators.put(powerShellServer.getDomain(), new PowerShellServerHealthIndicator(powerShellServer.getUrl(), restTemplateBuilder));
            }
        }
    }


    @Override
    protected void doHealthCheck(Health.Builder builder) {
        Status status;
        Map<String, Object> details = new HashMap<>();
        if (healthIndicators.isEmpty()) {
            status = Status.OUT_OF_SERVICE;
        } else {
            status = Status.UP;
            for (var entry : healthIndicators.entrySet()) {
                Health health = entry.getValue().health();
                if (!Status.UP.equals(health.getStatus())) {
                    status = Status.DOWN;
                }
                details.put(entry.getKey(), health);
            }
        }
        builder.status(status).withDetails(details);
    }

    private static class PowerShellServerHealthIndicator extends AbstractServiceHealthIndicator {
        PowerShellServerHealthIndicator(String serviceUrl, RestTemplateBuilder restTemplateBuilder) {
            super("Power Shell Connector health check failed", serviceUrl, restTemplateBuilder);
        }
    }
}