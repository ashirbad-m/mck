package com.mckesson.exchange;

import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.springframework.boot.web.client.RestTemplateCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;

import javax.net.ssl.SSLContext;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.concurrent.TimeUnit;

@Configuration
public class ExchangeConfiguration {

    @Bean
    public RestTemplateCustomizer restTemplateCustomizer() {
        return restTemplate -> {
            try {
                SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
                        .loadTrustMaterial(null, (X509Certificate[] chain, String authType) -> true)
                        .build();
                SSLConnectionSocketFactory sslSocketFactoryCopy = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

                restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory(
                        HttpClients.custom()
                                .setDefaultRequestConfig(RequestConfig.custom().setCookieSpec(CookieSpecs.IGNORE_COOKIES).build())
                                .setConnectionTimeToLive(5, TimeUnit.MINUTES)//set maximum time to live for connection in pool
                                .setSSLSocketFactory(sslSocketFactoryCopy)
                                .build()));
            } catch (KeyStoreException | NoSuchAlgorithmException | KeyManagementException ex) {
                throw new RuntimeException(ex);
            }
        };
    }

    /*@Bean
    public RestTemplateCustomizer restTemplateConverterCustomizer(ObjectMapper objectMapper) {
        return restTemplate -> restTemplate.getMessageConverters()
                .stream()
                .filter(AbstractJackson2HttpMessageConverter.class::isInstance)
                .map(AbstractJackson2HttpMessageConverter.class::cast)
                .findFirst()
                .ifPresent(converter -> converter.registerObjectMappersForType(Object.class, m -> m.put(MediaType.APPLICATION_JSON, objectMapper)));
    }*/
}
