package com.mckesson.exchange.service;

import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.PowerShellResult;
import com.mckesson.common.rest.OAuth2RestClient;
import com.mckesson.common.security.VeracodeUtils;
import com.mckesson.common.workday.converter.ConverterUtils;
import com.mckesson.exchange.config.PowerShellDomainConfiguration;
import com.mckesson.exchange.config.PowerShellServer;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.*;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import javax.annotation.Nullable;
import javax.naming.ldap.LdapName;
import javax.validation.constraints.NotNull;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * Implements logic to execute PowerShell actions
 */
@Service
@Slf4j
public class ExchangeService {


    /**
     * Contains mapping between domains and exchange service
     */
    private final Map<String, ExchangeServiceInternal> connectorByDomain;

    @Autowired
    public ExchangeService(
            PowerShellDomainConfiguration configuration,
            RestTemplateBuilder restTemplateBuilder,
            @Value("${security.oauth2.token-uri}") String accessTokenUri,
            @Value("${security.oauth2.client.client-id}") String clientId,
            @Value("${security.oauth2.client.client-secret}") String clientSecret,
            @Value("${security.oauth2.client.scope}") String scope,
            @Value("${security.oauth2.client.connect-timeout}") int connectTimeout,
            RetryTemplate retryTemplate
    ) {
        //Creates mappings between domain names and active connectors
        connectorByDomain = configuration.getNodes().stream()
                .filter(PowerShellServer::isEnabled)
                .map(node -> Pair.of(node.getDomain(), new ExchangeServiceInternal(
                                node.getUrl(), restTemplateBuilder, accessTokenUri, clientId, clientSecret, scope, connectTimeout, retryTemplate
                        ))
                ).collect(Collectors.toMap(Pair::getLeft, Pair::getRight));
    }

    /**
     * Executes HTTP request with oAuth headers
     *
     * @param domain         domain for PowerShell command execution
     * @param path           request path
     * @param method         request method
     * @param requestBody    request body
     * @param requestHeaders request headers
     * @param responseType   Java type of response (for Response entity)
     * @param onError        error handler
     * @param <T>            Java type of request body
     * @param <R>            Java type of response
     * @return Response entity
     */
    private <T, R> ResponseEntity<R> processRequestWithOAuth(
            @NotNull String domain,
            String path,
            HttpMethod method,
            @Nullable T requestBody,
            @Nullable HttpHeaders requestHeaders,
            Class<R> responseType,
            Consumer<Exception> onError
    ) {
        return processRequestWithOAuth(domain, path, method, requestBody, requestHeaders, responseType, Collections.emptyMap(), onError);
    }

    /**
     * Executes HTTP request with oAuth headers
     *
     * @param domain         domain for PowerShell command execution
     * @param path           request path
     * @param method         request method
     * @param requestBody    request body
     * @param requestHeaders request headers
     * @param responseType   Java type of response (for Response entity)
     * @param uriVariables   request URI variables
     * @param onError        error handler
     * @param <T>            Java type of request body
     * @param <R>            Java type of response
     * @return Response entity
     */
    private <T, R> ResponseEntity<R> processRequestWithOAuth(
            @NotNull String domain,
            String path,
            HttpMethod method,
            @Nullable T requestBody,
            @Nullable HttpHeaders requestHeaders,
            Class<R> responseType,
            Map<String, ?> uriVariables,
            Consumer<Exception> onError
    ) {
        return connectorByDomain.get(domain).processRequestWithOAuthInternal(path, method, requestBody, requestHeaders, responseType, uriVariables, onError);
    }

    /**
     * Requests oAuth headers for security reasons and execute PowerShell command on remote connector
     *
     * @param domain  domain for PowerShell command execution
     * @param path    request path
     * @param method  request method
     * @param params  PowerShell script arguments
     * @param onError error handler
     * @return PowerShell result object
     */
    private PowerShellResult processRequest(@NotNull String domain, String path, HttpMethod method, MultiValueMap<String, Object> params, Consumer<Exception> onError) {
        return processRequest(domain, path, method, params, 10, TimeUnit.MINUTES, onError);
    }

    /**
     * Requests oAuth headers for security reasons and execute PowerShell command on remote connector
     *
     * @param domain   domain for PowerShell command execution
     * @param path     request path
     * @param method   request method
     * @param params   PowerShell script arguments
     * @param timeout  execution timeout value
     * @param timeUnit execution timeout unit
     * @param onError  error handler
     * @return PowerShell result object
     */
    private PowerShellResult processRequest(@NotNull String domain, String path, HttpMethod method, MultiValueMap<String, Object> params, long timeout, TimeUnit timeUnit, Consumer<Exception> onError) {
        log.info("Process PowerShell request path: {}, params: {}", VeracodeUtils.encode(path), VeracodeUtils.encode(ConverterUtils.writeValueAsString(params)));
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        String uuid = processRequestWithOAuth(domain, path, method, params, requestHeaders, String.class, onError).getBody();
        long maxWait = timeUnit.toMillis(timeout);//TODO
        long threshold = System.currentTimeMillis() + maxWait;
        String requestPath = "ps/request/{uuid}";
        while (System.currentTimeMillis() < threshold) {
            ResponseEntity<String> response = processRequestWithOAuth(domain, requestPath, HttpMethod.HEAD, null, requestHeaders, String.class,
                    Map.of("uuid", VeracodeUtils.encode4url(uuid)), onError);
            if (response.getStatusCode() == HttpStatus.NO_CONTENT) {
                PowerShellResult result = processRequestWithOAuth(domain, requestPath, HttpMethod.GET, null, requestHeaders, PowerShellResult.class,
                        Map.of("uuid", VeracodeUtils.encode4url(uuid)), onError).getBody();
                log.info("PowerShell execution result: {}", VeracodeUtils.encode4java(String.valueOf(result)));
                if (result != null && result.isError()) {
                    throw new RuntimeException("PowerShell execution error: " + result.getCommandOutput() + ", request uuid: " + uuid);
                } else {
                    return result;
                }
            } else if (response.getStatusCode() == HttpStatus.ACCEPTED) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                    throw new RuntimeException(ex);
                }
            } else {
                throw new RuntimeException("PowerShell error: " + response.getStatusCode() + ", request uuid: " + uuid);
            }
        }
        throw new RuntimeException("PowerShell execution timeout, request uuid: " + uuid);
    }

    /**
     * Gets an object that represents the current host program.
     *
     * @param domain  domain for PowerShell command execution
     * @param onError error handler
     * @return PowerShell result object
     * @see <a href="https://docs.microsoft.com/en-us/powershell/module/Microsoft.PowerShell.Utility/Get-Host">Get-Host</a>
     */
    public PowerShellResult getHost(@NotNull String domain, Consumer<Exception> onError) {
        return processRequest(domain, "ps/get-host", HttpMethod.GET, null, onError);
    }

    /**
     * Gets value of automatic variable $PSVersionTable
     * (This is a read-only hash table that returns information specifically about the PowerShell engin version).
     *
     * @param domain  domain for PowerShell command execution
     * @param onError error handler
     * @return PowerShell result object
     */
    public PowerShellResult version(@NotNull String domain, Consumer<Exception> onError) {
        return processRequest(domain, "ps/version", HttpMethod.POST, null, onError);
    }

    /**
     * Checks that mailbox exists on Exchange servers
     *
     * @param domain          domain for PowerShell command execution
     * @param userName        username
     * @param exchangeServers exchange servers
     * @param server          AD DC to use
     * @param onError         error handler
     * @return true if mailbox exists, otherwise false
     */
    public boolean isMailboxExist(@NotNull String domain, @NotNull String userName, @NotNull Collection<String> exchangeServers, @NotNull String server, Consumer<Exception> onError) {
        PowerShellResult response = getRecipient(domain, userName, exchangeServers, server, onError);
        return response.isError() && "Success".equals(response.getCommandOutput());
    }

    /**
     * Finds Exchange recipient by username (checks that user mailbox was created)
     *
     * @param domain          domain for PowerShell command execution
     * @param userName        username
     * @param exchangeServers exchange servers
     * @param server          AD DC to use
     * @param onError         error handler
     * @return PowerShell result object
     */
    public PowerShellResult getRecipient(@NotNull String domain, @NotNull String userName, @NotNull Collection<String> exchangeServers, @NotNull String server, Consumer<Exception> onError) {
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("userName", userName);
        params.addAll("exchangeServers", new ArrayList<>(exchangeServers));
        params.add("server", server);
        return processRequest(domain, "ps/get-recipient", HttpMethod.POST, params, onError);
    }

    /**
     * Delete DFS directories
     *
     * @param domain        powershell domain
     * @param userName      user name WITHOUT domain specifier
     * @param linkName      DFS link name
     * @param computerNames array of names of the servers that contains DFS share
     * @return PowerShell result object
     */
    public PowerShellResult deleteDfsDirectories(@NotNull String domain, @NotNull String userName, @NotNull String linkName, @NotNull List<String> computerNames, Consumer<Exception> onError) {
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("userName", userName);
        params.add("linkName", linkName);
        params.addAll("computerNames", computerNames);
        return processRequest(domain, "ps/delete-dfs-directories", HttpMethod.POST, params, onError);
    }

    /**
     * List DFS directories
     *
     * @param domain        powershell domain
     * @param userName      user name WITHOUT domain specifier
     * @param linkName      DFS link name
     * @param computerNames array of names of the servers that contains DFS share
     * @return PowerShell result object
     */
    public PowerShellResult listDfsDirectories(@NotNull String domain, @NotNull String userName, @NotNull String linkName, @NotNull List<String> computerNames, Consumer<Exception> onError) {
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("userName", userName);
        params.add("linkName", linkName);
        params.addAll("computerNames", computerNames);
        return processRequest(domain, "ps/list-dfs-directories", HttpMethod.POST, params, onError);
    }

    /**
     * Manage mailbox
     *
     * @param domain                 powershell domain
     * @param action                 name of the action to execute
     * @param exchangeServers        array of Exchange servers to be used
     * @param userName               user name in the format DOMAIN\USER
     * @param mail                   e-mail to set for the user
     * @param mails                  e-mails to set for the user as secondary
     * @param server                 AD DC to use
     * @param mailNickname           Exchange mailbox identifier
     * @param office365AddressSuffix address suffix to use for O365
     * @return PowerShell result object
     */
    public PowerShellResult manageMailbox(@NotNull String domain, @NotNull String action, @NotNull Collection<String> exchangeServers, @NotNull String userName, String mail, List<String> mails, @NotNull String server, String mailNickname, String office365AddressSuffix, Consumer<Exception> onError) {
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("office365AddressSuffix", office365AddressSuffix);
        params.addAll("exchangeServers", new ArrayList<>(exchangeServers));
        params.add("action", action);
        params.add("userName", userName);
        params.add("mailNickname", mailNickname);
        params.add("mail", mail);
        if (mails != null) {
            params.addAll("mails", mails);
        }
        params.add("server", server);
        return processRequest(domain, "ps/manage-mailbox", HttpMethod.POST, params, onError);
    }

    /**
     * Manage o365 mailbox
     *
     * @param domain            powershell domain
     * @param action            name of the action to execute
     * @param userPrincipalName user's UPN
     * @param url               URL of O365 PowerShell endpoint
     * @param credentialAddress address of generic credential (stored in Windows Credential Manager) to use for connection to O365
     * @return PowerShell result object
     */
    public PowerShellResult manageO365Mailbox(@NotNull String domain, @NotNull String action, @NotNull String userPrincipalName, String url, String credentialAddress, Consumer<Exception> onError) {
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("url", url);
        params.add("credentialAddress", credentialAddress);
        params.add("action", action);
        params.add("userPrincipalName", userPrincipalName);
        return processRequest(domain, "ps/manage-o365-mailbox", HttpMethod.POST, params, onError);
    }

    /**
     * Modify group membership
     *
     * @param domain         powershell domain
     * @param user           user dn
     * @param server         AD DC to use
     * @param groupsToAdd    groups to add user to
     * @param groupsToRemove groups to remove user from
     * @return PowerShell result object
     */
    public PowerShellResult modifyGroupMembership(@NotNull String domain, @NotNull LdapName user, @NotNull String server, @NotNull List<PassportAction.AdsiInfo> groupsToAdd, @NotNull List<PassportAction.AdsiInfo> groupsToRemove, Consumer<Exception> onError) {
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("user", user);
        params.add("server", server);
        params.add("groupsToAdd", ConverterUtils.writeValueAsString(groupsToAdd));
        params.add("groupsToRemove", ConverterUtils.writeValueAsString(groupsToRemove));
        return processRequest(domain, "ps/modify-group-membership", HttpMethod.POST, params, onError);
    }

    /**
     * Update workday user
     *
     * @param domain            Powershell Connector Instance Name
     * @param workdayAction     Update action
     * @param parameters        Parameters map
     * @param onError           Error handler
     *
     * @return                  Action result
     */
    public PowerShellResult backToWorkday (@NotNull String domain, @NotNull String workdayAction, @NotNull Map<String, String> parameters, Consumer<Exception> onError) {
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("workdayAction", workdayAction);
        params.add("parameters", ConverterUtils.writeValueAsString(parameters));
        return processRequest(domain, "ps/back-to-workday", HttpMethod.POST, params, onError);
    }

    /**
     * Move item
     *
     * @param domain powershell domain
     * @param source source directory
     * @param target target directory
     * @return PowerShell result object
     * @see <a href="https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.management/move-item">Move-Item</a>
     */
    public PowerShellResult moveItem(@NotNull String domain, @NotNull String source, @NotNull String target, Consumer<Exception> onError) {
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("source", source);
        params.add("target", target);
        return processRequest(domain, "ps/move-item", HttpMethod.POST, params, onError);
    }

    /**
     * Changes the name of an Active Directory object.
     *
     * @param domain            powershell domain
     * @param distinguishedName distinguished name
     * @param server            AD server name
     * @param newName           new name
     * @return PowerShell result object
     * @see <a href="https://docs.microsoft.com/en-us/powershell/module/addsadministration/rename-adobject">Rename-ADObject</a>
     */

    public PowerShellResult changeName(@NotNull String domain, @NotNull String distinguishedName, @NotNull String newName, @NotNull String server, Consumer<Exception> onError) {
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("identity", distinguishedName);
        params.add("newName", newName);
        params.add("server", server);
        return processRequest(domain, "ps/change-name", HttpMethod.POST, params, onError);
    }

    /**
     * Modifies an Active Directory user (set logon hours).
     *
     * @param domain   powershell domain
     * @param identity identity
     * @param server   AD server name
     * @param logon    true/false
     * @return PowerShell result object
     * @see <a href="https://docs.microsoft.com/en-us/powershell/module/addsadministration/Set-ADUser">Set-ADUser</a>
     */
    public PowerShellResult setLogonHours(@NotNull String domain, @NotNull String identity, @NotNull String server, boolean logon, Consumer<Exception> onError) {
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("identity", identity);
        params.add("server", server);
        params.add("logon", logon);
        return processRequest(domain, "ps/set-logon-hours", HttpMethod.POST, params, onError);
    }

    /**
     * Setup home directory
     *
     * @param domain   powershell domain
     * @param userName user name in the format DOMAIN\USER
     * @param target   target directory to be created. It must be UNC path, otherwise owner can't be changed
     * @return PowerShell result object
     */
    public PowerShellResult setupHomeDirectory(@NotNull String domain, @NotNull String userName, @NotNull String target, Consumer<Exception> onError) {
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("userName", userName);
        params.add("target", target);
        return processRequest(domain, "ps/setup-home-directory", HttpMethod.POST, params, onError);
    }

    /**
     * Internal implementation of exchange service for one domain
     */
    private static class ExchangeServiceInternal extends OAuth2RestClient {
        public ExchangeServiceInternal(String serviceUrl, RestTemplateBuilder restTemplateBuilder,
                                       String accessTokenUri, String clientId, String clientSecret, String scope,
                                       int connectTimeout, RetryTemplate retryTemplate) {
            super(serviceUrl, restTemplateBuilder, accessTokenUri, clientId, clientSecret, scope, connectTimeout, retryTemplate);
        }

        protected <T, R> ResponseEntity<R> processRequestWithOAuthInternal(
                String path,
                HttpMethod method,
                @Nullable T requestBody,
                @Nullable HttpHeaders requestHeaders,
                Class<R> responseType,
                Map<String, ?> uriVariables,
                Consumer<Exception> onError
        ) {
            return processRequestWithOAuth(path, method, requestBody, requestHeaders, responseType, uriVariables, onError);
        }
    }
}