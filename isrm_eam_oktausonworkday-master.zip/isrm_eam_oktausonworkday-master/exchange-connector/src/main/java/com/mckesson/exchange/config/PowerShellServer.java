package com.mckesson.exchange.config;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

/**
 * PowerShell connector server information
 */
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PowerShellServer {
    String domain;
    boolean enabled;
    String url;
}
