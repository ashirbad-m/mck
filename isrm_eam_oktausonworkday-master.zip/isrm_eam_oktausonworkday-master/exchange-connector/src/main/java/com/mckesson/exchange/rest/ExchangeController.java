package com.mckesson.exchange.rest;

import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.PowerShellResult;
import com.mckesson.exchange.service.ExchangeProcessor;
import com.mckesson.exchange.service.ExchangeService;
import com.mckesson.security.HasGlobalAdminAccess;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.naming.ldap.LdapName;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/exchange")
@ConditionalOnProperty(name = "rest.controller.enabled", havingValue = "true")
@RequiredArgsConstructor
public class ExchangeController {

    private final ExchangeService exchangeService;
    private final ExchangeProcessor exchangeProcessor;

    @PostMapping("/processAction")
    public ResponseEntity<Object> processAction(@RequestBody PassportAction task) {
        exchangeProcessor.processAction(task);
        return ResponseEntity.ok().build();
    }

    /**
     * Gets an object that represents the current host program.
     *
     * @see <a href="https://docs.microsoft.com/en-us/powershell/module/Microsoft.PowerShell.Utility/Get-Host">Get-Host</a>
     */
    @GetMapping("/get-host")
    @HasGlobalAdminAccess
    public PowerShellResult getHost(@RequestParam("domain") String domain) {
        return exchangeService.getHost(domain, (ex) -> {
        });
    }

    /**
     * Delete DFS directories
     *
     * @param userName      user name WITHOUT domain specifier
     * @param linkName      DFS link name
     * @param computerNames array of names of the servers that contains DFS share
     */
    @PostMapping(value = "/delete-dfs-directories", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @HasGlobalAdminAccess
    public PowerShellResult deleteDfsDirectories(@RequestParam("domain") String domain,
                                                 @RequestParam("userName") String userName,
                                                 @RequestParam("linkName") String linkName,
                                                 @RequestParam("computerNames") List<String> computerNames) {
        return exchangeService.deleteDfsDirectories(domain, userName, linkName, computerNames, (ex) -> {
        });
    }

    /**
     * List DFS directories
     *
     * @param userName      user name WITHOUT domain specifier
     * @param linkName      DFS link name
     * @param computerNames array of names of the servers that contains DFS share
     */
    @PostMapping(value = "/list-dfs-directories", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @HasGlobalAdminAccess
    public PowerShellResult listDfsDirectories(@RequestParam("domain") String domain,
                                               @RequestParam("userName") String userName,
                                               @RequestParam("linkName") String linkName,
                                               @RequestParam("computerNames") List<String> computerNames) {
        return exchangeService.listDfsDirectories(domain, userName, linkName, computerNames, (ex) -> {
        });
    }

    /**
     * Mange mailbox
     *
     * @param office365AddressSuffix address suffix to use for O365
     * @param exchangeServers        array of Exchange servers to be used
     * @param action                 name of the action to execute
     * @param userName               user name in the format DOMAIN\USER
     * @param mailNickname           Exchange mailbox identifier
     * @param mail                   e-mail to set for the user
     * @param mails                  e-mails to set for the user as secondary
     * @param server                 AD DC to use
     */
    @PostMapping(value = "/manage-mailbox", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @HasGlobalAdminAccess
    public PowerShellResult manageMailbox(@RequestParam("domain") String domain,
                                          @RequestParam("office365AddressSuffix") String office365AddressSuffix,
                                          @RequestParam("exchangeServers") List<String> exchangeServers,
                                          @RequestParam("action") String action,
                                          @RequestParam("userName") String userName,
                                          @RequestParam("mailNickname") String mailNickname,
                                          @RequestParam("mail") String mail,
                                          @RequestParam("mails") List<String> mails,
                                          @RequestParam("server") String server) {
        return exchangeService.manageMailbox(domain, action, exchangeServers, userName, mail, mails, server, mailNickname, office365AddressSuffix, (ex) -> {
        });
    }

    /**
     * Manage o365 mailbox
     *
     * @param url               URL of O365 PowerShell endpoint
     * @param credentialAddress address of generic credential (stored in Windows Credential Manager) to use for connection to O365
     * @param action            name of the action to execute
     * @param userPrincipalName user's UPN
     */
    @PostMapping(value = "/manage-o365-mailbox", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @HasGlobalAdminAccess
    public PowerShellResult manageO365Mailbox(@RequestParam("domain") String domain,
                                              @RequestParam("url") String url,
                                              @RequestParam("credentialAddress") String credentialAddress,
                                              @RequestParam("action") String action,
                                              @RequestParam("userPrincipalName") String userPrincipalName) {
        return exchangeService.manageO365Mailbox(domain, action, userPrincipalName, url, credentialAddress, (ex) -> {
        });
    }

    /**
     * Modify group membership
     *
     * @param user           user dn
     * @param groupsToAdd    groups to add user to
     * @param groupsToRemove groups to remove user from
     * @param server         AD DC to use
     */
    @PostMapping(value = "/modify-group-membership", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @HasGlobalAdminAccess
    public PowerShellResult modifyGroupMembership(@RequestParam("domain") String domain,
                                                  @RequestParam("user") LdapName user,
                                                  @RequestParam("server") String server,
                                                  @RequestParam("groupsToAdd") List<PassportAction.AdsiInfo> groupsToAdd,
                                                  @RequestParam("groupsToRemove") List<PassportAction.AdsiInfo> groupsToRemove) {
        return exchangeService.modifyGroupMembership(domain, user, server, groupsToAdd, groupsToRemove, (ex) -> {
        });
    }

    /**
     * Update Worker Data in workday
     *
     * @param domain Powershell Connector Instance Name
     * @param workdayAction Action Name
     * @param parameters    Action Parameters map
     *
     * @return Execution result
     */
    @PostMapping(value = "/back-to-workday", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @HasGlobalAdminAccess
    public PowerShellResult backToWorkday(
        @RequestParam("domain") String domain,
        @RequestParam("server") String workdayAction,
        @RequestParam("parameters") Map<String, String> parameters
    ) {
        return exchangeService.backToWorkday(domain, workdayAction, parameters, (ex) -> {});
    }

    /**
     * Move item
     *
     * @param source source directory
     * @param target target directory
     * @see <a href="https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.management/move-item">Move-Item</a>
     */
    @PostMapping(value = "/move-item", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @HasGlobalAdminAccess
    public PowerShellResult moveItem(@RequestParam("domain") String domain,
                                     @RequestParam("source") String source,
                                     @RequestParam("target") String target) {
        return exchangeService.moveItem(domain, source, target, (ex) -> {
        });
    }

    /**
     * Changes the name of an Active Directory object.
     *
     * @param distinguishedName identity
     * @param server            AD server name
     * @param newName           new name
     * @see <a href="https://docs.microsoft.com/en-us/powershell/module/addsadministration/rename-adobject">Rename-ADObject</a>
     */
    @PostMapping(value = "/change-name", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @HasGlobalAdminAccess
    public PowerShellResult changeName(@RequestParam("domain") String domain,
                                       @RequestParam("identity") String distinguishedName,
                                       @RequestParam("newName") String newName,
                                       @RequestParam("server") String server) {
        return exchangeService.changeName(domain, distinguishedName, newName, server, (ex) -> {
        });
    }

    /**
     * Modifies an Active Directory user (set logon hours).
     *
     * @param identity identity
     * @param server   AD server name
     * @param logon    true/false
     * @see <a href="https://docs.microsoft.com/en-us/powershell/module/addsadministration/Set-ADUser">Set-ADUser</a>
     */
    @PostMapping(value = "/set-logon-hours", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @HasGlobalAdminAccess
    public PowerShellResult setLogonHours(@RequestParam("domain") String domain,
                                          @RequestParam("identity") String identity,
                                          @RequestParam("server") String server,
                                          @RequestParam("logon") boolean logon) {
        return exchangeService.setLogonHours(domain, identity, server, logon, (ex) -> {
        });
    }

    /**
     * Setup home directory
     *
     * @param userName user name in the format DOMAIN\USER
     * @param target   target directory to be created. It must be UNC path, otherwise owner can't be changed
     */
    @PostMapping(value = "/setup-home-directory", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @HasGlobalAdminAccess
    public PowerShellResult setupHomeDirectory(@RequestParam("domain") String domain,
                                               @RequestParam("userName") String userName,
                                               @RequestParam("target") String target) {
        return exchangeService.setupHomeDirectory(domain, userName, target, (ex) -> {
        });
    }
}