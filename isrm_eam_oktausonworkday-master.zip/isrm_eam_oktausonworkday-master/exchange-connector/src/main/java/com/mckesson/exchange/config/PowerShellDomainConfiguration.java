package com.mckesson.exchange.config;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * Configuration of domain for PowerShell connectors
 */
@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "domains.power-shell", ignoreUnknownFields = false)
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PowerShellDomainConfiguration {
    private List<PowerShellServer> nodes;

    public PowerShellServer getServer(final String domain) {
        return nodes.stream().filter(node -> node.isEnabled() && node.getDomain().equalsIgnoreCase(domain)).findFirst()
                .orElseThrow(() -> new RuntimeException("PowerShell Server Configuration not found for domain = " + domain + ", please check configuration service"));
    }
}
