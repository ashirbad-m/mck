package com.mckesson.exchange.service;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.PassportActionProcessor;
import com.mckesson.common.audit.AuditService;
import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.ExecutionMetric;
import com.mckesson.common.model.ModuleEnum;
import com.mckesson.common.workday.configuration.controller.ConfigurationClient;
import com.mckesson.common.workday.configuration.dto.GroupMappingDto;
import com.mckesson.common.workday.converter.ConverterUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.stereotype.Service;

import javax.naming.ldap.LdapName;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@Slf4j
@RequiredArgsConstructor
public class ExchangeProcessor implements PassportActionProcessor {
    private static final Long REMOTE_MAILBOX_VALUE = 2_147_483_648L; //2^31

    private static final String PASSPORT_UPDATE_HRBU = "passport.events.update-hrbu";
    private static final String EXCHANGE_PREFIX = "passport.exchange.";
    private static final String EXCHANGE_LOGON_HOURS = EXCHANGE_PREFIX + "logon-hours";
    private static final String EXCHANGE_ADDR_LIST_ON = EXCHANGE_PREFIX + "address-list.show";
    private static final String EXCHANGE_ADDR_LIST_OFF = EXCHANGE_PREFIX + "address-list.hide";
    private static final String EXCHANGE_CREATE_O365_MAIL = EXCHANGE_PREFIX + "create-o365-mail";
    private static final String EXCHANGE_CREATE_MAIL = EXCHANGE_PREFIX + "create-mail";
    private static final String EXCHANGE_CREATE_HOME = EXCHANGE_PREFIX + "home.create";
    private static final String EXCHANGE_PRIMARY_ADDR = EXCHANGE_PREFIX + "mail.primary";
    private static final String EXCHANGE_SECONDARY_ADDR = EXCHANGE_PREFIX + "mail.secondary";
    private static final String EXCHANGE_ARCHIVE_HOME = EXCHANGE_PREFIX + "home.archive";
    private static final String EXCHANGE_DELETE_PROFILE = EXCHANGE_PREFIX + "termination.delete-profile";
    private static final String EXCHANGE_DEVICE_DISABLED_O365 = EXCHANGE_PREFIX + "termination.disable-o365-device";
    private static final String EXCHANGE_DEVICE_DISABLED = EXCHANGE_PREFIX + "termination.disable-device";
    private static final String EXCHANGE_CAS_SET = EXCHANGE_PREFIX + "active-directory.set-cas";
    private static final String EXCHANGE_ERROR = EXCHANGE_PREFIX + "error";
    private static final String EXCHANGE_MODIFY_GROUP_MEMBERSHIP = EXCHANGE_PREFIX + "active-directory.modify-group-membership";
    private static final String EXCHANGE_BACK_TO_WORKDAY = EXCHANGE_PREFIX + "workday.back-to-workday";

    private final MessageBrokerPublisher messageBrokerPublisher;
    private final ExchangeService exchangeService;
    private final ExecutorService threadPool = Executors.newFixedThreadPool(50);
    private final AuditService auditService;
    private final ConfigurationClient configurationClient;

    private Consumer<Exception> onError(PassportAction.PowerShellEventBody eventBody, String situation) {
        return (ex) -> auditService.audit(generateEvent(eventBody, situation)
                .status("ERROR")
                .message(ex.getMessage())
                .build());
    }

    @Override
    public void processAction(PassportAction passportAction) {
        processActionInternal(passportAction);
    }

    protected Future<?> processActionInternal(PassportAction passportAction) {
        return threadPool.submit(() -> {
            final String eventBodyJson = passportAction.getEventBody();
            PassportAction.PowerShellEventBody eventBody = ConverterUtils.readSimpleJson(eventBodyJson, PassportAction.PowerShellEventBody.class, null);
            Date startTime = new Date();
            try {
                switch (eventBody.getAction()) {
                    case "leaveOfAbsence":
                        if (Boolean.TRUE.equals(eventBody.getLogon())) {
                            setLogonHours(eventBody, true);
                            showInAddressLists(eventBody);
                        } else {
                            setLogonHours(eventBody, false);
                            hideFromAddressLists(eventBody);
                        }
                        break;
                    case "createMail":
                        createMail(eventBody);
                        setSecondaryMail(eventBody);
                        break;
                    case "createHome":
                        createHome(eventBody);
                        break;
                    case "createMailAndHome":
                        createMail(eventBody);
                        setSecondaryMail(eventBody);
                        createHome(eventBody);
                        break;
                    case "updateMail":
                        setPrimaryMail(eventBody);
                        setSecondaryMail(eventBody);
                        break;
                    case "archiveHomeAndDeleteTSP":
                        archiveHome(eventBody);
                        deleteTerminalServerProfile(eventBody);
                        break;
                    case "terminateMailAndASD":
                        disableActiveSyncDevice(eventBody);
                        deleteMail(eventBody);
                        break;
                    case "setCAS":
                        setCAS(eventBody);
                        break;
                    case "updateHrbu":
                        updateHrbu(eventBody);
                        break;
                    case "modifyGroupMembership":
                        modifyGroupMembership(eventBody);
                        break;
                    case "backToWorkday":
                        backToWorkday(eventBody);
                        break;
                    default:
                        log.warn("Unknown task action: {}", eventBody.getAction());
                }
            } catch (Throwable th) {
                log.error("Unexpected error", th);
                auditService.audit(generateEvent(eventBody, EXCHANGE_ERROR).status("ERROR").message("Unexpected error: " + th.getMessage())
                        .oldValues(ExceptionUtils.getStackTrace(th)).newValues(eventBodyJson).build());
            } finally {
                passportAction.getMetrics().add(new ExecutionMetric(passportAction.getEventType().getModule(), getClass(), startTime));
                messageBrokerPublisher.send(ModuleEnum.FINALIZER, passportAction);
            }
        });
    }

    private AuditEvent.AuditEventBuilder generateEvent(PassportAction.PowerShellEventBody eventBody, String situation) {
        return AuditEvent.generateEvent(eventBody)
                .module(ModuleEnum.EXCHANGE)
                .status("SUCCESS")
                .duration(Instant.now().getEpochSecond())
                .situation(situation)
                .newValues(ConverterUtils.writeValueAsString(eventBody));
    }

    private void updateHrbu(PassportAction.PowerShellEventBody eventBody) {
        archiveHome(eventBody);
        deleteTerminalServerProfile(eventBody);

        boolean isO365Mailbox = isO365Mailbox(eventBody.getMsExchRecipientTypeDetails());
        final String userPrincipalName = eventBody.getUserPrincipalName();
        if (isO365Mailbox) {
            exchangeService.manageO365Mailbox(eventBody.getDomain(), "disableActiveSyncDeviceInO365", userPrincipalName, eventBody.getOffice365Url(), null,
                    onError(eventBody, EXCHANGE_DEVICE_DISABLED_O365));
            auditService.audit(generateEvent(eventBody, EXCHANGE_DEVICE_DISABLED_O365)
                    .message("Disabled active-sync device in o365 for: " + userPrincipalName).build());
        } else {
            exchangeService.manageMailbox(eventBody.getDomain(), "disableActiveSyncDevice", eventBody.getExchangeServers(), eventBody.getUserName(), null, null,
                    eventBody.getLdapHostName(), eventBody.getUserMailNickname(), null, onError(eventBody, EXCHANGE_DEVICE_DISABLED));
            auditService.audit(generateEvent(eventBody, EXCHANGE_DEVICE_DISABLED)
                    .message("Disabled active-sync device for: " + userPrincipalName).build());
        }
        auditService.audit(generateEvent(eventBody, PASSPORT_UPDATE_HRBU).message("HRBU has been updated for:" + eventBody.getUserName()).build());
        deleteMail(eventBody);
    }

    //<editor-fold defaultstate="collapsed" desc="ExchangeService wrappers">
    private boolean isO365Mailbox(Long msExchRecipientTypeDetails) {
        return REMOTE_MAILBOX_VALUE.equals(msExchRecipientTypeDetails);
    }

    private void createMail(PassportAction.PowerShellEventBody eventBody) {
        String emailPrimary = eventBody.getEmailPrimary();
        boolean isO365Mailbox = isO365Mailbox(eventBody.getMsExchRecipientTypeDetails());
        String action = isO365Mailbox ? "enableRemote" : "enable";
        String userName = eventBody.getUserName();
        String situation = isO365Mailbox ? EXCHANGE_CREATE_O365_MAIL : EXCHANGE_CREATE_MAIL;
        exchangeService.manageMailbox(eventBody.getDomain(), action, eventBody.getExchangeServers(), userName, emailPrimary, null, eventBody.getLdapHostName(), null, null,
                onError(eventBody, situation));

        if (isO365Mailbox) {
            auditService.audit(generateEvent(eventBody, EXCHANGE_CREATE_O365_MAIL).message("Create o365 mail box for: " + emailPrimary).build());
        } else {
            auditService.audit(generateEvent(eventBody, EXCHANGE_CREATE_MAIL).message("Create mail box: " + emailPrimary).build());
        }
    }

    private void setCAS(PassportAction.PowerShellEventBody eventBody) {
        final String userPrincipalName = eventBody.getUserPrincipalName();
        exchangeService.manageO365Mailbox(eventBody.getDomain(), "setCAS", userPrincipalName, eventBody.getOffice365Url(), eventBody.getOffice365CredentialsAddress(),
                onError(eventBody, EXCHANGE_CAS_SET));
        auditService.audit(generateEvent(eventBody, EXCHANGE_CAS_SET).message("Setting CAS for: " + userPrincipalName).build());
    }

    private void setPrimaryMail(PassportAction.PowerShellEventBody eventBody) {
        String action = isO365Mailbox(eventBody.getMsExchRecipientTypeDetails()) ? "setPrimaryEmailRemote" : "setPrimaryEmail";
        String userName = eventBody.getUserName();
        String server = eventBody.getLdapHostName();
        String emailPrimary = eventBody.getEmailPrimary();
        exchangeService.manageMailbox(eventBody.getDomain(), action, eventBody.getExchangeServers(), userName, emailPrimary, null, server, null, null,
                onError(eventBody, EXCHANGE_PRIMARY_ADDR));
        auditService.audit(generateEvent(eventBody, EXCHANGE_PRIMARY_ADDR).message("Set primary email: " + emailPrimary).build());
    }

    private void setSecondaryMail(PassportAction.PowerShellEventBody eventBody) {
        List<String> mails = Stream.of(eventBody.getEmailSecondary(), eventBody.getEmailSecondaryAdditional())
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        if (!mails.isEmpty()) {
            String action = isO365Mailbox(eventBody.getMsExchRecipientTypeDetails()) ? "setSecondaryEmailRemote" : "setSecondaryEmail";
            String userName = eventBody.getUserName();
            String server = eventBody.getLdapHostName();
            exchangeService.manageMailbox(eventBody.getDomain(), action, eventBody.getExchangeServers(), userName, null, mails, server, null, null,
                    onError(eventBody, EXCHANGE_SECONDARY_ADDR));
            final String mailsJoined = String.join(", ", mails);
            auditService.audit(generateEvent(eventBody, EXCHANGE_SECONDARY_ADDR)
                    .message("Set secondary addresses: " + mailsJoined).build());
        }
    }

    private void hideFromAddressLists(PassportAction.PowerShellEventBody eventBody) {
        String action = isO365Mailbox(eventBody.getMsExchRecipientTypeDetails()) ? "hideFromAddressListsRemote" : "hideFromAddressLists";
        String emailPrimary = eventBody.getEmailPrimary();
        String userName = eventBody.getUserName();
        String server = eventBody.getLdapHostName();
        exchangeService.manageMailbox(eventBody.getDomain(), action, eventBody.getExchangeServers(), userName, emailPrimary, null, server, null, null,
                onError(eventBody, EXCHANGE_ADDR_LIST_OFF));
        auditService.audit(generateEvent(eventBody, EXCHANGE_ADDR_LIST_OFF).message("Hide from address list for: " + emailPrimary).build());
    }

    private void showInAddressLists(PassportAction.PowerShellEventBody eventBody) {
        String action = isO365Mailbox(eventBody.getMsExchRecipientTypeDetails()) ? "showInAddressListsRemote" : "showInAddressLists";
        String emailPrimary = eventBody.getEmailPrimary();
        String userName = eventBody.getUserName();
        String server = eventBody.getLdapHostName();
        Collection<String> exchangeServers = eventBody.getExchangeServers();
        exchangeService.manageMailbox(eventBody.getDomain(), action, exchangeServers, userName, emailPrimary, null, server, null, null,
                onError(eventBody, EXCHANGE_ADDR_LIST_ON));
        auditService.audit(generateEvent(eventBody, EXCHANGE_ADDR_LIST_ON).message("Show in address list for: " + emailPrimary).build());
    }

    private void disableActiveSyncDevice(PassportAction.PowerShellEventBody eventBody) {
        boolean isO365Mailbox = isO365Mailbox(eventBody.getMsExchRecipientTypeDetails());
        final String action = isO365Mailbox ? "disableActiveSyncDeviceInO365" : "disableActiveSyncDevice";
        if (isO365Mailbox) {
            final String userPrincipalName = eventBody.getUserPrincipalName();
            exchangeService.manageO365Mailbox(eventBody.getDomain(), action, userPrincipalName, eventBody.getOffice365Url(), null,
                    onError(eventBody, EXCHANGE_DEVICE_DISABLED_O365));
            auditService.audit(generateEvent(eventBody, EXCHANGE_DEVICE_DISABLED_O365)
                    .message("Disabled active-sync device in o365 for: " + userPrincipalName).build());
        } else {
            String userName = eventBody.getUserName();
            exchangeService.manageMailbox(eventBody.getDomain(), action, eventBody.getExchangeServers(), userName, null, null, eventBody.getLdapHostName(), eventBody.getUserMailNickname(), null,
                    onError(eventBody, EXCHANGE_DEVICE_DISABLED));
            auditService.audit(generateEvent(eventBody, EXCHANGE_DEVICE_DISABLED)
                    .message("Disabled active-sync device for: " + userName).build());
        }
    }

    private void deleteMail(PassportAction.PowerShellEventBody eventBody) {
        boolean isO365Mailbox = isO365Mailbox(eventBody.getMsExchRecipientTypeDetails());
        String action = isO365Mailbox ? "disableRemote" : "disable";
        String emailPrimary = eventBody.getEmailPrimary();
        String userName = eventBody.getUserName();
        String server = eventBody.getLdapHostName();
        Collection<String> exchangeServers = eventBody.getExchangeServers();
        exchangeService.manageMailbox(eventBody.getDomain(), action, exchangeServers, userName, emailPrimary, null, server, null, null,
                onError(eventBody, EXCHANGE_DEVICE_DISABLED));
        final String msg = isO365Mailbox ? "Disabled o365 mailbox for: " : "Disabled mailbox for: ";
        auditService.audit(generateEvent(eventBody, EXCHANGE_DEVICE_DISABLED).message(msg + userName).build());
    }

    protected void createHome(PassportAction.PowerShellEventBody eventBody) {
        String homeDirectory = eventBody.getUserHomeDirectory();
        if (StringUtils.isNotBlank(homeDirectory)) {
            String userName = eventBody.getUserName();
            exchangeService.setupHomeDirectory(eventBody.getDomain(), userName, homeDirectory, onError(eventBody, EXCHANGE_CREATE_HOME));
            auditService.audit(generateEvent(eventBody, EXCHANGE_CREATE_HOME).message("Create home folder for: " + userName).build());
        }
    }

    private void archiveHome(PassportAction.PowerShellEventBody eventBody) {
        String homeDirectory = eventBody.getUserHomeDirectory();
        //Move user home directory with all contents to directory 2ARCHIVENETSEC
        //on the same parent. I.e. ..\$USER ->..\2ARCHIVENETSEC
        String archivedHomeDirectory = eventBody.getUserArchivedHomeDirectory();//UsonUtil.generateArchivedHomeDirectory(homeDirectory);
        if (StringUtils.isNotBlank(homeDirectory) && StringUtils.isNotBlank(archivedHomeDirectory)) {
            exchangeService.moveItem(eventBody.getDomain(), homeDirectory, archivedHomeDirectory, onError(eventBody, EXCHANGE_ARCHIVE_HOME));
            auditService.audit(generateEvent(eventBody, EXCHANGE_ARCHIVE_HOME)
                    .message("Home folder was archived to: " + archivedHomeDirectory).build());
        }
    }

    private void deleteTerminalServerProfile(PassportAction.PowerShellEventBody eventBody) {
        //Delete Terminal Server Profile
        //Using DFS cmdlet find all targets (folders)
        //that mapped to the profile name \\uson.usoncology.int\profiles\%sn[0]%
        //and delete 2 folders in each:
        //%sAMAccountName%
        //%sAMAccountName%.V2
        Collection<String> dfsServers = eventBody.getDfsServers();
        if (!dfsServers.isEmpty()) {
            final String userSamAccountName = eventBody.getUserSamAccountName();
            exchangeService.deleteDfsDirectories(eventBody.getDomain(), userSamAccountName, eventBody.getDfsLinkName(), new ArrayList<>(dfsServers),
                    onError(eventBody, EXCHANGE_DELETE_PROFILE));
            auditService.audit(generateEvent(eventBody, EXCHANGE_DELETE_PROFILE).message("Profile has been deleted for: " + userSamAccountName).build());
        }
    }

    /**
     * @param eventBody event body
     * @param logon     enable/disable logon
     */
    private void setLogonHours(PassportAction.PowerShellEventBody eventBody, boolean logon) {
        String userSamAccountName = eventBody.getUserSamAccountName();
        exchangeService.setLogonHours(eventBody.getDomain(), userSamAccountName, eventBody.getLdapHostName(), logon, onError(eventBody, EXCHANGE_LOGON_HOURS));
        auditService.audit(generateEvent(eventBody, EXCHANGE_LOGON_HOURS).message("logonHours is on for: " + userSamAccountName).build());
    }

    private void modifyGroupMembership(final PassportAction.PowerShellEventBody eventBody) {
        final PassportAction.GroupMembershipEventBody groupMembershipEventBody = Objects.requireNonNull(eventBody.getGroupMembershipEventBody());
        final List<DomainConfig> domainConfigs =
                configurationClient.allDomainConfigs()
                        .stream().sorted((o1, o2) -> o2.getRootOu().size() - o1.getRootOu().size()).collect(Collectors.toList());

        if (domainConfigs.isEmpty()) {
            throw new RuntimeException("Domain Configurations not found");
        }

        final Function<LdapName, PassportAction.AdsiInfo> getAdsiInfo = (dn) ->
                domainConfigs
                        .stream()
                        .filter(d0 -> dn.startsWith(d0.getRootOu()))
                        .findFirst()
                        .map(d1 -> new PassportAction.AdsiInfo(dn, d1.getLdapHostName()))
                        .orElseThrow(() -> new RuntimeException(
                                String.format("Host name for '%s' not found", dn)
                        ));

        final PassportAction.AdsiInfo userInfo = getAdsiInfo.apply(groupMembershipEventBody.getUserDn());

        final Function<Supplier<Set<String>>, List<PassportAction.AdsiInfo>> getAdsiInfos = getter ->
                Optional.ofNullable(getter.get()).map(configurationClient::findGroupMappingsByOktaCns).orElseGet(Collections::emptyList).stream()
                        .map(GroupMappingDto::getDn)
                        .distinct()
                        .map(getAdsiInfo)
                        .filter(gi -> !gi.getServer().equals(userInfo.getServer()))
                        .collect(Collectors.toList());

        final List<PassportAction.AdsiInfo> groupsToAddCrossDomain = getAdsiInfos.apply(groupMembershipEventBody::getOktaCnsToAdd);
        final List<PassportAction.AdsiInfo> groupsToRemoveCrossDomain = getAdsiInfos.apply(groupMembershipEventBody::getOktaCnsToRemove);

        if (groupsToAddCrossDomain.isEmpty() && groupsToRemoveCrossDomain.isEmpty()) {
            log.info("No cross domain membership modifications for {}", groupMembershipEventBody.getUserDn());
            return;
        }

        exchangeService.modifyGroupMembership(eventBody.getDomain(),
                userInfo.getDn(), userInfo.getServer(),
                groupsToAddCrossDomain, groupsToRemoveCrossDomain,
                onError(eventBody, EXCHANGE_MODIFY_GROUP_MEMBERSHIP)
        );
        auditService.audit(
                generateEvent(eventBody, EXCHANGE_MODIFY_GROUP_MEMBERSHIP)
                        .message("modifyGroupMembership for: " + userInfo.getDn().getRdn(userInfo.getDn().size() - 1))
                        .oldValues(ConverterUtils.writeValueAsString(groupsToRemoveCrossDomain))
                        .newValues(ConverterUtils.writeValueAsString(groupsToAddCrossDomain))
                        .build()
        );
    }

     /**
     * Update Worker Data in workday
     *
     * @param eventBody Event payload
     */
    private void backToWorkday (final PassportAction.PowerShellEventBody eventBody) {
        final PassportAction.BackToWorkdayEventBody web = eventBody.getBackToWorkdayEventBody();
        exchangeService.backToWorkday(eventBody.getDomain(), web.getWorkdayAction(), web.getParameters(), onError(eventBody, EXCHANGE_BACK_TO_WORKDAY));
        auditService.audit(
            generateEvent(eventBody, EXCHANGE_BACK_TO_WORKDAY)
                .message("back to workday action: " + web.getWorkdayAction())
                .newValues(ConverterUtils.writeValueAsString(web.getParameters()))
                .build()
        );
    }
    //</editor-fold>
}
