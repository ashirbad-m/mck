# Workday B2E

Workday B2E Schema.

For normal work need to store **mysql-connector-java-8.0.19.jar** to **./lib** directory.
