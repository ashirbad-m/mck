package com.mckesson.audit.model;

import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.model.ModuleEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.UUID;

class AuditEventEntryTest {

    @Test
    void create() {
        var event = AuditEvent.builder()
                .date(new Date())
                .app(AuditEvent.Application.PASSPORT)
                .oktaUserId(UUID.randomUUID().toString())
                .batchId(UUID.randomUUID().toString())
                .oktaEventId(UUID.randomUUID().toString())
                .owfFlowId(UUID.randomUUID().toString())
                .owfExecutionId(UUID.randomUUID().toString())
                .module(ModuleEnum.AUDIT)
                .status("status1")
                .message("message1")
                .situation("situation1")
                .action("action1")
                .subAction("subAction1")
                .oldValues("oldValues1")
                .newValues("newValues1")
                .duration(1L)
                .build();
        var result = AuditEventEntry.create(event);

        Assertions.assertEquals(event.getDate(), result.getDate());
        Assertions.assertEquals(event.getApp(), result.getApp());
        Assertions.assertEquals(event.getOktaUserId(), result.getOktaUserId());
        Assertions.assertEquals(event.getBatchId(), result.getBatchId());
        Assertions.assertEquals(event.getOktaEventId(), result.getOktaEventId());
        Assertions.assertEquals(event.getOwfFlowId(), result.getOwfFlowId());
        Assertions.assertEquals(event.getOwfExecutionId(), result.getOwfExecutionId());
        Assertions.assertEquals(event.getModule(), result.getModule());
        Assertions.assertEquals(event.getStatus(), result.getStatus());
        Assertions.assertEquals(event.getMessage(), result.getMessage());
        Assertions.assertEquals(event.getSituation(), result.getSituation());
        Assertions.assertEquals(event.getAction(), result.getAction());
        Assertions.assertEquals(event.getSubAction(), result.getSubAction());
        Assertions.assertEquals(event.getOldValues(), result.getOldValues());
        Assertions.assertEquals(event.getNewValues(), result.getNewValues());
        Assertions.assertEquals(event.getDuration(), result.getDuration());
    }

    @Test
    void toAuditEvent() {
        var event = AuditEventEntry.builder()
                .date(new Date())
                .app(AuditEvent.Application.PASSPORT)
                .oktaUserId(UUID.randomUUID().toString())
                .batchId(UUID.randomUUID().toString())
                .oktaEventId(UUID.randomUUID().toString())
                .owfFlowId(UUID.randomUUID().toString())
                .owfExecutionId(UUID.randomUUID().toString())
                .module(ModuleEnum.AUDIT)
                .status("status1")
                .message("message1")
                .situation("situation1")
                .action("action1")
                .subAction("subAction1")
                .oldValues("oldValues1")
                .newValues("newValues1")
                .duration(1L)
                .build();
        var result = event.toAuditEvent();

        Assertions.assertEquals(event.getDate(), result.getDate());
        Assertions.assertEquals(event.getApp(), result.getApp());
        Assertions.assertEquals(event.getOktaUserId(), result.getOktaUserId());
        Assertions.assertEquals(event.getBatchId(), result.getBatchId());
        Assertions.assertEquals(event.getOktaEventId(), result.getOktaEventId());
        Assertions.assertEquals(event.getOwfFlowId(), result.getOwfFlowId());
        Assertions.assertEquals(event.getOwfExecutionId(), result.getOwfExecutionId());
        Assertions.assertEquals(event.getModule(), result.getModule());
        Assertions.assertEquals(event.getStatus(), result.getStatus());
        Assertions.assertEquals(event.getMessage(), result.getMessage());
        Assertions.assertEquals(event.getSituation(), result.getSituation());
        Assertions.assertEquals(event.getAction(), result.getAction());
        Assertions.assertEquals(event.getSubAction(), result.getSubAction());
        Assertions.assertEquals(event.getOldValues(), result.getOldValues());
        Assertions.assertEquals(event.getNewValues(), result.getNewValues());
        Assertions.assertEquals(event.getDuration(), result.getDuration());
    }

    @Test
    void convertToDatabaseColumn() {
        var instance = new AuditEventEntry.ModuleEnumConverter();

        Assertions.assertNull(instance.convertToDatabaseColumn(null));
        for (var module : ModuleEnum.values()) {
            Assertions.assertEquals(module.name(), instance.convertToDatabaseColumn(module));
        }
    }

    @Test
    void convertToEntityAttribute() {
        var instance = new AuditEventEntry.ModuleEnumConverter();

        Assertions.assertNull(instance.convertToEntityAttribute(null));
        Assertions.assertNull(instance.convertToEntityAttribute("Fake"));

        for (var module : ModuleEnum.values()) {
            Assertions.assertEquals(module, instance.convertToEntityAttribute(module.name()));
        }
    }
}