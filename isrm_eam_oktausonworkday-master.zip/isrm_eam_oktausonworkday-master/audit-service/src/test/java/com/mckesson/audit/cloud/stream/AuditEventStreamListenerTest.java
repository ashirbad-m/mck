package com.mckesson.audit.cloud.stream;

import com.mckesson.audit.service.AuditEventProcessor;
import com.mckesson.common.model.AuditEvent;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.UUID;

class AuditEventStreamListenerTest {

    @Test
    void processEvent() {
        var auditEventProcessor = Mockito.mock(AuditEventProcessor.class);
        var instance = new AuditEventStreamListener(auditEventProcessor);
        var event = AuditEvent.builder()
                .oktaEventId(UUID.randomUUID().toString())
                .build();

        instance.processEvent(event);
        Mockito.verify(auditEventProcessor).processEvent(Mockito.eq(event));
        Mockito.verifyNoMoreInteractions(auditEventProcessor);
    }
}