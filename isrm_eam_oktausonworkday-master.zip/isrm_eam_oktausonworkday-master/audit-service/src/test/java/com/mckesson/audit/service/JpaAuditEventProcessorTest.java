package com.mckesson.audit.service;

import com.mckesson.audit.model.AuditEventEntry;
import com.mckesson.audit.model.OktaEventEntry;
import com.mckesson.audit.repository.AuditRepository;
import com.mckesson.audit.repository.OktaEventRepository;
import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.workday.converter.ConverterUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

class JpaAuditEventProcessorTest {

    @Test
    void createAuditEventEntry() {
        var oktaEventRepository = Mockito.mock(OktaEventRepository.class);
        var auditRepository = Mockito.mock(AuditRepository.class);
        var instance = new JpaAuditEventProcessor(oktaEventRepository, auditRepository);

        var auditEvent = AuditEvent.builder().build();
        instance.createAuditEventEntry(auditEvent);

        Mockito.verify(auditRepository).save(Mockito.eq(AuditEventEntry.create(auditEvent)));
        Mockito.verifyNoMoreInteractions(oktaEventRepository, auditRepository);
    }

    @Test
    void createOktaEventEntry() {
        var oktaEventRepository = Mockito.mock(OktaEventRepository.class);
        var auditRepository = Mockito.mock(AuditRepository.class);
        var instance = new JpaAuditEventProcessor(oktaEventRepository, auditRepository);

        var auditEvent = AuditEvent.builder()
                .newValues(null)
                .build();
        instance.createOktaEventEntry(auditEvent);
        Mockito.verifyNoMoreInteractions(oktaEventRepository, auditRepository);


        OktaEventEntry event = new OktaEventEntry();
        event.setEventId(UUID.randomUUID().toString());

        auditEvent = AuditEvent.builder()
                .newValues(ConverterUtils.writeValueAsString(event))
                .build();

        instance.createOktaEventEntry(auditEvent);

        Mockito.verify(oktaEventRepository).save(Mockito.eq(ConverterUtils.readSimpleJson(auditEvent.getNewValues(), OktaEventEntry.class, null)));
        Mockito.verifyNoMoreInteractions(oktaEventRepository, auditRepository);
    }

    @Test
    void getEvents() {
        var oktaEventRepository = Mockito.mock(OktaEventRepository.class);
        var auditRepository = Mockito.mock(AuditRepository.class);
        var instance = new JpaAuditEventProcessor(oktaEventRepository, auditRepository);

        var item1 = new AuditEventEntry();
        item1.setId(1L);
        item1.setOktaEventId(UUID.randomUUID().toString());

        var items = List.of(item1);
        Date from = new Date();
        Date to = new Date();
        Mockito.when(auditRepository.findAllByDateBetween(Mockito.eq(from), Mockito.eq(to))).thenReturn(items);
        var expected = items.stream().map(AuditEventEntry::toAuditEvent).collect(Collectors.toList());
        Assertions.assertEquals(expected, instance.getEvents(from, to));
    }
}