package com.mckesson.audit;

import com.mckesson.common.model.AuditEvent;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.List;

class AbstractAuditEventProcessorTest {

    @Test
    void processEvent() {
        var instance = new TestAuditEventProcessor();
        var event = AuditEvent.builder()
                .action("EventStarted")
                .build();

        instance.processEvent(event);
        Assertions.assertNull(instance.auditEventEntry);
        Assertions.assertEquals(event, instance.oktaEventEntry);

        instance = new TestAuditEventProcessor();
        event = AuditEvent.builder()
                .action("Test")
                .build();

        instance.processEvent(event);
        Assertions.assertEquals(event, instance.auditEventEntry);
        Assertions.assertNull(instance.oktaEventEntry);
    }

    private static class TestAuditEventProcessor extends AbstractAuditEventProcessor {

        private AuditEvent auditEventEntry = null;
        private AuditEvent oktaEventEntry = null;

        @Override
        protected void createAuditEventEntry(AuditEvent event) {
            this.auditEventEntry = event;
        }

        @Override
        protected void createOktaEventEntry(AuditEvent event) {
            this.oktaEventEntry = event;
        }

        @Override
        public List<AuditEvent> getEvents(Date from, Date to) {
            return null;
        }
    }
}