package com.mckesson.audit.service;

import com.mckesson.common.mail.MailService;
import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.model.EmailMessage;
import com.mckesson.common.model.ModuleEnum;
import org.joda.time.LocalDate;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

class AuditReportGeneratorTest {

    @Test
    void generateReport() {
        var mailService = new MailService() {
            EmailMessage message = null;

            @Override
            public void send(EmailMessage message, Consumer<Exception> onError) {
                this.message = message;
            }
        };
        var auditEventProcessor = Mockito.mock(AuditEventProcessor.class);
        String subject = "subject";
        String sendTo = "send-to";

        List<AuditEvent> events = Arrays.asList(
                AuditEvent.builder()
                        .date(new Date())
                        .app(AuditEvent.Application.PASSPORT)
                        .oktaUserId(UUID.randomUUID().toString())
                        .batchId(UUID.randomUUID().toString())
                        .oktaEventId(UUID.randomUUID().toString())
                        .owfFlowId(UUID.randomUUID().toString())
                        .owfExecutionId(UUID.randomUUID().toString())
                        .module(null)
                        .status("status1")
                        .message("message1")
                        .situation("situation1")
                        .action("action1")
                        .subAction(null)
                        .oldValues("oldValues1")
                        .newValues("newValues1")
                        .duration(1L)
                        .build(),
                AuditEvent.builder()
                        .date(new Date())
                        .app(AuditEvent.Application.PASSPORT)
                        .oktaUserId(UUID.randomUUID().toString())
                        .batchId(UUID.randomUUID().toString())
                        .oktaEventId(UUID.randomUUID().toString())
                        .owfFlowId(UUID.randomUUID().toString())
                        .owfExecutionId(UUID.randomUUID().toString())
                        .module(ModuleEnum.OKTA_CLIENT)
                        .status("status2")
                        .message("message2")
                        .situation("situation2")
                        .action("action2")
                        .subAction("subAction2")
                        .oldValues("oldValues2")
                        .newValues("newValues2")
                        .duration(2L)
                        .build(),
                AuditEvent.builder()
                        .date(new Date())
                        .app(AuditEvent.Application.PASSPORT)
                        .oktaUserId(UUID.randomUUID().toString())
                        .batchId(UUID.randomUUID().toString())
                        .oktaEventId(UUID.randomUUID().toString())
                        .owfFlowId(UUID.randomUUID().toString())
                        .owfExecutionId(UUID.randomUUID().toString())
                        .module(ModuleEnum.OKTA_CLIENT)
                        .status("status3")
                        .message("message3")
                        .situation("situation3")
                        .action("action3")
                        .subAction("subAction3")
                        .oldValues("oldValues3")
                        .newValues("newValues3")
                        .duration(3L)
                        .build()
        );
        LocalDate to = LocalDate.now();
        LocalDate from = to.minusDays(1);
        Mockito.when(auditEventProcessor.getEvents(Mockito.eq(from.toDate()), Mockito.eq(to.toDate()))).thenReturn(events);

        var instance = new AuditReportGenerator(mailService, auditEventProcessor, subject, sendTo);

        instance.generateReport();
        Assertions.assertNotNull(mailService.message);
    }
}