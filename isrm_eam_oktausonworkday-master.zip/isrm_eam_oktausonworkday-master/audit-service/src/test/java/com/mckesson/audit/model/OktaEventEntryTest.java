package com.mckesson.audit.model;

import com.mckesson.common.workday.converter.ConverterUtils;
import org.joda.time.LocalDate;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OktaEventEntryTest {

    @Test
    void readSimpleJson() {
        var expectedDate1 = new LocalDate(2022, 1, 1);
        var expectedDate2 = new LocalDate(2022, 1, 2);
        var expectedDate3 = new LocalDate(2022, 1, 3);
        var expectedDate4 = new LocalDate(2022, 1, 4);

        String value = "{\"event_id_unique\":\"1\"," +
                "\"address_last_modified\":\"2022-01-01\"," +
                "\"date_activated\":\"2022-01-02\"," +
                "\"position_effective_date\":\"2022-01-03\"," +
                "\"hire_date\":\"2022-01-04\"}";
        OktaEventEntry entry = ConverterUtils.readSimpleJson(value, OktaEventEntry.class, null);
        Assertions.assertNotNull(entry);
        var addressLastModified = new LocalDate(entry.getAddressLastModified().getTime());
        var dateActivated = new LocalDate(entry.getDateActivated().getTime());
        var positionEffectiveDate = new LocalDate(entry.getPositionEffectiveDate().getTime());
        var hireDate = new LocalDate(entry.getHireDate().getTime());
        Assertions.assertEquals(expectedDate1, addressLastModified);
        Assertions.assertEquals(expectedDate2, dateActivated);
        Assertions.assertEquals(expectedDate3, positionEffectiveDate);
        Assertions.assertEquals(expectedDate4, hireDate);

        value = "{\"event_id_unique\":\"1\"," +
                "\"address_last_modified\":\"2022-01-01T06:51:32.611Z\"," +
                "\"date_activated\":\"2022-01-02T06:51:32.611Z\"," +
                "\"position_effective_date\":\"2022-01-03T06:51:32.611Z\","+
                "\"hire_date\":\"2022-01-04T06:51:32.611Z\"}";
        entry = ConverterUtils.readSimpleJson(value, OktaEventEntry.class, null);
        Assertions.assertNotNull(entry);
        addressLastModified = new LocalDate(entry.getAddressLastModified().getTime());
        dateActivated = new LocalDate(entry.getDateActivated().getTime());
        positionEffectiveDate = new LocalDate(entry.getPositionEffectiveDate().getTime());
        hireDate = new LocalDate(entry.getHireDate().getTime());
        Assertions.assertEquals(expectedDate1, addressLastModified);
        Assertions.assertEquals(expectedDate2, dateActivated);
        Assertions.assertEquals(expectedDate3, positionEffectiveDate);
        Assertions.assertEquals(expectedDate4, hireDate);
    }
}