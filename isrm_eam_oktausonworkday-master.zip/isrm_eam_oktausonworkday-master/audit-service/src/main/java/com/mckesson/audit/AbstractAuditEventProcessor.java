package com.mckesson.audit;

import com.mckesson.audit.service.AuditEventProcessor;
import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.workday.converter.ConverterUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * Common implementation of audit event processor,
 * define type of audit event and choose appropriate method for processing
 * @see com.mckesson.audit.service.AuditEventProcessor
 */
@Slf4j
public abstract class AbstractAuditEventProcessor implements AuditEventProcessor {

    @Override
    public void processEvent(AuditEvent event) {
        log.debug("On audit event: {}", ConverterUtils.writeValueAsString(event));
        if (StringUtils.equalsIgnoreCase("EventStarted", event.getAction())) {
            createOktaEventEntry(event);
        } else {
            createAuditEventEntry(event);
        }
    }

    /**
     * Creates audit event
     * @param event audit event
     */
    protected abstract void createAuditEventEntry(AuditEvent event);

    /**
     * Create record about OktaEvent
     * @param event audit event
     */
    protected abstract void createOktaEventEntry(AuditEvent event);
}
