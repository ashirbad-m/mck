package com.mckesson.audit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.mckesson.audit", "com.mckesson.common", "com.mckesson.common.workday.converter"})
public class AuditServiceApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(AuditServiceApplication.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(AuditServiceApplication.class, args);
    }
}
