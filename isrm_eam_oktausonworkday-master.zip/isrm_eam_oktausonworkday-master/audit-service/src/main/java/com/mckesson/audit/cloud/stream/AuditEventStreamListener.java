package com.mckesson.audit.cloud.stream;

import com.mckesson.audit.service.AuditEventProcessor;
import com.mckesson.common.model.AuditEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/**
 * Processes audit event messages from Spring Cloud stream
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Profile("stream")
public class AuditEventStreamListener {

    private final AuditEventProcessor auditEventProcessor;

    @StreamListener(target = Processor.INPUT, condition = "headers['module']==T(com.mckesson.common.model.ModuleEnum).AUDIT.name() && headers['class']=='com.mckesson.common.model.AuditEvent'")
    public void processEvent(final AuditEvent event) {
        auditEventProcessor.processEvent(event);
    }
}
