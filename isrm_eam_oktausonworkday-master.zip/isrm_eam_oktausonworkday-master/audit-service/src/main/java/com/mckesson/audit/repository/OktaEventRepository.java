package com.mckesson.audit.repository;

import com.mckesson.audit.model.OktaEventEntry;
import org.springframework.data.repository.CrudRepository;

/**
 * Provides access to DB data (OktaEvent information)
 */
public interface OktaEventRepository extends CrudRepository<OktaEventEntry, String> {
}
