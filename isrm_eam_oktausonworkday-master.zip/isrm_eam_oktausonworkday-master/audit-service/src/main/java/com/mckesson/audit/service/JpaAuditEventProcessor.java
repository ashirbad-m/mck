package com.mckesson.audit.service;

import com.mckesson.audit.AbstractAuditEventProcessor;
import com.mckesson.audit.model.AuditEventEntry;
import com.mckesson.audit.model.OktaEventEntry;
import com.mckesson.audit.repository.AuditRepository;
import com.mckesson.audit.repository.OktaEventRepository;
import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.workday.converter.ConverterUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * JPA based implementation, uses repositories to process audit events
 */
@Service
@RequiredArgsConstructor
public class JpaAuditEventProcessor extends AbstractAuditEventProcessor {

    private final OktaEventRepository oktaEventRepository;
    private final AuditRepository auditRepository;

    @Override
    protected void createAuditEventEntry(AuditEvent event) {
        AuditEventEntry entry = AuditEventEntry.create(event);
        auditRepository.save(entry);
    }

    @Override
    protected void createOktaEventEntry(AuditEvent event) {
        OktaEventEntry entry = ConverterUtils.readSimpleJson(event.getNewValues(), OktaEventEntry.class, null);
        if (entry != null) {
            oktaEventRepository.save(entry);
        }
    }

    @Override
    public List<AuditEvent> getEvents(Date from, Date to) {
        return auditRepository.findAllByDateBetween(from, to).stream().map(AuditEventEntry::toAuditEvent).collect(Collectors.toList());
    }
}
