package com.mckesson.audit.repository;

import com.mckesson.audit.model.AuditEventEntry;
import org.springframework.data.repository.CrudRepository;

import java.util.Date;
import java.util.List;

/**
 * Provides access to DB data (audit information)
 */
public interface AuditRepository extends CrudRepository<AuditEventEntry, Long> {

    /**
     * Find all audit events between given dates
     * @param from start date of period (inclusive)
     * @param to end tate of period (inclusive)
     * @return found audit events
     */
    List<AuditEventEntry> findAllByDateBetween(Date from, Date to);
}
