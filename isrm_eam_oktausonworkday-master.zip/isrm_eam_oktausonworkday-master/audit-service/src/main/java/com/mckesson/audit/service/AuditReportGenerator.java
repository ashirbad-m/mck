package com.mckesson.audit.service;

import com.google.common.collect.Sets;
import com.mckesson.common.mail.MailService;
import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.model.EmailMessage;
import com.mckesson.common.model.EmailMessageAttachment;
import com.mckesson.common.model.ModuleEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * Generator of audit reports
 */
@Component
@Slf4j
public class AuditReportGenerator {

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormat.forPattern("yyyy-MM-dd");
    private final MailService mailService;
    private final AuditEventProcessor auditEventProcessor;
    @Value("${audit.report.subject}")
    private final String subject;
    @Value("${audit.report.send-to}")
    private final String sendTo;

    public AuditReportGenerator(
            MailService mailService,
            AuditEventProcessor auditEventProcessor,
            @Value("${audit.report.subject}") String subject,
            @Value("${audit.report.send-to}") String sendTo
    ) {
        this.mailService = mailService;
        this.auditEventProcessor = auditEventProcessor;
        this.subject = subject;
        this.sendTo = sendTo;
    }

    @Scheduled(cron = "${audit.report.cron.expression}")
    public void generateReport() {
        log.info("Start report generation");
        LocalDate to = LocalDate.now();
        LocalDate from = to.minusDays(1);
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            List<AuditEvent> auditEvents = auditEventProcessor.getEvents(from.toDate(), to.toDate());

            SXSSFWorkbook workbook = new SXSSFWorkbook();
            CreationHelper createHelper = workbook.getCreationHelper();

            SXSSFSheet sheet = workbook.createSheet("Report");
            sheet.trackAllColumnsForAutoSizing();
            sheet.createFreezePane(0, 1);
            CellStyle headerStyle = workbook.createCellStyle();
            headerStyle.setAlignment(HorizontalAlignment.CENTER);
            headerStyle.setVerticalAlignment(VerticalAlignment.CENTER);
            headerStyle.setBorderBottom(BorderStyle.THIN);
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);

            CellStyle dateStyle = workbook.createCellStyle();
            dateStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy-mm-dd hh:mm:ss"));

            CellStyle longTextStyle = workbook.createCellStyle();
            longTextStyle.setWrapText(false);

            int rownum = 0;
            SXSSFRow row = sheet.createRow(rownum++);
            int column = 0;
            List<String> headers = Arrays.asList(
                    "Date", "App", "OKTA User Id", "Batch Id", "OKTA Event Id",
                    "OWF FlowId", "OWF Execution Id", "Module", "Status", "Message", "Situation", "Action", "Subaction",
                    "Old values", "New values");
            for (String header : headers) {
                Cell cell = row.createCell(column++);
                cell.setCellValue(header);
                cell.setCellStyle(headerStyle);
            }
            for (AuditEvent event : auditEvents) {
                column = 0;
                row = sheet.createRow(rownum++);
                Cell cell = row.createCell(column++);
                cell.setCellValue(event.getDate());
                cell.setCellStyle(dateStyle);

                setCellString(row.createCell(column++), event.getApp().name());
                setCellString(row.createCell(column++), event.getOktaUserId());
                setCellString(row.createCell(column++), event.getBatchId());
                setCellString(row.createCell(column++), event.getOktaEventId());
                setCellString(row.createCell(column++), event.getOwfFlowId());
                setCellString(row.createCell(column++), event.getOwfExecutionId());
                setCellString(row.createCell(column++), event.getModule() != null ? event.getModule().name() : "");
                setCellString(row.createCell(column++), event.getStatus());
                setCellString(row.createCell(column++), event.getMessage());
                setCellString(row.createCell(column++), event.getSituation());
                setCellString(row.createCell(column++), event.getAction());
                setCellString(row.createCell(column++), event.getSubAction());

                cell = row.createCell(column++);
                cell.setCellValue(StringUtils.left(StringUtils.defaultString(event.getOldValues()), 32767));
                cell.setCellStyle(longTextStyle);

                cell = row.createCell(column++);
                cell.setCellValue(StringUtils.left(StringUtils.defaultString(event.getNewValues()), 32767));
                cell.setCellStyle(longTextStyle);
            }

            for (column = 0; column < headers.size() - 2; column++) {
                sheet.autoSizeColumn(column);
            }

            try (GzipCompressorOutputStream gzos = new GzipCompressorOutputStream(baos)) {
                workbook.write(gzos);
            }

            EmailMessage message = new EmailMessage();
            message.setTo(Sets.newHashSet(sendTo.split(",")));
            message.setSubject(subject + " " + DATE_FORMAT.print(from) + " - " + DATE_FORMAT.print(to));
            message.setBody("See attachment");
            message.setAttachments(Arrays.asList(
                    new EmailMessageAttachment("audit-report.xlsx.gz", "application/x-gzip", baos.toByteArray())
            ));

            mailService.send(message, (ex) -> {
                AuditEvent event = AuditEvent.builder()
                        .date(new Date())
                        .app(AuditEvent.Application.PASSPORT)
                        .module(ModuleEnum.EXCHANGE)
                        .situation("Send email")
                        .status("ERROR")
                        .message(ex.getMessage())
                        .build();
                auditEventProcessor.processEvent(event);
            });
            log.info("Report generated");
        } catch (Exception ex) {
            log.error("Report generation has failed", ex);
        }
    }

    /**
     * Fill cell with string value or create blank cell
     *
     * @param cell  cell from sheet
     * @param value string value
     */
    private void setCellString(Cell cell, String value) {
        if (StringUtils.isNotBlank(value)) {
            cell.setCellValue(value);
        } else {
            cell.setBlank();
        }
    }

    /**
     * Fill cell with long value or create blank cell
     *
     * @param cell  cell from sheet
     * @param value long value
     */
    private void setCellLong(Cell cell, Long value) {
        if (value != null) {
            cell.setCellValue(value);
        } else {
            cell.setBlank();
        }
    }
}
