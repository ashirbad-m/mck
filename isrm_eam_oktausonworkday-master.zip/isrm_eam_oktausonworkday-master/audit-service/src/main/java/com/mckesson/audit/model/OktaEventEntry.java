package com.mckesson.audit.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "okta_event")
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class OktaEventEntry implements Serializable {

    @JsonProperty("event_id_unique")
    @Id
    String eventIdUnique;

    @JsonProperty("batch_id")
    String batchId;

    @JsonProperty("okta_user_id")
    String oktaUserId;

    @JsonProperty("event_type")
    String eventType;

    @JsonProperty("event_action")
    String eventAction;

    @JsonProperty("event_state")
    String eventState;

    @JsonProperty("event_id")
    String eventId;

    @JsonProperty("event_shortDesc")
    String eventShortDesc;

    @Temporal(TemporalType.TIMESTAMP)
    @JsonProperty("event_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    Date eventDate;

    @JsonProperty("wd_uid")
    String wdUid;

    @JsonProperty("worker_id")
    String workerId;

    @JsonProperty("employee")
    Boolean employee;

    @JsonProperty("user_id")
    String userId;

    @JsonProperty("email")
    String email;

    @JsonProperty("manager_id")
    String managerId;

    @JsonProperty("active")
    Boolean active;

    @JsonProperty("trm")
    Boolean trm;

    @JsonProperty("title")
    String title;

    @Temporal(TemporalType.DATE)
    @JsonProperty("date_activated")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    Date dateActivated;

    @Temporal(TemporalType.DATE)
    @JsonProperty("hire_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    Date hireDate;

    @Temporal(TemporalType.DATE)
    @JsonProperty("position_effective_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    Date positionEffectiveDate;

    @JsonProperty("worker_type")
    String workerType;

    @JsonProperty("hrbu")
    String hrbu;

    @JsonProperty("legal_name")
    String legalName;

    @JsonProperty("first_name")
    String firstName;

    @JsonProperty("last_name")
    String lastName;

    @JsonProperty("middle_name")
    String middleName;

    @JsonProperty("legal_prefix")
    String legalPrefix;

    @JsonProperty("legal_suffix")
    String legalSuffix;

    @JsonProperty("preferred_first_name")
    String preferredFirstName;

    @JsonProperty("preferred_last_name")
    String preferredLastName;

    @JsonProperty("preferred_prefix")
    String preferredPrefix;

    @JsonProperty("preferred_suffix")
    String preferredSuffix;

    @JsonProperty("telephone_number")
    String telephoneNumber;

    @JsonProperty("mobile")
    String mobile;

    @JsonProperty("fax")
    String fax;

    @JsonProperty("country")
    String country;

    @JsonProperty("state")
    String state;

    @JsonProperty("city")
    String city;

    @JsonProperty("address")
    String address;

    @JsonProperty("postal_address")
    String postalAddress;

    @JsonProperty("postal_code")
    String postalCode;

    @JsonProperty("hr_partner")
    String hrPartner;

    @JsonProperty("executive_director")
    String executiveDirector;

    @JsonProperty("job_family")
    String jobFamily;

    @JsonProperty("ssn")
    String ssn;

    @JsonProperty("leave_of_absence")
    Boolean leaveOfAbsence;

    @JsonProperty("company_id")
    String companyId;

    @JsonProperty("worker_type_descriptor")
    String workerTypeDescriptor;

    @JsonProperty("gl_pay_type")
    String glPayType;

    @Temporal(TemporalType.DATE)
    @JsonProperty("address_last_modified")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    Date addressLastModified;
}
