package com.mckesson.audit.service;

import com.mckesson.common.model.AuditEvent;

import java.util.Date;
import java.util.List;

/**
 * Defines interface for audit event processing
 */
public interface AuditEventProcessor {
    /**
     * Process audit event
     * @param event
     */
    void processEvent(AuditEvent event);

    /**
     * Provides stored audit events for given period
     * @param from start date of period (inclusive)
     * @param to end date of period (inclusive)
     * @return found events
     */
    List<AuditEvent> getEvents(Date from, Date to);
}
