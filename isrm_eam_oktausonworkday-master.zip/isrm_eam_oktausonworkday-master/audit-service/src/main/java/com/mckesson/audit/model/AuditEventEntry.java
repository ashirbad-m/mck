package com.mckesson.audit.model;

import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.model.ModuleEnum;
import lombok.*;
import lombok.experimental.FieldDefaults;
import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.annotation.Validated;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "audit")
@Validated
@Data
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class AuditEventEntry implements Serializable {
    @Id
    @GeneratedValue
    Long id;
    @NotNull
    @Temporal(TemporalType.TIMESTAMP)
    Date date;
    @NotNull
    @Enumerated(EnumType.STRING)
    AuditEvent.Application app;
    @NotNull
    String oktaUserId;
    String batchId;
    String oktaEventId;
    String owfFlowId;
    String owfExecutionId;

    @Enumerated(EnumType.STRING)
    @Convert(converter = ModuleEnumConverter.class)
    ModuleEnum module;
    String status;
    @NotNull
    String message;
    @NotNull
    String situation;
    String action;
    String subAction;
    String oldValues;
    String newValues;
    Long duration;

    public static AuditEventEntry create(AuditEvent event) {
        return AuditEventEntry.builder()
                .date(event.getDate())
                .app(event.getApp())
                .situation(StringUtils.left(event.getSituation(), 255))
                .oktaUserId(StringUtils.left(event.getOktaUserId(), 36))
                .batchId(StringUtils.left(event.getBatchId(), 36))
                .oktaEventId(StringUtils.left(event.getOktaEventId(), 36))
                .owfFlowId(StringUtils.left(event.getOwfFlowId(), 64))
                .owfExecutionId(StringUtils.left(event.getOwfExecutionId(), 64))
                .module(event.getModule())
                .status(StringUtils.left(event.getStatus(), 36))
                .message(StringUtils.left(event.getMessage(), 255))
                .action(StringUtils.left(event.getAction(), 255))
                .subAction(StringUtils.left(event.getSubAction(), 255))
                .oldValues(event.getOldValues())
                .newValues(event.getNewValues())
                .duration(event.getDuration())
                .build();
    }

    public AuditEvent toAuditEvent() {
        return AuditEvent.builder()
                .date(getDate())
                .app(getApp())
                .situation(getSituation())
                .oktaUserId(getOktaUserId())
                .batchId(getBatchId())
                .oktaEventId(getOktaEventId())
                .owfFlowId(getOwfFlowId())
                .owfExecutionId(getOwfExecutionId())
                .module(getModule())
                .status(getStatus())
                .message(getMessage())
                .action(getAction())
                .subAction(getSubAction())
                .oldValues(getOldValues())
                .newValues(getNewValues())
                .duration(getDuration())
                .build();
    }

    @Converter
    public static class ModuleEnumConverter implements AttributeConverter<ModuleEnum, String> {

        @Override
        public String convertToDatabaseColumn(ModuleEnum module) {
            if (module == null) {
                return null;
            } else {
                return module.name();
            }
        }

        @Override
        public ModuleEnum convertToEntityAttribute(String value) {
            if (value == null) {
                return null;
            } else {
                try {
                    return ModuleEnum.valueOf(value);
                } catch (IllegalArgumentException ex) {
                    return null;
                }
            }
        }
    }
}
