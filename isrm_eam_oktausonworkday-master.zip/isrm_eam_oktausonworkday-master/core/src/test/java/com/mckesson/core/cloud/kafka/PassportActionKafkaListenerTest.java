package com.mckesson.core.cloud.kafka;

import com.mckesson.common.domain.PassportAction;
import com.mckesson.core.service.CoreProcessor;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class PassportActionKafkaListenerTest {

    @Test
    void finalizeAction() {
        var coreProcessor = Mockito.mock(CoreProcessor.class);
        var instance = new PassportActionKafkaListener(coreProcessor);

        var passportAction = new PassportAction();
        passportAction.setEventType(PassportAction.EventTypeEnum.POWERSHELL);
        instance.finalizeAction(passportAction);

        Mockito.verify(coreProcessor).finalizeAction(Mockito.eq(passportAction));
        Mockito.verifyNoMoreInteractions(coreProcessor);
    }

    @Test
    void logAction() {
        var coreProcessor = Mockito.mock(CoreProcessor.class);
        var instance = new PassportActionKafkaListener(coreProcessor);

        var passportAction = new PassportAction();
        passportAction.setEventType(PassportAction.EventTypeEnum.POWERSHELL);
        instance.logAction(passportAction);

        Mockito.verify(coreProcessor).logAction(Mockito.eq(passportAction));
        Mockito.verifyNoMoreInteractions(coreProcessor);
    }
}