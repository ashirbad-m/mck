package com.mckesson.core.service;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.dao.CoreEventDao;
import com.mckesson.common.domain.AdInfo;
import com.mckesson.common.domain.OktaUser;
import com.mckesson.common.model.*;
import com.mckesson.common.scenario.ScenarioProvider;
import com.mckesson.common.workday.configuration.controller.ConfigurationClient;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.UUID;

class GatewayProcessorTest {

    @Test
    void onCoreEvent() throws InvalidNameException {
        var messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
        var coreEventDao = Mockito.mock(CoreEventDao.class);
        var configurationClient = Mockito.mock(ConfigurationClient.class);

        var instance = new GatewayProcessor(new ScenarioProvider(), messageBrokerPublisher, coreEventDao, configurationClient);

        var coreEvent = new CoreEvent();
        coreEvent.setModule(ModuleEnum.GATEWAY);
        coreEvent.setId(UUID.randomUUID().toString());
        coreEvent.setBatchId(UUID.randomUUID().toString());
        coreEvent.setTarget("target");
        coreEvent.setScenario(ScenarioEnum.CREATE);
        coreEvent.setStage("stage");

        instance.processEvent(coreEvent);
        Assertions.assertTrue(coreEvent.isFailed());
        Assertions.assertNotNull(coreEvent.getError());


        coreEvent = new CoreEvent();
        coreEvent.setModule(ModuleEnum.GATEWAY);
        coreEvent.setId(UUID.randomUUID().toString());
        coreEvent.setBatchId(UUID.randomUUID().toString());
        coreEvent.setTarget("target");
        coreEvent.setScenario(ScenarioEnum.CREATE);
        coreEvent.setStage("stage");
        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User1,OU=Test,DC=mshusontest,DC=com"));
        var adInfo = new AdInfo();
        nextOktaUser.setAdInfo(adInfo);
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        //coreEvent.setNextOktaUser(nextOktaUser);
        coreEvent.setPrevOktaUser(prevOktaUser);
        coreEvent.setModule(ModuleEnum.GATEWAY);
        coreEvent.setFailed(false);
        coreEvent.setError(null);

        var domainConfig = DomainConfig.builder().name("domain").build();
        var hrbuConfig = HrbuConfig.builder()
                .hrbu("hrbu")
                .city("city")
                .street("address")
                .ou(new LdapName("cn=xxx"))
                .vantageLookupStrategy(true)
                .build();

        Mockito.when(configurationClient.findHrbuConfig(prevOktaUser.getHrbu(), prevOktaUser.getCity(), prevOktaUser.getStreetAddress())).thenReturn(hrbuConfig);
        Mockito.when(configurationClient.findDomainConfig(Mockito.eq(hrbuConfig))).thenReturn(domainConfig);
        instance.processEvent(coreEvent);

        var updatedEvent = coreEvent.builder()
                .module(ModuleEnum.ACTIVE_DIRECTORY)
                .prevOktaUser(nextOktaUser)
                .hrbuConfig(hrbuConfig)
                .domainConfig(domainConfig)
                .build();
        Mockito.verify(coreEventDao).create(Mockito.refEq(coreEvent, "metrics"));
        Assertions.assertEquals(domainConfig.getName(), prevOktaUser.getDomain());
    }
}