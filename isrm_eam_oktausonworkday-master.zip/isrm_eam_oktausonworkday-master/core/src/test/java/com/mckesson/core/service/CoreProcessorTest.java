package com.mckesson.core.service;

import com.mckesson.common.dao.CoreEventDao;
import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.model.ScenarioEnum;
import com.mckesson.common.workday.converter.ConverterUtils;
import com.mckesson.core.model.ExecutionTimePassport;
import com.mckesson.core.repository.ExecutionTimeRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.UUID;

class CoreProcessorTest {

    @Test
    void logEvent() {
        var coreEventDao = Mockito.mock(CoreEventDao.class);
        var executionTimeRepository = Mockito.mock(ExecutionTimeRepository.class);
        var instance = new CoreProcessor(coreEventDao, executionTimeRepository);

        var coreEvent = CoreEvent.builder().target("target").scenario(ScenarioEnum.CREATE).stage("stage").metrics(new ArrayList<>()).build();
        instance.logEvent(coreEvent);

        Mockito.verify(coreEventDao).update(Mockito.eq(coreEvent));
        Mockito.verifyNoMoreInteractions(coreEventDao, executionTimeRepository);
    }

    @Test
    void finalizeEvent() {
        var coreEventDao = Mockito.mock(CoreEventDao.class);
        var executionTimeRepository = Mockito.mock(ExecutionTimeRepository.class);
        var instance = new CoreProcessor(coreEventDao, executionTimeRepository);

        var coreEvent = CoreEvent.builder().target("target").scenario(ScenarioEnum.CREATE).stage("stage").metrics(new ArrayList<>()).build();
        instance.finalizeEvent(coreEvent);

        Mockito.verify(executionTimeRepository).saveAll(Mockito.eq(ExecutionTimePassport.fromCoreEvent(coreEvent)));
        Mockito.verify(coreEventDao).delete(Mockito.eq(coreEvent));
        Mockito.verifyNoMoreInteractions(coreEventDao, executionTimeRepository);
    }

    @Test
    void logAction() {
        var coreEventDao = Mockito.mock(CoreEventDao.class);
        var executionTimeRepository = Mockito.mock(ExecutionTimeRepository.class);
        var instance = new CoreProcessor(coreEventDao, executionTimeRepository);

        var eventBody = new PassportAction.PowerShellEventBody("domain");
        eventBody.setEventId(UUID.randomUUID().toString());
        eventBody.setBatchId(UUID.randomUUID().toString());
        var passportAction = new PassportAction();
        passportAction.setEventBody(ConverterUtils.writeValueAsString(eventBody));
        passportAction.setEventType(PassportAction.EventTypeEnum.POWERSHELL);
        instance.logAction(passportAction);

        Mockito.verifyNoMoreInteractions(coreEventDao, executionTimeRepository);
    }

    @Test
    void finalizeAction() {
        var coreEventDao = Mockito.mock(CoreEventDao.class);
        var executionTimeRepository = Mockito.mock(ExecutionTimeRepository.class);
        var instance = new CoreProcessor(coreEventDao, executionTimeRepository);

        var eventBody = new PassportAction.PowerShellEventBody("domain");
        eventBody.setEventId(UUID.randomUUID().toString());
        eventBody.setBatchId(UUID.randomUUID().toString());
        var passportAction = new PassportAction();
        passportAction.setEventBody(ConverterUtils.writeValueAsString(eventBody));
        passportAction.setEventType(PassportAction.EventTypeEnum.POWERSHELL);
        instance.finalizeAction(passportAction);

        Mockito.verify(executionTimeRepository).saveAll(Mockito.eq(ExecutionTimePassport.fromPassportAction(passportAction)));
        Mockito.verifyNoMoreInteractions(coreEventDao, executionTimeRepository);
    }
}