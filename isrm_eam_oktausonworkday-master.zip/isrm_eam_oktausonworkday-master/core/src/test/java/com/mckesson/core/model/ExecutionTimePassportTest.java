package com.mckesson.core.model;

import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.model.ExecutionMetric;
import com.mckesson.common.model.ModuleEnum;
import com.mckesson.common.model.ScenarioEnum;
import com.mckesson.common.workday.converter.ConverterUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

class ExecutionTimePassportTest {

    @Test
    void fromCoreEvent() {
        var executionMetric1 = new ExecutionMetric();
        executionMetric1.setModule(ModuleEnum.EXCHANGE);
        executionMetric1.setClassName("ClassName1");
        executionMetric1.setStart(new Date());
        executionMetric1.setEnd(new Date());

        var executionMetric2 = new ExecutionMetric();
        executionMetric2.setModule(ModuleEnum.AUDIT);
        executionMetric2.setClassName("ClassName2");
        executionMetric2.setStart(new Date());
        executionMetric2.setEnd(new Date());

        var coreEvent = new CoreEvent();
        coreEvent.setId(UUID.randomUUID().toString());
        coreEvent.setBatchId(UUID.randomUUID().toString());
        coreEvent.setTarget("target");
        coreEvent.setScenario(ScenarioEnum.CREATE);
        coreEvent.setStage("stage");
        coreEvent.setMetrics(new ArrayList<>(List.of(executionMetric1, executionMetric2)));

        String flowName = coreEvent.getTarget() + "/" + coreEvent.getScenario().getName() + "/" + coreEvent.getStage();
        var result = ExecutionTimePassport.fromCoreEvent(coreEvent);

        Assertions.assertEquals(2, result.size());
        Assertions.assertEquals(coreEvent.getId(), result.get(0).getEventId());
        Assertions.assertEquals(coreEvent.getBatchId(), result.get(0).getBatchId());
        Assertions.assertEquals(flowName, result.get(0).getFlowName());
        Assertions.assertEquals(executionMetric1.getModule().name(), result.get(0).getModule());
        Assertions.assertEquals(executionMetric1.getClassName(), result.get(0).getClassName());
        Assertions.assertEquals(executionMetric1.getStart(), result.get(0).getStartTime());
        Assertions.assertEquals(executionMetric1.getEnd(), result.get(0).getEndTime());

        Assertions.assertEquals(coreEvent.getId(), result.get(1).getEventId());
        Assertions.assertEquals(coreEvent.getBatchId(), result.get(1).getBatchId());
        Assertions.assertEquals(flowName, result.get(1).getFlowName());
        Assertions.assertEquals(executionMetric2.getModule().name(), result.get(1).getModule());
        Assertions.assertEquals(executionMetric2.getClassName(), result.get(1).getClassName());
        Assertions.assertEquals(executionMetric2.getStart(), result.get(1).getStartTime());
        Assertions.assertEquals(executionMetric2.getEnd(), result.get(1).getEndTime());
    }

    @Test
    void fromPassportAction() {
        var executionMetric1 = new ExecutionMetric();
        executionMetric1.setModule(ModuleEnum.EXCHANGE);
        executionMetric1.setClassName("ClassName1");
        executionMetric1.setStart(new Date());
        executionMetric1.setEnd(new Date());

        var executionMetric2 = new ExecutionMetric();
        executionMetric2.setModule(ModuleEnum.AUDIT);
        executionMetric2.setClassName("ClassName2");
        executionMetric2.setStart(new Date());
        executionMetric2.setEnd(new Date());

        var eventBody = new PassportAction.PowerShellEventBody("domain");
        eventBody.setEventId(UUID.randomUUID().toString());
        eventBody.setBatchId(UUID.randomUUID().toString());
        var passportAction = new PassportAction();
        passportAction.setEventBody(ConverterUtils.writeValueAsString(eventBody));
        passportAction.setEventType(PassportAction.EventTypeEnum.POWERSHELL);
        passportAction.setMetrics(new ArrayList<>(List.of(executionMetric1, executionMetric2)));

        String flowName = passportAction.getClass().getSimpleName() + ":" + passportAction.getEventType().getName();

        var result = ExecutionTimePassport.fromPassportAction(passportAction);

        Assertions.assertEquals(2, result.size());
        Assertions.assertEquals(eventBody.getEventId(), result.get(0).getEventId());
        Assertions.assertEquals(eventBody.getBatchId(), result.get(0).getBatchId());
        Assertions.assertEquals(flowName, result.get(0).getFlowName());
        Assertions.assertEquals(executionMetric1.getModule().name(), result.get(0).getModule());
        Assertions.assertEquals(executionMetric1.getClassName(), result.get(0).getClassName());
        Assertions.assertEquals(executionMetric1.getStart(), result.get(0).getStartTime());
        Assertions.assertEquals(executionMetric1.getEnd(), result.get(0).getEndTime());

        Assertions.assertEquals(eventBody.getEventId(), result.get(1).getEventId());
        Assertions.assertEquals(eventBody.getBatchId(), result.get(1).getBatchId());
        Assertions.assertEquals(flowName, result.get(1).getFlowName());
        Assertions.assertEquals(executionMetric2.getModule().name(), result.get(1).getModule());
        Assertions.assertEquals(executionMetric2.getClassName(), result.get(1).getClassName());
        Assertions.assertEquals(executionMetric2.getStart(), result.get(1).getStartTime());
        Assertions.assertEquals(executionMetric2.getEnd(), result.get(1).getEndTime());
    }
}