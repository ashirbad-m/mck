package com.mckesson.core.rest;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.audit.AuditService;
import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.model.ModuleEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

class RestGatewayControllerTest {

    @Test
    void onCoreEvent() {
        var messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
        var auditService = Mockito.mock(AuditService.class);

        var instance = new RestGatewayController(messageBrokerPublisher, auditService);

        var coreEvent = CoreEvent.builder()
                .metrics(new ArrayList<>())
                .build();
        instance.onCoreEvent(coreEvent);

        Assertions.assertEquals(ModuleEnum.GATEWAY, coreEvent.getModule());
        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.GATEWAY), Mockito.refEq(coreEvent, "date", "metrics"));
        Mockito.verifyNoMoreInteractions(messageBrokerPublisher);
    }

    @Test
    void onPassportAction() {
        var messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
        var auditService = Mockito.mock(AuditService.class);

        var instance = new RestGatewayController(messageBrokerPublisher, auditService);

        var passportAction = new PassportAction();
        passportAction.setEventType(PassportAction.EventTypeEnum.POWERSHELL);
        instance.onPassportAction(passportAction);

        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(PassportAction.EventTypeEnum.POWERSHELL.getModule()),
                Mockito.refEq(passportAction, "date", "metrics"));
        Mockito.verifyNoMoreInteractions(messageBrokerPublisher);
    }

    @Test
    void onAuditEvent() {
        var messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
        var auditService = Mockito.mock(AuditService.class);

        var auditEvent = AuditEvent.builder()
                .date(new Date())
                .app(AuditEvent.Application.OKTA)
                .oktaUserId(UUID.randomUUID().toString())
                .message(UUID.randomUUID().toString())
                .situation(UUID.randomUUID().toString())
                .build();
        var instance = new RestGatewayController(messageBrokerPublisher, auditService);

        instance.onAuditEvent(auditEvent);
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "metrics"));
        Mockito.verifyNoMoreInteractions(messageBrokerPublisher);
    }
}