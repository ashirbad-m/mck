package com.mckesson.core.cloud.rabbit;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.core.service.CoreProcessor;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.ArrayList;

class CoreEventRabbitListenerTest {

    @Test
    void logEvent() {
        var coreProcessor = Mockito.mock(CoreProcessor.class);
        var instance = new CoreEventRabbitListener(coreProcessor);

        var coreEvent = CoreEvent.builder()
                .metrics(new ArrayList<>())
                .build();
        instance.logEvent(coreEvent);

        Mockito.verify(coreProcessor).logEvent(Mockito.eq(coreEvent));
        Mockito.verifyNoMoreInteractions(coreProcessor);
    }

    @Test
    void finalizeEvent() {
        var coreProcessor = Mockito.mock(CoreProcessor.class);
        var instance = new CoreEventRabbitListener(coreProcessor);

        var coreEvent = CoreEvent.builder()
                .metrics(new ArrayList<>())
                .build();
        instance.finalizeEvent(coreEvent);

        Mockito.verify(coreProcessor).finalizeEvent(Mockito.eq(coreEvent));
        Mockito.verifyNoMoreInteractions(coreProcessor);
    }
}