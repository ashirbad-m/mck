package com.mckesson.core.rest;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.audit.AuditService;
import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.CoreEvent;
import com.mckesson.core.service.CoreProcessor;
import com.mckesson.core.service.GatewayProcessor;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

class RestProcessorControllerTest {

    @Test
    void processEvent() {
        var coreProcessor = Mockito.mock(CoreProcessor.class);
        var gatewayProcessor = Mockito.mock(GatewayProcessor.class);

        var instance = new RestProcessorController(coreProcessor, gatewayProcessor);

        var coreEvent = CoreEvent.builder()
                .metrics(new ArrayList<>())
                .build();
        Assertions.assertEquals(ResponseEntity.ok().build(), instance.processEvent(coreEvent));

        Mockito.verify(gatewayProcessor).processEvent(Mockito.eq(coreEvent));
        Mockito.verifyNoMoreInteractions(coreProcessor, gatewayProcessor);
    }

    @Test
    void processAllEvent() {
        var coreProcessor = Mockito.mock(CoreProcessor.class);
        var gatewayProcessor = Mockito.mock(GatewayProcessor.class);

        var instance = new RestProcessorController(coreProcessor, gatewayProcessor);

        var coreEvent = CoreEvent.builder()
                .metrics(new ArrayList<>())
                .build();
        Assertions.assertEquals(ResponseEntity.ok().build(), instance.processAllEvent(coreEvent));

        Mockito.verify(coreProcessor).logEvent(Mockito.eq(coreEvent));
        Mockito.verifyNoMoreInteractions(coreProcessor, gatewayProcessor);
    }

    @Test
    void processFinalizerEvent() {
        var coreProcessor = Mockito.mock(CoreProcessor.class);
        var gatewayProcessor = Mockito.mock(GatewayProcessor.class);

        var instance = new RestProcessorController(coreProcessor, gatewayProcessor);

        var coreEvent = CoreEvent.builder()
                .metrics(new ArrayList<>())
                .build();
        Assertions.assertEquals(ResponseEntity.ok().build(), instance.processFinalizerEvent(coreEvent));

        Mockito.verify(coreProcessor).finalizeEvent(Mockito.eq(coreEvent));
        Mockito.verifyNoMoreInteractions(coreProcessor, gatewayProcessor);
    }
}