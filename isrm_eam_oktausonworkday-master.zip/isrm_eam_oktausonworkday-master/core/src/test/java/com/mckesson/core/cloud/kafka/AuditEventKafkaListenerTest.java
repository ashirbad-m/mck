package com.mckesson.core.cloud.kafka;

import com.mckesson.common.model.AuditEvent;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.UUID;

class AuditEventKafkaListenerTest {

    @Test
    void logEvent() {
        var instance = new AuditEventKafkaListener();

        var auditEvent = AuditEvent.builder()
                .date(new Date())
                .app(AuditEvent.Application.OKTA)
                .oktaUserId(UUID.randomUUID().toString())
                .message(UUID.randomUUID().toString())
                .situation(UUID.randomUUID().toString())
                .build();
        instance.logEvent(auditEvent);
    }
}