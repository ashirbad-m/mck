package com.mckesson.core.cloud.rabbit;

import com.mckesson.common.domain.PassportAction;
import com.mckesson.core.service.CoreProcessor;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class PassportActionRabbitListenerTest {

    @Test
    void finalizeAction() {
        var coreProcessor = Mockito.mock(CoreProcessor.class);
        var instance = new PassportActionRabbitListener(coreProcessor);

        var passportAction = new PassportAction();
        passportAction.setEventType(PassportAction.EventTypeEnum.POWERSHELL);
        instance.finalizeAction(passportAction);

        Mockito.verify(coreProcessor).finalizeAction(Mockito.eq(passportAction));
        Mockito.verifyNoMoreInteractions(coreProcessor);
    }

    @Test
    void logAction() {
        var coreProcessor = Mockito.mock(CoreProcessor.class);
        var instance = new PassportActionRabbitListener(coreProcessor);

        var passportAction = new PassportAction();
        passportAction.setEventType(PassportAction.EventTypeEnum.POWERSHELL);
        instance.logAction(passportAction);

        Mockito.verify(coreProcessor).logAction(Mockito.eq(passportAction));
        Mockito.verifyNoMoreInteractions(coreProcessor);
    }
}