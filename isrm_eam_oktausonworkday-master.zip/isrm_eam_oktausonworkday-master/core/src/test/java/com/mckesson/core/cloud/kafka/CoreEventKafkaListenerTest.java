package com.mckesson.core.cloud.kafka;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.core.cloud.rabbit.CoreEventRabbitListener;
import com.mckesson.core.service.CoreProcessor;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class CoreEventKafkaListenerTest {

    @Test
    void logEvent() {
        var coreProcessor = Mockito.mock(CoreProcessor.class);
        var instance = new CoreEventKafkaListener(coreProcessor);

        var coreEvent = CoreEvent.builder()
                .metrics(new ArrayList<>())
                .build();
        instance.logEvent(coreEvent);

        Mockito.verify(coreProcessor).logEvent(Mockito.eq(coreEvent));
        Mockito.verifyNoMoreInteractions(coreProcessor);
    }

    @Test
    void finalizeEvent() {
        var coreProcessor = Mockito.mock(CoreProcessor.class);
        var instance = new CoreEventKafkaListener(coreProcessor);

        var coreEvent = CoreEvent.builder()
                .metrics(new ArrayList<>())
                .build();
        instance.finalizeEvent(coreEvent);

        Mockito.verify(coreProcessor).finalizeEvent(Mockito.eq(coreEvent));
        Mockito.verifyNoMoreInteractions(coreProcessor);
    }
}