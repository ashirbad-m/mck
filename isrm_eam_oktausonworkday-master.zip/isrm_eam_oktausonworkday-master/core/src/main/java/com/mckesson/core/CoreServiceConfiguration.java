package com.mckesson.core;

import org.springframework.context.annotation.Configuration;

@Configuration
public class CoreServiceConfiguration {
}
