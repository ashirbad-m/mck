package com.mckesson.core.repository;

import com.mckesson.core.model.ExecutionTimePassport;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * Provides access to DB data (execution time information)
 */
@Repository
public interface ExecutionTimeRepository extends CrudRepository<ExecutionTimePassport, String> {
}
