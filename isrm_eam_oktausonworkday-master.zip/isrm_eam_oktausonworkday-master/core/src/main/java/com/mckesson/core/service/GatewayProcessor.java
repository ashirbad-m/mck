package com.mckesson.core.service;

import com.mckesson.common.AbstractCoreEventProcessor;
import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.dao.CoreEventDao;
import com.mckesson.common.domain.OktaUser;
import com.mckesson.common.model.*;
import com.mckesson.common.scenario.ScenarioProvider;
import com.mckesson.common.workday.configuration.controller.ConfigurationClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Processes CoreEvent and updated it with Configuration data
 */
@Service
@Slf4j
public class GatewayProcessor extends AbstractCoreEventProcessor {

    private final Map<ScenarioEnum, Consumer<CoreEvent>> processors = Arrays.stream(ScenarioEnum.values())
            .collect(Collectors.toMap(Function.identity(), entry -> this::onCoreEvent));
    private final CoreEventDao coreEventDao;
    private final ConfigurationClient configurationClient;

    public GatewayProcessor(ScenarioProvider scenarioProvider, MessageBrokerPublisher messageBrokerPublisher,
                            CoreEventDao coreEventDao, ConfigurationClient configurationClient) {
        super(scenarioProvider, messageBrokerPublisher, ModuleEnum.GATEWAY);
        this.coreEventDao = coreEventDao;
        this.configurationClient = configurationClient;
    }

    @Override
    protected Map<ScenarioEnum, Consumer<CoreEvent>> getProcessors() {
        return processors;
    }

    private void onCoreEvent(CoreEvent event) {
        event = setConfigs(event);
        coreEventDao.create(event);
    }

    private CoreEvent setConfigs(CoreEvent event) {
        OktaUser oktaUser = event.getNextOktaUser();
        if (oktaUser == null) {
            oktaUser = event.getPrevOktaUser();
        }
        if (oktaUser != null) {
            HrbuConfig hrbuConfig = configurationClient.findHrbuConfig(oktaUser.getHrbu(), oktaUser.getCity(), oktaUser.getStreetAddress());
            DomainConfig domainConfig = configurationClient.findDomainConfig(hrbuConfig);
            event.setHrbuConfig(hrbuConfig);
            event.setDomainConfig(domainConfig);
            if (event.getPrevOktaUser() != null) {
                event.getPrevOktaUser().setDomain(domainConfig.getName());
            }
            if (event.getNextOktaUser() != null) {
                event.getNextOktaUser().setDomain(domainConfig.getName());
            }
            return event;
        } else {
            throw new IllegalStateException();
        }
    }
}
