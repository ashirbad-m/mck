package com.mckesson.core.cloud.stream;

import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.workday.converter.ConverterUtils;
import com.mckesson.core.service.CoreProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/**
 * Spring Streams listener for PassportActions
 */
@Service
@RequiredArgsConstructor
@Profile("stream")
@Slf4j
public class PassportActionStreamListener {
    private final CoreProcessor coreProcessor;

    /**
     * Remove processed passport action
     *
     * @param action passport action
     */
    @StreamListener(target = Processor.INPUT, condition = "headers['module']==T(com.mckesson.common.model.ModuleEnum).FINALIZER.name() && headers['class']=='com.mckesson.common.domain.PassportAction'")
    public void finalizeAction(final PassportAction action) {
        log.info("Finalize passport action:" + ConverterUtils.writeValueAsString(action));
        coreProcessor.finalizeAction(action);
    }

    /**
     * Update passport action state (Logs all passport actions)
     *
     * @param action passport action
     */
    @StreamListener(target = Processor.INPUT, condition = "headers['module']==T(com.mckesson.common.model.ModuleEnum).ALL.name() && headers['class']=='com.mckesson.common.domain.PassportAction'")
    public void logAction(final PassportAction action) {
        log.info("'All' listener for a passport action:" + ConverterUtils.writeValueAsString(action));
        coreProcessor.logAction(action);
    }
}
