package com.mckesson.core.cloud.rabbit;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.core.service.CoreProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/**
 * RabbitMQ listener for CoreEvents
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Profile("rabbit")
public class CoreEventRabbitListener {

    private final CoreProcessor coreProcessor;

    /**
     * Update event state (Logs all events)
     *
     * @param event core event
     */
    @RabbitListener(queues = "${rabbit.exchange}.ALL")
    public void logEvent(CoreEvent event) {
        coreProcessor.logEvent(event);
    }

    /**
     * Remove processed event
     *
     * @param event core event
     */
    @RabbitListener(queues = "${rabbit.exchange}.FINALIZER")
    public void finalizeEvent(CoreEvent event) {
        coreProcessor.finalizeEvent(event);
    }
}
