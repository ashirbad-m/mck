package com.mckesson.core.cloud.stream;

import com.mckesson.common.model.AuditEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/**
 * Spring streams listener for AuditEvent
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Profile("stream")
public class AuditEventStreamListener {

    /**
     * Update audit event state
     *
     * @param event audit event
     */
    @StreamListener(target = Processor.INPUT, condition = "headers['module']==T(com.mckesson.common.model.ModuleEnum).ALL.name() && headers['class']=='com.mckesson.common.model.AuditEvent'")
    public void logEvent(final AuditEvent event) {
        //log.trace("Incoming audit event: {}", ConverterUtils.writeValueAsString(event));
    }
}
