package com.mckesson.core.model;

import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.model.ExecutionMetric;
import com.mckesson.common.workday.converter.ConverterUtils;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.*;

/**
 * Defines structure to keep information about steps execution
 */
@Entity
@Table(name = "execution_time_passport")
@Data
public class ExecutionTimePassport implements Serializable {

    @Id
    @GeneratedValue
    private Long rowId;
    private String batchId;
    private String eventId;
    private String flowName;
    private String module;
    private String className;
    @Temporal(TemporalType.TIMESTAMP)
    private Date startTime;
    @Temporal(TemporalType.TIMESTAMP)
    private Date endTime;
    private long executionTime;
    private long delay;

    public static List<ExecutionTimePassport> fromCoreEvent(CoreEvent coreEvent) {
        String eventId = coreEvent.getId();
        String batchId = coreEvent.getBatchId();
        String flowName = coreEvent.getTarget() + "/" + coreEvent.getScenario().getName() + "/" + coreEvent.getStage();
        return from(eventId, batchId, flowName, coreEvent.getMetrics());
    }

    public static List<ExecutionTimePassport> fromPassportAction(PassportAction action) {
        PassportAction.CommonEventBody eventBody = ConverterUtils.readSimpleJson(action.getEventBody(), PassportAction.CommonEventBody.class, null);
        String eventId = eventBody.getEventId();
        String batchId = eventBody.getBatchId();
        String flowName = action.getClass().getSimpleName() + ":" + action.getEventType().getName();
        return from(eventId, batchId, flowName, action.getMetrics());
    }

    private static List<ExecutionTimePassport> from(String eventId, String batchId, String flowName, List<ExecutionMetric> metrics) {
        List<ExecutionTimePassport> result = new ArrayList<>(metrics.size());

        ExecutionMetric prev = null;

        Collections.sort(metrics, Comparator.comparing(ExecutionMetric::getStart));
        for (ExecutionMetric item : metrics) {
            long delay = 0;
            if (prev != null) {
                delay = item.getStart().getTime() - prev.getEnd().getTime();
            }
            ExecutionTimePassport et = new ExecutionTimePassport();
            et.setEventId(eventId);
            et.setBatchId(batchId);
            et.setFlowName(flowName);
            et.setModule(item.getModule().name());
            et.setClassName(item.getClassName());
            et.setStartTime(item.getStart());
            et.setEndTime(item.getEnd());
            et.setExecutionTime(item.getEnd().getTime() - item.getStart().getTime());
            et.setDelay(delay);
            result.add(et);

            prev = item;
        }
        return result;
    }
}

