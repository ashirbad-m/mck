package com.mckesson.core.cloud.stream;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.core.service.CoreProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/**
 * Spring Streams listener for CoreEvents
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Profile("stream")
public class CoreEventStreamListener {

    private final CoreProcessor coreProcessor;

    /**
     * Remove processed event
     *
     * @param event
     */
    @StreamListener(target = Processor.INPUT, condition = "headers['module']==T(com.mckesson.common.model.ModuleEnum).FINALIZER.name() && headers['class']=='com.mckesson.common.model.CoreEvent'")
    public void finalizeEvent(final CoreEvent event) {
        coreProcessor.finalizeEvent(event);
    }

    /**
     * Update event state (Logs all events)
     *
     * @param event core event
     */
    @StreamListener(target = Processor.INPUT, condition = "headers['module']==T(com.mckesson.common.model.ModuleEnum).ALL.name() && headers['class']=='com.mckesson.common.model.CoreEvent'")
    public void logEvent(final CoreEvent event) {
        coreProcessor.logEvent(event);
    }
}
