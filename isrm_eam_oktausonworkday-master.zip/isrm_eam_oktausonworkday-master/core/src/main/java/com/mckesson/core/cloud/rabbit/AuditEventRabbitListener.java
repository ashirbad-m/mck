package com.mckesson.core.cloud.rabbit;

import com.mckesson.common.model.AuditEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/**
 * RabbitMQ listener for AuditEvents
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Profile("rabbit")
public class AuditEventRabbitListener {

    /**
     * Update audit event state
     *
     * @param event audit event
     */
    @RabbitListener(queues = "${rabbit.exchange}.FINALIZER")
    public void logEvent(final AuditEvent event) {
        //log.trace("Incoming audit event: {}", ConverterUtils.writeValueAsString(event));
    }
}
