package com.mckesson.core.service;

import com.mckesson.common.dao.CoreEventDao;
import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.workday.converter.ConverterUtils;
import com.mckesson.core.model.ExecutionTimePassport;
import com.mckesson.core.repository.ExecutionTimeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class CoreProcessor {

    private final CoreEventDao coreEventDao;
    private final ExecutionTimeRepository executionTimeRepository;

    /**
     * Update event state (Logs all events)
     *
     * @param event core event
     */
    public void logEvent(CoreEvent event) {
        coreEventDao.update(event);
    }

    /**
     * Remove processed event
     *
     * @param event core event
     */
    public void finalizeEvent(CoreEvent event) {
        executionTimeRepository.saveAll(ExecutionTimePassport.fromCoreEvent(event));
        coreEventDao.delete(event);
    }

    /**
     * Update passport action state (Logs all passport actions)
     *
     * @param action passport action
     */
    public void logAction(PassportAction action) {
        log.debug("Processing task:\n{}", ConverterUtils.writeValueAsString(action));
    }

    /**
     * Remove processed passport action
     *
     * @param action passport action
     */
    public void finalizeAction(PassportAction action) {
        executionTimeRepository.saveAll(ExecutionTimePassport.fromPassportAction(action));
    }
}
