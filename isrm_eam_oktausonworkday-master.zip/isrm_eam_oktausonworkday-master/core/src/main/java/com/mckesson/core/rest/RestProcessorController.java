package com.mckesson.core.rest;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.core.service.CoreProcessor;
import com.mckesson.core.service.GatewayProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/gateway")
@Slf4j
@RequiredArgsConstructor
@ConditionalOnProperty(name = "rest.controller.enabled", havingValue = "true")
public class RestProcessorController {

    private final CoreProcessor coreProcessor;
    private final GatewayProcessor gatewayProcessor;

    @PostMapping("/process")
    public ResponseEntity<Object> processEvent(@RequestBody CoreEvent event) {
        gatewayProcessor.processEvent(event);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/process/all")
    public ResponseEntity<Object> processAllEvent(@RequestBody CoreEvent event) {
        coreProcessor.logEvent(event);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/process/finalizer")
    public ResponseEntity<Object> processFinalizerEvent(@RequestBody CoreEvent event) {
        coreProcessor.finalizeEvent(event);
        return ResponseEntity.ok().build();
    }
}
