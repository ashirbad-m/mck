package com.mckesson.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.mckesson.core", "com.mckesson.common", "com.mckesson.common.workday.converter"})
public class CoreServiceApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(CoreServiceApplication.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(CoreServiceApplication.class, args);
    }
}
