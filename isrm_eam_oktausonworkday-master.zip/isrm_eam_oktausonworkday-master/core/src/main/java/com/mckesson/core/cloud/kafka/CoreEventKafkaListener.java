package com.mckesson.core.cloud.kafka;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.workday.converter.ConverterUtils;
import com.mckesson.core.service.CoreProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

/**
 * Kafka listener for CoreEvents
 */
@Service
@Slf4j
@Profile("kafka")
@RequiredArgsConstructor
public class CoreEventKafkaListener {

    private final CoreProcessor coreProcessor;

    /**
     * Update event state (Logs all events)
     *
     * @param event core event
     */
    @KafkaListener(topics = "${kafka.topic.prefix}.ALL")
    public void logEvent(final CoreEvent event) {
        log.debug("Event:\n{}", ConverterUtils.writeValueAsString(event));
        coreProcessor.logEvent(event);
    }

    /**
     * Remove processed event
     *
     * @param event core event
     */
    @KafkaListener(topics = "${kafka.topic.prefix}.FINALIZER")
    public void finalizeEvent(final CoreEvent event) {
        log.debug("finalizeEvent:\n{}", ConverterUtils.writeValueAsString(event));
        coreProcessor.finalizeEvent(event);
    }
}
