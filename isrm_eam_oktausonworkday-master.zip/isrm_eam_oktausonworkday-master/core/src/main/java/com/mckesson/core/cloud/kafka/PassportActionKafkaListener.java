package com.mckesson.core.cloud.kafka;

import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.workday.converter.ConverterUtils;
import com.mckesson.core.service.CoreProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

/**
 * Kafka listener for PassportActions
 */
@Service
@Slf4j
@Profile("kafka")
@RequiredArgsConstructor
public class PassportActionKafkaListener {

    private final CoreProcessor coreProcessor;

    /**
     * Remove processed passport action
     *
     * @param action passport action
     */
    @KafkaListener(topics = "${kafka.topic.prefix}.FINALIZER")
    public void finalizeAction(final PassportAction action) {
        log.info("Finalize passport action:" + ConverterUtils.writeValueAsString(action));
        coreProcessor.finalizeAction(action);
    }

    /**
     * Update passport action state (Logs all passport actions)
     *
     * @param action passport action
     */
    @KafkaListener(topics = "${kafka.topic.prefix}.ALL")
    public void logAction(final PassportAction action) {
        log.info("'All' listener for a passport action:" + ConverterUtils.writeValueAsString(action));
        coreProcessor.logAction(action);
    }
}
