package com.mckesson.core.rest;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.audit.AuditService;
import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.model.ExecutionMetric;
import com.mckesson.common.model.ModuleEnum;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * Controller to accept request from SCIM connector
 */
@RestController
@RequestMapping("/gateway")
@Slf4j
@RequiredArgsConstructor
public class RestGatewayController {

    private final MessageBrokerPublisher messageBrokerPublisher;
    private final AuditService auditService;
    private final static ModuleEnum MODULE = ModuleEnum.GATEWAY;

    /**
     * Accepts CoreEvent for processing on passport side
     * @param coreEvent core event
     */
    @PostMapping("/on-core-event")
    public void onCoreEvent(@RequestBody CoreEvent coreEvent) {
        Date start = new Date();
        coreEvent.setModule(MODULE);
        coreEvent.getMetrics().add(new ExecutionMetric(MODULE, getClass(), start));
        messageBrokerPublisher.send(coreEvent.getModule(), coreEvent);
    }

    /**
     * Accepts PassportAction for processing on passport side
     * @param passportAction passport action
     */
    @PostMapping("/on-passport-action")
    public void onPassportAction(@RequestBody PassportAction passportAction) {
        Date start = new Date();
        ModuleEnum module = passportAction.getEventType().getModule();
        passportAction.getMetrics().add(new ExecutionMetric(MODULE, getClass(), start));
        messageBrokerPublisher.send(module, passportAction);
    }

    /**
     * Accepts AuditEvent for processing on passport side
     * @param auditEvent audit event
     */
    @PostMapping("/on-audit-event")
    public void onAuditEvent(@RequestBody AuditEvent auditEvent) {
        auditService.audit(auditEvent);
    }
}
