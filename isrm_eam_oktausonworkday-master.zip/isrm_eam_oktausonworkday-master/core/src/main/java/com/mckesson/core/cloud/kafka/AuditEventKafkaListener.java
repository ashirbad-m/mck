package com.mckesson.core.cloud.kafka;

import com.mckesson.common.model.AuditEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

/**
 * Kafka listener for AuditEvents
 */
@Service
@Slf4j
@Profile("kafka")
@RequiredArgsConstructor
public class AuditEventKafkaListener {

    /**
     * Update audit event state
     *
     * @param event audit event
     */
    @KafkaListener(topics = "${kafka.topic.prefix}.FINALIZER")
    public void logEvent(final AuditEvent event) {
        //log.trace("Incoming audit event: {}", ConverterUtils.writeValueAsString(event));
    }
}
