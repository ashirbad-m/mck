package com.mckesson.core.cloud.rabbit;

import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.workday.converter.ConverterUtils;
import com.mckesson.core.service.CoreProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/**
 * RabbitMQ listener for PassportActions
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Profile("rabbit")
public class PassportActionRabbitListener {

    private final CoreProcessor coreProcessor;

    /**
     * Update passport action state (Logs all passport actions)
     *
     * @param action passport action
     */
    @RabbitListener(queues = "${rabbit.exchange}.ALL")
    public void logAction(final PassportAction action) {
        log.info("'All' listener for a passport action:" + ConverterUtils.writeValueAsString(action));
        coreProcessor.logAction(action);
    }

    /**
     * Remove processed event
     *
     * @param action core event
     */
    @RabbitListener(queues = "${rabbit.exchange}.FINALIZER")
    public void finalizeAction(final PassportAction action) {
        log.info("Finalize passport action:" + ConverterUtils.writeValueAsString(action));
        coreProcessor.finalizeAction(action);
    }
}
