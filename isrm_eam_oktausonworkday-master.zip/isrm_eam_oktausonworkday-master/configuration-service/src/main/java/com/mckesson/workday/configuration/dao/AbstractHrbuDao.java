package com.mckesson.workday.configuration.dao;

import com.mckesson.common.workday.converter.LdapNameConverter;
import com.mckesson.common.workday.converter.SetOfStringConverter;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.ColumnTransformer;

import javax.naming.ldap.LdapName;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.MappedSuperclass;
import java.util.Set;

@MappedSuperclass
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public abstract class AbstractHrbuDao {

    @Column(length = 255)
    @Convert(converter = LdapNameConverter.class)
    LdapName ou;

    @Column(length = 255)
    String homeDrive;

    @Column(length = 255)
    String homeDir;

    @Column(length = 255)
    String loginScript;

    @Column(name = "employee_groups", columnDefinition = "TEXT")
    @Convert(converter = SetOfStringConverter.class)
    Set<String> groups;

    @Column(columnDefinition = "TEXT")
    @Convert(converter = SetOfStringConverter.class)
    Set<String> contractorGroups;

    @Column(columnDefinition = "TEXT", name = "contingentworkertype_outside_worker_groups")
    @Convert(converter = SetOfStringConverter.class)
    Set<String> outsideWorkerGroups;

    @Column(columnDefinition = "TEXT", name="contingentworkertype_x_groups")
    @Convert(converter = SetOfStringConverter.class)
    Set<String> extGroups;

    @Column
    @ColumnTransformer(read = "IFNULL(active_sync, 0)")
    Boolean activeSync;

    @Column(length = 255)
    String itcMail;
}
