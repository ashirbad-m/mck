package com.mckesson.workday.configuration.repository;

import com.mckesson.workday.configuration.dao.HrbuDao;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface HrbuRepository extends CrudRepository<HrbuDao, String> {
    /**
     * Finds HrbuDaos by hrbu
     *
     * @param hrbu hrbu value
     * @return found HrbuDao or null
     */
    Optional<HrbuDao> findByHrbu(String hrbu);

    /**
     * Delete HrbuDao by hrbu
     *
     * @param hrbu hrbu value
     */
    void deleteByHrbu(String hrbu);
}
