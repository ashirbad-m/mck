package com.mckesson.workday.configuration.dao;

import com.mckesson.common.workday.converter.SetOfStringConverter;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Set;

@Entity(name="global")
@Data
@EqualsAndHashCode(of = { "id" })
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class GlobalDao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column(columnDefinition = "TEXT")
    @Convert(converter = SetOfStringConverter.class)
    Set<String> preventLoaJobCodes;

    @Column(columnDefinition = "TEXT")
    @Convert(converter = SetOfStringConverter.class)
    Set<String> suppressHrbuTransfer;

    @Column(columnDefinition = "TEXT")
    @Convert(converter = SetOfStringConverter.class)
    Set<String> suppressClinicalTransfer;

    @Column(length = 255)
    String mckessonHrbu;

    @Column(columnDefinition = "TEXT")
    @Convert(converter = SetOfStringConverter.class)
    Set<String> texasHrbus;

}
