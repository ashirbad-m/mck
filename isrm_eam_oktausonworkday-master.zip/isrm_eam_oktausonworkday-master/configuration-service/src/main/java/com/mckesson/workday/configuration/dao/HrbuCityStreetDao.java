package com.mckesson.workday.configuration.dao;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import javax.naming.ldap.LdapName;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Set;

@Entity(name="hrbu_city_street")
@Data
@EqualsAndHashCode(of = { "id" }, callSuper = false)
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class HrbuCityStreetDao extends AbstractHrbuDao{

    @Builder
    public HrbuCityStreetDao(
        //<editor-fold desc="super">
        LdapName ou,
        String homeDrive,
        String homeDir,
        String loginScript,
        Set<String> groups,
        Set<String> contractorGroups,
        Set<String> outsideWorkerGroups,
        Set<String> extGroups,
        boolean activeSync,
        String itcMail,
        //</editor-fold>

        //<editor-fold desc="this">
        Long id,
        String city,
        String street
        //</editor-fold>
    ) {
        super(
            ou, homeDrive, homeDir, loginScript,
            groups, contractorGroups, outsideWorkerGroups, extGroups,
            activeSync, itcMail
        );

        this.id = id;
        this.city = city;
        this.street = street;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column(length = 38)
    String city;

    @Column(length = 38)
    String street;

}
