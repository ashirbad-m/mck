package com.mckesson.workday.configuration;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
public class ConfigurationServiceConfiguration {
    // TODO: We do not have second AD in our DEV environment, so we hve to disable the second domain from our configuraiton
    @Value("${temporary.excluded.domain}")
    String temporaryExcludedDomain;
}
