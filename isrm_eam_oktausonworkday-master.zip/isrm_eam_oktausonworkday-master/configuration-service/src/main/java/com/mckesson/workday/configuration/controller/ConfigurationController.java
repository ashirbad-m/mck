package com.mckesson.workday.configuration.controller;

import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.HrbuConfig;
import com.mckesson.common.model.WorkdayConfig;
import com.mckesson.common.security.VeracodeUtils;
import com.mckesson.common.workday.configuration.ConfigurationService;
import com.mckesson.common.workday.configuration.dto.GroupMappingDto;
import com.mckesson.common.workday.configuration.dto.GroupMappingType;
import com.mckesson.common.workday.configuration.dto.HrbuCityStreetDto;
import com.mckesson.common.workday.configuration.dto.HrbuDto;
import com.mckesson.common.workday.configuration.dto.request.DomainConfigRequest;
import com.mckesson.common.workday.configuration.dto.request.GroupMappingRequest;
import com.mckesson.common.workday.configuration.dto.request.HrbuViewRequest;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static com.mckesson.common.workday.configuration.controller.ConfigurationControllerConstants.*;

/**
 * REST API provides environment configuration
 */
@RestController
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Slf4j
public class ConfigurationController {

    final ConfigurationService service;

    //<editor-fold desc="global">
    @GetMapping(ALL_GLOBALS)
    public ResponseEntity<List<WorkdayConfig>> getAllGlobals() {
        final List<WorkdayConfig> result = service.getAllGlobals();
        log.trace("getAllGlobals:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @GetMapping(SINGLE_GLOBAL)
    public ResponseEntity<WorkdayConfig> findSingleGlobal() {
        final WorkdayConfig result = service.findGlobalConfig();
        log.trace("findSingleGlobal:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @GetMapping(GET_GLOBAL + "{id}")
    public ResponseEntity<WorkdayConfig> findGlobalById(@PathVariable final Long id) {
        final WorkdayConfig result = service.findGlobalById(id);
        log.trace("findGlobalById:\n {}", result);
        return ResponseEntity.ok(result);
    }

    /*@PutMapping(SAVE_GLOBAL)
    public ResponseEntity<WorkdayConfig> saveGlobal(@RequestBody final WorkdayConfig globalDto) {
        log.trace("saveGlobal=before:\n {}", globalDto);
        final WorkdayConfig result = service.saveGlobal(globalDto);
        log.trace("saveGlobal=after:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @DeleteMapping(DELETE_GLOBAL + "{id}")
    public ResponseEntity<Boolean> deleteGlobal(@PathVariable final Long id) {
        log.trace("deleteGlobal=before:\n {}", id);
        service.deleteGlobal(id);
        log.trace("saveGlobal=after finished:\n {}", id);
        return ResponseEntity.ok(true);
    }*/
    //</editor-fold>

    //<editor-fold desc="group_mapping">
    @GetMapping(ALL_GROUP_MAPPINGS)
    public ResponseEntity<List<GroupMappingDto>> getAllGroupMappings() {
        final List<GroupMappingDto> result = service.getAllGroupMappings();
        log.trace("getAllGlobals:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @GetMapping(GET_GROUP_MAPPING + "{id}")
    public ResponseEntity<GroupMappingDto> findGroupMappingById(@PathVariable final Long id) {
        final GroupMappingDto result = service.findGroupMappingById(id);
        log.trace("findGroupMappingById:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @GetMapping(GET_GROUP_MAPPING_BY_NAME)
    public ResponseEntity<GroupMappingDto> findGroupMappingByName(@PathVariable final String name) {
        final GroupMappingDto result = service.findGroupMappingByName(VeracodeUtils.encode4java(name));
        log.trace("findGroupMappingById:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @PostMapping(FIND_GROUP_MAPPINGS_BY_NAMES)
    public ResponseEntity<List<GroupMappingDto>> findGroupMappingsByNames(@RequestBody final Collection<String> names) {
        final List<GroupMappingDto> result = service.findGroupMappingsByNames(names.stream().map(VeracodeUtils::encode4java)
                .collect(Collectors.toList()));
        log.trace("findGroupMappingsByNames:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @PostMapping(FIND_GROUP_MAPPINGS_BY_OKTA_CNS)
    public ResponseEntity<List<GroupMappingDto>> findGroupMappingsByOktaCns(@RequestBody final Collection<String> oktaCns) {
        final List<GroupMappingDto> result = service.findGroupMappingsByOktaCns(oktaCns.stream().map(VeracodeUtils::encode4java)
                .collect(Collectors.toList()));
        log.trace("findGroupMappingsByOktaCns:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @GetMapping(FIND_GROUP_MAPPINGS_BY_TYPE)
    public ResponseEntity<List<GroupMappingDto>> findGroupMappingsByType(@PathVariable final GroupMappingType type) {
        final List<GroupMappingDto> result = service.findGroupMappingsByType(type);
        log.trace("findGroupMappingsByType:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @PostMapping(FIND_GROUP_MAPPINGS_BY_NAMES_AND_TYPE)
    public ResponseEntity<List<GroupMappingDto>> findGroupMappingsByNamesAndType(@RequestBody final GroupMappingRequest request) {
        final List<GroupMappingDto> result = service.findGroupMappingsByNameInAndType(request);
        log.trace("findGroupMappingsByNamesAndType:\n {}", result);
        return ResponseEntity.ok(result);
    }

    /*@PutMapping(SAVE_GROUP_MAPPING)
    public ResponseEntity<GroupMappingDto> saveGroupMapping(@RequestBody final GroupMappingDto groupMappingDto) {
        log.trace("saveGroupMapping=before:\n {}", VeracodeUtils.encode4java(groupMappingDto.toString()));
        final GroupMappingDto result = service.saveGroupMapping(groupMappingDto);
        log.trace("saveGroupMapping=after:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @DeleteMapping(DELETE_GROUP_MAPPING + "{id}")
    public ResponseEntity<Boolean> deleteGroupMapping(@PathVariable final Long id) {
        log.trace("deleteGroupMapping=before:\n {}", id);
        service.deleteGroupMapping(id);
        log.trace("deleteGroupMapping=after finished:\n {}", id);
        return ResponseEntity.ok(true);
    }*/
    //</editor-fold>

    //<editor-fold desc="domains">
    @GetMapping(ALL_DOMAINS)
    public ResponseEntity<List<DomainConfig>> allDomainConfigs() {
        final List<DomainConfig> result = service.allDomainConfigs();
        log.trace("getAllDomains:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @GetMapping(GET_DOMAIN + "{id}")
    public ResponseEntity<DomainConfig> findDomainConfigById(@PathVariable final Long id) {
        final DomainConfig result = service.findDomainConfigById(id);
        log.trace("findDomainById:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @GetMapping(GET_DOMAIN_BY_NAME)
    public ResponseEntity<DomainConfig> findDomainConfigByName(@PathVariable final String name) {
        final DomainConfig result = service.findDomainConfigByName(VeracodeUtils.encode4java(name));
        log.trace("findDomainByName:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @PostMapping(FIND_DOMAIN)
    public ResponseEntity<DomainConfig> findDomainConfig(@RequestBody final DomainConfigRequest request) {
        log.trace("findDomainConfig-request:\n {}", VeracodeUtils.encode4java(request.toString()));
        final DomainConfig result = service.findDomainConfigByOu(request.getOu());
        log.trace("findDomainConfig-result:\n {}", result);
        return ResponseEntity.ok(result);
    }

    /*@PutMapping(SAVE_DOMAIN)
    public ResponseEntity<DomainConfig> saveDomainConfig(@RequestBody final DomainConfig domainsDto) {
        log.trace("saveDomain=before:\n {}", VeracodeUtils.encode4java(domainsDto.toString()));
        final DomainConfig result = service.saveDomainConfig(domainsDto);
        log.trace("saveDomain=after:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @DeleteMapping(DELETE_DOMAIN + "{id}")
    public ResponseEntity<Boolean> deleteDomainConfig(@PathVariable final Long id) {
        log.trace("deleteDomain=before:\n {}", id);
        service.deleteDomainConfig(id);
        log.trace("deleteDomain=after finished:\n {}", id);
        return ResponseEntity.ok(true);
    }*/
    //</editor-fold>

    //<editor-fold desc="hrbu">
    @GetMapping(ALL_HRBU)
    public ResponseEntity<List<HrbuDto>> getAllHrbu() {
        final List<HrbuDto> result = service.getAllHrbu();
        log.trace("getAllHrbu:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @GetMapping(GET_HRBU)
    public ResponseEntity<HrbuDto> findHrbuById(@PathVariable String hrbu) {
        hrbu = VeracodeUtils.encode4java(hrbu);
        final HrbuDto result = service.findHrbuByHrbu(hrbu);
        log.trace("findHrbuById:\n {}", result);
        return ResponseEntity.ok(result);
    }

    /*@PutMapping(SAVE_HRBU)
    public ResponseEntity<HrbuDto> saveHrbu(@RequestBody final HrbuDto hrbuDto) {
        log.trace("saveHrbu=before:\n {}", VeracodeUtils.encode4java(hrbuDto.toString()));
        final HrbuDto result = service.saveHrbu(hrbuDto);
        log.trace("saveHrbu=after:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @DeleteMapping(DELETE_HRBU + "{hrbu}")
    public ResponseEntity<Boolean> deleteHrbu(@PathVariable String hrbu) {
        hrbu = VeracodeUtils.encode4java(hrbu);
        log.trace("deleteHrbu=before:\n {}", hrbu);
        service.deleteHrbuByHrbu(hrbu);
        log.trace("deleteHrbu=after finished:\n {}", hrbu);
        return ResponseEntity.ok(true);
    }*/
    //</editor-fold>

    //<editor-fold desc="hrbu_city_street">
    @GetMapping(ALL_HRBU_CITY_STREET)
    public ResponseEntity<List<HrbuCityStreetDto>> getAllHrbuCityStreet() {
        final List<HrbuCityStreetDto> result = service.getAllHrbuCityStreet();
        log.trace("getAllHrbuCityStreet:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @GetMapping(GET_HRBU_CITY_STREET + "{id}")
    public ResponseEntity<HrbuCityStreetDto> findHrbuCityStreetById(@PathVariable final Long id) {
        final HrbuCityStreetDto result = service.findHrbuCityStreetById(id);
        log.trace("findHrbuCityStreetById:\n {}", result);
        return ResponseEntity.ok(result);
    }

    /*@PutMapping(SAVE_HRBU_CITY_STREET)
    public ResponseEntity<HrbuCityStreetDto> saveHrbuCityStreet(@RequestBody final HrbuCityStreetDto hrbuCityStreetDto) {
        log.trace("saveHrbuCityStreet=before:\n {}", VeracodeUtils.encode4java(hrbuCityStreetDto.toString()));
        final HrbuCityStreetDto result = service.saveHrbuCityStreet(hrbuCityStreetDto);
        log.trace("saveHrbuCityStreet=after:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @DeleteMapping(DELETE_HRBU_CITY_STREET + "{id}")
    public ResponseEntity<Boolean> deleteHrbuCityStreet(@PathVariable final Long id) {
        log.trace("deleteHrbuCityStreet=before:\n {}", id);
        service.deleteHrbuCityStreet(id);
        log.trace("deleteHrbuCityStreet=after finished:\n {}", id);
        return ResponseEntity.ok(true);
    }*/
    //</editor-fold>

    //<editor-fold desc="hrbu_view">
    @PostMapping(FIND_HRBU_CONFIG)
    public ResponseEntity<List<HrbuConfig>> findHrbuConfig(@RequestBody final HrbuViewRequest hrbuViewRequest) {
        log.trace("findHrbuView-request:\n {}", VeracodeUtils.encode4java(hrbuViewRequest.toString()));
        final List<HrbuConfig> result = service.findHrbuConfig(hrbuViewRequest);
        log.trace("findHrbuView-result:\n {}", result);
        return ResponseEntity.ok(result);
    }

    @GetMapping(ALL_HRBU_CONFIGS)
    public ResponseEntity<List<HrbuConfig>> getAllHrbuConfigs() {
        final List<HrbuConfig> result = service.getAllHrbuConfigs();
        log.trace("getAllHrbuConfigs:\n {}", result);
        return ResponseEntity.ok(result);
    }
    //</editor-fold>
}
