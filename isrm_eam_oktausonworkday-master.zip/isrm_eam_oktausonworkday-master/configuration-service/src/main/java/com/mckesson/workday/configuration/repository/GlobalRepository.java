package com.mckesson.workday.configuration.repository;

import com.mckesson.workday.configuration.dao.GlobalDao;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GlobalRepository extends PagingAndSortingRepository<GlobalDao, Long> {
}
