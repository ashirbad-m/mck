package com.mckesson.workday.configuration.service;

import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.HrbuConfig;
import com.mckesson.common.model.WorkdayConfig;
import com.mckesson.common.security.VeracodeUtils;
import com.mckesson.common.workday.configuration.ConfigurationService;
import com.mckesson.common.workday.configuration.dto.GroupMappingDto;
import com.mckesson.common.workday.configuration.dto.GroupMappingType;
import com.mckesson.common.workday.configuration.dto.HrbuCityStreetDto;
import com.mckesson.common.workday.configuration.dto.HrbuDto;
import com.mckesson.common.workday.configuration.dto.request.GroupMappingRequest;
import com.mckesson.common.workday.configuration.dto.request.HrbuViewRequest;
import com.mckesson.workday.configuration.ConfigurationServiceConfiguration;
import com.mckesson.workday.configuration.dao.HrbuViewDao;
import com.mckesson.workday.configuration.exception.ConfigurationException;
import com.mckesson.workday.configuration.repository.*;
import lombok.AccessLevel;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.naming.ldap.LdapName;
import javax.persistence.criteria.*;
import java.util.Collection;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.mckesson.common.workday.converter.ConverterUtils.nullableString;
import static com.mckesson.workday.configuration.dao.mapper.ConfigurationDaoMapper.CFG_MAPPER;

@Service
@Slf4j
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Transactional(readOnly = true)
public class ConfigurationServiceImpl implements ConfigurationService {

    private static final String LIKE_ANY = "%";
    private static final String HRBU = "hrbu";
    private static final String HRBU_CITY = "city";
    private static final String HRBU_STREET = "street";
    private static final String LONG_ID = "id";


    private static Expression<Boolean> nullSafeStringExpression(
            final Root<?> root,
            final CriteriaBuilder builder,
            final String fieldName,
            final Supplier<String> valueGetter,
            final BiFunction<Path<String>, String, Expression<Boolean>> notNullExpressionBuilder
    ) {
        final Path<String> path = root.get(fieldName);
        String value;
        Predicate pred = builder.isNull(path);
        if ((value = nullableString(valueGetter.get())) != null) {
            pred = builder.or(pred, notNullExpressionBuilder.apply(path, value));
        }
        return pred;
    }

    private static Expression<Boolean> paramLikeField(
            CriteriaBuilder criteriaBuilder,
            String paramValue,
            Path<String> fieldPath
    ) {
        return criteriaBuilder.like(
                criteriaBuilder.literal(paramValue.toUpperCase()),
                criteriaBuilder.concat(criteriaBuilder.concat(LIKE_ANY, criteriaBuilder.upper(fieldPath)), LIKE_ANY)
        );
    }

    final GlobalRepository globalRepository;
    final GroupMappingRepository groupMappingRepository;
    final DomainsRepository domainsRepository;
    final HrbuRepository hrbuRepository;
    final HrbuCityStreetRepository hrbuCityStreetRepository;
    final HrbuViewRepository hrbuViewRepository;
    final ConfigurationServiceConfiguration config;

    private Stream<WorkdayConfig> allGlobalsStream() {
        return StreamSupport.stream(
                globalRepository.findAll(Sort.by(Sort.Direction.ASC, LONG_ID)).spliterator(),
                false
        ).map(CFG_MAPPER::toGlobalDto);
    }

    //<editor-fold desc="global">
    @Override
    public List<WorkdayConfig> getAllGlobals() {
        return allGlobalsStream().collect(Collectors.toList());
    }

    @Override
    public WorkdayConfig findGlobalConfig() {
        return allGlobalsStream().findFirst().orElseThrow(() -> new ConfigurationException("Configuration not found"));
    }

    @Override
    public WorkdayConfig findGlobalById(@NonNull final Long id) {
        return globalRepository.findById(id).map(CFG_MAPPER::toGlobalDto).orElse(null);
    }

    /*@Override
    @Transactional
    public WorkdayConfig saveGlobal(@NonNull final WorkdayConfig globalDto) {
        return CFG_MAPPER.toGlobalDto(
                globalRepository.save(CFG_MAPPER.toGlobalDao(globalDto))
        );
    }

    @Override
    @Transactional
    public boolean deleteGlobal(@NonNull final Long id) {
        globalRepository.deleteById(id);
        return true;
    }*/
    //</editor-fold>

    //<editor-fold desc="group_mapping">
    @Override
    public List<GroupMappingDto> getAllGroupMappings() {
        return StreamSupport.stream(
                groupMappingRepository.findAll().spliterator(),
                false
        ).map(CFG_MAPPER::toGroupMappingDto).collect(Collectors.toList());
    }

    @Override
    public GroupMappingDto findGroupMappingById(@NonNull final Long id) {
        return groupMappingRepository.findById(id).map(CFG_MAPPER::toGroupMappingDto).orElse(null);
    }

    @Override
    public GroupMappingDto findGroupMappingByName(@NonNull final String name) {
        return groupMappingRepository.findByName(VeracodeUtils.encode4java(name)).map(CFG_MAPPER::toGroupMappingDto).orElse(null);
    }

    @Override
    public List<GroupMappingDto> findGroupMappingsByNames(@NonNull final Collection<String> names) {
        return groupMappingRepository.findByNameIn(names.stream().map(VeracodeUtils::encode4java).collect(Collectors.toList()))
                .stream().map(CFG_MAPPER::toGroupMappingDto).collect(Collectors.toList());
    }

    @Override
    public List<GroupMappingDto> findGroupMappingsByOktaCns(@NonNull final Collection<String> oktaCns) {
        return groupMappingRepository.findByOktaCnIn(oktaCns.stream().map(VeracodeUtils::encode4java).collect(Collectors.toList()))
                .stream().map(CFG_MAPPER::toGroupMappingDto).collect(Collectors.toList());
    }

    @Override
    public List<GroupMappingDto> findGroupMappingsByType(@NonNull final GroupMappingType type) {
        return groupMappingRepository.findByType(type).stream().map(CFG_MAPPER::toGroupMappingDto).collect(Collectors.toList());
    }

    @Override
    public List<GroupMappingDto> findGroupMappingsByNameInAndType(@NonNull final GroupMappingRequest groupMappingRequest) {
        return groupMappingRepository.findByNameInAndType(
                groupMappingRequest.getNames(), groupMappingRequest.getType()
        ).stream().map(CFG_MAPPER::toGroupMappingDto).collect(Collectors.toList());
    }

    /*@Override
    @Transactional
    public GroupMappingDto saveGroupMapping(@NonNull final GroupMappingDto groupMappingDto) {
        return CFG_MAPPER.toGroupMappingDto(
                groupMappingRepository.save(CFG_MAPPER.toGroupMappingDao(groupMappingDto))
        );
    }

    @Override
    @Transactional
    public boolean deleteGroupMapping(@NonNull final Long id) {
        groupMappingRepository.deleteById(id);
        return true;
    }*/
    //</editor-fold>

    //<editor-fold desc="domains">
    @Override
    public List<DomainConfig> allDomainConfigs() {
        return StreamSupport.stream(
                domainsRepository.findAll().spliterator(),
                false
        ).filter(dc -> !dc.getName().equalsIgnoreCase(config.getTemporaryExcludedDomain())).map(CFG_MAPPER::toDomainsDto).collect(Collectors.toList());
    }

    @Override
    public DomainConfig findDomainConfigById(@NonNull final Long id) {
        return domainsRepository.findById(id).map(CFG_MAPPER::toDomainsDto).orElse(null);
    }

    @Override
    public DomainConfig findDomainConfigByName(@NonNull final String name) {
        return domainsRepository.findByName(VeracodeUtils.encode4java(name)).map(CFG_MAPPER::toDomainsDto).orElse(null);
    }

    @Override
    public DomainConfig findDomainConfigByOu(@NonNull final LdapName ou) {
        return StreamSupport.stream(
                        domainsRepository.findAll().spliterator(),
                        false
                )
                .sorted((o1, o2) -> o2.getRootOu().size() - o1.getRootOu().size())
                .filter(d -> ou.startsWith(d.getRootOu()))
                .findFirst()
                .map(CFG_MAPPER::toDomainsDto)
                .orElseThrow(() -> new ConfigurationException(String.format("Domain Config not found. OU: %s", ou)));
    }

    /*@Override
    @Transactional
    public DomainConfig saveDomainConfig(@NonNull final DomainConfig domainDto) {
        return CFG_MAPPER.toDomainsDto(
                domainsRepository.save(CFG_MAPPER.toDomainsDao(domainDto))
        );
    }

    @Override
    @Transactional
    public boolean deleteDomainConfig(@NonNull final Long id) {
        domainsRepository.deleteById(id);
        return true;
    }*/
    //</editor-fold>

    //<editor-fold desc="hrbu">
    @Override
    public List<HrbuDto> getAllHrbu() {
        return StreamSupport.stream(
                hrbuRepository.findAll().spliterator(),
                false
        ).map(CFG_MAPPER::toHrbuDto).collect(Collectors.toList());
    }

    @Override
    public HrbuDto findHrbuByHrbu(@NonNull final String hrbu) {
        return hrbuRepository.findByHrbu(VeracodeUtils.encode4java(hrbu)).map(CFG_MAPPER::toHrbuDto).orElse(null);
    }

    /*@Override
    @Transactional
    public HrbuDto saveHrbu(@NonNull final HrbuDto hrbuDto) {
        return CFG_MAPPER.toHrbuDto(
                hrbuRepository.save(CFG_MAPPER.toHrbuDao(hrbuDto))
        );
    }

    @Override
    @Transactional
    public boolean deleteHrbuByHrbu(@NonNull final String hrbu) {
        hrbuRepository.deleteByHrbu(VeracodeUtils.encode4java(hrbu));
        return true;
    }*/
    //</editor-fold>

    //<editor-fold desc="hrbu_city_street">
    @Override
    public List<HrbuCityStreetDto> getAllHrbuCityStreet() {
        return StreamSupport.stream(
                hrbuCityStreetRepository.findAll().spliterator(),
                false
        ).map(CFG_MAPPER::toHrbuCityStreetDto).collect(Collectors.toList());
    }

    @Override
    public HrbuCityStreetDto findHrbuCityStreetById(@NonNull final Long id) {
        return hrbuCityStreetRepository.findById(id).map(CFG_MAPPER::toHrbuCityStreetDto).orElse(null);
    }

    /*@Override
    @Transactional
    public HrbuCityStreetDto saveHrbuCityStreet(@NonNull final HrbuCityStreetDto hrbuCityStreetDto) {
        return CFG_MAPPER.toHrbuCityStreetDto(
                hrbuCityStreetRepository.save(CFG_MAPPER.toHrbuCityStreetDao(hrbuCityStreetDto))
        );
    }

    @Override
    @Transactional
    public boolean deleteHrbuCityStreet(@NonNull final Long id) {
        hrbuCityStreetRepository.deleteById(id);
        return true;
    }*/
    //</editor-fold>

    //<editor-fold desc="hrbu_view">
    @Override
    public List<HrbuConfig> findHrbuConfig(@NonNull final HrbuViewRequest hrbuViewRequest) {
        Stream<HrbuViewDao> daoStream = hrbuViewRepository.findAll(
                (root, query, criteriaBuilder) -> criteriaBuilder.and(
                        criteriaBuilder.and(
                                criteriaBuilder.equal(root.get(HRBU), hrbuViewRequest.getHrbu().substring(0, 5)),
                                nullSafeStringExpression(root, criteriaBuilder, HRBU_CITY, hrbuViewRequest::getCity, criteriaBuilder::equal)
                        ),
                        nullSafeStringExpression(root, criteriaBuilder, HRBU_STREET, hrbuViewRequest::getStreet, (p, s) -> paramLikeField(criteriaBuilder, s, p))
                ),
                Sort.by(Sort.Order.asc(HRBU), Sort.Order.desc(HRBU_CITY), Sort.Order.desc(HRBU_STREET))
        ).stream();
        if (hrbuViewRequest.isFirstOnly()) {
            daoStream = daoStream.limit(1);
        }
        List<HrbuConfig> result = daoStream.map(CFG_MAPPER::toHrbuViewDto).collect(Collectors.toList());
        if (hrbuViewRequest.isFirstOnly() && result.isEmpty()) {
            throw new ConfigurationException("HRBU not found");
        }
        return result;
    }

    @Override
    public List<HrbuConfig> getAllHrbuConfigs() {
        return StreamSupport.stream(hrbuViewRepository.findAll().spliterator(), false)
                .map(CFG_MAPPER::toHrbuViewDto).collect(Collectors.toList());
    }
    //</editor-fold>
}
