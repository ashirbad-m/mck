package com.mckesson.workday.configuration.dao;

import com.mckesson.common.workday.configuration.dto.GroupMappingType;
import com.mckesson.common.workday.converter.LdapNameConverter;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.ColumnTransformer;

import javax.naming.ldap.LdapName;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="group_mapping")
@Data
@EqualsAndHashCode(of = { "id" })
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class GroupMappingDao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column(length = 255)
    String name;

    @Column(length = 255)
    @Convert(converter = LdapNameConverter.class)
    LdapName dn;

    @Column(columnDefinition = "ENUM('<someValues>')")
    @Enumerated(EnumType.STRING)
    @ColumnTransformer(read = "UPPER(type)", write = "LOWER(?)")
    GroupMappingType type;

    @Column(length = 255)
    String oktaCn;
}
