package com.mckesson.workday.configuration.exception;

/**
 * Defines exception thrown by configuration client
 */
public class ConfigurationException extends RuntimeException {
    private static final long serialVersionUID = 8451279138789923748L;

    public ConfigurationException(String message) {
        super(ConfigurationException.class.getSimpleName() + ": " + message);
    }
}
