package com.mckesson.workday.configuration.dao;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.ColumnTransformer;

import javax.naming.ldap.LdapName;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Set;

@Entity(name="hrbu")
@Data
@EqualsAndHashCode(of = { "hrbu" }, callSuper = false)
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
public class HrbuDao extends AbstractHrbuDao{

    @Builder
    public HrbuDao(
        //<editor-fold desc="super">
        LdapName ou,
        String homeDrive,
        String homeDir,
        String loginScript,
        Set<String> groups,
        Set<String> contractorGroups,
        Set<String> outsideWorkerGroups,
        Set<String> extGroups,
        boolean activeSync,
        String itcMail,
        //</editor-fold>

        //<editor-fold desc="this">
        String hrbu,
        boolean city,
        String mailSuffix,
        String secondaryMailSuffix,
        boolean enabled,
        boolean vantageLookupStrategy,
        boolean o365
        //</editor-fold>
    ) {
        super(
            ou, homeDrive, homeDir, loginScript,
            groups, contractorGroups, outsideWorkerGroups, extGroups,
            activeSync, itcMail
        );

        this.hrbu = hrbu;
        this.city = city;
        this.mailSuffix = mailSuffix;
        this.secondaryMailSuffix = secondaryMailSuffix;
        this.enabled = enabled;
        this.vantageLookupStrategy = vantageLookupStrategy;
        this.o365 = o365;
    }

    @Id
    @Column(length = 38)
    String hrbu;

    @Column
    @ColumnTransformer(read = "IFNULL(city, 0)")
    boolean city;

    @Column(length = 255)
    String mailSuffix;

    @Column(length = 255)
    String secondaryMailSuffix;

    @Column
    @ColumnTransformer(read = "IFNULL(enabled, 0)")
    boolean enabled;

    @Column
    @ColumnTransformer(read = "IFNULL(vantage_lookup_strategy, 0)")
    boolean vantageLookupStrategy;

    @Column
    @ColumnTransformer(read = "IFNULL(o365, 0)")
    boolean o365;
}
