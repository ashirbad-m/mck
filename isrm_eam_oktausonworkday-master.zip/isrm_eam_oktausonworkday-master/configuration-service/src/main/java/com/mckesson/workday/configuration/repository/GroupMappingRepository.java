package com.mckesson.workday.configuration.repository;

import com.mckesson.common.workday.configuration.dto.GroupMappingType;
import com.mckesson.workday.configuration.dao.GroupMappingDao;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface GroupMappingRepository extends CrudRepository<GroupMappingDao, Long> {
    /**
     * Finds GroupMappingDaos by names
     *
     * @param names collections of names
     * @return found GroupMappingDaos
     */
    List<GroupMappingDao> findByNameIn(Collection<String> names);

    /**
     * Finds GroupMappingDaos by OKTA CNs
     *
     * @param oktaCns OKTA CNs
     * @return fournd GroupMappingDaos
     */
    List<GroupMappingDao> findByOktaCnIn(Collection<String> oktaCns);

    /**
     * Finds GroupMappingDao by name
     *
     * @param name name
     * @return found GroupMappingDao or null
     */
    Optional<GroupMappingDao> findByName(String name);

    /**
     * Finds GroupMappingDaos by names and type
     *
     * @param names collection of names
     * @param type  type
     * @return found GroupMappingDaos
     */
    List<GroupMappingDao> findByNameInAndType(Collection<String> names, GroupMappingType type);

    /**
     * FindsGroupMappingDaos by type
     *
     * @param type type
     * @return found GroupMappingDaos
     */
    List<GroupMappingDao> findByType(GroupMappingType type);
}
