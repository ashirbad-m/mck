package com.mckesson.workday.configuration.dao;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.ColumnTransformer;

import javax.naming.ldap.LdapName;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Set;

@Entity(name="hrbu_view")
@Data
@EqualsAndHashCode(of = { "id" }, callSuper = false)
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
public class HrbuViewDao extends AbstractHrbuDao{

    @Builder
    public HrbuViewDao(
        //<editor-fold desc="super">
        LdapName ou,
        String homeDrive,
        String homeDir,
        String loginScript,
        Set<String> groups,
        Set<String> contractorGroups,
        Set<String> outsideWorkerGroups,
        Set<String> extGroups,
        boolean activeSync,
        String itcMail,
        //</editor-fold>

        //<editor-fold desc="hrbu">
        String hrbu,
        String mailSuffix,
        String secondaryMailSuffix,
        boolean enabled,
        boolean vantageLookupStrategy,
        boolean o365,
        //</editor-fold>

        //<editor-fold desc="hrbu_city_street">
        String city,
        String street,
        //</editor-fold>

        //<editor-fold desc="calculated">
        String id,
        boolean notifyManager
        //</editor-fold>

    ) {
        super(
            ou, homeDrive, homeDir, loginScript,
            groups, contractorGroups, outsideWorkerGroups, extGroups,
            activeSync, itcMail
        );

        this.hrbu = hrbu;
        this.mailSuffix = mailSuffix;
        this.secondaryMailSuffix = secondaryMailSuffix;
        this.enabled = enabled;
        this.vantageLookupStrategy = vantageLookupStrategy;
        this.o365 = o365;

        this.city = city;
        this.street = street;

        this.id = id;
        this.notifyManager = notifyManager;
    }

    @Column(length = 38)
    String hrbu;

    @Column(length = 255)
    String mailSuffix;

    @Column(length = 255)
    String secondaryMailSuffix;

    @Column
    @ColumnTransformer(read = "IFNULL(enabled, 0)")
    boolean enabled;

    @Column
    @ColumnTransformer(read = "IFNULL(vantage_lookup_strategy, 0)")
    boolean vantageLookupStrategy;

    @Column
    @ColumnTransformer(read = "IFNULL(o365, 0)")
    boolean o365;

    @Column(length = 38)
    String city;

    @Column(length = 38)
    String street;

    @Id
    @Column(length = 38)
    String id;

    @Column
    @ColumnTransformer(read = "IFNULL(notify_manager, 0)")
    boolean notifyManager;

}
