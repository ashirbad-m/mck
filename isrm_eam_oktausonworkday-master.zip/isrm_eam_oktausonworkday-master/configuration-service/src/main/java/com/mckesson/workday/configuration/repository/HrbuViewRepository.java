package com.mckesson.workday.configuration.repository;

import com.mckesson.workday.configuration.dao.HrbuViewDao;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HrbuViewRepository extends PagingAndSortingRepository<HrbuViewDao, String>, JpaSpecificationExecutor<HrbuViewDao> {
}
