package com.mckesson.workday.configuration.repository;

import com.mckesson.workday.configuration.dao.DomainsDao;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DomainsRepository extends CrudRepository<DomainsDao, Long> {
    /**
     * Finds DomainsDao by name
     * @param name name
     * @return
     */
    Optional<DomainsDao> findByName(String name);
}
