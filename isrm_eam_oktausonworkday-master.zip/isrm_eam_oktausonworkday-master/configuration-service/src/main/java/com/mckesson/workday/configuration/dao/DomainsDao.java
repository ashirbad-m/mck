package com.mckesson.workday.configuration.dao;

import com.mckesson.common.workday.converter.JsonMapConverter;
import com.mckesson.common.workday.converter.LdapNameConverter;
import com.mckesson.common.workday.converter.SetOfLdapNameConverter;
import com.mckesson.common.workday.converter.SetOfStringConverter;
import com.mckesson.common.workday.converter.URIConverter;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import javax.naming.ldap.LdapName;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.net.URI;
import java.util.Map;
import java.util.Set;

@Entity(name="domains")
@Data
@EqualsAndHashCode(of = { "id" })
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class DomainsDao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column(length = 100)
    String name;

    @Column(length = 255)
    @Convert(converter = LdapNameConverter.class)
    LdapName rootOu;

    @Column(length = 100)
    String fullName;

    @Column(length = 100)
    String ldapHostName;

    @Column(columnDefinition = "TEXT")
    @Convert(converter = SetOfStringConverter.class)
    Set<String> exchangeServers;

    @Column(length = 100)
    String defaultMailDomain;

    @Column(name="office365_address_suffix", length = 100)
    String office365AddressSuffix;

    @Column(name="office365_url", length = 255)
    @Convert(converter = URIConverter.class)
    URI office365Url;

    @Column(name="office365_credentials_address", length = 255)
    String office365CredentialsAddress;

    @Column(length = 100)
    @Convert(converter = LdapNameConverter.class)
    LdapName terminatedOu;

    @Column(columnDefinition = "TEXT")
    @Convert(converter = SetOfLdapNameConverter.class)
    Set<LdapName> defaultAddressBookJson;

    @Column(columnDefinition = "TEXT")
    @Convert(converter = JsonMapConverter.class)
    Map<String, Object> defaultManagerJson;

    @Column(length = 255)
    String terminalServicesProfileRoot;

    @Column(length = 100)
    String company;

    @Column(length = 255)
    @Convert(converter = LdapNameConverter.class)
    LdapName stagingOu;

    @Column(length = 255)
    @Convert(converter = LdapNameConverter.class)
    LdapName terminatedUsersGroup;

    @Column(columnDefinition = "TEXT")
    @Convert(converter = SetOfLdapNameConverter.class)
    Set<LdapName> workersOuJson;

    @Column(columnDefinition = "TEXT")
    @Convert(converter = SetOfLdapNameConverter.class)
    Set<LdapName> questOuJson;

    @Column(columnDefinition = "TEXT")
    @Convert(converter = SetOfLdapNameConverter.class)
    Set<LdapName> adminsOuJson;

    @Column
    Long primaryGroupId;

    @Column
    Long terminatedUsersPrimaryGroupId;

    @Column(columnDefinition = "TEXT")
    @Convert(converter = SetOfStringConverter.class)
    Set<String> dfsServers;
}
