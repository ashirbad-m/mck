package com.mckesson.workday.configuration.dao.mapper;

import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.HrbuConfig;
import com.mckesson.common.model.WorkdayConfig;
import com.mckesson.common.workday.configuration.dto.GroupMappingDto;
import com.mckesson.common.workday.configuration.dto.HrbuCityStreetDto;
import com.mckesson.common.workday.configuration.dto.HrbuDto;
import com.mckesson.workday.configuration.dao.*;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * DTO converter based on Mapstruct library
 */
@Mapper
public interface ConfigurationDaoMapper {
    ConfigurationDaoMapper CFG_MAPPER = Mappers.getMapper(ConfigurationDaoMapper.class);

    @Mapping(source = "defaultAddressBook", target = "defaultAddressBookJson")
    @Mapping(source = "defaultManager", target = "defaultManagerJson")
    @Mapping(source = "workersOu", target = "workersOuJson")
    @Mapping(source = "questOu", target = "questOuJson")
    @Mapping(source = "adminsOu", target = "adminsOuJson")
    DomainsDao toDomainsDao(DomainConfig dto);

    @InheritInverseConfiguration
    DomainConfig toDomainsDto(final DomainsDao dao);

    GlobalDao toGlobalDao(final WorkdayConfig dto);

    WorkdayConfig toGlobalDto(final GlobalDao dao);

    GroupMappingDao toGroupMappingDao(final GroupMappingDto dto);

    GroupMappingDto toGroupMappingDto(final GroupMappingDao dao);

    HrbuCityStreetDao toHrbuCityStreetDao(final HrbuCityStreetDto dto);

    HrbuCityStreetDto toHrbuCityStreetDto(final HrbuCityStreetDao dao);

    HrbuDao toHrbuDao(final HrbuDto dto);

    HrbuDto toHrbuDto(final HrbuDao dao);

    HrbuViewDao toHrbuViewDao(final HrbuConfig dto);

    HrbuConfig toHrbuViewDto(final HrbuViewDao dao);
}
