package com.mckesson.workday.configuration.repository;

import com.mckesson.workday.configuration.dao.HrbuCityStreetDao;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HrbuCityStreetRepository extends CrudRepository<HrbuCityStreetDao, Long> {
}
