package com.mckesson.workday.configuration.controller;

import com.google.common.collect.ImmutableSet;
import com.mckesson.common.ConfigurationClientImpl;
import com.mckesson.common.model.DomainConfig;
import com.mckesson.common.model.HrbuConfig;
import com.mckesson.common.model.WorkdayConfig;
import com.mckesson.common.workday.CommonTest;
import com.mckesson.common.workday.configuration.controller.ConfigurationClient;
import com.mckesson.common.workday.configuration.dto.GroupMappingDto;
import com.mckesson.common.workday.configuration.dto.GroupMappingType;
import com.mckesson.common.workday.configuration.dto.HrbuCityStreetDto;
import com.mckesson.common.workday.configuration.dto.HrbuDto;
import com.mckesson.common.workday.configuration.dto.request.GroupMappingRequest;
import com.mckesson.common.workday.configuration.dto.request.HrbuViewRequest;
import com.mckesson.workday.configuration.dao.*;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.HttpServerErrorException;

import javax.naming.ConfigurationException;
import javax.naming.ldap.LdapName;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static com.mckesson.common.workday.converter.ConverterUtils.nullableLdapName;
import static org.junit.jupiter.api.Assertions.*;
import static com.mckesson.workday.configuration.dao.mapper.ConfigurationDaoMapper.CFG_MAPPER;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
class ConfigurationControllerTest extends CommonTest {

    private static final Predicate<HttpServerErrorException.InternalServerError> EX_TEST = e ->
            Objects.requireNonNull(e.getMessage()).contains(ConfigurationException.class.getSimpleName() + ": ");
    private static final String TEST_SERVICE_URL = "http://localhost:%d/configuration-service/";
    private static final String UNDEFINED_ID = "Undefined";
    private static final Set<String> TEST_GM_NAMES = ImmutableSet.of("CTX_FILEMGR".toLowerCase(), "CTX_Office07".toUpperCase(), UNDEFINED_ID);
    private static final Set<String> TEST_GM_OKTA_CNS = ImmutableSet.of("(GROUP_USON)CTX_FILEMGR".toLowerCase(), "(GROUP_USON)CTX_Office07".toUpperCase(), UNDEFINED_ID);
    private static final Set<String> TEXAS_HRBUS = ImmutableSet.of("HR017", "HR064", "HR080", "HR081", "HR082", "HR083", "HR084", "HR085", "HR098", "HR099");
    private static final Set<String> TEST_PL_JOB_CODES = ImmutableSet.of("4", "5", "6");
    private static final Set<String> TEST_SUPPRESS_CLINICAL_TRANSFER = ImmutableSet.of("7", "8", "9", "10");
    private static final String TEST_PLJ_CODES = "945:945-Network - Physician - All";
    private static final LdapName EXPECTED_HRBU_OU = nullableLdapName("OU=Users,OU=US_IntraFUSION,OU=Clinical,OU=MSHPS,OU=B2E_Workday_Okta_AD,DC=mshusontest,DC=com");
    private static final String EXPECTED_HRBU_ITC_MAIL = "MSHPS_ITC_US_IntraFUSION@mckessonspecialtyhealth.com";
    private static final String EXPECTED_HRBU_MAIL_SUFFIX = "intraFUSION.com";
    private static final String EXPECTED_HRBU_ITC_MAIL_SUFFIX = "mckessonspecialtyhealth.com";
    private static final String EXPECTED_HRBU_CITY_STREET_CITY = "Irving";
    private static final String EXPECTED_HRBU_CITY_STREET_STREET = "1501 West Royal Lane";
    private static final LdapName EXPECTED_HRBU_CITY_STREET_OU = nullableLdapName("OU=Users,OU=Proton,OU=TX_TXO,OU=CSA,OU=USON,OU=B2E_Workday_Okta_AD,DC=mshusontest,DC=com");
    private static final String EXPECTED_HRBU_CITY_STREET_LOGIN_SCRIPT = "TXOproton.vbs";
    private static final String EXPECTED_HRBU_CITY_STREET_ITC_MAIL = "USON_ITC_TXOMidCities@USONCOLOGY.COM";
    private static final String UNEXPECTED_HRBU_VIEW_HRBU = "XXXHR085";
    private static final String EXPECTED_HRBU_VIEW_HRBU_LARGE = "HR085--------";
    private static final String EXPECTED_HRBU_VIEW_HRBU = "HR085";
    private static final String UNEXPECTED_HRBU_VIEW_CITY = "XXX";
    private static final String EXPECTED_HRBU_VIEW_CITY = "IRVING";
    private static final String UNEXPECTED_HRBU_VIEW_STREET = "XXXX";
    private static final String EXPECTED_HRBU_VIEW_STREET = "----1501 WEST ROYAL LANE-----";

    private static ConfigurationClient client;

    @LocalServerPort
    private int port;

    @Autowired
    private RestTemplateBuilder restTemplateBuilder;

    @Autowired
    private UserGenerationProperties ugp;

    @Override
    protected void init0() {
        restTemplateBuilder.errorHandler(new DefaultResponseErrorHandler());
        client = new ConfigurationClientImpl(String.format(TEST_SERVICE_URL, port), restTemplateBuilder);
        new UsersGenerator(ugp, client).generateUsers();
    }

    @Test
    @SneakyThrows
    void cornerCaseMapperTest() {
        assertNull(CFG_MAPPER.toDomainsDao(null));
        assertNull(CFG_MAPPER.toDomainsDto(null));
        assertNull(CFG_MAPPER.toGlobalDao(null));
        assertNull(CFG_MAPPER.toGlobalDto(null));
        assertNull(CFG_MAPPER.toGroupMappingDao(null));
        assertNull(CFG_MAPPER.toGroupMappingDto(null));
        assertNull(CFG_MAPPER.toHrbuCityStreetDao(null));
        assertNull(CFG_MAPPER.toHrbuCityStreetDto(null));
        assertNull(CFG_MAPPER.toHrbuDao(null));
        assertNull(CFG_MAPPER.toHrbuDto(null));
        assertNull(CFG_MAPPER.toHrbuViewDao(null));
        assertNull(CFG_MAPPER.toHrbuViewDto(null));

        assertNull(CFG_MAPPER.toDomainsDao(DomainConfig.builder().build()).getDfsServers());
        assertNull(CFG_MAPPER.toDomainsDto(DomainsDao.builder().build()).getDfsServers());

        assertNull(CFG_MAPPER.toGlobalDao(WorkdayConfig.builder().build()).getPreventLoaJobCodes());
        assertNull(CFG_MAPPER.toGlobalDto(GlobalDao.builder().build()).getPreventLoaJobCodes());

        assertNull(CFG_MAPPER.toHrbuCityStreetDao(HrbuCityStreetDto.builder().build()).getGroups());
        assertNull(CFG_MAPPER.toHrbuCityStreetDto(HrbuCityStreetDao.builder().build()).getGroups());

        assertNull(CFG_MAPPER.toHrbuDto(HrbuDao.builder().hrbu("").build()).getGroups());
        assertNull(CFG_MAPPER.toHrbuDao(HrbuDto.builder().hrbu("").build()).getGroups());

        assertNull(CFG_MAPPER.toHrbuViewDao(HrbuConfig.builder().hrbu("").ou(new LdapName("cn=xxx")).build()).getGroups());
        assertNull(CFG_MAPPER.toHrbuViewDto(HrbuViewDao.builder().hrbu("").ou(new LdapName("cn=xxx")).build()).getGroups());

    }

    //<editor-fold desc="global">
    @Test
    void getAllGlobalsTest() {
        final List<GlobalDao> result = client.getAllGlobals().stream().map(CFG_MAPPER::toGlobalDao).collect(Collectors.toList());

        assertTrue(result.size() > 0);
        final GlobalDao first = result.get(0);
        assertEquals(1L, first.getId());
        assertEquals(1, first.getPreventLoaJobCodes().size());
        assertEquals(10, first.getTexasHrbus().size());

        assertEquals(0, first.getSuppressClinicalTransfer().size());
        assertEquals(0, first.getSuppressHrbuTransfer().size());

        assertEquals("HR065", first.getMckessonHrbu());
        assertTrue(first.getTexasHrbus().containsAll(TEXAS_HRBUS));

        assertTrue(first.getPreventLoaJobCodes().contains(TEST_PLJ_CODES));

        assertEquals(first, CFG_MAPPER.toGlobalDao(client.findGlobalConfig()));
    }

    @Test
    void getGlobalTest() {
        final WorkdayConfig result0 = client.findGlobalById(-1L);
        assertNull(result0);

        final WorkdayConfig result1 = client.findGlobalById(1L);
        assertNotNull(result1);
    }

    /*@Test
    void saveGlobalTest() {
        final WorkdayConfig dto = WorkdayConfig.builder()
                .mckessonHrbu("1")
                .preventLoaJobCodes(TEST_PL_JOB_CODES)
                .suppressClinicalTransfer(TEST_SUPPRESS_CLINICAL_TRANSFER)
                .suppressHrbuTransfer(null)
                .texasHrbus(ImmutableSet.of())
                .build();

        final WorkdayConfig result0 = client.saveGlobal(dto);

        final WorkdayConfig result1 = client.findGlobalById(result0.getId());

        assertEquals(result0.getId(), result1.getId());
        assertEquals(3, result1.getPreventLoaJobCodes().size());
        assertEquals(0, result1.getTexasHrbus().size());

        assertEquals(4, result1.getSuppressClinicalTransfer().size());
        assertEquals(0, result1.getSuppressHrbuTransfer().size());

        assertEquals("1", result1.getMckessonHrbu());
        assertTrue(result1.getPreventLoaJobCodes().containsAll(TEST_PL_JOB_CODES));
        assertTrue(result1.getSuppressClinicalTransfer().containsAll(TEST_SUPPRESS_CLINICAL_TRANSFER));
    }

    @Test
    void deleteGlobalTest() {
        final WorkdayConfig dto = WorkdayConfig.builder().build();
        final WorkdayConfig result0 = client.saveGlobal(dto);
        final WorkdayConfig result1 = client.findGlobalById(result0.getId());
        assertNotNull(result1);
        assertTrue(client.deleteGlobal(result1.getId()));
        final WorkdayConfig result2 = client.findGlobalById(result1.getId());
        assertNull(result2);
    }*/
    //</editor-fold>

    //<editor-fold desc="group_mapping">
    @Test
    void getAllGroupMappingsTest() {
        final List<GroupMappingDao> result = client.getAllGroupMappings().stream().map(CFG_MAPPER::toGroupMappingDao).collect(Collectors.toList());
        assertTrue(result.size() >= 189);
    }

    @Test
    void getGroupMappingTest() {
        final GroupMappingDto result0 = client.findGroupMappingById(-1L);
        assertNull(result0);

        final GroupMappingDto result1 = client.findGroupMappingById(153L);
        assertNotNull(result1);

        assertEquals("RMCC Employees", result1.getName());
        assertEquals(GroupMappingType.HRBU, result1.getType());
        assertEquals(
                "CN=RMCC Employees,OU=CO_Rocky Mountain Cancer Centers,OU=Distribution Groups,OU=Groups,OU=USON,OU=B2E_Workday_Okta_AD,DC=mshusontest,DC=com",
                result1.getDn().toString()
        );
    }

    @Test
    void getGroupMappingByNameTest() {
        final GroupMappingDto result0 = client.findGroupMappingByName(UNDEFINED_ID);
        assertNull(result0);

        final GroupMappingDto result1 = client.findGroupMappingByName("Svr-IL-CCHSC".toLowerCase());
        assertNotNull(result1);

        assertEquals("Svr-IL-CCHSC", result1.getName());
        assertEquals(GroupMappingType.HRBU, result1.getType());
        assertEquals(
                "CN=Svr-IL-CCHSC,OU=IL_IllinoisCancerSpecialists,OU=Help Desk Managed Groups,OU=Groups,OU=USON,OU=B2E_Workday_Okta_AD,DC=mshusontest,DC=com",
                result1.getDn().toString()
        );
    }

    @Test
    void findGroupMappingByTypeTest() {
        final List<GroupMappingDto> result = client.findGroupMappingsByType(GroupMappingType.DEFAULT);
        assertEquals(4, result.size());
        assertEquals("Zscaler_Prod_USON", result.stream().filter(i -> i.getId() == 344L).map(GroupMappingDto::getName).findFirst().orElse(""));
    }

    @Test
    void findGroupMappingByNamesTest() {
        final List<GroupMappingDto> result = client.findGroupMappingsByNames(TEST_GM_NAMES);
        assertEquals(2, result.size());
        assertEquals(2, result.stream().filter(i -> i.getName().equals("CTX_FILEMGR") || i.getName().equals("CTX_Office07")).count());
    }

    @Test
    void findGroupMappingByOktaCnsTest() {
        final List<GroupMappingDto> result = client.findGroupMappingsByOktaCns(TEST_GM_OKTA_CNS);
        assertEquals(2, result.size());
        assertEquals(2, result.stream().filter(i -> i.getOktaCn().equals("(GROUP_USON)CTX_FILEMGR") || i.getOktaCn().equals("(GROUP_USON)CTX_Office07")).count());
    }

    @Test
    void findGroupMappingByNamesAndTypeTest() {
        final List<GroupMappingDto> result0 = client.findGroupMappingsByNameInAndType(
                GroupMappingRequest.builder().names(TEST_GM_NAMES).type(GroupMappingType.DEFAULT).build()
        );
        assertEquals(0, result0.size());

        final List<GroupMappingDto> result1 = client.findGroupMappingsByNameInAndType(
                GroupMappingRequest.builder().names(TEST_GM_NAMES).type(GroupMappingType.HRBU).build()
        );
        assertEquals(2, result1.size());
        assertEquals(2, result1.stream().filter(i -> i.getName().equals("CTX_FILEMGR") || i.getName().equals("CTX_Office07")).count());
    }

    /*@Test
    void saveGroupMappingTest() {
        final GroupMappingDto dto = GroupMappingDto.builder().id(315L)
                .name(UUID.randomUUID().toString())
                .dn(nullableLdapName("OU=TEST,DC=Test"))
                .type(GroupMappingType.CSA)
                .build();

        final GroupMappingDto result0 = client.saveGroupMapping(dto);
        final GroupMappingDto result1 = client.findGroupMappingById(result0.getId());
        assertEquals(result0, result1);
    }

    @Test
    void deleteGroupMappingTest() {
        final GroupMappingDto dto = GroupMappingDto.builder()
                .name(UUID.randomUUID().toString())
                .dn(nullableLdapName("OU=TEST,DC=Test"))
                .type(GroupMappingType.CSA)
                .build();

        final GroupMappingDto result0 = client.saveGroupMapping(dto);
        final GroupMappingDto result1 = client.findGroupMappingById(result0.getId());
        assertNotNull(result1);
        assertTrue(client.deleteGroupMapping(result1.getId()));
        final GroupMappingDto result2 = client.findGroupMappingById(result1.getId());
        assertNull(result2);
    }*/
    //</editor-fold>

    //<editor-fold desc="domains">
    @Test
    void allDomainConfigsTest() {
        final List<DomainsDao> result = client.allDomainConfigs().stream().map(CFG_MAPPER::toDomainsDao).collect(Collectors.toList());
        assertTrue(result.size() >= 1);
    }

    @Test
    void getDomainConfigTest() {

        final DomainConfig result0 = client.findDomainConfigById(-1L);
        assertNull(result0);

        final DomainConfig result1 = client.findDomainConfigById(2L);
        assertNotNull(result1);

        assertEquals("mshps", result1.getName());
        assertEquals(2L, result1.getId());

    }

    @Test
    void findDomainConfigTest() {
        try {
            client.findDomainConfig(HrbuConfig.builder().hrbu("QQQ").ou(nullableLdapName("cn=XXXX,cn=YYY")).build());
            fail();
        } catch (HttpServerErrorException.InternalServerError ex) {
            assertTrue(EX_TEST.test(ex));
        }
        final DomainConfig result1 = client.findDomainConfig(
                HrbuConfig.builder().hrbu("QQQ").ou(EXPECTED_HRBU_OU).build()
        );
        assertEquals(client.findDomainConfigById(2L), result1);
        final DomainConfig result2 = client.findDomainConfig(
                HrbuConfig.builder().hrbu("QQQ").ou(EXPECTED_HRBU_CITY_STREET_OU).build()
        );
        assertEquals(client.findDomainConfigById(1L), result2);
    }

    @Test
    void getDomainConfigByNameTest() {
        final DomainConfig result0 = client.findDomainConfigByName(UNDEFINED_ID);
        assertNull(result0);

        final DomainConfig result1 = client.findDomainConfigByName("uson".toUpperCase());
        assertNotNull(result1);

        assertEquals("uson", result1.getName());
    }

    /*@Test
    void saveDomainConfigTest() {
        final DomainConfig dto = DomainConfig.builder()
                .name(UUID.randomUUID().toString())
                .rootOu(nullableLdapName("CN=Name1"))
                .fullName("fullName_1")
                .ldapHostName("ldapHostName-1")
                .exchangeServers(ImmutableSet.of("S1", "S2"))
                .defaultMailDomain("defaultMailDomain-1")
                .office365AddressSuffix("office365AddressSuffix-1")
                .office365Url(nullableUri("http://QQQ:389/WWW"))
                .office365CredentialsAddress("office365CredentialsAddress-1")
                .terminatedOu(nullableLdapName("CN=terminatedOu1"))
                .defaultAddressBook(ImmutableSet.of(nullableLdapName("CN=defaultAddressBook1"), nullableLdapName("CN=defaultAddressBook2")))
                .defaultManager(ImmutableMap.of("key-1", "defaultManager-1", "key-2", "defaultManager-2"))
                .terminalServicesProfileRoot("terminalServicesProfileRoot-1")
                .company("company-1")
                .stagingOu(nullableLdapName("CN=stagingOu1"))
                .terminatedUsersGroup(nullableLdapName("CN=terminatedUsersGroup1"))
                .workersOu(ImmutableSet.of(nullableLdapName("CN=workersOu1"), nullableLdapName("CN=workersOu2")))
                .questOu(ImmutableSet.of(nullableLdapName("CN=questOu1"), nullableLdapName("CN=questOu2"), nullableLdapName("CN=questOu3")))
                .adminsOu(ImmutableSet.of(nullableLdapName("CN=adminsOu1"), nullableLdapName("CN=adminsOu2"), nullableLdapName("CN=adminsOu3"), nullableLdapName("CN=adminsOu4")))
                .primaryGroupId(111L)
                .terminatedUsersPrimaryGroupId(111L)
                .dfsServers(Collections.emptySet())
                .build();

        final DomainConfig result0 = client.saveDomainConfig(dto);

        final DomainConfig result1 = client.findDomainConfigById(result0.getId());
        assertEquals(result0, result1);

        final DomainConfig dto1 = result1.toBuilder()
                .id(null)
                .name(UUID.randomUUID().toString())
                .exchangeServers(null)
                .terminatedOu(null)
                .defaultAddressBook(null)
                .defaultManager(null)
                .stagingOu(null)
                .terminatedUsersGroup(null)
                .workersOu(null)
                .questOu(null)
                .adminsOu(null)
                .build();

        final DomainConfig result3 = client.saveDomainConfig(dto1);

        final DomainConfig result4 = client.findDomainConfigById(result3.getId());

        assertEquals(ImmutableSet.of(), result4.getExchangeServers());
        assertNull(result4.getTerminatedOu());
        assertEquals(ImmutableSet.of(), result4.getDefaultAddressBook());
        assertEquals(new HashMap<String, Object>(), result4.getDefaultManager());
        assertNull(result4.getStagingOu());
        assertNull(result4.getTerminatedUsersGroup());
        assertEquals(ImmutableSet.of(), result4.getWorkersOu());
        assertEquals(ImmutableSet.of(), result4.getQuestOu());
        assertEquals(ImmutableSet.of(), result4.getAdminsOu());

        final DomainConfig dto2 = result1.toBuilder()
                .id(null)
                .name(UUID.randomUUID().toString())
                .exchangeServers(ImmutableSet.of())
                .defaultAddressBook(ImmutableSet.of())
                .defaultManager(ImmutableMap.of())
                .workersOu(ImmutableSet.of())
                .questOu(ImmutableSet.of())
                .adminsOu(ImmutableSet.of())
                .build();

        final DomainConfig result5 = client.saveDomainConfig(dto2);

        final DomainConfig result6 = client.findDomainConfigById(result5.getId());

        assertEquals(ImmutableSet.of(), result6.getExchangeServers());
        assertEquals(ImmutableSet.of(), result6.getDefaultAddressBook());
        assertEquals(new HashMap<String, Object>(), result6.getDefaultManager());
        assertEquals(ImmutableSet.of(), result6.getWorkersOu());
        assertEquals(ImmutableSet.of(), result6.getQuestOu());
        assertEquals(ImmutableSet.of(), result6.getAdminsOu());
    }

    @Test
    void deleteDomainConfigTest() {
        final DomainConfig dto = DomainConfig.builder().build();
        final DomainConfig result0 = client.saveDomainConfig(dto);
        final DomainConfig result1 = client.findDomainConfigById(result0.getId());
        assertNotNull(result1);
        assertTrue(client.deleteDomainConfig(result1.getId()));
        final DomainConfig result2 = client.findDomainConfigById(result1.getId());
        assertNull(result2);
    }*/
    //</editor-fold>

    //<editor-fold desc="hrbu">
    @Test
    void getAllHrbuTest() {
        final List<HrbuDao> result = client.getAllHrbu().stream().map(CFG_MAPPER::toHrbuDao).collect(Collectors.toList());
        assertTrue(result.size() >= 66);

    }

    @Test
    void getHrbuTest() {
        final HrbuDto single0 = client.findHrbuByHrbu(UNDEFINED_ID);
        assertNull(single0);

        final HrbuDto single1 = client.findHrbuByHrbu("IF100");
        assertNotNull(single1);
        assertEquals(EXPECTED_HRBU_OU, single1.getOu());
        assertEquals(EXPECTED_HRBU_ITC_MAIL, single1.getItcMail());
        assertEquals(EXPECTED_HRBU_MAIL_SUFFIX, single1.getMailSuffix());
        assertEquals(EXPECTED_HRBU_ITC_MAIL_SUFFIX, single1.getSecondaryMailSuffix());
    }

    /*@Test
    void saveHrbuTest() {
        final HrbuDto dto = HrbuDto.builder()
                .hrbu("TEST33")
                .ou(nullableLdapName("Cn=Test33"))
                .homeDrive("F:\\")
                .homeDir("/tmp")
                .loginScript("autoexec.bat")
                .groups(ImmutableSet.of("G1", "G2", "G3"))
                .contractorGroups(ImmutableSet.of("G4", "G5", "G6"))
                .outsideWorkerGroups(ImmutableSet.of("G7", "G8", "G9"))
                .extGroups(ImmutableSet.of("G10", "G11", "G12", "G13"))
                .activeSync(true)
                .city(false)
                .mailSuffix("SUF33")
                .secondaryMailSuffix("sec33")
                .itcMail("XXX@YYY.COM")
                .enabled(false)
                .vantageLookupStrategy(true)
                .o365(false)
                .build();

        assertNotNull(client.saveHrbu(dto));

        final HrbuDto result1 = client.findHrbuByHrbu(dto.getHrbu().toLowerCase());

        assertEquals(
                dto,
                result1.toBuilder().hrbu(dto.getHrbu()).build()
        );

        final HrbuDto dto1 = dto.toBuilder()
                .hrbu("TEST44")
                .ou(null)
                .loginScript(null)
                .groups(null)
                .contractorGroups(null)
                .contractorGroups(null)
                .outsideWorkerGroups(null)
                .extGroups(null)
                .city(false)
                .build();


        assertNotNull(client.saveHrbu(dto1));

        final HrbuDto result2 = client.findHrbuByHrbu(dto1.getHrbu());

        assertEquals(dto.getHomeDrive(), result2.getHomeDrive());
        assertNull(result2.getOu());
        assertNull(result2.getLoginScript());
        assertEquals(0, result2.getGroups().size());
        assertEquals(0, result2.getContractorGroups().size());
        assertEquals(0, result2.getOutsideWorkerGroups().size());
        assertEquals(0, result2.getExtGroups().size());
        assertFalse(result2.isCity());

        final HrbuDto dto3 = dto.toBuilder()
                .hrbu("TEST55")
                .groups(ImmutableSet.of())
                .contractorGroups(ImmutableSet.of())
                .outsideWorkerGroups(ImmutableSet.of())
                .extGroups(ImmutableSet.of())
                .build();

        assertNotNull(client.saveHrbu(dto3));

        final HrbuDto result3 = client.findHrbuByHrbu(dto3.getHrbu());

        assertEquals(0, result3.getGroups().size());
        assertEquals(0, result3.getContractorGroups().size());
        assertEquals(0, result3.getOutsideWorkerGroups().size());
        assertEquals(0, result3.getExtGroups().size());

        assertTrue(client.deleteHrbuByHrbu("TEST33"));
        assertTrue(client.deleteHrbuByHrbu("TEST44"));
        assertTrue(client.deleteHrbuByHrbu("TEST55"));
    }

    @Test
    void deleteHrbuTest() {
        final HrbuDto dto = HrbuDto.builder().hrbu("TEST88").build();

        assertNotNull(client.saveHrbu(dto));

        final HrbuDto result0 = client.findHrbuByHrbu(dto.getHrbu());
        assertNotNull(result0);

        assertTrue(client.deleteHrbuByHrbu(dto.getHrbu()));

        final HrbuDto result1 = client.findHrbuByHrbu(dto.getHrbu());
        assertNull(result1);
    }*/
    //</editor-fold>

    //<editor-fold desc="hrbu_city_street">
    @Test
    void getAllHrbuCityStreetTest() {
        final List<HrbuCityStreetDao> result = client.getAllHrbuCityStreet().stream().map(CFG_MAPPER::toHrbuCityStreetDao).collect(Collectors.toList());
        assertTrue(result.size() >= 111);
    }

    @Test
    void getHrbuCityStreetTest() {
        final HrbuCityStreetDto single0 = client.findHrbuCityStreetById(-1L);
        assertNull(single0);

        final HrbuCityStreetDto single1 = client.findHrbuCityStreetById(277L);
        assertNotNull(single1);

        assertEquals(EXPECTED_HRBU_CITY_STREET_CITY, single1.getCity());
        assertEquals(EXPECTED_HRBU_CITY_STREET_STREET, single1.getStreet());
        assertEquals(EXPECTED_HRBU_CITY_STREET_OU, single1.getOu());
        assertNull(single1.getHomeDrive());
        assertNull(single1.getHomeDir());
        assertEquals(EXPECTED_HRBU_CITY_STREET_LOGIN_SCRIPT, single1.getLoginScript());
        assertTrue(single1.isActiveSync());
        assertEquals(EXPECTED_HRBU_CITY_STREET_ITC_MAIL, single1.getItcMail());
    }

    /*@Test
    void saveHrbuCityStreetTest() {
        final HrbuCityStreetDto dto = HrbuCityStreetDto.builder()
                .ou(nullableLdapName("Cn=Test33"))
                .homeDrive("F:\\")
                .homeDir("/tmp")
                .loginScript("autoexec.bat")
                .groups(ImmutableSet.of("G1", "G2", "G3"))
                .contractorGroups(ImmutableSet.of("G4", "G5", "G6"))
                .outsideWorkerGroups(ImmutableSet.of("G7", "G8", "G9"))
                .extGroups(ImmutableSet.of("G10", "G11", "G12", "G13"))
                .activeSync(true)
                .itcMail("XXX@YYY.COM")
                .city("City33")
                .street("street33")
                .build();

        final HrbuCityStreetDto result0 = client.saveHrbuCityStreet(dto);

        final HrbuCityStreetDto result1 = client.findHrbuCityStreetById(result0.getId());

        assertEquals(dto.toBuilder().id(result1.getId()).build(), result1);

        final HrbuCityStreetDto dto1 = dto.toBuilder()
                .id(null)
                .ou(null)
                .homeDir(null)
                .groups(null)
                .contractorGroups(null)
                .outsideWorkerGroups(null)
                .extGroups(null)
                .activeSync(false)
                .street(null)
                .build();

        final HrbuCityStreetDto result2 = client.saveHrbuCityStreet(dto1);

        final HrbuCityStreetDto result3 = client.findHrbuCityStreetById(result2.getId());

        assertNull(result3.getOu());
        assertNull(result3.getHomeDir());

        assertEquals(0, result3.getGroups().size());
        assertEquals(0, result3.getContractorGroups().size());
        assertEquals(0, result3.getOutsideWorkerGroups().size());
        assertEquals(0, result3.getExtGroups().size());

        assertFalse(result3.isActiveSync());
        assertNull(result3.getStreet());
        assertEquals(dto.getCity(), result3.getCity());

        final HrbuCityStreetDto dto2 = dto.toBuilder()
                .id(null)
                .groups(ImmutableSet.of())
                .contractorGroups(ImmutableSet.of())
                .outsideWorkerGroups(ImmutableSet.of())
                .extGroups(ImmutableSet.of())
                .build();

        final HrbuCityStreetDto result4 = client.saveHrbuCityStreet(dto2);

        final HrbuCityStreetDto result5 = client.findHrbuCityStreetById(result4.getId());

        assertEquals(0, result5.getGroups().size());
        assertEquals(0, result5.getContractorGroups().size());
        assertEquals(0, result5.getOutsideWorkerGroups().size());
        assertEquals(0, result5.getExtGroups().size());

        assertTrue(client.deleteHrbuCityStreet(result0.getId()));
        assertTrue(client.deleteHrbuCityStreet(result2.getId()));
        assertTrue(client.deleteHrbuCityStreet(result4.getId()));
    }

    @Test
    void deleteHrbuCityStreetTest() {
        final HrbuCityStreetDto dto = HrbuCityStreetDto.builder().build();

        final HrbuCityStreetDto result0 = client.saveHrbuCityStreet(dto);

        final HrbuCityStreetDto result1 = client.findHrbuCityStreetById(result0.getId());
        assertNotNull(result1);

        assertTrue(client.deleteHrbuCityStreet(result0.getId()));

        final HrbuCityStreetDto result2 = client.findHrbuCityStreetById(result0.getId());
        assertNull(result2);
    }*/
    //</editor-fold>

    //<editor-fold desc="hrbu_view">
    private void compareHrbuViewWithRealData(final HrbuConfig hv0, final HrbuDto h, final HrbuCityStreetDto hcs) {
        BiFunction<Supplier<?>, Supplier<?>, ?> crossCheck =
                (hSupplier, hscSupplier) -> (h.isCity() ? hscSupplier : hSupplier).get();

        HrbuViewDao hvd = CFG_MAPPER.toHrbuViewDao(hv0);

        if (hcs != null) {
            assertEquals(crossCheck.apply(h::getOu, hcs::getOu), hvd.getOu());
            assertEquals(crossCheck.apply(h::getHomeDrive, hcs::getHomeDrive), hvd.getHomeDrive());
            assertEquals(crossCheck.apply(h::getHomeDir, hcs::getHomeDir), hvd.getHomeDir());
            assertEquals(crossCheck.apply(h::getLoginScript, hcs::getLoginScript), hvd.getLoginScript());

            assertEquals(crossCheck.apply(h::getGroups, hcs::getGroups), hvd.getGroups());
            assertEquals(crossCheck.apply(h::getContractorGroups, hcs::getContractorGroups), hvd.getContractorGroups());
            assertEquals(crossCheck.apply(h::getOutsideWorkerGroups, hcs::getOutsideWorkerGroups), hvd.getOutsideWorkerGroups());
            assertEquals(crossCheck.apply(h::getExtGroups, hcs::getExtGroups), hvd.getExtGroups());

            assertEquals(crossCheck.apply(h::isActiveSync, hcs::isActiveSync), hvd.getActiveSync());

            assertEquals(hcs.getCity(), hvd.getCity());
            assertEquals(hcs.getStreet(), hvd.getStreet());
        } else {
            assertNull(hvd.getCity());
            assertNull(hvd.getStreet());
        }

        assertEquals(
                h.isCity() && (hcs == null || hcs.getCity() == null),
                hvd.isNotifyManager()
        );

        assertEquals(h.getHrbu(), hvd.getHrbu());
        assertEquals(h.getMailSuffix(), hvd.getMailSuffix());
        assertEquals(h.getSecondaryMailSuffix(), hvd.getSecondaryMailSuffix());
        assertEquals(h.isEnabled(), hvd.isEnabled());
        assertEquals(h.isVantageLookupStrategy(), hvd.isVantageLookupStrategy());
        assertEquals(h.isO365(), hvd.isO365());

    }

    @Test
    void findHrbuConfigTest() {
        final HrbuViewRequest request0 = HrbuViewRequest.builder()
                .hrbu(UNEXPECTED_HRBU_VIEW_HRBU)
                .firstOnly(false)
                .build();

        final List<HrbuConfig> result0 = client.findHrbuConfig(request0);

        assertEquals(0, result0.size());

        final HrbuViewRequest request1 = HrbuViewRequest.builder()
                .hrbu(EXPECTED_HRBU_VIEW_HRBU_LARGE)
                .firstOnly(false)
                .build();

        final List<HrbuConfig> result1 = client.findHrbuConfig(request1);
        assertEquals(1, result1.size());
        final HrbuConfig dto1Single = result1.get(0);
        assertEquals(EXPECTED_HRBU_VIEW_HRBU, dto1Single.getHrbu());
        compareHrbuViewWithRealData(
                dto1Single,
                client.findHrbuByHrbu(EXPECTED_HRBU_VIEW_HRBU),
                client.findHrbuCityStreetById(179L)
        );

        final HrbuViewRequest request2 = request1.toBuilder().city(UNEXPECTED_HRBU_VIEW_CITY).build();
        final List<HrbuConfig> result2 = client.findHrbuConfig(request2);
        assertEquals(1, result2.size());
        assertEquals(dto1Single, result2.get(0));

        final HrbuViewRequest request3 = request2.toBuilder().city(ConfigurationControllerTest.EXPECTED_HRBU_VIEW_CITY).build();
        final List<HrbuConfig> result3 = client.findHrbuConfig(request3);
        assertEquals(2, result3.size());
        compareHrbuViewWithRealData(
                result3.get(0),
                client.findHrbuByHrbu(EXPECTED_HRBU_VIEW_HRBU),
                client.findHrbuCityStreetById(216L)
        );
        assertEquals(dto1Single, result3.get(1));

        final HrbuViewRequest request4 = request3.toBuilder().street(UNEXPECTED_HRBU_VIEW_STREET).build();
        final List<HrbuConfig> result4 = client.findHrbuConfig(request4);
        assertEquals(2, result4.size());
        assertEquals(result3.get(0), result4.get(0));
        assertEquals(dto1Single, result4.get(1));

        final HrbuViewRequest request5 = request4.toBuilder().street(EXPECTED_HRBU_VIEW_STREET).build();
        final List<HrbuConfig> result5 = client.findHrbuConfig(request5);
        assertEquals(3, result5.size());
        compareHrbuViewWithRealData(
                result5.get(0),
                client.findHrbuByHrbu(EXPECTED_HRBU_VIEW_HRBU),
                client.findHrbuCityStreetById(277L)
        );
        assertEquals(result4.get(0), result5.get(1));
        assertEquals(dto1Single, result5.get(2));

        final HrbuViewRequest request6 = request5.toBuilder().firstOnly(true).build();
        final List<HrbuConfig> result6 = client.findHrbuConfig(request6);
        assertEquals(1, result6.size());
        compareHrbuViewWithRealData(
                result6.get(0),
                client.findHrbuByHrbu(EXPECTED_HRBU_VIEW_HRBU),
                client.findHrbuCityStreetById(277L)
        );

        final HrbuViewRequest request7 = request6.toBuilder().hrbu(UNEXPECTED_HRBU_VIEW_HRBU).build();

        try {
            client.findHrbuConfig(request7);
            fail();
        } catch (HttpServerErrorException.InternalServerError ex) {
            assertTrue(EX_TEST.test(ex));
        }
    }
    //</editor-fold>
}
