package com.mckesson.workday.configuration.controller;

import com.mckesson.common.model.HrbuConfig;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;

@Data
@AllArgsConstructor
public class UserGenerator {

    private static int randomInt(int min, int max) {
        return new Random().ints(min, max).findFirst().orElse(min);
    }

    private static Date randomDate(Date min, Date max) {
        long mills = new Random().longs(100, min.getTime(), max.getTime()).findFirst().orElse(min.getTime());
        return new Date(mills);
    }

    private static String randomFirstLetters() {
        final StringBuilder sb = new StringBuilder();
        new Random().ints('A', 'Z' + 1).limit(3).forEach(i -> sb.append((char)i));
        return new String(sb);
    }

    private static final Supplier<Boolean> booleanGenerator = () -> randomInt(0, 2) % 2 == 0;

    private static final Function<String[], String> randomElement = (options) -> options[randomInt(0, options.length)];

    private int index;
    private HrbuConfig config;
    private UserGenerationProperties properties;

    private final UnaryOperator<String> singleDigitGenerator = (s) -> String.format(s ,index);

    private final BiFunction<String, String, String> firstLetterGenerator = (s, fl) -> String.format(s, fl, index);

    private String randomUid() {
        int randomPart = randomInt(0, 100000);
        return String.format(properties.getUniqueValueFormat(), randomPart, index);
    }

    Map<String, Object> generateUser () {
        final HashMap<String, Object> result = new HashMap<>(properties.getDefaultValues());
        Stream.of(properties.getNullFields()).forEach(n -> result.put(n ,null));
        Stream.of(properties.getBooleanValues()).forEach( n -> result.put(n, booleanGenerator.get()));
        final UserGenerationProperties.DateValues dateValues = properties.getDateValues();
        final Date min = dateValues.getOptions().getMin();
        final Date max = dateValues.getOptions().getMax();
        Stream.of(dateValues.getValues()).forEach(
            dv -> result.put(dv.getName(), new SimpleDateFormat(dv.getFormat()).format(randomDate(min, max)))
        );
        final String uid = randomUid();
        properties.getUniqueValues().forEach(
            (k, v) -> result.put(k, String.format(v, uid))
        );
        properties.getSingleDigitValues().forEach(
            (k ,v) -> result.put(k, singleDigitGenerator.apply(v))
        );
        final String firstLetters = randomFirstLetters();
        properties.getFirstLetterValues().forEach(
            (k ,v) -> result.put(k, firstLetterGenerator.apply(v, firstLetters))
        );
        Stream.of(properties.getEnumerationValues()).forEach(
            (ev) -> {
                String value = randomElement.apply(ev.getValues());
                result.put(ev.getName(), value);
                if (StringUtils.isNotBlank(ev.getSecondName())) {
                    result.put(ev.getSecondName(), value);
                }
            }
        );
        Stream.of(properties.getHrbuFields()).forEach(
            hf -> result.put(hf, String.format(properties.getHrbuFormat(), config.getHrbu(), index))
        );
        final String city = config.getCity();
        Stream.of(properties.getCityFields()).forEach(
            cf -> result.put(cf, StringUtils.isBlank(city)? "NO_CITY" : city)
        );
        final String street = config.getStreet();
        Stream.of(properties.getAddressFields()).forEach(
            af -> result.put(
                af,
                String.format(properties.getAddressFormat(), index, StringUtils.isBlank(street)? "NO_STREET" : street)
            )
        );

        return result;
    }

}
