package com.mckesson.workday.configuration.controller;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.test.context.TestConfiguration;

import java.security.SecureRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

@TestConfiguration
@ConfigurationProperties(prefix = "users-generator", ignoreUnknownFields = true)
@Data
public class UserGenerationProperties {
    @Data
    public static class DateValue {
        String name;
        String format;
    }


    public static class DateOptions {
        private static final String YYYY_MM_DD = "yyyy-MM-dd";
        Date min;
        Date max;

        public Date getMin() {
            return min;
        }

        public Date getMax() {
            return max;
        }

        public void setMin(String min) throws ParseException {
            this.min = new SimpleDateFormat(YYYY_MM_DD).parse(min);
        }

        public void setMax(String max) throws ParseException {
            this.max = new SimpleDateFormat(YYYY_MM_DD).parse(max);
        }
    }

    @Data
    public static class DateValues {
        DateOptions options;
        DateValue[] values;
    }

    @Data
    public static class EnumerationValue {
        String name;
        String secondName;
        String[] values;
    }

    int countOfUsers;
    String outputDirectory;
    String outputFile;
    String headerOfFile;
    String createUserTemplate;
    Map<String, Object> defaultValues;
    String[] nullFields;
    String[] booleanValues;
    DateValues dateValues;
    Map<String, String> uniqueValues;
    Map<String, String> singleDigitValues;
    Map<String, String> firstLetterValues;
    EnumerationValue[] enumerationValues;
    String[] relationFields;
    String[] hrbuFields;
    String[] addressFields;
    String[] cityFields;
    String addressFormat;
    String hrbuFormat;
    String uniqueValueFormat;
}
