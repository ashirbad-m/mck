package com.mckesson.workday.configuration.controller;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableBiMap;
import com.mckesson.common.model.HrbuConfig;
import com.mckesson.common.workday.configuration.controller.ConfigurationClient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.SneakyThrows;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
public class UsersGenerator {

    private static final String UNIQUE_KEY = "employeeNumber";
    private static final ObjectMapper mapper;

    static {
        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
    }

    private UserGenerationProperties properties;
    private ConfigurationClient client;

    @SneakyThrows(IOException.class)
    public void generateUsers() {
        final List<HrbuConfig> hrbus = client.getAllHrbuConfigs();
        final int[] hrbuIndexes = new Random().ints(properties.getCountOfUsers() ,0, hrbus.size()).toArray();
        final SortedMap<String, Map<String, Object>> users = new TreeMap<>();
        for (int index = 0; index < hrbuIndexes.length; index++) {
            Map<String, Object> user = new UserGenerator(index + 1, hrbus.get(hrbuIndexes[index]), properties).generateUser();
            users.put(
                String.valueOf(user.get(UNIQUE_KEY)),
                user
            );
        }
        final String[] relFields = properties.getRelationFields();
        if (users.size() > relFields.length) {
            final List<String> managers = users.keySet().stream().limit(relFields.length).collect(Collectors.toList());
            final List<Map<String, Object>> users0 = users.values().stream().skip(relFields.length).collect(Collectors.toList());
            users0.forEach(
                (u) -> {
                    for (int i = 0 ; i < relFields.length; i++) {
                        u.put(relFields[i], managers.get(i));
                    }
                }
            );

        }
        try (
            BufferedWriter writer = Files.newBufferedWriter(
                Paths.get(properties.getOutputDirectory(), properties.getOutputFile())
            );
        ) {
            writer.write(String.format(properties.getHeaderOfFile(), ""));
            users.forEach(
                (key, user) -> {
                    try {
                        writer.write(String.format(
                            properties.getCreateUserTemplate(),
                            key,
                            mapper.writeValueAsString(ImmutableBiMap.of("profile", user))
                        ));
                    } catch (IOException e) {
                        throw new RuntimeException("generateUsers - error", e);
                    }
                }
            );
        }

    }

}
