Okta Sync Project
=================

System Requirements
-------------------

* Memory: 4Gb RAM
* JDK: version 8
* Apache Maven v3 or above (see Download and Install Maven http://maven.apache.org/download.cgi)
* Azure Cosmos DB Emulator https://docs.microsoft.com/en-us/azure/cosmos-db/local-emulator
* Hazelcast IMDG 3.x https://hazelcast.org/download/
* Redis 5.0.x https://redis.io/download
* Consul 1.7.x https://www.consul.io/downloads.html
* RabbitMQ 3.8.x https://www.rabbitmq.com/download.html
* Operating System: No requirement.

Environment setup
-------------------
#### 1. Azure Cosmos DB Emulator
[Export the Azure Cosmos DB Emulator certificates for use with Java](https://docs.microsoft.com/en-us/azure/cosmos-db/local-emulator-export-ssl-certificates)
#### 2. Hazelcast IMDG 3.x (Docker)
[Installing Hazelcast IMDG](http://docs.hazelcast.org/docs/latest-dev/manual/html-single/index.html#installation)
* docker pull hazelcast/hazelcast
* docker run --name hazelcast -d -p 5701:5701 hazelcast/hazelcast
* docker start hazelcast / docker stop hazelcast
#### 3. Redis Docker
* docker pull redis 
* docker run --name redis -d -p 6379:6379 redis
* docker start redis / docker stop redis
#### 4. Mongo Docker
* docker pull mongo 
* docker run --name mongo -d -p 27017:27017 mongo
* docker start mongo / docker stop mongo
#### 5. RabbitMQ Docker
* docker pull rabbitmq
* docker run --name rabbitmq -d -p 5672:5672 -p 15672:15672 rabbitmq:3-management
* docker start rabbitmq / docker stop rabbitmq
#### 6. Docker compose
* docker-compose -f ./docker-compose.yml up -d

Structure
-------------------
Project contains following modules:

* Module common contains common interfaces and classes.
* Module audit contains Audit implementation
* Module ad-connector contains ActiveDirectory client implementation
* Module core contains Core implementation
* Module exchange-connector contains MS Exchange client (PowerShell client) implementation
* Module power-shell-connector containsPowerShell client implementation
* Module mail-service contains Email notification service
* Module remedyforce-connector contains RemedyForce client implementation

Build
-------------------

* Clone parent repo [isrm_iam_global_mfa_commons_parent](https://bitbucket.mckesson.com:8443/scm/isrm/isrm_iam_global_mfa_commons_parent.git)
* From isrm_iam_global_mfa_commons_parent run command `mvn clean install -N` to install parent pom

* Clone repo [isrm_iam_global_mfa_commons](https://bitbucket.mckesson.com:8443/scm/isrm/isrm_iam_global_mfa_commons.git)
* From isrm_iam_global_mfa_commons run command `mvn clean install`

* Clone repo [isrm_iam_global_mfa_commons_rest](https://bitbucket.mckesson.com:8443/scm/isrm/isrm_iam_global_mfa_commons_rest.git)
* From isrm_iam_global_mfa_commons_rest run command `mvn clean install`

* Download *[Okta-Provisioning-Connector-SDK-02.00.02.zip](https://usoncology-dev1-admin.oktapreview.com/static/toolkits/Okta-Provisioning-Connector-SDK-02.00.02.zip)*
from [Okta portal](https://usoncology-dev1-admin.oktapreview.com/admin/settings/downloads) and unzip

* Run script `Okta-Provisioning-Connector-SDK-02.00.02.zip\lib\install`
* Go to folder [isrm_iam_wd_b2e_poc](https://bitbucket.mckesson.com:8443/scm/isrm/isrm_iam_wd_b2e_poc.git) and run `mvn -P <DATABASE PROFILE>,stream-kafka clean install`
> DATABASE PROFILE is one of:
> * **db_local** (*default*)
> * **db_dev**
> * **db_uat**
> * **db_prod**

Deploy artifacts
-------------------
#### 1. Create `settings.xml`
```xml
<?xml version="1.0" encoding="UTF-8"?>
<settings xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.2.0 http://maven.apache.org/xsd/settings-1.2.0.xsd" xmlns="http://maven.apache.org/SETTINGS/1.2.0"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <servers>
    <server>
      <username>user.email</username>
      <password>user-api-key</password>
      <id>mckesson-iam-local</id>
    </server>
  </servers>
  <profiles>
    <profile>
      <id>mckesson-jfrog</id>
      <repositories>
        <repository>
          <id>mckesson-iam-local</id>
          <url>https://mck.jfrog.io/artifactory/iam-local</url>
        </repository>
      </repositories>
    </profile>
  </profiles>
</settings>
```

#### 2. Deploy `isrm_iam_global_mfa_commons_parent` from folder isrm_iam_global_mfa_commons_parent run command
```bash
mvn deploy:deploy -N -DaltDeploymentRepository=mckesson-iam-local::default::https://mck.jfrog.io/artifactory/iam-local
```

#### 3. Deploy `isrm_iam_global_mfa_commons` from folder isrm_iam_global_mfa_commons run command
```bash
mvn jar:jar deploy:deploy -DaltDeploymentRepository=mckesson-iam-local::default::https://mck.jfrog.io/artifactory/iam-local
```

#### 4. Deploy `isrm_iam_global_mfa_commons_rest` from folder isrm_iam_global_mfa_commons_rest run command
```bash
mvn jar:jar deploy:deploy -DaltDeploymentRepository=mckesson-iam-local::default::https://mck.jfrog.io/artifactory/iam-local
```
