Okta Sync Project
=================

Deploy to PCF
-------------------
# 1. cf CLI
[Install cf CLI](https://docs.cloudfoundry.org/cf-cli/install-go-cli.html) and login on pcf dev/uat
# 2. Build project and download jar files
* use command to build project `mvn -P stream-kafka -DskipTests=true clean install`
# 3. Use deployment descriptor from source code (update if needed): [manifest-dev.yml](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/manifest-dev.yml) or [manifest-uat.yml](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/manifest-uat.yml)
* Update location of jar files for each service inside descriptor (see for **path** attribute)
```yaml
applications:
  - name: ad-connector
    memory: 1G
    buildpacks:
      - java_buildpack_offline
    path: PUT_PATH_HERE/ad-connector.jar
    routes:
      - route: passportdev.mckesson.com/ad-connector
    env:
      JBP_CONFIG_OPEN_JDK_JRE: '{ jre: { version: 11.+ } }'
```
# 4. Update configuration files on PCF
* use default JSON files from folder `.conf` (see [source code](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/.conf)) 
## Kafka configuration [passport-kafka.json](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/.conf/passport-kafka.json)
```json
{
	"host": "kafka-host",
	"port": 9092,
	"username": "User name",
	"password": "Password",
	"security.protocol": "SASL_SSL"
}
```
Please use `core-events-stream-uat` as topic name.

## JDBC configuration [usonworkdayuat.json](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/.conf/usonworkdayuat.json)
```json
{
	"datasourceDriver": "com.mysql.cj.jdbc.Driver",
	"datasourceUrl": "jdbc:mysql://mysql-hostname:3306",
	"datasourceUrlParams": "serverTimezone=UTC",
	"datasourceUser": "MysqlUser",
	"datasourcePwd": "MysqlPwd"
}
```

## Redis configuration [passport-redis.json](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/.conf/passport-redis.json)
```json
{
	"host": "10.15.26.4",
	"port": 6379,
	"pwd": "",
	"useSSL": false
}
```

## Audit service [passport-audit-service.json](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/.conf/passport-audit-service.json)
```json
{
	"datasourceSchema": "wd_b2e_execution"
}
```
## Configuration service [passport-configuration-service.json](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/.conf/passport-configuration-service.json)
```json
{
	"datasourceSchema": "wd_b2e_config"
}
```
## Core service [passport-core.json](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/.conf/passport-core.json)
```json
{
	"datasourceSchema": "wd_b2e_execution"
}
```
## Exchange connector service [passport-exchange-connector.json](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/.conf/passport-exchange-connector.json)
```json
{
    "security.oauth2.base-url": "https://usoncology-uat.okta.com/oauth2/default",
    "security.oauth2.client.client-id": "0oauk2w6zdJh4sSVF0h7",
    "security.oauth2.client.client-secret": "secret",
    "security.oauth2.client.scope": "power-shell-connector",

    "services.configuration.host": "https://passportuat.mckesson.com/configuration-service/",
    "services.power-shell-connector.host": "https://isrm-309.mshusontest.com:443/power-shell-connector/"
}
```
where
* `services.configuration.host` - link to configuration service on PCF
* `services.power-shell-connector.host` - link to PowerShell connector (trailing `/` is required)
* `security.oauth2.*` - oAuth settings for details see [Create a Secure Spring REST API](https://developer.okta.com/blog/2018/12/18/secure-spring-rest-api#set-up-an-oauth-20-resource-server). Also see example of [configured <u>Java Token Auth</u>](https://usoncology-uat-admin.okta.com/admin/app/oidc_client/instance/0oauk2w6zdJh4sSVF0h7/#tab-general)

## RemedyForce connector service [passport-remedyforce-connector.json](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/.conf/passport-remedyforce-connector.json)
```json
{
  "remedyforce.username": "username",
  "remedyforce.password": "password",
  "remedyforce.endpoint": "msh--rf",
  "remedyforce.defaultClientId": "0053C000002hbuVQAQ",
    
  "remedyforce.service-request.clinicalTransfer.requestDefinitionId": "a4kJ0000000DlixIAC",
  "remedyforce.service-request.hrbuTransfer.requestDefinitionId": "a4kJ0000000DliiIAC",
  "remedyforce.service-request.newUser.requestDefinitionId": "a4kJ0000000DliTIAS",
  "remedyforce.service-request.newUserExecutive.requestDefinitionId": "a4kJ0000000DliYIAS",
  "remedyforce.service-request.termination.requestDefinitionId": "a4k6C000000Gv7yQAC",
  "remedyforce.service-request.userAccountExpired.requestDefinitionId": "a4kJ0000000DlinIAC",
  "remedyforce.task.terminationCentricity.queueName": "Centricity Business",
  "remedyforce.task.terminationCentricity.templateId": "a5DJ0000000FTA4MAO",
  "remedyforce.task.terminationDatabase.queueName": "Infrastructure USON",
  "remedyforce.task.terminationDatabase.templateId": "a5DJ0000000FT9zMAG",
  "remedyforce.task.terminationERPSecurity.queueName": "Security - Application",
  "remedyforce.task.terminationERPSecurity.templateId": "a5DJ0000000FT9fMAG",
  "remedyforce.task.terminationIknowmed.queueName": "Tech Product Support L1",
  "remedyforce.task.terminationIknowmed.templateId": "a5DJ0000000FTAEMA4",
  "remedyforce.task.terminationSalesforce.queueName": "Salesforce",
  "remedyforce.task.terminationSalesforce.templateId": "a5DJ0000000FT9kMAG",
  "remedyforce.task.terminationTelecom.queueName": "Telecom",
  "remedyforce.task.terminationTelecom.templateId": "a5D0f000001UT0HEAW",
  "remedyforce.task.terminationTXO.queueName": "IT TXO PMS",
  "remedyforce.task.terminationTXO.templateId": "a5DJ0000000FTA9MAO",
  "remedyforce.task.terminationWorkday.queueName": "HR Applications",
  "remedyforce.task.terminationWorkday.templateId": "a5DJ0000000FTAJMA4"
}
```
Configuration should be created from OpenIDM Workday configuration files.

## Okta client service [passport-okta-client.json](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/.conf/passport-okta-client.json)
```json
{
	"oktaclient": {
		"baseUrl": "https://usoncology-uat.okta.com/api/v1",
		"baseUrlAdmin": "https://usoncology-uat-admin.okta.com/api/v1",
		"token": "token",
		"timeout": 10000,
		"attempts": 3
	}
}
```
Fill this section with data from okta portal (see [Create an API token](https://developer.okta.com/docs/guides/create-an-api-token/overview/))

## SCIM connector service [passport-scim-connector.json](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/.conf/passport-scim-connector.json)
```json
{
	"scim.app.name": "usoncology-uat_mckpassport_1",
	"scim.security.user": "user",
	"scim.security.password": "user",
	"datasourceSchema": "wd_b2e_execution",
	"services.core.endpoint": "https://passportuat.mckesson.com/core/gateway"
}
```

Use values of `scim.security.user` and `scim.security.password` for security settings for scim connector application on Okta side. Value of `scim.app.name` is
application name assigned by OKTA.

## Mail service [passport-mail-service.json](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/.conf/passport-mail-service.json)

```json
{
	"security.oauth2.base-url": "https://usoncology-uat.okta.com/oauth2/default",
	"security.oauth2.client.client-id": "0oauk2w6zdJh4sSVF0h7",
	"security.oauth2.client.client-secret": "secret",
	"security.oauth2.client.scope": "mail-service",
	"mail.host": "smtp.mckesson.com",
	"mail.port": 25,
	"mail.username": "",
	"mail.password": "",
	"email-sender.enabled": true,
	"email-sender.from": "from@mckesson.com",
	"email-sender.altAddress": "user@mckesson.com"
}
```

# Deploy configuration to PCF

```shell
cf create-service credhub default usonworkdayuat -c .\.conf\usonworkdayuat.json
cf create-service credhub default passport-kafka -c .\.conf\passport-kafka.json
cf create-service credhub default passport-redis -c .\.conf\passport-redis.json
cf create-service credhub default passport-ad-connector -c .\.conf\passport-ad-connector.json
cf create-service credhub default passport-audit-service -c .\.conf\passport-audit-service.json
cf create-service credhub default passport-configuration-service -c .\.conf\passport-configuration-service.json
cf create-service credhub default passport-core -c .\.conf\passport-core.json
cf create-service credhub default passport-exchange-connector -c .\.conf\passport-exchange-connector.json
cf create-service credhub default passport-okta-client -c .\.conf\passport-okta-client.json
cf create-service credhub default passport-remedyforce-connector -c .\.conf\passport-remedyforce-connector.json
cf create-service credhub default passport-scim-connector -c .\.conf\passport-scim-connector.json
cf create-service credhub default passport-mail-service -c .\.conf\passport-mail-service.json
```
to update existing service use command
```shell
cf update-service passport-kafka -c .\.conf\passport-kafka.json
```
bind configuration to application
```shell
cf bind-service audit-service usonworkdayuat
cf bind-service configuration-service usonworkdayuat
cf bind-service core usonworkdayuat
cf bind-service scim-connector usonworkdayuat

cf bind-service audit-service passport-kafka
cf bind-service ad-connector passport-kafka
cf bind-service core passport-kafka
cf bind-service exchange-connector passport-kafka
cf bind-service okta-client passport-kafka
cf bind-service remedyforce-connector passport-kafka

cf bind-service ad-connector passport-redis
cf bind-service scim-connector passport-redis

cf bind-service ad-connector passport-ad-connector
cf bind-service audit-service passport-audit-service
cf bind-service configuration-service passport-configuration-service
cf bind-service core passport-core
cf bind-service scim-connector passport-scim-connector
cf bind-service exchange-connector passport-exchange-connector
cf bind-service remedyforce-connector passport-remedyforce-connector
cf bind-service okta-client passport-okta-client

cf bind-service mail-service passport-mail-service
```

# 7. Create/Update DB structure (apply migrations)
Use liquibase migration scripts from [b2e_db\liquibase](https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_wd_b2e_poc/browse/b2e_db/liquibase) <br/>
Run script to apply migrations
```shell
liquibase.bat --url="jdbc:mysql://mysql:3306/wd_b2e_config?serverTimezone=UTC" --changeLogFile="master.xml" --username=User --password=Pwd update
```

# 8. Deploy services
* `cf push audit-service -f .\manifest-dev.yml` 
* `cf push configuration-service -f .\manifest-dev.yml`
* `cf push core -f .\manifest-dev.yml`
* `cf push ad-connector -f .\manifest-dev.yml`
* `cf push exchange-connector -f .\manifest-dev.yml`
* `cf push remedyforce-connector -f .\manifest-dev.yml`
* `cf push okta-client -f .\manifest-dev.yml`
* `cf push mail-service -f .\manifest-dev.yml`
* `cf push scim-connector -f .\manifest-dev.yml`
