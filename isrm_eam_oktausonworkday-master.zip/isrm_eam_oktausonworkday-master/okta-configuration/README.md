# Contents of Directory

* `./Okta.http` - Set of useful requests to Okta API

    > ## All requests listed below are in __Okta.http__ in a __parameterized__ form

## `dev` - Settings for dev-environment

---

### `dev/AD`

* `all_dns(hierarhy MSHUSONTEST_OU_GROUP_CN).ldif` - Import file with All OrgUnits- & Groups- hierarhy

---

### `dev/flows`

* `stagesWorkflows.json` - Formatted Export of `stages-workflows` Folder

---

### `dev/groups`

* `okta-groups.json` - Export of Okta Groups associated with AD Groups & OrgUnits

    > usoncology-uat-admin.okta.com/api/v1/groups?limit=1000&q=(

* `push-groups.json` - Export Relations between Okta Groups & AD Groups

    > usoncology-uat-admin.okta.com/api/internal/instance/0oatgqr0aiK3rKt7H0h7/grouppush?limit=100
    >
    > usoncology-uat-admin.okta.com/api/internal/instance/0oatgqr0aiK3rKt7H0h7/grouppush?lastSeenMappingId=gPmtssbez8U5tLrsQ0h7&limit=100

---

### `dev/mappings`

* `ad-okta.json` - Export AD - Okta mapping

    > usoncology-uat-admin.okta.com/api/internal/v1/mappings?source=otytgqr0avqAPzB030h7&target=otyotswitrHG9PHLi0h7

* `okta-ad.json` - Export Okta - AD mapping

    > usoncology-uat-admin.okta.com/api/internal/v1/mappings?source=otyotswitrHG9PHLi0h7&target=otytgqr0avqAPzB030h7

* `okta-passport.json` - Export Okta - Passport mapping

    > usoncology-uat-admin.okta.com/api/internal/v1/mappings?source=otyotswitrHG9PHLi0h7&target=otytattvk9YU5jW4s0h7

* `okta-workday.json` - Export Okta - Workday mapping

    >usoncology-uat-admin.okta.com/api/internal/v1/mappings?source=otyotswitrHG9PHLi0h7&target=otysaoeuo8VgKxkCp0h7

* `passport-okta.json` - Export Passport - Okta mapping

    > usoncology-uat-admin.okta.com/api/internal/v1/mappings?source=otytattvk9YU5jW4s0h7&target=otyotswitrHG9PHLi0h7

* `workday-okta.json` - Export Workday - Okta mapping

    > usoncology-uat-admin.okta.com/api/internal/v1/mappings?source=otysaoeuo8VgKxkCp0h7&target=otyotswitrHG9PHLi0h7

---

### `dev/profiles`

* `ad-user.json` - AD Profile

    > usoncology-uat-admin.okta.com/api/v1/apps/user/types/otytgqr0avqAPzB030h7/schemas

* `okta-user.json` - Okta Profile

    > usoncology-uat-admin.okta.com/api/v1/meta/schemas/user/default

* `passport-user.json` - Passport Profile

    > usoncology-uat-admin.okta.com/api/v1/apps/user/types/otytattvk9YU5jW4s0h7/schemas

* `workday-user.json` - Workday Profile

    > usoncology-uat-admin.okta.com/api/v1/apps/user/types/otysaoeuo8VgKxkCp0h7/schemas

* `event-type.json` - Passport Event User Type

    > usoncology-uat-admin.okta.com/api/v1/user/types/00uvztaui6E72BhFJ0h7

* `event-user.json` - Profile of  Event User Type

    > usoncology-uat-admin.okta.com/api/v1/user/types/00uvztaui6E72BhFJ0h7/schemas

passport-user.json
---

### `dev/tables`

* `deferred_tasks.json` - Structure of `deferred_tasks` table
* `domains_table.json` - Structure of `domains_table` table
* `flow_mappings.json` - Structure of `flow_mappings` table
* `global_table.json` - Structure of `global_table` table
* `group_mapping_table.json` - Structure of `group_mapping_table` table
* `hrbu_view_table.json` - Structure of `hrbu_view_table` table
* `okta_events.json` - Structure of `okta_events` table
* `domains_table.csv` - Import file for `domains_table` table
* `flow_mappings.csv` - Import file for `flow_mappings` table
* `global_table.csv` - Import file for `global_table` table
* `group_mapping_table.csv` - Import file for `group_mapping_table` table
* `hrbu_view_table.csv` - Import file for `hrbu_view_table` table

---

### `dev/users

* `passport-event.json` - Passport Event User

    > usoncology-uat-admin.okta.com/api/v1/users/00uvztaui6E72BhFJ0h7

---

