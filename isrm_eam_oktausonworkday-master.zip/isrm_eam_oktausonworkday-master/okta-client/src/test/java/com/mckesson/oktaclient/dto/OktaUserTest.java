package com.mckesson.oktaclient.dto;

import com.mckesson.common.domain.Manager;
import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.model.ScenarioEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Optional;

class OktaUserTest {

    @Test
    void constructorTest() {
        CoreEvent coreEvent = CoreEvent.builder()
                .target("targe")
                .scenario(ScenarioEnum.CREATE)
                .stage("stage")
                .build();
        OktaUser oktaUser = new OktaUser(coreEvent);

        Assertions.assertEquals(coreEvent.getTarget(), oktaUser.getEvtTarget());
        Assertions.assertEquals(coreEvent.getScenario().getName(), oktaUser.getEvtScenario());
        Assertions.assertEquals(coreEvent.getStage(), oktaUser.getEvtStage());
    }

    @Test
    void setManagerAsObject() {
        OktaUser oktaUser = new OktaUser();
        Assertions.assertNull(oktaUser.getPsManagerObject());

        oktaUser.setPsManagerAsObject(null);
        Assertions.assertEquals("", oktaUser.getPsManagerObject());

        Manager manager = new Manager();
        String managerObject = Optional.ofNullable(manager).map(Manager::getManagerAsString).get();
        oktaUser.setPsManagerAsObject(manager);
        Assertions.assertEquals(managerObject, oktaUser.getPsManagerObject());
    }

    @Test
    void setOldManagerAsObject() {
        OktaUser oktaUser = new OktaUser();
        Assertions.assertNull(oktaUser.getPsOldManagerObject());

        oktaUser.setPsOldManagerAsObject(null);
        Assertions.assertEquals("", oktaUser.getPsOldManagerObject());

        Manager manager = new Manager();
        String managerObject = Optional.ofNullable(manager).map(Manager::getManagerAsString).get();
        oktaUser.setPsOldManagerAsObject(manager);
        Assertions.assertEquals(managerObject, oktaUser.getPsOldManagerObject());
    }
}