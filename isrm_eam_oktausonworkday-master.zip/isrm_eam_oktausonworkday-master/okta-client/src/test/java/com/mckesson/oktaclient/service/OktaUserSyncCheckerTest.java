package com.mckesson.oktaclient.service;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.audit.AuditService;
import com.mckesson.common.domain.CommonUser;
import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.model.ModuleEnum;
import com.mckesson.common.model.SyncCheck;
import com.mckesson.oktaclient.dto.OktaGroupResponse;
import com.mckesson.oktaclient.dto.OktaUser;
import com.mckesson.oktaclient.dto.OktaUserResponse;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Date;
import java.util.List;
import java.util.UUID;

class OktaUserSyncCheckerTest {

    @Test
    public void runCheck() {
        var messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
        var oktaUserService = Mockito.mock(OktaUserService.class);
        var auditService = Mockito.mock(AuditService.class);
        String groupName = "group-name";
        var instance = new OktaUserSyncChecker(messageBrokerPublisher, oktaUserService, auditService, groupName);

        var group = new OktaGroupResponse();
        group.setId("group1");

        String userId = UUID.randomUUID().toString();
        OktaUser user = new OktaUser();
        user.setPsUserId(userId);
        user.setAdOuSelector("OuSelector");
        var userResponse = new OktaUserResponse();
        userResponse.setProfile(user);
        userResponse.setId(UUID.randomUUID().toString());

        user.setAdActive(false);
        user.setWdActive(true);
        user.setAdAddress("AdAddress");
        user.setWdAddress("WdAddress");
        user.setAdCity("AdCity");
        user.setWdCity("WdCity");
        user.setAdCn("AdCn");
        user.setWdCn("WdCn");
        user.setAdCompanyId("AdCompanyId");
        user.setWdCompanyId("WdCompanyId");
        user.setAdCountry("AdCountry");
        user.setWdCountry("WdCountry");
        user.setAdDescription("AdDescription");
        user.setWdDescription("WdDescription");
        user.setAdDisplayName("AdDisplayName");
        user.setWdDisplayName("WdDisplayName");
        user.setAdEmail("AdEmail");
        user.setWdEmail("WdEmail");
        user.setAdEmailPrimary("AdEmailPrimary");
        user.setWdEmailPrimary("WdEmailPrimary");
        user.setAdEmailSecondary("AdEmailSecondary");
        user.setWdEmailSecondary("WdEmailSecondary");
        user.setAdEmailSecondaryAdditional("AdEmailSecondaryAdditional");
        user.setWdEmailSecondaryAdditional("WdEmailSecondaryAdditional");
        user.setAdEmployee(false);
        user.setWdEmployee(true);
        user.setAdExecutiveDirector("AdExecutiveDirector");
        user.setWdExecutiveDirector("WdExecutiveDirector");
        user.setAdExecutiveDirectorHRBU("AdExecutiveDirectorHRBU");
        user.setWdExecutiveDirectorHRBU("WdExecutiveDirectorHRBU");
        user.setAdExecutiveDirectorUserId("AdExecutiveDirectorUserId");
        user.setWdExecutiveDirectorUserId("WdExecutiveDirectorUserId");
        user.setAdFax("AdFax");
        user.setWdFax("WdFax");
        user.setAdFirstName("AdFirstName");
        user.setWdFirstName("WdFirstName");
        user.setAdHRBU("AdHRBU");
        user.setWdHRBU("WdHRBU");
        user.setAdLastName("AdLastName");
        user.setWdLastName("WdLastName");
        user.setAdLeaveOfAbsence(false);
        user.setWdLeaveOfAbsence(true);
        user.setAdLegalName("AdLegalName");
        user.setWdLegalName("WdLegalName");
        user.setAdLegalPrefix("AdLegalPrefix");
        user.setWdLegalPrefix("WdLegalPrefix");
        user.setAdLegalSuffix("AdLegalSuffix");
        user.setWdLegalSuffix("WdLegalSuffix");
        user.setAdManagerHRBU("AdManagerHRBU");
        user.setWdManagerHRBU("WdManagerHRBU");
        user.setAdManagerId("AdManagerId");
        user.setWdManagerId("WdManagerId");
        user.setAdManagerUserId("AdManagerUserId");
        user.setWdManagerUserId("WdManagerUserId");
        user.setAdMiddleName("AdMiddleName");
        user.setWdMiddleName("WdMiddleName");
        user.setAdMobile("AdMobile");
        user.setWdMobile("WdMobile");
        user.setAdPhysicalDeliveryOfficeName("AdPhysicalDeliveryOfficeName");
        user.setWdPhysicalDeliveryOfficeName("WdPhysicalDeliveryOfficeName");
        user.setAdPostalAddress("AdPostalAddress");
        user.setWdPostalAddress("WdPostalAddress");
        user.setAdPostalCode("AdPostalCode");
        user.setWdPostalCode("WdPostalCode");
        user.setAdPreferredFirstName("AdPreferredFirstName");
        user.setWdPreferredFirstName("WdPreferredFirstName");
        user.setAdPreferredLastName("AdPreferredLastName");
        user.setWdPreferredLastName("WdPreferredLastName");
        user.setAdPreferredPrefix("AdPreferredPrefix");
        user.setWdPreferredPrefix("WdPreferredPrefix");
        user.setAdPreferredSuffix("AdPreferredSuffix");
        user.setWdPreferredSuffix("WdPreferredSuffix");
        user.setAdState("AdState");
        user.setWdState("WdState");
        user.setAdTelephoneNumber("AdTelephoneNumber");
        user.setWdTelephoneNumber("WdTelephoneNumber");
        user.setAdTerminated(false);
        user.setWdTerminated(true);
        user.setAdTitle("AdTitle");
        user.setWdTitle("WdTitle");
        user.setAdUserId("AdUserId");
        user.setWdUserId("WdUserId");
        user.setAdUserPrincipalName("AdUserPrincipalName");
        user.setWdUserPrincipalName("WdUserPrincipalName");
        user.setAdWorkerId("AdWorkerId");
        user.setWdWorkerId("WdWorkerId");
        user.setAdWorkerType("AdWorkerType");
        user.setWdWorkerType("WdWorkerType");
        user.setAdWorkerTypeDescriptor("AdWorkerTypeDescriptor");
        user.setWdWorkerTypeDescriptor("WdWorkerTypeDescriptor");

        Mockito.when(oktaUserService.findGroups(Mockito.eq(groupName), Mockito.any()))
                .thenReturn(List.of(group));
        Mockito.when(oktaUserService.getGroupUsers(Mockito.eq(group.getId())))
                .thenReturn(List.of(userResponse).iterator());
        instance.runCheck();

        var auditEvent = AuditEvent.builder()
                .date(new Date())
                .app(AuditEvent.Application.PASSPORT)
                .oktaUserId(userResponse.getId())
                .message("ERROR")
                .situation("Sync check")
                .status("ERROR")
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues("Active ad: `false` wd: `true`\n" +
                        "Address ad: `AdAddress` wd: `WdAddress`\n" +
                        "City ad: `AdCity` wd: `WdCity`\n" +
                        "Cn ad: `AdCn` wd: `WdCn`\n" +
                        "CompanyId ad: `AdCompanyId` wd: `WdCompanyId`\n" +
                        "Country ad: `AdCountry` wd: `WdCountry`\n" +
                        "Description ad: `AdDescription` wd: `WdDescription`\n" +
                        //"DisplayName ad: `AdDisplayName` wd: `WdDisplayName`\n" +
                        "Email ad: `AdEmail` wd: `WdEmail`\n" +
                        "EmailPrimary ad: `AdEmailPrimary` wd: `WdEmailPrimary`\n" +
                        "EmailSecondary ad: `AdEmailSecondary` wd: `WdEmailSecondary`\n" +
                        "EmailSecondaryAdditional ad: `AdEmailSecondaryAdditional` wd: `WdEmailSecondaryAdditional`\n" +
                        "Employee ad: `false` wd: `true`\n" +
                        "ExecutiveDirector ad: `AdExecutiveDirector` wd: `WdExecutiveDirector`\n" +
                        "ExecutiveDirectorHRBU ad: `AdExecutiveDirectorHRBU` wd: `WdExecutiveDirectorHRBU`\n" +
                        "ExecutiveDirectorUserId ad: `AdExecutiveDirectorUserId` wd: `WdExecutiveDirectorUserId`\n" +
                        "Fax ad: `AdFax` wd: `WdFax`\n" +
                        "FirstName ad: `AdFirstName` wd: `WdFirstName`\n" +
                        "HRBU ad: `AdHRBU` wd: `WdHRBU`\n" +
                        "LastName ad: `AdLastName` wd: `WdLastName`\n" +
                        "LeaveOfAbsence ad: `false` wd: `true`\n" +
                        "LegalName ad: `AdLegalName` wd: `WdLegalName`\n" +
                        "LegalPrefix ad: `AdLegalPrefix` wd: `WdLegalPrefix`\n" +
                        "LegalSuffix ad: `AdLegalSuffix` wd: `WdLegalSuffix`\n" +
                        "ManagerHRBU ad: `AdManagerHRBU` wd: `WdManagerHRBU`\n" +
                        "ManagerId ad: `AdManagerId` wd: `WdManagerId`\n" +
                        "ManagerUserId ad: `AdManagerUserId` wd: `WdManagerUserId`\n" +
                        "MiddleName ad: `AdMiddleName` wd: `WdMiddleName`\n" +
                        "Mobile ad: `AdMobile` wd: `WdMobile`\n" +
                        "PhysicalDeliveryOfficeName ad: `AdPhysicalDeliveryOfficeName` wd: `WdPhysicalDeliveryOfficeName`\n" +
                        "PostalAddress ad: `AdPostalAddress` wd: `WdPostalAddress`\n" +
                        "PostalCode ad: `AdPostalCode` wd: `WdPostalCode`\n" +
                        "PreferredFirstName ad: `AdPreferredFirstName` wd: `WdPreferredFirstName`\n" +
                        "PreferredLastName ad: `AdPreferredLastName` wd: `WdPreferredLastName`\n" +
                        "PreferredPrefix ad: `AdPreferredPrefix` wd: `WdPreferredPrefix`\n" +
                        "PreferredSuffix ad: `AdPreferredSuffix` wd: `WdPreferredSuffix`\n" +
                        "State ad: `AdState` wd: `WdState`\n" +
                        "TelephoneNumber ad: `AdTelephoneNumber` wd: `WdTelephoneNumber`\n" +
                        "Terminated ad: `false` wd: `true`\n" +
                        "Title ad: `AdTitle` wd: `WdTitle`\n" +
                        "UserPrincipalName ad: `AdUserPrincipalName` wd: `WdUserPrincipalName`\n" +
                        "WorkerId ad: `AdWorkerId` wd: `WdWorkerId`\n" +
                        "WorkerType ad: `AdWorkerType` wd: `WdWorkerType`\n" +
                        "WorkerTypeDescriptor ad: `AdWorkerTypeDescriptor` wd: `WdWorkerTypeDescriptor`")
                .build();
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));

        Mockito.reset(auditService, oktaUserService);

        user = new OktaUser();
        user.setPsUserId(userId);
        user.setAdOuSelector("OuSelector");
        userResponse = new OktaUserResponse();
        userResponse.setProfile(user);
        userResponse.setId(UUID.randomUUID().toString());
        user.setAdWorkerTypeDescriptor("AdWorkerTypeDescriptor");
        user.setWdWorkerTypeDescriptor("WdWorkerTypeDescriptor");

        Mockito.when(oktaUserService.findGroups(Mockito.eq(groupName), Mockito.any()))
                .thenReturn(List.of(group));
        Mockito.when(oktaUserService.getGroupUsers(Mockito.eq(group.getId())))
                .thenReturn(List.of(userResponse).iterator());
        instance.runCheck();

        auditEvent = AuditEvent.builder()
                .date(new Date())
                .app(AuditEvent.Application.PASSPORT)
                .oktaUserId(userResponse.getId())
                .message("ERROR")
                .situation("Sync check")
                .status("ERROR")
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues("WorkerTypeDescriptor ad: `AdWorkerTypeDescriptor` wd: `WdWorkerTypeDescriptor`")
                .build();
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));

        Mockito.reset(auditService, oktaUserService);
        user = new OktaUser();
        user.setPsUserId(userId);
        user.setAdOuSelector("OuSelector");
        user.setAdShowInAddressBook("[\"\"]");
        userResponse = new OktaUserResponse();
        userResponse.setProfile(user);
        userResponse.setId(UUID.randomUUID().toString());
        user.setAdWorkerTypeDescriptor("WorkerTypeDescriptor");
        user.setWdWorkerTypeDescriptor("WorkerTypeDescriptor");

        Mockito.when(oktaUserService.findGroups(Mockito.eq(groupName), Mockito.any()))
                .thenReturn(List.of(group));
        Mockito.when(oktaUserService.getGroupUsers(Mockito.eq(group.getId())))
                .thenReturn(List.of(userResponse).iterator());
        Mockito.when(oktaUserService.getUserGroups(Mockito.eq(userId), Mockito.any()))
                .thenReturn(List.of());
        instance.runCheck();

        var syncCheck = SyncCheck.builder()
                .oktaUserId(userResponse.getId())
                .user(CommonUser.builder()
                        .proxyAddresses(List.of())
                        .showInAddressBook(List.of())
                        .memberOf(List.of())
                        .logonHours("000000000000000000000000000000000000000000")
                        .build())
                .build();
        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.ACTIVE_DIRECTORY), Mockito.any(SyncCheck.class));
    }
}