package com.mckesson.oktaclient.rest;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.oktaclient.service.OktaProcessor;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class OktaControllerTest {

    @Test
    void processEvent() {
        OktaProcessor oktaProcessor = Mockito.mock(OktaProcessor.class);
        CoreEvent event = Mockito.mock(CoreEvent.class);

        OktaController instance = new OktaController(oktaProcessor);
        instance.processEvent(event);
        Mockito.verify(oktaProcessor).processEvent(Mockito.eq(event));
    }
}