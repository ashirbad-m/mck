package com.mckesson.oktaclient.rest;

import com.mckesson.oktaclient.dto.OktaUser;
import com.mckesson.oktaclient.service.OktaUserService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.UUID;

class OktaUserControllerTest {

    @Test
    void getUser() {
        OktaUserService oktaUserService = Mockito.mock(OktaUserService.class);
        OktaUserController instance = new OktaUserController(oktaUserService);

        String id = UUID.randomUUID().toString();
        instance.getUser(id);
        Mockito.verify(oktaUserService).getOktaUser(Mockito.eq(id), Mockito.any());
    }

    @Test
    void updateUser() {
        OktaUserService oktaUserService = Mockito.mock(OktaUserService.class);
        OktaUserController instance = new OktaUserController(oktaUserService);

        String id = UUID.randomUUID().toString();
        OktaUser oktaUser = new OktaUser();
        instance.updateUser(id, oktaUser);
        Mockito.verify(oktaUserService).setTargetAndUpdateUser(Mockito.eq(id), Mockito.eq(oktaUser), Mockito.eq(null),
                Mockito.eq(true), Mockito.any());
    }
}