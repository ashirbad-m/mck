package com.mckesson.oktaclient.service;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.audit.AuditService;
import com.mckesson.common.domain.OktaUser;
import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.*;
import com.mckesson.common.scenario.ScenarioProvider;
import com.mckesson.common.workday.converter.ConverterUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;

import static com.mckesson.common.workday.converter.ConverterUtils.object2Json;

class OktaProcessorTest {

    private final ScenarioProvider scenarioProvider = new ScenarioProvider();
    private final MessageBrokerPublisher messageBrokerPublisher = Mockito.mock(MessageBrokerPublisher.class);
    private final OktaUserService oktaUserService = Mockito.mock(OktaUserService.class);
    private final AuditService auditService = Mockito.mock(AuditService.class);

    @BeforeEach
    public void setUp() {
        Mockito.reset(messageBrokerPublisher);
        Mockito.reset(oktaUserService);
        Mockito.reset(auditService);
    }

    @Test
    void getProcessors() {
        OktaProcessor oktaProcessor = new OktaProcessor(scenarioProvider, messageBrokerPublisher, oktaUserService, auditService);
        var processors = oktaProcessor.getProcessors();
        for (var scenario : ScenarioEnum.values()) {
            Assertions.assertTrue(processors.containsKey(scenario));
        }
    }

    @Test
    void processAction() {
        OktaProcessor oktaProcessor = new OktaProcessor(scenarioProvider, messageBrokerPublisher, oktaUserService, auditService);

        PassportAction.OktaEventBody eventBody = new PassportAction.OktaEventBody();
        eventBody.setIncidentData("");
        eventBody.setEventId("eventId");
        eventBody.setBatchId("batchId");
        eventBody.setOwfFlowId("owfFlowId");
        eventBody.setOwfExecutionId("owfExecutionId");
        eventBody.setOktaUserId("oktaUserId");

        PassportAction passportAction = new PassportAction();
        passportAction.setEventType(PassportAction.EventTypeEnum.OKTA);
        passportAction.setEventBody(ConverterUtils.writeValueAsString(eventBody));

        oktaProcessor.processAction(passportAction);
        Mockito.verify(oktaUserService, Mockito.never()).setTargetAndUpdateUser(Mockito.eq(eventBody.getOktaUserId()), Mockito.any(), Mockito.eq(null), Mockito.anyBoolean(), Mockito.any());
        Mockito.verify(auditService, Mockito.never()).audit(Mockito.any());

        eventBody = new PassportAction.OktaEventBody();
        eventBody.setIncidentData("incidentData");
        eventBody.setEventId("eventId");
        eventBody.setBatchId("batchId");
        eventBody.setOwfFlowId("owfFlowId");
        eventBody.setOwfExecutionId("owfExecutionId");
        eventBody.setOktaUserId("oktaUserId");

        passportAction = new PassportAction();
        passportAction.setEventType(PassportAction.EventTypeEnum.OKTA);
        passportAction.setEventBody(ConverterUtils.writeValueAsString(eventBody));

        com.mckesson.oktaclient.dto.OktaUser dto = new com.mckesson.oktaclient.dto.OktaUser();
        if (StringUtils.isNotBlank(eventBody.getIncidentData())) {
            dto.setPsIncidentData(eventBody.getIncidentData());
        }

        AuditEvent auditEvent = AuditEvent.generateEvent(eventBody)
                .module(ModuleEnum.OKTA_CLIENT)
                .status("SUCCESS")
                .situation("passport.okta-client.send.action")
                .newValues(ConverterUtils.writeValueAsString(dto))
                .message("Success")
                .build();

        oktaProcessor.processAction(passportAction);
        Mockito.verify(oktaUserService).setTargetAndUpdateUser(
                Mockito.eq(eventBody.getOktaUserId()), Mockito.eq(dto), Mockito.eq(null), Mockito.eq(false), Mockito.any());
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
        Mockito.verify(messageBrokerPublisher).send(Mockito.eq(ModuleEnum.FINALIZER), Mockito.refEq(passportAction, "metrics"));

        Mockito.reset(oktaUserService);
        Mockito.reset(auditService);
        var ex = new HttpClientErrorException(HttpStatus.NOT_FOUND);
        Mockito.when(oktaUserService.setTargetAndUpdateUser(Mockito.eq(eventBody.getOktaUserId()), Mockito.eq(dto), Mockito.eq(null), Mockito.eq(false), Mockito.any()))
                .thenThrow(ex);
        oktaProcessor.processAction(passportAction);
        auditEvent = AuditEvent.generateEvent(eventBody)
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues(ConverterUtils.writeValueAsString(dto))
                .status("ERROR")
                .message("Error on update user: " + ex.getMessage())
                .situation("passport.okta-client.send.action")
                .build();
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));

        Mockito.reset(oktaUserService);
        Mockito.reset(auditService);
        ex = new HttpClientErrorException(HttpStatus.SERVICE_UNAVAILABLE);
        Mockito.when(oktaUserService.setTargetAndUpdateUser(Mockito.eq(eventBody.getOktaUserId()), Mockito.eq(dto), Mockito.eq(null), Mockito.eq(false), Mockito.any()))
                .thenThrow(ex);
        try {
            oktaProcessor.processAction(passportAction);
            Assertions.fail("Wrong behavior");
        } catch (HttpClientErrorException e) {
            Assertions.assertEquals(ex, e);
        } catch (Throwable th) {
            Assertions.fail("Wrong behavior");
        }
    }

    @Test
    void registerError() {
        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        CoreEvent coreEvent = CoreEvent.builder()
                .target("target")
                .scenario(ScenarioEnum.CREATE)
                .stage("stage")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .build();

        OktaProcessor oktaProcessor = new OktaProcessor(scenarioProvider, messageBrokerPublisher, oktaUserService, auditService);

        PassportError pe = new PassportError("uuid1", "errorInfo1", ModuleEnum.FINALIZER, ScenarioEnum.CREATE, "stage1");
        coreEvent.setError(pe);


        com.mckesson.oktaclient.dto.OktaUser dto = new com.mckesson.oktaclient.dto.OktaUser(coreEvent);
        if (pe.getScenario() != ScenarioEnum.REQUEST) {
            dto.setEvtScenario("break");
        }
        dto.setEvtStage("errorRegister");
        dto.setEvtContext(object2Json(pe, Objects::isNull, ""));

        AuditEvent auditEvent = AuditEvent.generateEvent(coreEvent)
                .status("SUCCESS")
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues(ConverterUtils.writeValueAsString(dto))
                .message("Sending error notification")
                .situation("passport.okta-client.send.error").build();

        oktaProcessor.registerError(coreEvent);
        Mockito.verify(oktaUserService).setTargetAndUpdateUser(
                Mockito.eq(nextOktaUser.getUserId()), Mockito.any(), Mockito.eq(coreEvent), Mockito.eq(true), Mockito.any());
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));

        Mockito.reset(oktaUserService, auditService);
        coreEvent = CoreEvent.builder()
                .target("target")
                .scenario(ScenarioEnum.REQUEST)
                .stage("stage")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .build();

        pe = new PassportError("uuid1", "errorInfo1", ModuleEnum.FINALIZER, ScenarioEnum.REQUEST, "stage1");
        coreEvent.setError(pe);

        dto = new com.mckesson.oktaclient.dto.OktaUser(coreEvent);
        if (pe.getScenario() != ScenarioEnum.REQUEST) {
            dto.setEvtScenario("break");
        }
        dto.setEvtStage("errorRegister");
        dto.setEvtContext(object2Json(pe, Objects::isNull, ""));

        auditEvent = AuditEvent.generateEvent(coreEvent)
                .status("SUCCESS")
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues(ConverterUtils.writeValueAsString(dto))
                .message("Sending error notification")
                .situation("passport.okta-client.send.error").build();

        oktaProcessor.registerError(coreEvent);
        Mockito.verify(oktaUserService).setTargetAndUpdateUser(
                Mockito.eq(nextOktaUser.getUserId()), Mockito.any(), Mockito.eq(coreEvent), Mockito.eq(true), Mockito.any());
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
    }

    @Test
    void onCreate() throws InvalidNameException {
        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User,OU=Test,DC=mshusontest,DC=com"));
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        CoreEvent coreEvent = CoreEvent.builder()
                .module(ModuleEnum.OKTA_CLIENT)
                .target("target")
                .scenario(ScenarioEnum.CREATE)
                .stage("stage")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .metrics(new ArrayList<>())
                .build();
        OktaProcessor oktaProcessor = new OktaProcessor(scenarioProvider, messageBrokerPublisher, oktaUserService, auditService);

        oktaProcessor.processEvent(coreEvent);
        Mockito.verify(oktaUserService, Mockito.never()).setTargetAndUpdateUser(Mockito.eq(nextOktaUser.getUserId()), Mockito.any(), Mockito.eq(coreEvent), Mockito.anyBoolean(), Mockito.any());
        Mockito.verify(auditService, Mockito.never()).audit(Mockito.any());
        //messageBrokerPublisher.send(nextEvent.getModule(), nextEvent) //TODO

        coreEvent = CoreEvent.builder()
                .module(ModuleEnum.OKTA_CLIENT)
                .target("target")
                .scenario(ScenarioEnum.CREATE)
                .stage("start")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .metrics(new ArrayList<>())
                .build();
        var dto = new com.mckesson.oktaclient.dto.OktaUser(coreEvent);
        OktaUser next = coreEvent.getNextOktaUser();
        dto.setPsEmailPrimary(next.getEmailPrimary());
        dto.setPsEmailSecondary(next.getEmailSecondary());
        dto.setPsEmailSecondaryAdditional(next.getEmailSecondaryAdditional());
        dto.setPsCn(next.getCn());
        dto.setDn(next.getDn().toString());
        dto.setPsUserPrincipalName(next.getUserPrincipalName());
        dto.setPsUserId(next.getSamAccountName());

        var auditEvent = AuditEvent.generateEvent(coreEvent)
                .status("SUCCESS")
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues(ConverterUtils.writeValueAsString(dto))
                .message("Sending onCreate notification")
                .situation("passport.okta-client.send.create")
                .build();
        oktaProcessor.processEvent(coreEvent);
        Mockito.verify(oktaUserService).setTargetAndUpdateUser(
                Mockito.eq(nextOktaUser.getUserId()), Mockito.eq(dto), Mockito.eq(coreEvent), Mockito.eq(true), Mockito.any());
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
    }

    @Test
    void onRequest() throws InvalidNameException {
        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User,OU=Test,DC=mshusontest,DC=com"));
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        prevOktaUser.setDn(new LdapName("CN=User,OU=Test,DC=mshusontest,DC=com"));
        CoreEvent coreEvent = CoreEvent.builder()
                .module(ModuleEnum.OKTA_CLIENT)
                .target("target")
                .scenario(ScenarioEnum.REQUEST)
                .stage("stage")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .metrics(new ArrayList<>())
                .build();
        OktaProcessor oktaProcessor = new OktaProcessor(scenarioProvider, messageBrokerPublisher, oktaUserService, auditService);

        oktaProcessor.processEvent(coreEvent);
        Mockito.verify(oktaUserService, Mockito.never()).setTargetAndUpdateUser(Mockito.eq(nextOktaUser.getUserId()), Mockito.any(), Mockito.eq(coreEvent), Mockito.anyBoolean(), Mockito.any());
        Mockito.verify(auditService, Mockito.never()).audit(Mockito.any());

        coreEvent = CoreEvent.builder()
                .module(ModuleEnum.OKTA_CLIENT)
                .target("target")
                .scenario(ScenarioEnum.REQUEST)
                .stage("adInfo")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .metrics(new ArrayList<>())
                .build();
        var dto = new com.mckesson.oktaclient.dto.OktaUser(coreEvent);
        dto.setPsAdInfo(object2Json(coreEvent.getOktaUser().getAdInfo(), Objects::isNull, ""));

        var auditEvent = AuditEvent.generateEvent(coreEvent)
                .status("SUCCESS")
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues(ConverterUtils.writeValueAsString(dto))
                .message("Sending onRequest notification")
                .situation("passport.okta-client.send.request")
                .build();
        oktaProcessor.processEvent(coreEvent);
        Mockito.verify(oktaUserService).setTargetAndUpdateUser(
                Mockito.eq(nextOktaUser.getUserId()), Mockito.eq(dto), Mockito.eq(coreEvent), Mockito.eq(false), Mockito.any());
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
    }

    @Test
    void onDeferred() throws InvalidNameException {
        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setManager(new LdapName("CN=Manager,OU=Test,DC=mshusontest,DC=com"));
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        prevOktaUser.setManager(new LdapName("CN=Manager,OU=Test,DC=mshusontest,DC=com"));
        CoreEvent coreEvent = CoreEvent.builder()
                .module(ModuleEnum.OKTA_CLIENT)
                .target("target")
                .scenario(ScenarioEnum.DEFERRED)
                .stage("stage")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .metrics(new ArrayList<>())
                .build();
        OktaProcessor oktaProcessor = new OktaProcessor(scenarioProvider, messageBrokerPublisher, oktaUserService, auditService);

        oktaProcessor.processEvent(coreEvent);
        Mockito.verify(oktaUserService, Mockito.never()).setTargetAndUpdateUser(Mockito.eq(nextOktaUser.getUserId()), Mockito.any(), Mockito.eq(coreEvent), Mockito.anyBoolean(), Mockito.any());
        Mockito.verify(auditService, Mockito.never()).audit(Mockito.any());

        coreEvent = CoreEvent.builder()
                .module(ModuleEnum.OKTA_CLIENT)
                .target("target")
                .scenario(ScenarioEnum.DEFERRED)
                .stage("linkmanager")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .metrics(new ArrayList<>())
                .build();
        var dto = new com.mckesson.oktaclient.dto.OktaUser(coreEvent);
        dto.setPsManagerAsObject(coreEvent.getOktaUser().getManagerObject());
        dto.setPsManagerDn(String.valueOf(coreEvent.getOktaUser().getManager()));

        var auditEvent = AuditEvent.generateEvent(coreEvent)
                .status("SUCCESS")
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues(ConverterUtils.writeValueAsString(dto))
                .message("Sending onDeferred notification")
                .situation("passport.okta-client.send.deferred")
                .build();
        oktaProcessor.processEvent(coreEvent);
        Mockito.verify(oktaUserService).setTargetAndUpdateUser(
                Mockito.eq(nextOktaUser.getUserId()), Mockito.eq(dto), Mockito.eq(coreEvent), Mockito.eq(true), Mockito.any());
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));

        coreEvent = CoreEvent.builder()
                .module(ModuleEnum.OKTA_CLIENT)
                .target("target")
                .scenario(ScenarioEnum.DEFERRED)
                .stage("getManagerForEMail")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .metrics(new ArrayList<>())
                .build();
        dto = new com.mckesson.oktaclient.dto.OktaUser(coreEvent);
        dto.setPsManagerAsObject(coreEvent.getOktaUser().getManagerObject());

        auditEvent = AuditEvent.generateEvent(coreEvent)
                .status("SUCCESS")
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues(ConverterUtils.writeValueAsString(dto))
                .message("Sending onDeferred notification")
                .situation("passport.okta-client.send.deferred")
                .build();
        oktaProcessor.processEvent(coreEvent);
        Mockito.verify(oktaUserService).setTargetAndUpdateUser(
                Mockito.eq(nextOktaUser.getUserId()), Mockito.eq(dto), Mockito.eq(coreEvent), Mockito.eq(true), Mockito.any());
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
    }

    @Test
    void onSynchronize() throws InvalidNameException {
        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User,OU=Test,DC=mshusontest,DC=com"));
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        prevOktaUser.setDn(new LdapName("CN=User,OU=Test,DC=mshusontest,DC=com"));
        CoreEvent coreEvent = CoreEvent.builder()
                .module(ModuleEnum.OKTA_CLIENT)
                .target("target")
                .scenario(ScenarioEnum.SYNCHRONIZE)
                .stage("stage")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .metrics(new ArrayList<>())
                .build();
        OktaProcessor oktaProcessor = new OktaProcessor(scenarioProvider, messageBrokerPublisher, oktaUserService, auditService);

        oktaProcessor.processEvent(coreEvent);
        Mockito.verify(oktaUserService, Mockito.never()).setTargetAndUpdateUser(Mockito.eq(nextOktaUser.getUserId()), Mockito.any(), Mockito.eq(coreEvent), Mockito.anyBoolean(), Mockito.any());
        Mockito.verify(auditService, Mockito.never()).audit(Mockito.any());

        coreEvent = CoreEvent.builder()
                .module(ModuleEnum.OKTA_CLIENT)
                .target("target")
                .scenario(ScenarioEnum.SYNCHRONIZE)
                .stage("start")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .metrics(new ArrayList<>())
                .build();
        var dto = new com.mckesson.oktaclient.dto.OktaUser(coreEvent);
        dto.setPsEmailPrimary(nextOktaUser.getEmailPrimary());
        dto.setPsEmailSecondary(nextOktaUser.getEmailSecondary());
        dto.setPsEmailSecondaryAdditional(nextOktaUser.getEmailSecondaryAdditional());
        dto.setPsCn(nextOktaUser.getCn());
        dto.setDn(nextOktaUser.getDn().toString());
        dto.setPsUserPrincipalName(nextOktaUser.getUserPrincipalName());
        dto.setPsUserId(nextOktaUser.getSamAccountName());
        dto.setPsAccountExpires(nextOktaUser.getAccountExpires());
        dto.setPsManagerAsObject(nextOktaUser.getManagerObject());
        dto.setPsManagerDn(String.valueOf(nextOktaUser.getManager()));

        var auditEvent = AuditEvent.generateEvent(coreEvent)
                .status("SUCCESS")
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues(ConverterUtils.writeValueAsString(dto))
                .message("Sending onSynchronize notification")
                .situation("passport.okta-client.send.synchronize")
                .build();
        oktaProcessor.processEvent(coreEvent);
        Mockito.verify(oktaUserService).setTargetAndUpdateUser(
                Mockito.eq(nextOktaUser.getUserId()), Mockito.eq(dto), Mockito.eq(coreEvent), Mockito.eq(true), Mockito.any());
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));

        Mockito.reset(oktaUserService, auditService);
        nextOktaUser.setAccountExpires((new Date().getTime() + 11644473600000L) * 10000);
        coreEvent = CoreEvent.builder()
                .module(ModuleEnum.OKTA_CLIENT)
                .target("target")
                .scenario(ScenarioEnum.SYNCHRONIZE)
                .stage("start")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .metrics(new ArrayList<>())
                .build();
        dto = new com.mckesson.oktaclient.dto.OktaUser(coreEvent);
        dto.setPsEmailPrimary(nextOktaUser.getEmailPrimary());
        dto.setPsEmailSecondary(nextOktaUser.getEmailSecondary());
        dto.setPsEmailSecondaryAdditional(nextOktaUser.getEmailSecondaryAdditional());
        dto.setPsCn(nextOktaUser.getCn());
        dto.setDn(nextOktaUser.getDn().toString());
        dto.setPsUserPrincipalName(nextOktaUser.getUserPrincipalName());
        dto.setPsUserId(nextOktaUser.getSamAccountName());
        dto.setPsAccountExpires(nextOktaUser.getAccountExpires());
        dto.setPsManagerAsObject(nextOktaUser.getManagerObject());
        dto.setPsManagerDn(String.valueOf(nextOktaUser.getManager()));

        auditEvent = AuditEvent.generateEvent(coreEvent)
                .status("SUCCESS")
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues(ConverterUtils.writeValueAsString(dto))
                .message("Sending onSynchronize notification")
                .situation("passport.okta-client.send.synchronize")
                .build();
        oktaProcessor.processEvent(coreEvent);
        Mockito.verify(oktaUserService).setTargetAndUpdateUser(
                Mockito.eq(nextOktaUser.getUserId()), Mockito.eq(dto), Mockito.eq(coreEvent), Mockito.eq(true), Mockito.any());
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
    }

    @Test
    void onTerminate() throws InvalidNameException {
        OktaProcessor oktaProcessor = new OktaProcessor(scenarioProvider, messageBrokerPublisher, oktaUserService, auditService);
        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User,OU=Test,DC=mshusontest,DC=com"));
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        CoreEvent coreEvent = CoreEvent.builder()
                .module(ModuleEnum.OKTA_CLIENT)
                .target("target")
                .scenario(ScenarioEnum.TERMINATE)
                .stage("stage")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .metrics(new ArrayList<>())
                .build();

        oktaProcessor.processEvent(coreEvent);
        Mockito.verify(oktaUserService, Mockito.never()).setTargetAndUpdateUser(Mockito.eq(nextOktaUser.getUserId()), Mockito.any(), Mockito.eq(coreEvent), Mockito.anyBoolean(), Mockito.any());
        Mockito.verify(auditService, Mockito.never()).audit(Mockito.any());

        coreEvent = CoreEvent.builder()
                .module(ModuleEnum.OKTA_CLIENT)
                .target("target")
                .scenario(ScenarioEnum.TERMINATE)
                .stage("start")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .metrics(new ArrayList<>())
                .build();
        var dto = new com.mckesson.oktaclient.dto.OktaUser(coreEvent);
        dto.setPsServerNames(nextOktaUser.getServerNames());
        dto.setPsAssociatedAccountsTermination(nextOktaUser.getAssociatedAccountsTermination());
        dto.setPsInfo(nextOktaUser.getInfo());
        dto.setPsOldManagerAsObject(prevOktaUser.getManagerObject());
        dto.setPsCn(nextOktaUser.getCn());

        var auditEvent = AuditEvent.generateEvent(coreEvent)
                .status("SUCCESS")
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues(ConverterUtils.writeValueAsString(dto))
                .message("Sending onTerminate / onCrossDomain notification")
                .situation("passport.okta-client.send.terminate")
                .build();
        oktaProcessor.processEvent(coreEvent);
        Mockito.verify(oktaUserService).setTargetAndUpdateUser(
                Mockito.eq(nextOktaUser.getUserId()), Mockito.eq(dto), Mockito.eq(coreEvent), Mockito.eq(true), Mockito.any());
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));

        Mockito.reset(oktaUserService, auditService);
        coreEvent = CoreEvent.builder()
                .module(ModuleEnum.OKTA_CLIENT)
                .target("target")
                .scenario(ScenarioEnum.TERMINATE)
                .stage("prepare")
                .nextOktaUser(nextOktaUser)
                .prevOktaUser(prevOktaUser)
                .metrics(new ArrayList<>())
                .build();
        dto = new com.mckesson.oktaclient.dto.OktaUser();
        dto.setPsCn(nextOktaUser.getCn());
        dto.setDn(nextOktaUser.getDn().toString());
        dto.setPsManagerDn(String.valueOf(nextOktaUser.getManager()));

        auditEvent = AuditEvent.generateEvent(coreEvent)
                .status("SUCCESS")
                .module(ModuleEnum.OKTA_CLIENT)
                .newValues(ConverterUtils.writeValueAsString(dto))
                .message("Sending prepare onTerminate / onCrossDomain notification")
                .situation("passport.okta-client.send.prepare-terminate")
                .build();
        oktaProcessor.processEvent(coreEvent);
        Mockito.verify(oktaUserService).setTargetAndUpdateUser(
                Mockito.eq(nextOktaUser.getUserId()), Mockito.eq(dto), Mockito.eq(coreEvent), Mockito.eq(true), Mockito.any());
        Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
    }


    @Test
    void onUpdate() throws InvalidNameException {
        OktaProcessor oktaProcessor = new OktaProcessor(scenarioProvider, messageBrokerPublisher, oktaUserService, auditService);
        OktaUser nextOktaUser = new OktaUser();
        nextOktaUser.setUserId(UUID.randomUUID().toString());
        nextOktaUser.setDn(new LdapName("CN=User,OU=Test,DC=mshusontest,DC=com"));
        OktaUser prevOktaUser = new OktaUser();
        prevOktaUser.setUserId(UUID.randomUUID().toString());
        prevOktaUser.setDn(new LdapName("CN=User,OU=Test,DC=mshusontest,DC=com"));

        var stages = Arrays.asList("stage", "commit", "nameChange-cn", "nameChange-email", "nameChange-all", "prepare",
                "HRBUTransfer", "ClinicalTransfer", "TXOTransfer");
        for (var stage : stages) {
            Mockito.reset(oktaUserService, auditService);

            CoreEvent coreEvent = CoreEvent.builder()
                    .module(ModuleEnum.OKTA_CLIENT)
                    .target("target")
                    .scenario(ScenarioEnum.UPDATE)
                    .stage(stage)
                    .nextOktaUser(nextOktaUser)
                    .prevOktaUser(prevOktaUser)
                    .metrics(new ArrayList<>())
                    .build();
            com.mckesson.oktaclient.dto.OktaUser dto;
            if ("commit".equals(stage)) {
                dto = new com.mckesson.oktaclient.dto.OktaUser(coreEvent);
                dto.setPsManagerAsObject(nextOktaUser.getManagerObject());
                dto.setPsOldManagerAsObject(prevOktaUser.getManagerObject());
                dto.setPsManagerDn(String.valueOf(prevOktaUser.getManager()));
            } else if ("nameChange-cn".equals(stage) || "nameChange-email".equals(stage) || "nameChange-all".equals(stage)) {
                dto = new com.mckesson.oktaclient.dto.OktaUser(coreEvent);
                if (!"nameChange-cn".equals(stage)) {
                    dto.setPsEmailPrimary(nextOktaUser.getEmailPrimary());
                    dto.setPsEmailSecondary(nextOktaUser.getEmailSecondary());
                    dto.setPsEmailSecondaryAdditional(nextOktaUser.getEmailSecondaryAdditional());
                }
                if (!"nameChange-email".equals(stage)) {
                    dto.setPsCn(nextOktaUser.getCn());
                }
            } else if ("prepare".equals(stage)) {
                dto = new com.mckesson.oktaclient.dto.OktaUser();
                dto.setPsCn(nextOktaUser.getCn());
                dto.setDn(nextOktaUser.getDn().toString());
                dto.setPsManagerDn(String.valueOf(nextOktaUser.getManager()));
            } else {
                dto = toDto(coreEvent);
                if ("HRBUTransfer".equalsIgnoreCase(stage)) {
                    dto.setEvtTarget("owf");
                    dto.setEvtScenario("update");
                    dto.setEvtStage("HRBUTransferStep2");
                } else if ("ClinicalTransfer".equalsIgnoreCase(stage)) {
                    dto.setEvtTarget("owf");
                    dto.setEvtScenario("update");
                    dto.setEvtStage("ClinicalTransferStep2");
                } else if ("TXOTransfer".equalsIgnoreCase(stage)) {
                    dto.setEvtTarget("owf");
                    dto.setEvtScenario("update");
                    dto.setEvtStage("TXOTransferStep2");
                    dto.setPsGroups(StringUtils.join(coreEvent.getOktaUser().getGroups(), ','));
                    dto.setPsOldGroups(StringUtils.join(prevOktaUser.getGroups(), ','));
                }
            }

            var auditEvent = AuditEvent.generateEvent(coreEvent)
                    .status("SUCCESS")
                    .module(ModuleEnum.OKTA_CLIENT)
                    .newValues(ConverterUtils.writeValueAsString(dto))
                    .message("Sending onUpdate notification")
                    .situation("passport.okta-client.send.update")
                    .build();
            oktaProcessor.processEvent(coreEvent);
            Mockito.verify(oktaUserService).setTargetAndUpdateUser(
                    Mockito.eq(nextOktaUser.getUserId()), Mockito.eq(dto), Mockito.eq(coreEvent), Mockito.eq(true), Mockito.any());
            Mockito.verify(auditService).audit(Mockito.refEq(auditEvent, "date", "duration"));
        }
    }

    private com.mckesson.oktaclient.dto.OktaUser toDto(CoreEvent event) {
        com.mckesson.oktaclient.dto.OktaUser dto = new com.mckesson.oktaclient.dto.OktaUser(event);
        OktaUser prev = event.getPrevOktaUser();
        OktaUser next = event.getNextOktaUser();

        updateIfChanged(dto::setFirstName, OktaUser::getFirstName, prev, next.getFirstName());
        updateIfChanged(dto::setLastName, OktaUser::getLastName, prev, next.getLastName());
        updateIfChanged(dto::setPsMiddleName, OktaUser::getMiddleName, prev, next.getMiddleName());

        updateIfChanged(dto::setPsLegalName, OktaUser::getLegalName, prev, next.getLegalName());
        updateIfChanged(dto::setPsLegalPrefix, OktaUser::getLegalPrefix, prev, next.getLegalPrefix());
        updateIfChanged(dto::setPsLegalSuffix, OktaUser::getLegalSuffix, prev, next.getLegalSuffix());
        updateIfChanged(dto::setPsPreferredFirstName, OktaUser::getPreferredFirstName, prev, next.getPreferredFirstName());

        updateIfChanged(dto::setPsPreferredLastName, OktaUser::getPreferredLastName, prev, next.getPreferredLastName());
        updateIfChanged(dto::setPsPreferredPrefix, OktaUser::getPreferredPrefix, prev, next.getPreferredPrefix());
        updateIfChanged(dto::setPsPreferredSuffix, OktaUser::getPreferredSuffix, prev, next.getPreferredSuffix());

        updateIfChanged(dto::setTitle, OktaUser::getTitle, prev, next.getTitle());
        updateIfChanged(dto::setPsDisplayName, OktaUser::getDisplayName, prev, next.getDisplayName());

        updateIfChanged(dto::setCity, OktaUser::getCity, prev, next.getCity());
        updateIfChanged(dto::setState, OktaUser::getState, prev, next.getState());
        updateIfChanged(dto::setPostalAddress, OktaUser::getPostalAddress, prev, next.getPostalAddress());
        updateIfChanged(dto::setPsCountry, OktaUser::getCountry, prev, next.getCountry());
        updateIfChanged(dto::setStreetAddress, OktaUser::getStreetAddress, prev, next.getStreetAddress());
        updateIfChanged(dto::setPsFax, OktaUser::getFax, prev, next.getFax());


        updateIfChanged(dto::setPsManagerId, OktaUser::getManagerId, prev, next.getManagerId());

        updateIfChanged(dto::setPsActive, OktaUser::isActive, prev, next.isActive());
        updateIfChanged(dto::setPsTerminated, OktaUser::getTerminated, prev, next.getTerminated());

        updateIfChanged(dto::setPsDateActivated, OktaUser::getDateActivated, prev, next.getDateActivated());
        updateIfChanged(dto::setPsHireDate, OktaUser::getHireDate, prev, next.getHireDate());
        updateIfChanged(dto::setPsPositionEffectiveDate, OktaUser::getPositionEffectiveDate, prev, next.getPositionEffectiveDate());

        updateIfChanged(dto::setPsWorkerType, OktaUser::getWorkerType, prev, next.getWorkerType());
        updateIfChanged(dto::setPsHrPartner, OktaUser::getHrPartner, prev, next.getHrPartner());
        updateIfChanged(dto::setPsExecutiveDirector, OktaUser::getExecutiveDirector, prev, next.getExecutiveDirector());

        updateIfChanged(dto::setPsJobFamily, OktaUser::getJobFamily, prev, next.getJobFamily());
        updateIfChanged(dto::setPsSsn, OktaUser::getSsn, prev, next.getSsn());

        updateIfChanged(dto::setPsLeaveOfAbsence, OktaUser::isLeaveOfAbsence, prev, next.isLeaveOfAbsence());
        updateIfChanged(dto::setPsCompanyId, OktaUser::getCompanyId, prev, next.getCompanyId());
        updateIfChanged(dto::setPsWorkerTypeDescriptor, OktaUser::getWorkerTypeDescriptor, prev, next.getWorkerTypeDescriptor());
        updateIfChanged(dto::setPsGlPayType, OktaUser::getGlPayType, prev, next.getGlPayType());

        dto.setDn(String.valueOf(next.getDn()));
        updateIfChanged(dto::setPsCn, OktaUser::getCn, prev, next.getCn());
        updateIfChanged(dto::setPsUid, OktaUser::getUid, prev, next.getUid());

        updateIfChanged(dto::setPsOldHRBU, OktaUser::getHrbu, prev, next.getHrbu());
        updateIfChanged(dto::setPsOldCity, OktaUser::getCity, prev, next.getCity());
        updateIfChanged(dto::setPsOldAddress, OktaUser::getStreetAddress, prev, next.getStreetAddress());
        updateIfChanged(dto::setPsOldLeaveOfAbsence, OktaUser::isLeaveOfAbsence, prev, next.isLeaveOfAbsence());
        updateIfChanged(dto::setPsOldCompanyId, OktaUser::getCompanyId, prev, next.getCompanyId());
        updateIfChanged(dto::setPsOldWorkerTypeDescriptor, OktaUser::getWorkerTypeDescriptor, prev, next.getWorkerTypeDescriptor());
        updateIfChanged(dto::setPsOldManagerUserId, OktaUser::getManagerUserId, prev, next.getManagerUserId());
        updateIfChanged(dto::setPsOldManagerHRBU, OktaUser::getManagerHrbu, prev, next.getManagerHrbu());
        updateIfChanged(dto::setPsOldExecutiveDirectorUserId, OktaUser::getExecutiveDirectorUserId, prev, next.getExecutiveDirectorUserId());
        updateIfChanged(dto::setPsOldExecutiveDirectorHRBU, OktaUser::getExecutiveDirectorHrbu, prev, next.getExecutiveDirectorHrbu());
        updateIfChanged(dto::setPsOldEmployee, OktaUser::isEmployee, prev, next.isEmployee());
        updateIfChanged(dto::setPsOldManagerId, OktaUser::getManagerId, prev, next.getManagerId());
        updateIfChanged(dto::setPsOldFirstName, OktaUser::getFirstName, prev, next.getFirstName());
        updateIfChanged(dto::setPsOldLastName, OktaUser::getLastName, prev, next.getLastName());
        updateIfChanged(dto::setPsOldPreferredFirstName, OktaUser::getPreferredFirstName, prev, next.getPreferredFirstName());
        updateIfChanged(dto::setPsOldPreferredLastName, OktaUser::getPreferredLastName, prev, next.getPreferredLastName());
        updateIfChanged(dto::setPsOldPreferredPrefix, OktaUser::getPreferredPrefix, prev, next.getPreferredPrefix());
        updateIfChanged(dto::setPsOldPreferredSuffix, OktaUser::getPreferredSuffix, prev, next.getPreferredSuffix());
        updateIfChanged(dto::setPsOldLegalPrefix, OktaUser::getLegalPrefix, prev, next.getLegalPrefix());
        updateIfChanged(dto::setPsOldLegalSuffix, OktaUser::getLegalSuffix, prev, next.getLegalSuffix());
        updateIfChanged(dto::setPsOldLegalName, OktaUser::getLegalName, prev, next.getLegalName());

        updateIfChanged(dto::setPsEmployee, OktaUser::isEmployee, prev, next.isEmployee());

        updateIfChanged(dto::setPsManagerUserId, OktaUser::getManagerUserId, prev, next.getManagerUserId());
        updateIfChanged(dto::setPsManagerHRBU, OktaUser::getManagerHrbu, prev, next.getManagerHrbu());
        updateIfChanged(dto::setPsExecutiveDirectorUserId, OktaUser::getExecutiveDirectorUserId, prev, next.getExecutiveDirectorUserId());
        updateIfChanged(dto::setPsExecutiveDirectorHRBU, OktaUser::getExecutiveDirectorHrbu, prev, next.getExecutiveDirectorHrbu());

        updateIfChanged(dto::setPsEmailPrimary, OktaUser::getEmailPrimary, prev, next.getEmailPrimary());
        updateIfChanged(dto::setPsEmailSecondaryAdditional, OktaUser::getEmailSecondaryAdditional, prev, next.getEmailSecondaryAdditional());
        updateIfChanged(dto::setPsEmailSecondary, OktaUser::getEmailSecondary, prev, next.getEmailSecondary());
        updateIfChanged(dto::setPsMailboxCreated, OktaUser::getMailboxCreated, prev, next.getMailboxCreated());
        updateIfChanged(dto::setPsInfo, OktaUser::getInfo, prev, next.getInfo());
        updateIfChanged(dto::setPsManagerAsObject, OktaUser::getManagerObject, prev, next.getManagerObject());
        updateIfChanged(dto::setPsServerNames, OktaUser::getServerNames, prev, next.getServerNames());

        updateIfChanged(dto::setPsHomeDirectory, OktaUser::getHomeDirectory, prev, next.getHomeDirectory());
        updateIfChanged(dto::setPsAssociatedAccountsTermination, OktaUser::getAssociatedAccountsTermination, prev, next.getAssociatedAccountsTermination());

        dto.setEvtId(event.getId());
        dto.setEvtImportCompleted(event.getImportCompleted());
        dto.setEvtContext(event.getContext());
        dto.setEvtTarget(event.getTarget());
        dto.setEvtScenario(event.getScenario().getName());
        dto.setEvtStage(event.getStage());
        return dto;
    }

    private <T> void updateIfChanged(Consumer<T> setter, Function<OktaUser, T> prevGetter, OktaUser prev, T nextValue) {
        if (prev == null || !Objects.equals(prevGetter.apply(prev), nextValue)) {
            setter.accept(nextValue);
        }
    }
}