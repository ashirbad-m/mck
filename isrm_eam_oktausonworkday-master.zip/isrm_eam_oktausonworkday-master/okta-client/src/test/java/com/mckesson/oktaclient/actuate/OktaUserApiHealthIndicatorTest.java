package com.mckesson.oktaclient.actuate;

import com.mckesson.oktaclient.OktaClientConfiguration;
import com.mckesson.oktaclient.dto.OktaUserResponse;
import com.mckesson.oktaclient.service.OktaUserService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;

import java.util.Map;

class OktaUserApiHealthIndicatorTest {

    @Test
    void doHealthCheck() {
        OktaClientConfiguration config = Mockito.mock(OktaClientConfiguration.class);
        OktaUserService oktaUserService = Mockito.mock(OktaUserService.class);

        String location = "some_location";
        Mockito.when(config.getBaseUrl()).thenReturn(location);
        OktaUserApiHealthIndicator instance = new OktaUserApiHealthIndicator(config, oktaUserService);

        Mockito.when(oktaUserService.getAllOktaUsers(Mockito.eq(10))).thenThrow(new RuntimeException("test"));
        Health health = instance.health();
        Assertions.assertEquals(Status.DOWN, health.getStatus());
        Assertions.assertEquals(Map.of("location", location, "error", "java.lang.RuntimeException: test"), health.getDetails());

        Mockito.reset(oktaUserService);
        Mockito.when(oktaUserService.getAllOktaUsers(Mockito.eq(10))).thenReturn(new OktaUserResponse[]{});

        health = instance.health();
        Assertions.assertEquals(Status.UP, health.getStatus());
        Assertions.assertEquals(Map.of("location", location), health.getDetails());
    }
}