package com.mckesson.oktaclient.service;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.model.ScenarioEnum;
import com.mckesson.oktaclient.OktaClientConfiguration;
import com.mckesson.oktaclient.dto.OktaUser;
import com.mckesson.oktaclient.dto.OktaUserResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Supplier;

class OktaUserServiceTest {

    private final RestTemplateBuilder restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
    private final RestTemplate restTemplate = Mockito.mock(RestTemplate.class);
    private final RetryTemplate retryTemplate = new RetryTemplate();
    private final String baseUrl = "https://localhost/path/";
    private final OktaClientConfiguration config = new OktaClientConfiguration();

    @BeforeEach
    public void setUp() {
        Mockito.reset(restTemplateBuilder);
        Mockito.reset(restTemplate);

        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);
        Mockito.when(restTemplateBuilder.requestFactory(Mockito.any(Supplier.class))).thenReturn(restTemplateBuilder);

        config.setBaseUrl(baseUrl);
        config.setTimeout(30_000);
        config.setToken("token");
    }

    @Test
    void getAllOktaUsers() {
        OktaUserService oktaUserService = new OktaUserService(restTemplateBuilder, config, retryTemplate);

        int limit = 10;
        OktaUserResponse[] body = new OktaUserResponse[]{new OktaUserResponse()};
        Mockito.when(restTemplate.exchange(
                        Mockito.eq(baseUrl + "users?limit={limit}"),
                        Mockito.eq(HttpMethod.GET),
                        Mockito.any(),
                        Mockito.eq(OktaUserResponse[].class),
                        Mockito.eq(Map.of("limit", limit))))
                .thenReturn(ResponseEntity.ok(body));

        Assertions.assertEquals(body, oktaUserService.getAllOktaUsers(limit));

        try {
            Mockito.when(restTemplate.exchange(
                            Mockito.eq(baseUrl + "users?limit={limit}"),
                            Mockito.eq(HttpMethod.GET),
                            Mockito.any(),
                            Mockito.eq(OktaUserResponse[].class),
                            Mockito.eq(Map.of("limit", limit))))
                    .thenReturn(ResponseEntity.status(HttpStatus.FORBIDDEN).build());
            oktaUserService.getAllOktaUsers(limit);
            Assertions.fail("Wrong behavior");
        } catch (ResponseStatusException ex) {
            Assertions.assertEquals("403 FORBIDDEN \"Cannot read Okta users\"", ex.getMessage());
            Assertions.assertEquals(HttpStatus.FORBIDDEN, ex.getStatus());
        }

        try {
            Mockito.when(restTemplate.exchange(
                            Mockito.eq(baseUrl + "users?limit={limit}"),
                            Mockito.eq(HttpMethod.GET),
                            Mockito.any(),
                            Mockito.eq(OktaUserResponse[].class),
                            Mockito.eq(Map.of("limit", limit))))
                    .thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).build());
            oktaUserService.getAllOktaUsers(limit);
            Assertions.fail("Wrong behavior");
        } catch (ResponseStatusException ex) {
            Assertions.assertEquals("400 BAD_REQUEST \"Bad Request\"", ex.getMessage());
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, ex.getStatus());
        }
    }

    @Test
    void getOktaUser() {
        OktaUserService oktaUserService = new OktaUserService(restTemplateBuilder, config, retryTemplate);

        Consumer<Exception> onError = (ex) -> {
        };

        String userId = UUID.randomUUID().toString();
        OktaUser user = new OktaUser();
        user.setPsUserId(userId);
        OktaUserResponse response = new OktaUserResponse();
        response.setProfile(user);

        Mockito.when(restTemplate.exchange(
                        Mockito.eq(baseUrl + "users/{userId}"),
                        Mockito.eq(HttpMethod.GET),
                        Mockito.any(),
                        Mockito.eq(OktaUserResponse.class),
                        Mockito.eq(Map.of("userId", userId))))
                .thenReturn(ResponseEntity.ok(response));

        Assertions.assertEquals(user, oktaUserService.getOktaUser(userId, onError));

        try {
            Mockito.when(restTemplate.exchange(
                            Mockito.eq(baseUrl + "users/{userId}"),
                            Mockito.eq(HttpMethod.GET),
                            Mockito.any(),
                            Mockito.eq(OktaUserResponse.class),
                            Mockito.eq(Map.of("userId", userId))))
                    .thenReturn(ResponseEntity.status(HttpStatus.FORBIDDEN).build());
            oktaUserService.getOktaUser(userId, onError);
            Assertions.fail("Wrong behavior");
        } catch (ResponseStatusException ex) {
            Assertions.assertEquals("403 FORBIDDEN \"Cannot read Okta user with id=" + userId + "\"", ex.getMessage());
            Assertions.assertEquals(HttpStatus.FORBIDDEN, ex.getStatus());
        }

        try {
            Mockito.when(restTemplate.exchange(
                            Mockito.eq(baseUrl + "users/{userId}"),
                            Mockito.eq(HttpMethod.GET),
                            Mockito.any(),
                            Mockito.eq(OktaUserResponse.class),
                            Mockito.eq(Map.of("userId", userId))))
                    .thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).build());
            oktaUserService.getOktaUser(userId, onError);
            Assertions.fail("Wrong behavior");
        } catch (ResponseStatusException ex) {
            Assertions.assertEquals("404 NOT_FOUND \"Okta user is not found for id=" + userId + "\"", ex.getMessage());
            Assertions.assertEquals(HttpStatus.NOT_FOUND, ex.getStatus());
        }
    }

    @Test
    void setTargetAndUpdateUser() {
        OktaUserService oktaUserService = new OktaUserService(restTemplateBuilder, config, retryTemplate);

        Consumer<Exception> onError = (ex) -> {
        };

        String userId = UUID.randomUUID().toString();
        OktaUser user = new OktaUser();
        user.setEvtOwfTrigger(null);

        user.setPsUserId(userId);
        OktaUserResponse response = new OktaUserResponse();
        response.setProfile(user);

        CoreEvent ce = CoreEvent.builder()
                .target("target")
                .stage("stage")
                .scenario(ScenarioEnum.CREATE)
                .build();

        Mockito.when(restTemplate.exchange(
                        Mockito.eq(baseUrl + "users/{userId}"),
                        Mockito.eq(HttpMethod.POST),
                        Mockito.any(),
                        Mockito.eq(OktaUserResponse.class),
                        Mockito.eq(Map.of("userId", userId))))
                .thenReturn(ResponseEntity.ok(response));

        Assertions.assertEquals(user, oktaUserService.setTargetAndUpdateUser(userId, user, ce, true, onError));
        Assertions.assertNotNull(user.getEvtOwfTrigger());
        Assertions.assertNotNull(user.getFlowInfo());
        Assertions.assertEquals("owf", user.getEvtTarget());

        user.setEvtOwfTrigger(null);
        Assertions.assertEquals(user, oktaUserService.setTargetAndUpdateUser(userId, user, ce, false, onError));
        Assertions.assertNull(user.getEvtOwfTrigger());
        Assertions.assertNotNull(user.getFlowInfo());
        Assertions.assertEquals("owf", user.getEvtTarget());
    }

    @Test
    void updateUser() {
        OktaUserService oktaUserService = new OktaUserService(restTemplateBuilder, config, retryTemplate);

        Consumer<Exception> onError = (ex) -> {
        };

        String userId = UUID.randomUUID().toString();
        OktaUser user = new OktaUser();
        user.setPsUserId(userId);
        OktaUserResponse response = new OktaUserResponse();
        response.setProfile(user);

        Mockito.when(restTemplate.exchange(
                        Mockito.eq(baseUrl + "users/{userId}"),
                        Mockito.eq(HttpMethod.POST),
                        Mockito.any(),
                        Mockito.eq(OktaUserResponse.class),
                        Mockito.eq(Map.of("userId", userId))))
                .thenReturn(ResponseEntity.ok(response));

        Assertions.assertEquals(user, oktaUserService.updateUser(userId, user, onError));

        try {
            Mockito.when(restTemplate.exchange(
                            Mockito.eq(baseUrl + "users/{userId}"),
                            Mockito.eq(HttpMethod.POST),
                            Mockito.any(),
                            Mockito.eq(OktaUserResponse.class),
                            Mockito.eq(Map.of("userId", userId))))
                    .thenReturn(ResponseEntity.status(HttpStatus.FORBIDDEN).build());
            oktaUserService.updateUser(userId, user, onError);
            Assertions.fail("Wrong behavior");
        } catch (ResponseStatusException ex) {
            Assertions.assertEquals("403 FORBIDDEN \"Cannot update Okta user with id=" + userId + "\"", ex.getMessage());
            Assertions.assertEquals(HttpStatus.FORBIDDEN, ex.getStatus());
        }

        try {
            Mockito.when(restTemplate.exchange(
                            Mockito.eq(baseUrl + "users/{userId}"),
                            Mockito.eq(HttpMethod.POST),
                            Mockito.any(),
                            Mockito.eq(OktaUserResponse.class),
                            Mockito.eq(Map.of("userId", userId))))
                    .thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).build());
            oktaUserService.updateUser(userId, user, onError);
            Assertions.fail("Wrong behavior");
        } catch (ResponseStatusException ex) {
            Assertions.assertEquals("404 NOT_FOUND \"Okta user is not found for id=" + userId + "\"", ex.getMessage());
            Assertions.assertEquals(HttpStatus.NOT_FOUND, ex.getStatus());
        }
    }
}