package com.mckesson.oktaclient.service;

import com.mckesson.oktaclient.dto.OktaUser;
import com.mckesson.oktaclient.dto.OktaUserResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class PaginatedResponseIteratorTest {


    @Test
    void loadData() {
        String userId = UUID.randomUUID().toString();
        OktaUser user = new OktaUser();
        user.setPsUserId(userId);
        var expected = new OktaUserResponse();
        expected.setProfile(user);

        var instance = new PaginatedResponseIterator("url1", OktaUserResponse[].class) {
            @Override
            protected ResponseEntity<OktaUserResponse[]> exchange(String url, Class responseType) {
                var headers = new HttpHeaders();
                if ("url1".equals(url)) {
                    headers.add("link", "<url2>; rel=\"next\"");
                    return new ResponseEntity<>(new OktaUserResponse[]{expected}, headers, HttpStatus.OK);
                } else {
                    return new ResponseEntity<>(new OktaUserResponse[]{}, headers, HttpStatus.OK);

                }
            }
        };
        var actual = instance.next();
        Assertions.assertEquals(actual, expected);
        Assertions.assertFalse(instance.hasNext());
        Assertions.assertNull(instance.next());
    }
}