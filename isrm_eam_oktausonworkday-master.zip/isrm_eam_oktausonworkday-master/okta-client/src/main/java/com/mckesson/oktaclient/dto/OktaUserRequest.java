package com.mckesson.oktaclient.dto;

import lombok.AccessLevel;
import lombok.Value;
import lombok.experimental.FieldDefaults;

/**
 * OKTA user request class
 * @see https://developer.okta.com/docs/reference/api/users/#update-user
 */
@Value
@FieldDefaults(makeFinal = true, level = AccessLevel.PRIVATE)
public class OktaUserRequest {
    OktaUser profile;
}
