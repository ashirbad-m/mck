package com.mckesson.oktaclient.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

/**
 * OKTA list of users response class
 * @see https://developer.okta.com/docs/reference/api/users/#list-users
 */
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(Include.NON_NULL)
public class OktaUserResponse {
    String id;
    String status;

    // Date fields
    String created;
    String activated;
    String statusChanged;
    String lastLogin;
    String lastUpdated;
    String passwordChanged;
    OktaType type;
    OktaCredentials credentials;

    OktaUser profile;
}
