package com.mckesson.oktaclient.actuate;

import com.mckesson.oktaclient.OktaClientConfiguration;
import com.mckesson.oktaclient.service.OktaUserService;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

/**
 * Checks status of OKTA User API (REST)
 */
@Component
public class OktaUserApiHealthIndicator extends AbstractHealthIndicator {
    private final String location;
    private final OktaUserService oktaUserService;

    public OktaUserApiHealthIndicator(OktaClientConfiguration config, OktaUserService oktaUserService) {
        super("OKTA User API health check failed");
        Assert.notNull(config, "OktaClientConfiguration must not be null");
        Assert.notNull(oktaUserService, "oktaUserService must not be null");
        this.location = config.getBaseUrl();
        this.oktaUserService = oktaUserService;
    }

    @Override
    protected void doHealthCheck(Health.Builder builder) {
        builder.withDetail("location", location);
        oktaUserService.getAllOktaUsers(10);
        builder.up();
    }
}
