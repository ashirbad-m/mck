package com.mckesson.oktaclient.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mckesson.common.domain.Manager;
import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.model.ScenarioEnum;
import com.mckesson.common.workday.converter.ConverterUtils;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.function.BinaryOperator;

/**
 * OKTA user profile class
 * @see <a href="https://developer.okta.com/docs/reference/api/users/#example">User</a>
 * @see <a href="https://developer.okta.com/docs/reference/api/users/#list-users">List Users</a>
 */
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(Include.NON_NULL)
public class OktaUser {
    @JsonProperty("dn")
    String dn;
    @JsonProperty("login")
    String login;
    @JsonProperty("firstName")
    String firstName;
    @JsonProperty("lastName")
    String lastName;
    @JsonProperty("displayName")
    String flowInfo;
    @JsonProperty("employeeNumber")
    String employeeNumber;
    @JsonProperty("state")
    String state;
    @JsonProperty("primaryPhone")
    String primaryPhone;
    @JsonProperty("email")
    String email;
    @JsonProperty("streetAddress")
    String streetAddress;
    @JsonProperty("title")
    String title;
    @JsonProperty("mobilePhone")
    String mobilePhone;
    @JsonProperty("city")
    String city;
    @JsonProperty("countryCode")
    String countryCode;
    @JsonProperty("zipCode")
    String zipCode;
    @JsonProperty("postalAddress")
    String postalAddress;
    @JsonProperty("secondEmail")
    String secondEmail;

    @JsonProperty("p20_evt_target")
    String evtTarget;
    @JsonProperty("p20_evt_scenario")
    String evtScenario;
    @JsonProperty("p20_evt_stage")
    String evtStage;
    @JsonProperty("p20_evt_context")
    String evtContext;
    @JsonProperty("p20_evt_id")
    String evtId;
    @JsonProperty("p20_evt_importCompleted")
    Boolean evtImportCompleted;
    @JsonProperty("p20_evt_owfTrigger")
    String evtOwfTrigger;
    @JsonProperty("eventType")
    String eventType;
    @JsonProperty("eventBody")
    String eventBody;

    @JsonProperty("p20_ps_cn")
    String psCn;
    @JsonProperty("p20_ps_userId")
    String psUserId;
    @JsonProperty("p20_ps_firstName")
    String psFirstName;
    @JsonProperty("p20_ps_lastName")
    String psLastName;
    @JsonProperty("p20_ps_middleName")
    String psMiddleName;
    @JsonProperty("p20_ps_title")
    String psTitle;
    @JsonProperty("p20_ps_displayName")
    String psDisplayName;
    @JsonProperty("p20_ps_state")
    String psState;
    @JsonProperty("p20_ps_postalAddress")
    String psPostalAddress;
    @JsonProperty("p20_ps_managerDn")
    String psManagerDn;
    @JsonProperty("p20_ps_active")
    Boolean psActive;
    @JsonProperty("p20_ps_terminated")
    Boolean psTerminated;
    @JsonProperty("p20_ps_dateActivated")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    Date psDateActivated;
    @JsonProperty("p20_ps_hireDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    Date psHireDate;
    @JsonProperty("p20_ps_positionEffectiveDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    Date psPositionEffectiveDate;
    @JsonProperty("p20_ps_workerType")
    String psWorkerType;
    @JsonProperty("p20_ps_jobFamily")
    String psJobFamily;
    @JsonProperty("p20_ps_ssn")
    String psSsn;
    @JsonProperty("p20_ps_HRPartner")
    Long psHrPartner;
    @JsonProperty("p20_ps_glPayType")
    String psGlPayType;
    @JsonProperty("p20_ps_uid")
    String psUid;
    @JsonProperty("p20_ps_country")
    String psCountry;
    @JsonProperty("p20_ps_fax")
    String psFax;
    @JsonProperty("p20_ps_executiveDirector")
    Long psExecutiveDirector;
    @JsonProperty("p20_ps_company")
    String psCompany;
    @JsonProperty("p20_ps_homeDirectory")
    String psHomeDirectory;
    @JsonProperty("p20_ps_oldHomeDirectory")
    String psOldHomeDirectory;
    @JsonProperty("p20_ps_homeDrive")
    String psHomeDrive;
    @JsonProperty("p20_ps_accountExpires")
    Long psAccountExpires;
    @JsonProperty("p20_ps_scriptPath")
    String psScriptPath;
    @JsonProperty("p20_ps_primaryGroupId")
    Long psPrimaryGroupId;
    @JsonProperty("p20_ps_description")
    String psDescription;
    @JsonProperty("p20_ps_emailSecondary")
    String psEmailSecondary;
    @JsonProperty("p20_ps_userPrincipalName")
    String psUserPrincipalName;
    @JsonProperty("p20_ps_oldUserPrincipalName")
    String psOldUserPrincipalName;
    @JsonProperty("p20_ps_mobile")
    String psMobile;
    @JsonProperty("p20_ps_postalCode")
    String psPostalCode;
    @JsonProperty("p20_ps_telephoneNumber")
    String psTelephoneNumber;
    @JsonProperty("p20_ps_workerId")
    String psWorkerId;
    @JsonProperty("p20_ps_ou")
    String psOu;
    @JsonProperty("p20_ps_msExchRecipientTypeDetails")
    String psMsExchRecipientTypeDetails;
    @JsonProperty("p20_ps_showInAddressBook")
    String psShowInAddressBook;
    @JsonProperty("p20_ps_terminalServicesProfilePath")
    String psTerminalServicesProfilePath;
    @JsonProperty("p20_ps_emailPrimary")
    String psEmailPrimary;
    @JsonProperty("p20_ps_emailSecondaryAdditional")
    String psEmailSecondaryAdditional;
    @JsonProperty("p20_ps_physicalDeliveryOfficeName")
    String psPhysicalDeliveryOfficeName;
    @JsonProperty("p20_ps_mailboxCreated")
    Boolean psMailboxCreated;
    @JsonProperty("p20_ps_groups")
    String psGroups;
    @JsonProperty("p20_ps_oldGroups")
    String psOldGroups;
    @JsonProperty("p20_ps_info")
    String psInfo;
    @JsonProperty("p20_ps_managerObject")
    String psManagerObject;
    @JsonProperty("p20_ps_oldManagerObject")
    String psOldManagerObject;
    @JsonProperty("p20_ps_serverNames")
    Set<String> psServerNames;
    @JsonProperty("p20_ps_associatedAccountsTermination")
    String psAssociatedAccountsTermination;
    @JsonProperty("p20_ps_HRBU")
    String psHRBU;
    @JsonProperty("p20_ps_city")
    String psCity;
    @JsonProperty("p20_ps_address")
    String psAddress;
    @JsonProperty("p20_ps_leaveOfAbsence")
    Boolean psLeaveOfAbsence;
    @JsonProperty("p20_ps_companyId")
    String psCompanyId;
    @JsonProperty("p20_ps_workerTypeDescriptor")
    String psWorkerTypeDescriptor;
    @JsonProperty("p20_ps_managerUserId")
    String psManagerUserId;
    @JsonProperty("p20_ps_managerHRBU")
    String psManagerHRBU;
    @JsonProperty("p20_ps_executiveDirectorUserId")
    String psExecutiveDirectorUserId;
    @JsonProperty("p20_ps_executiveDirectorHRBU")
    String psExecutiveDirectorHRBU;
    @JsonProperty("p20_ps_employee")
    Boolean psEmployee;
    @JsonProperty("p20_ps_managerId")
    String psManagerId;
    @JsonProperty("p20_ps_preferredFirstName")
    String psPreferredFirstName;
    @JsonProperty("p20_ps_preferredLastName")
    String psPreferredLastName;
    @JsonProperty("p20_ps_preferredPrefix")
    String psPreferredPrefix;
    @JsonProperty("p20_ps_preferredSuffix")
    String psPreferredSuffix;
    @JsonProperty("p20_ps_legalPrefix")
    String psLegalPrefix;
    @JsonProperty("p20_ps_legalSuffix")
    String psLegalSuffix;
    @JsonProperty("p20_ps_legalName")
    String psLegalName;
    @JsonProperty("p20_ps_oldHRBU")
    String psOldHRBU;
    @JsonProperty("p20_ps_oldCity")
    String psOldCity;
    @JsonProperty("p20_ps_oldAddress")
    String psOldAddress;
    @JsonProperty("p20_ps_oldLeaveOfAbsence")
    Boolean psOldLeaveOfAbsence;
    @JsonProperty("p20_ps_oldCompanyId")
    String psOldCompanyId;
    @JsonProperty("p20_ps_oldWorkerTypeDescriptor")
    String psOldWorkerTypeDescriptor;
    @JsonProperty("p20_ps_oldManagerUserId")
    String psOldManagerUserId;
    @JsonProperty("p20_ps_oldManagerHRBU")
    String psOldManagerHRBU;
    @JsonProperty("p20_ps_oldExecutiveDirector")
    String psOldExecutiveDirector;
    @JsonProperty("p20_ps_oldExecutiveDirectorUserId")
    String psOldExecutiveDirectorUserId;
    @JsonProperty("p20_ps_oldExecutiveDirectorHRBU")
    String psOldExecutiveDirectorHRBU;
    @JsonProperty("p20_ps_oldEmployee")
    Boolean psOldEmployee;
    @JsonProperty("p20_ps_oldManagerId")
    String psOldManagerId;
    @JsonProperty("p20_ps_oldFirstName")
    String psOldFirstName;
    @JsonProperty("p20_ps_oldLastName")
    String psOldLastName;
    @JsonProperty("p20_ps_oldPreferredFirstName")
    String psOldPreferredFirstName;
    @JsonProperty("p20_ps_oldPreferredLastName")
    String psOldPreferredLastName;
    @JsonProperty("p20_ps_oldPreferredPrefix")
    String psOldPreferredPrefix;
    @JsonProperty("p20_ps_oldPreferredSuffix")
    String psOldPreferredSuffix;
    @JsonProperty("p20_ps_oldLegalPrefix")
    String psOldLegalPrefix;
    @JsonProperty("p20_ps_oldLegalSuffix")
    String psOldLegalSuffix;
    @JsonProperty("p20_ps_oldLegalName")
    String psOldLegalName;
    @JsonProperty("p20_ps_incidentData")
    String psIncidentData;
    @JsonProperty("p20_ps_oktaUserId")
    String psOktaUserId;
    @JsonProperty("p20_ps_adInfo")
    String psAdInfo;
    @JsonProperty("p20_ad_companyId")
    String adCompanyId;

    @JsonProperty("p20_ad_workerId")
    String adWorkerId;
    @JsonProperty("p20_ad_company")
    String adCompany;
    @JsonProperty("p20_ad_city")
    String adCity;
    @JsonProperty("p20_ad_displayName")
    String adDisplayName;
    @JsonProperty("p20_ad_postalAddress")
    String adPostalAddress;
    @JsonProperty("p20_ad_preferredFirstName")
    String adPreferredFirstName;
    @JsonProperty("p20_ad_preferredLastName")
    String adPreferredLastName;
    @JsonProperty("p20_ad_preferredPrefix")
    String adPreferredPrefix;
    @JsonProperty("p20_ad_preferredSuffix")
    String adPreferredSuffix;
    @JsonProperty("p20_ad_legalPrefix")
    String adLegalPrefix;
    @JsonProperty("p20_ad_legalSuffix")
    String adLegalSuffix;
    @JsonProperty("p20_ad_mobile")
    String adMobile;
    @JsonProperty("p20_ad_postalCode")
    String adPostalCode;
    @JsonProperty("p20_ad_executiveDirectorHRBU")
    String adExecutiveDirectorHRBU;
    @JsonProperty("p20_ad_userId")
    String adUserId;
    @JsonProperty("p20_ad_lastName")
    String adLastName;
    @JsonProperty("p20_ad_firstName")
    String adFirstName;
    @JsonProperty("p20_ad_homeDrive")
    String adHomeDrive;
    @JsonProperty("p20_ad_showInAddressBook")
    String adShowInAddressBook;
    @JsonProperty("p20_ad_manager")
    String adManager;
    @JsonProperty("p20_ad_primaryGroupId")
    Long adPrimaryGroupId;
    @JsonProperty("p20_ad_email_secondary")
    String adEmailSecondary;
    @JsonProperty("p20_ad_country")
    String adCountry;
    @JsonProperty("p20_ad_description")
    String adDescription;
    @JsonProperty("p20_ad_physicalDeliveryOfficeName")
    String adPhysicalDeliveryOfficeName;
    @JsonProperty("p20_ad_userPrincipalName")
    String adUserPrincipalName;
    @JsonProperty("AD_OU_SELECTOR")
    String adOuSelector;
    @JsonProperty("AD_GROUP_SELECTORS")
    String adGroupSelectors;
    @JsonProperty("p20_ad_executiveDirectorUserId")
    String adExecutiveDirectorUserId;
    @JsonProperty("p20_ad_workerTypeDescriptor")
    String adWorkerTypeDescriptor;
    @JsonProperty("p20_ad_legalName")
    String adLegalName;
    @JsonProperty("p20_ad_executiveDirector")
    String adExecutiveDirector;
    @JsonProperty("p20_ad_email_primary")
    String adEmailPrimary;
    @JsonProperty("p20_ad_email")
    String adEmail;
    @JsonProperty("p20_ad_telephoneNumber")
    String adTelephoneNumber;
    @JsonProperty("p20_ad_address")
    String adAddress;
    @JsonProperty("p20_ad_cn")
    String adCn;
    @JsonProperty("p20_ad_state")
    String adState;
    @JsonProperty("p20_ad_managerHRBU")
    String adManagerHRBU;
    @JsonProperty("p20_ad_scriptPath")
    String adScriptPath;
    @JsonProperty("p20_ad_info")
    String adInfo;
    @JsonProperty("p20_ad_accountExpires")
    Long adAccountExpires;
    @JsonProperty("p20_ad_managerUserId")
    String adManagerUserId;
    @JsonProperty("p20_ad_homeDirectory")
    String adHomeDirectory;
    @JsonProperty("p20_ad_title")
    String adTitle;
    @JsonProperty("p20_ad_HRBU")
    String adHRBU;
    @JsonProperty("p20_ad_terminalServicesProfilePath")
    String adTerminalServicesProfilePath;
    @JsonProperty("p20_ad_email_secondaryAdditional")
    String adEmailSecondaryAdditional;
    @JsonProperty("p20_ad_workerType")
    String adWorkerType;
    @JsonProperty("p20_ad_middleName")
    String adMiddleName;
    @JsonProperty("p20_ad_fax")
    String adFax;
    @JsonProperty("p20_ad_managerId")
    String adManagerId;
    @JsonProperty("p20_ad_msExchRecipientTypeDetails")
    Long adMsExchRecipientTypeDetails;
    @JsonProperty("p20_ad_employee")
    Boolean adEmployee;
    @JsonProperty("p20_ad_active")
    Boolean adActive;
    @JsonProperty("p20_ad_leaveOfAbsence")
    Boolean adLeaveOfAbsence;
    @JsonProperty("p20_ad_terminated")
    Boolean adTerminated;

    @JsonProperty("p20_wd_workerId")
    String wdWorkerId;
    @JsonProperty("p20_wd_HRBU")
    String wdHRBU;
    @JsonProperty("p20_wd_hireDate")
    String wdHireDate;
    @JsonProperty("p20_wd_fax")
    String wdFax;
    @JsonProperty("p20_wd_employee")
    Boolean wdEmployee;
    @JsonProperty("p20_wd_leaveOfAbsence")
    Boolean wdLeaveOfAbsence;
    @JsonProperty("p20_wd_active")
    Boolean wdActive;
    @JsonProperty("p20_wd_workerTypeDescriptor")
    String wdWorkerTypeDescriptor;
    @JsonProperty("p20_wd_uid")
    String wdUid;
    @JsonProperty("p20_wd_managerHRBU")
    String wdManagerHRBU;
    @JsonProperty("p20_wd_managerUserId")
    String wdManagerUserId;
    @JsonProperty("p20_wd_userId")
    String wdUserId;
    @JsonProperty("p20_wd_hrPartnerFirstName")
    String wdHrPartnerFirstName;
    @JsonProperty("p20_wd_hrPartnerLastName")
    String wdHrPartnerLastName;
    @JsonProperty("p20_wd_groupSelectors")
    String wdGroupSelectors;
    @JsonProperty("p20_wd_postalCode")
    String wdPostalCode;
    @JsonProperty("p20_wd_addressLastModified")
    String wdAddressLastModified;
    @JsonProperty("p20_wd_displayName")
    String wdDisplayName;
    @JsonProperty("p20_wd_ouSelector")
    String wdOuSelector;
    @JsonProperty("p20_wd_firstName")
    String wdFirstName;
    @JsonProperty("p20_wd_lastName")
    String wdLastName;
    @JsonProperty("p20_wd_state")
    String wdState;
    @JsonProperty("p20_wd_executiveDirectorHRBU")
    String wdExecutiveDirectorHRBU;
    @JsonProperty("p20_wd_physicalDeliveryOfficeName")
    String wdPhysicalDeliveryOfficeName;
    @JsonProperty("p20_wd_userPrincipalName")
    String wdUserPrincipalName;
    @JsonProperty("p20_wd_hrPartnerEMail")
    String wdHrPartnerEMail;
    @JsonProperty("p20_wd_legalSuffix")
    String wdLegalSuffix;
    @JsonProperty("p20_wd_legalPrefix")
    String wdLegalPrefix;
    @JsonProperty("p20_wd_country")
    String wdCountry;
    @JsonProperty("p20_wd_middleName")
    String wdMiddleName;
    @JsonProperty("p20_wd_title")
    String wdTitle;
    @JsonProperty("p20_wd_email_secondaryAdditional")
    String wdEmailSecondaryAdditional;
    @JsonProperty("p20_wd_description")
    String wdDescription;
    @JsonProperty("p20_wd_executiveDirectorUserId")
    String wdExecutiveDirectorUserId;
    @JsonProperty("p20_wd_email")
    String wdEmail;
    @JsonProperty("p20_wd_preferredFirstName")
    String wdPreferredFirstName;
    @JsonProperty("p20_wd_preferredLastName")
    String wdPreferredLastName;
    @JsonProperty("p20_wd_preferredSuffix")
    String wdPreferredSuffix;
    @JsonProperty("p20_wd_preferredPrefix")
    String wdPreferredPrefix;
    @JsonProperty("p20_wd_workerType")
    String wdWorkerType;
    @JsonProperty("p20_wd_dateActivated")
    String wdDateActivated;
    @JsonProperty("p20_wd_telephoneNumber")
    String wdTelephoneNumber;
    @JsonProperty("p20_wd_positionEffectiveDate")
    String wdPositionEffectiveDate;
    @JsonProperty("p20_wd_postalAddress")
    String wdPostalAddress;
    @JsonProperty("p20_wd_address")
    String wdAddress;
    @JsonProperty("p20_wd_glPayType")
    String wdGlPayType;
    @JsonProperty("p20_wd_terminated")
    Boolean wdTerminated;
    @JsonProperty("p20_wd_email_secondary")
    String wdEmailSecondary;
    @JsonProperty("p20_wd_cn")
    String wdCn;
    @JsonProperty("p20_wd_companyId")
    String wdCompanyId;
    @JsonProperty("p20_wd_mobile")
    String wdMobile;
    @JsonProperty("p20_wd_jobFamily")
    String wdJobFamily;
    @JsonProperty("p20_wd_ssn")
    String wdSsn;
    @JsonProperty("p20_wd_email_primary")
    String wdEmailPrimary;
    @JsonProperty("p20_wd_city")
    String wdCity;
    @JsonProperty("p20_wd_legalName")
    String wdLegalName;
    @JsonProperty("p20_wd_managerId")
    String wdManagerId;
    @JsonProperty("p20_wd_HRPartner")
    String wdHRPartner;
    @JsonProperty("p20_wd_executiveDirector")
    String wdExecutiveDirector;

    public OktaUser() {
    }

    public OktaUser(CoreEvent coreEvent) {
        setEvtTarget(coreEvent.getTarget());
        setEvtScenario(coreEvent.getScenario().getName());
        setEvtStage(coreEvent.getStage());
    }

    @JsonIgnore
    public void setPsManagerAsObject(Manager manager) {
        setPsManagerObject(Optional.ofNullable(manager).map(Manager::getManagerAsString).orElse(""));
    }

    @JsonIgnore
    public void setPsOldManagerAsObject(Manager manager) {
        setPsOldManagerObject(Optional.ofNullable(manager).map(Manager::getManagerAsString).orElse(""));
    }

    @JsonIgnore
    public void resetFlowInfo(CoreEvent ce, final boolean evtImportCompleted) {
        ce = Optional.ofNullable(ce).orElseGet(CoreEvent::new);
        final BinaryOperator<String> stringValue = (s1, s2) -> Optional.ofNullable(StringUtils.defaultIfBlank(s1, s2)).orElse("");
        setFlowInfo(
                ConverterUtils.writeValueAsString(
                        Map.of(
                                "p20_evt_importCompleted", evtImportCompleted,
                                "p20_evt_target", stringValue.apply(getEvtTarget(), ce.getTarget()),
                                "p20_evt_stage", stringValue.apply(getEvtStage(), ce.getStage()),
                                "p20_evt_scenario", stringValue.apply(
                                        getEvtScenario(), Optional.ofNullable(ce.getScenario()).map(ScenarioEnum::getName).orElse(null)
                                ),
                                "p20_evt_uuid", UUID.randomUUID().toString()
                        )
                )
        );
    }
}
