package com.mckesson.oktaclient;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
@ConfigurationProperties(prefix = "oktaclient")
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class OktaClientConfiguration {
    String baseUrl;
    String token;
    int timeout;
}
