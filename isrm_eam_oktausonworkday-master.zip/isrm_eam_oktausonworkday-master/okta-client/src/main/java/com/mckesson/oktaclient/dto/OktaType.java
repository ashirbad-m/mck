package com.mckesson.oktaclient.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

/**
 * OKTA user type class
 * @see https://developer.okta.com/docs/reference/api/users/#list-users
 */
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(Include.NON_NULL)
public class OktaType {
    String id;
}
