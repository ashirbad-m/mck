package com.mckesson.oktaclient.service;

import com.mckesson.common.AbstractCoreEventProcessor;
import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.PassportActionProcessor;
import com.mckesson.common.audit.AuditService;
import com.mckesson.common.domain.OktaUser;
import com.mckesson.common.domain.PassportAction;
import com.mckesson.common.model.*;
import com.mckesson.common.scenario.ScenarioProvider;
import com.mckesson.common.workday.converter.ConverterUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import java.util.Date;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.mckesson.common.workday.converter.ConverterUtils.object2Json;

@Service
@Slf4j
public class OktaProcessor extends AbstractCoreEventProcessor implements PassportActionProcessor {
    private static final String EVENT_PREFIX = "passport.okta-client.send.";
    private static final String EVENT_CREATE = EVENT_PREFIX + "create";
    private static final String EVENT_UPDATE = EVENT_PREFIX + "update";
    private static final String EVENT_SYNCHRONIZE = EVENT_PREFIX + "synchronize";
    private static final String EVENT_TERMINATE = EVENT_PREFIX + "terminate";
    private static final String EVENT_PREPARE_TERMINATE = EVENT_PREFIX + "prepare-terminate";
    private static final String EVENT_REQUEST = EVENT_PREFIX + "request";
    private static final String EVENT_DEFERRED = EVENT_PREFIX + "deferred";
    private static final String EVENT_ACTION = EVENT_PREFIX + "action";
    private static final String EVENT_ERROR = EVENT_PREFIX + "error";

    private final OktaUserService oktaUserService;
    private final MessageBrokerPublisher messageBrokerPublisher;
    private final AuditService auditService;
    private final Map<ScenarioEnum, Consumer<CoreEvent>> processors = Stream.<Pair<ScenarioEnum, Consumer<CoreEvent>>>of(
            Pair.of(ScenarioEnum.CREATE, this::onCreate),
            Pair.of(ScenarioEnum.UPDATE, this::onUpdate),
            Pair.of(ScenarioEnum.CROSSDOMAIN, this::onTerminate),
            Pair.of(ScenarioEnum.TERMINATE, this::onTerminate),
            Pair.of(ScenarioEnum.REQUEST, this::onRequest),
            Pair.of(ScenarioEnum.DEFERRED, this::onDeferred),
            Pair.of(ScenarioEnum.SYNCHRONIZE, this::onSynchronize)
    ).collect(Collectors.toMap(Pair::getLeft, Pair::getRight));

    public OktaProcessor(ScenarioProvider scenarioProvider, MessageBrokerPublisher messageBrokerPublisher, OktaUserService oktaUserService,
                         AuditService auditService) {
        super(scenarioProvider, messageBrokerPublisher, ModuleEnum.OKTA_CLIENT);
        this.oktaUserService = oktaUserService;
        this.messageBrokerPublisher = messageBrokerPublisher;
        this.auditService = auditService;
    }

    @Override
    protected Map<ScenarioEnum, Consumer<CoreEvent>> getProcessors() {
        return processors;
    }

    @Override
    public void processAction(PassportAction passportAction) {
        Date startTime = new Date();
        try {
            com.mckesson.oktaclient.dto.OktaUser dto = new com.mckesson.oktaclient.dto.OktaUser();
            PassportAction.OktaEventBody eventBody = ConverterUtils.readSimpleJson(passportAction.getEventBody(), PassportAction.OktaEventBody.class, null);
            boolean updated = false;

            if (StringUtils.isNotBlank(eventBody.getIncidentData())) {
                dto.setPsIncidentData(eventBody.getIncidentData());
                updated = true;
            }

            if (updated) {
                try {
                    oktaUserService.setTargetAndUpdateUser(eventBody.getOktaUserId(), dto, null, false,
                            (ex) -> auditService.audit(generateEvent(passportAction, dto)
                                    .status("ERROR")
                                    .message("Error on update user: " + ex.getMessage())
                                    .situation(EVENT_ACTION).build()));
                    auditService.audit(generateEvent(passportAction, dto).build());
                } catch (HttpClientErrorException ex) {
                    if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
                        //skip event
                        auditService.audit(generateEvent(passportAction, dto)
                                .status("ERROR")
                                .message("Error on update user: " + ex.getMessage())
                                .situation(EVENT_ACTION).build());
                    } else {
                        throw ex;
                    }
                }
            }
        } finally {
            passportAction.getMetrics().add(new ExecutionMetric(passportAction.getEventType().getModule(), getClass(), startTime));
            messageBrokerPublisher.send(ModuleEnum.FINALIZER, passportAction);
        }
    }

    @Override
    protected void registerError(CoreEvent event) {
        final OktaUser user = event.getOktaUser();
        com.mckesson.oktaclient.dto.OktaUser dto = new com.mckesson.oktaclient.dto.OktaUser(event);
        PassportError pe = event.getError();
        if (pe.getScenario() != ScenarioEnum.REQUEST) {
            dto.setEvtScenario("break");
        }
        dto.setEvtStage("errorRegister");
        dto.setEvtContext(object2Json(pe, Objects::isNull, ""));

        oktaUserService.setTargetAndUpdateUser(user.getUserId(), dto, event, true,
                (ex) -> auditService.audit(generateEvent(event, dto)
                        .status("ERROR")
                        .message("Error on update user: " + ex.getMessage()).situation(EVENT_ERROR).build()));
        auditService.audit(generateEvent(event, dto).message("Sending error notification").situation(EVENT_ERROR).build());
    }

    //<editor-fold desc="Processors">
    private void onCreate(CoreEvent event) {
        if ("start".equals(event.getStage())) {
            OktaUser next = event.getNextOktaUser();
            final com.mckesson.oktaclient.dto.OktaUser dto = createUserWithIdentifiers(event);

            oktaUserService.setTargetAndUpdateUser(next.getUserId(), dto, event, true,
                    (ex) -> auditService.audit(generateEvent(event, dto)
                            .status("ERROR")
                            .message("Error on update user: " + ex.getMessage()).situation(EVENT_CREATE).build()));
            auditService.audit(generateEvent(event, dto).message("Sending onCreate notification").situation(EVENT_CREATE).build());
        }
    }

    private void onUpdate(CoreEvent event) {
        OktaUser next = event.getNextOktaUser();
        com.mckesson.oktaclient.dto.OktaUser dto;

        if ("commit".equals(event.getStage())) {
            dto = new com.mckesson.oktaclient.dto.OktaUser(event);
            OktaUser prev = event.getPrevOktaUser();
            dto.setPsManagerAsObject(next.getManagerObject());
            dto.setPsOldManagerAsObject(prev.getManagerObject());
            dto.setPsManagerDn(String.valueOf(prev.getManager()));
        } else if (
                "nameChange-cn".equals(event.getStage())
                        || "nameChange-email".equals(event.getStage())
                        || "nameChange-all".equals(event.getStage())
        ) {
            dto = new com.mckesson.oktaclient.dto.OktaUser(event);
            if (!"nameChange-cn".equals(event.getStage())) {
                dto.setPsEmailPrimary(next.getEmailPrimary());
                dto.setPsEmailSecondary(next.getEmailSecondary());
                dto.setPsEmailSecondaryAdditional(next.getEmailSecondaryAdditional());
            }
            if (!"nameChange-email".equals(event.getStage())) {
                dto.setPsCn(next.getCn());
            }
        } else if ("prepare".equals(event.getStage())) {
            dto = saveDns(next);
        } else {
            dto = toDto(event);
            if ("HRBUTransfer".equalsIgnoreCase(event.getStage())) {
                dto.setEvtTarget("owf");
                dto.setEvtScenario("update");
                dto.setEvtStage("HRBUTransferStep2");
            } else if ("ClinicalTransfer".equalsIgnoreCase(event.getStage())) {
                dto.setEvtTarget("owf");
                dto.setEvtScenario("update");
                dto.setEvtStage("ClinicalTransferStep2");
            } else if ("TXOTransfer".equalsIgnoreCase(event.getStage())) {
                dto.setEvtTarget("owf");
                dto.setEvtScenario("update");
                dto.setEvtStage("TXOTransferStep2");
                dto.setPsGroups(StringUtils.join(event.getOktaUser().getGroups(), ','));
                dto.setPsOldGroups(StringUtils.join(event.getPrevOktaUser().getGroups(), ','));
            }
        }
        oktaUserService.setTargetAndUpdateUser(next.getUserId(), dto, event, true,
                (ex) -> auditService.audit(generateEvent(event, dto)
                        .status("ERROR")
                        .message("Error on update user: " + ex.getMessage()).situation(EVENT_UPDATE).build()));
        auditService.audit(generateEvent(event, dto).message("Sending onUpdate notification").situation(EVENT_UPDATE).build());
    }

    private void onTerminate(CoreEvent event) {
        if ("start".equals(event.getStage())) {
            com.mckesson.oktaclient.dto.OktaUser dto = new com.mckesson.oktaclient.dto.OktaUser(event);
            OktaUser next = event.getNextOktaUser();
            OktaUser prev = event.getPrevOktaUser();
            dto.setPsServerNames(next.getServerNames());
            dto.setPsAssociatedAccountsTermination(next.getAssociatedAccountsTermination());
            dto.setPsInfo(next.getInfo());
            dto.setPsOldManagerAsObject(prev.getManagerObject());
            dto.setPsCn(next.getCn());
            oktaUserService.setTargetAndUpdateUser(next.getUserId(), dto, event, true,
                    (ex) -> auditService.audit(generateEvent(event, dto)
                            .status("ERROR")
                            .message("Error on update user: " + ex.getMessage()).situation(EVENT_TERMINATE).build()));
            auditService.audit(generateEvent(event, dto).message("Sending onTerminate / onCrossDomain notification")
                    .situation(EVENT_TERMINATE).build());
        } else if ("prepare".equals(event.getStage())) {
            final OktaUser next = event.getNextOktaUser();
            final com.mckesson.oktaclient.dto.OktaUser dto = saveDns(next);
            oktaUserService.setTargetAndUpdateUser(next.getUserId(), dto, event, true,
                    (ex) -> auditService.audit(generateEvent(event, dto)
                            .status("ERROR")
                            .message("Error on update user: " + ex.getMessage()).situation(EVENT_PREPARE_TERMINATE).build()));
            auditService.audit(generateEvent(event, dto).message("Sending prepare onTerminate / onCrossDomain notification")
                    .situation(EVENT_PREPARE_TERMINATE).build());
        }
    }
    //</editor-fold>

    private <T> void updateIfChanged(Consumer<T> setter, Function<OktaUser, T> prevGetter, OktaUser prev, T nextValue) {
        if (prev == null || !Objects.equals(prevGetter.apply(prev), nextValue)) {
            setter.accept(nextValue);
        }
    }


    private void onRequest(CoreEvent event) {
        if ("adInfo".equals(event.getStage())) {
            final OktaUser ou = event.getOktaUser();
            com.mckesson.oktaclient.dto.OktaUser dto = new com.mckesson.oktaclient.dto.OktaUser(event);
            dto.setPsAdInfo(object2Json(ou.getAdInfo(), Objects::isNull, ""));
            oktaUserService.setTargetAndUpdateUser(ou.getUserId(), dto, event, false,
                    (ex) -> auditService.audit(generateEvent(event, dto)
                            .status("ERROR")
                            .message("Error on update user: " + ex.getMessage()).situation(EVENT_REQUEST).build()));
            auditService.audit(generateEvent(event, dto).message("Sending onRequest notification").situation(EVENT_REQUEST).build());
        }
    }

    private void onDeferred(CoreEvent event) {
        if ("linkmanager".equals(event.getStage())) {
            saveManager(event, true);
        } else if ("getManagerForEMail".equals(event.getStage())) {
            saveManager(event, false);
        }
    }


    private void onSynchronize(CoreEvent event) {
        if ("start".equals(event.getStage())) {
            OktaUser next = event.getNextOktaUser();
            final com.mckesson.oktaclient.dto.OktaUser dto = createUserWithIdentifiers(event);
            dto.setPsAccountExpires(next.getAccountExpires());
            dto.setPsManagerAsObject(next.getManagerObject());
            dto.setPsManagerDn(String.valueOf(next.getManager()));

            oktaUserService.setTargetAndUpdateUser(next.getUserId(), dto, event, true,
                    (ex) -> auditService.audit(generateEvent(event, dto)
                            .status("ERROR")
                            .message("Error on update user: " + ex.getMessage()).situation(EVENT_SYNCHRONIZE).build()));
            auditService.audit(generateEvent(event, dto).message("Sending onSynchronize notification").situation(EVENT_SYNCHRONIZE).build());
        }
    }

    /**
     * Creates DTO object from CoreEvent
     * @param event core event
     * @return DTO object
     */
    private com.mckesson.oktaclient.dto.OktaUser createUserWithIdentifiers(final CoreEvent event) {
        final com.mckesson.oktaclient.dto.OktaUser dto = new com.mckesson.oktaclient.dto.OktaUser(event);
        OktaUser next = event.getNextOktaUser();
        dto.setPsEmailPrimary(next.getEmailPrimary());
        dto.setPsEmailSecondary(next.getEmailSecondary());
        dto.setPsEmailSecondaryAdditional(next.getEmailSecondaryAdditional());
        dto.setPsCn(next.getCn());
        dto.setDn(next.getDn().toString());
        dto.setPsUserPrincipalName(next.getUserPrincipalName());
        dto.setPsUserId(next.getSamAccountName());
        return dto;
    }

    /**
     * Saves manager from core event into OKTA user
     * @param event core event
     * @param saveDn save DN or not
     */
    private void saveManager(CoreEvent event, boolean saveDn) {
        final OktaUser ou = event.getOktaUser();
        com.mckesson.oktaclient.dto.OktaUser dto = new com.mckesson.oktaclient.dto.OktaUser(event);
        dto.setPsManagerAsObject(ou.getManagerObject());
        if (saveDn) {
            dto.setPsManagerDn(String.valueOf(ou.getManager()));
        }
        oktaUserService.setTargetAndUpdateUser(ou.getUserId(), dto, event, true,
                (ex) -> auditService.audit(generateEvent(event, dto)
                        .status("ERROR")
                        .message("Error on update user: " + ex.getMessage()).situation(EVENT_DEFERRED).build()));
        auditService.audit(generateEvent(event, dto).message("Sending onDeferred notification").situation(EVENT_DEFERRED).build());
    }

    /**
     * Saves DNs from core event into OKTA user
     * @param current OktaUser from core event
     */
    private com.mckesson.oktaclient.dto.OktaUser saveDns(final OktaUser current) {
        com.mckesson.oktaclient.dto.OktaUser dto = new com.mckesson.oktaclient.dto.OktaUser();
        dto.setPsCn(current.getCn());
        dto.setDn(current.getDn().toString());
        dto.setPsManagerDn(String.valueOf(current.getManager()));
        return dto;
    }

    /**
     * Convert CoreEvent to okta user DTO
     * @param event core event
     * @return DTO
     */
    private com.mckesson.oktaclient.dto.OktaUser toDto(CoreEvent event) {
        com.mckesson.oktaclient.dto.OktaUser dto = new com.mckesson.oktaclient.dto.OktaUser(event);
        OktaUser prev = event.getPrevOktaUser();
        OktaUser next = event.getNextOktaUser();

        updateIfChanged(dto::setFirstName, OktaUser::getFirstName, prev, next.getFirstName());
        updateIfChanged(dto::setLastName, OktaUser::getLastName, prev, next.getLastName());
        updateIfChanged(dto::setPsMiddleName, OktaUser::getMiddleName, prev, next.getMiddleName());

        updateIfChanged(dto::setPsLegalName, OktaUser::getLegalName, prev, next.getLegalName());
        updateIfChanged(dto::setPsLegalPrefix, OktaUser::getLegalPrefix, prev, next.getLegalPrefix());
        updateIfChanged(dto::setPsLegalSuffix, OktaUser::getLegalSuffix, prev, next.getLegalSuffix());
        updateIfChanged(dto::setPsPreferredFirstName, OktaUser::getPreferredFirstName, prev, next.getPreferredFirstName());

        updateIfChanged(dto::setPsPreferredLastName, OktaUser::getPreferredLastName, prev, next.getPreferredLastName());
        updateIfChanged(dto::setPsPreferredPrefix, OktaUser::getPreferredPrefix, prev, next.getPreferredPrefix());
        updateIfChanged(dto::setPsPreferredSuffix, OktaUser::getPreferredSuffix, prev, next.getPreferredSuffix());

        updateIfChanged(dto::setTitle, OktaUser::getTitle, prev, next.getTitle());
        updateIfChanged(dto::setPsDisplayName, OktaUser::getDisplayName, prev, next.getDisplayName());

        updateIfChanged(dto::setCity, OktaUser::getCity, prev, next.getCity());
        updateIfChanged(dto::setState, OktaUser::getState, prev, next.getState());
        updateIfChanged(dto::setPostalAddress, OktaUser::getPostalAddress, prev, next.getPostalAddress());
        updateIfChanged(dto::setPsCountry, OktaUser::getCountry, prev, next.getCountry());
        updateIfChanged(dto::setStreetAddress, OktaUser::getStreetAddress, prev, next.getStreetAddress());
        updateIfChanged(dto::setPsFax, OktaUser::getFax, prev, next.getFax());


        updateIfChanged(dto::setPsManagerId, OktaUser::getManagerId, prev, next.getManagerId());

        updateIfChanged(dto::setPsActive, OktaUser::isActive, prev, next.isActive());
        updateIfChanged(dto::setPsTerminated, OktaUser::getTerminated, prev, next.getTerminated());

        updateIfChanged(dto::setPsDateActivated, OktaUser::getDateActivated, prev, next.getDateActivated());
        updateIfChanged(dto::setPsHireDate, OktaUser::getHireDate, prev, next.getHireDate());
        updateIfChanged(dto::setPsPositionEffectiveDate, OktaUser::getPositionEffectiveDate, prev, next.getPositionEffectiveDate());

        updateIfChanged(dto::setPsWorkerType, OktaUser::getWorkerType, prev, next.getWorkerType());
        updateIfChanged(dto::setPsHrPartner, OktaUser::getHrPartner, prev, next.getHrPartner());
        updateIfChanged(dto::setPsExecutiveDirector, OktaUser::getExecutiveDirector, prev, next.getExecutiveDirector());

        updateIfChanged(dto::setPsJobFamily, OktaUser::getJobFamily, prev, next.getJobFamily());
        updateIfChanged(dto::setPsSsn, OktaUser::getSsn, prev, next.getSsn());

        updateIfChanged(dto::setPsLeaveOfAbsence, OktaUser::isLeaveOfAbsence, prev, next.isLeaveOfAbsence());
        updateIfChanged(dto::setPsCompanyId, OktaUser::getCompanyId, prev, next.getCompanyId());
        updateIfChanged(dto::setPsWorkerTypeDescriptor, OktaUser::getWorkerTypeDescriptor, prev, next.getWorkerTypeDescriptor());
        updateIfChanged(dto::setPsGlPayType, OktaUser::getGlPayType, prev, next.getGlPayType());

        dto.setDn(String.valueOf(next.getDn()));
        updateIfChanged(dto::setPsCn, OktaUser::getCn, prev, next.getCn());
        updateIfChanged(dto::setPsUid, OktaUser::getUid, prev, next.getUid());

        updateIfChanged(dto::setPsOldHRBU, OktaUser::getHrbu, prev, next.getHrbu());
        updateIfChanged(dto::setPsOldCity, OktaUser::getCity, prev, next.getCity());
        updateIfChanged(dto::setPsOldAddress, OktaUser::getStreetAddress, prev, next.getStreetAddress());
        updateIfChanged(dto::setPsOldLeaveOfAbsence, OktaUser::isLeaveOfAbsence, prev, next.isLeaveOfAbsence());
        updateIfChanged(dto::setPsOldCompanyId, OktaUser::getCompanyId, prev, next.getCompanyId());
        updateIfChanged(dto::setPsOldWorkerTypeDescriptor, OktaUser::getWorkerTypeDescriptor, prev, next.getWorkerTypeDescriptor());
        updateIfChanged(dto::setPsOldManagerUserId, OktaUser::getManagerUserId, prev, next.getManagerUserId());
        updateIfChanged(dto::setPsOldManagerHRBU, OktaUser::getManagerHrbu, prev, next.getManagerHrbu());
        updateIfChanged(dto::setPsOldExecutiveDirectorUserId, OktaUser::getExecutiveDirectorUserId, prev, next.getExecutiveDirectorUserId());
        updateIfChanged(dto::setPsOldExecutiveDirectorHRBU, OktaUser::getExecutiveDirectorHrbu, prev, next.getExecutiveDirectorHrbu());
        updateIfChanged(dto::setPsOldEmployee, OktaUser::isEmployee, prev, next.isEmployee());
        updateIfChanged(dto::setPsOldManagerId, OktaUser::getManagerId, prev, next.getManagerId());
        updateIfChanged(dto::setPsOldFirstName, OktaUser::getFirstName, prev, next.getFirstName());
        updateIfChanged(dto::setPsOldLastName, OktaUser::getLastName, prev, next.getLastName());
        updateIfChanged(dto::setPsOldPreferredFirstName, OktaUser::getPreferredFirstName, prev, next.getPreferredFirstName());
        updateIfChanged(dto::setPsOldPreferredLastName, OktaUser::getPreferredLastName, prev, next.getPreferredLastName());
        updateIfChanged(dto::setPsOldPreferredPrefix, OktaUser::getPreferredPrefix, prev, next.getPreferredPrefix());
        updateIfChanged(dto::setPsOldPreferredSuffix, OktaUser::getPreferredSuffix, prev, next.getPreferredSuffix());
        updateIfChanged(dto::setPsOldLegalPrefix, OktaUser::getLegalPrefix, prev, next.getLegalPrefix());
        updateIfChanged(dto::setPsOldLegalSuffix, OktaUser::getLegalSuffix, prev, next.getLegalSuffix());
        updateIfChanged(dto::setPsOldLegalName, OktaUser::getLegalName, prev, next.getLegalName());

        updateIfChanged(dto::setPsEmployee, OktaUser::isEmployee, prev, next.isEmployee());

        updateIfChanged(dto::setPsManagerUserId, OktaUser::getManagerUserId, prev, next.getManagerUserId());
        updateIfChanged(dto::setPsManagerHRBU, OktaUser::getManagerHrbu, prev, next.getManagerHrbu());
        updateIfChanged(dto::setPsExecutiveDirectorUserId, OktaUser::getExecutiveDirectorUserId, prev, next.getExecutiveDirectorUserId());
        updateIfChanged(dto::setPsExecutiveDirectorHRBU, OktaUser::getExecutiveDirectorHrbu, prev, next.getExecutiveDirectorHrbu());

        updateIfChanged(dto::setPsEmailPrimary, OktaUser::getEmailPrimary, prev, next.getEmailPrimary());
        updateIfChanged(dto::setPsEmailSecondaryAdditional, OktaUser::getEmailSecondaryAdditional, prev, next.getEmailSecondaryAdditional());
        updateIfChanged(dto::setPsEmailSecondary, OktaUser::getEmailSecondary, prev, next.getEmailSecondary());
        updateIfChanged(dto::setPsMailboxCreated, OktaUser::getMailboxCreated, prev, next.getMailboxCreated());
        updateIfChanged(dto::setPsInfo, OktaUser::getInfo, prev, next.getInfo());
        updateIfChanged(dto::setPsManagerAsObject, OktaUser::getManagerObject, prev, next.getManagerObject());
        updateIfChanged(dto::setPsServerNames, OktaUser::getServerNames, prev, next.getServerNames());

        updateIfChanged(dto::setPsHomeDirectory, OktaUser::getHomeDirectory, prev, next.getHomeDirectory());
        updateIfChanged(dto::setPsAssociatedAccountsTermination, OktaUser::getAssociatedAccountsTermination, prev, next.getAssociatedAccountsTermination());

        dto.setEvtId(event.getId());
        dto.setEvtImportCompleted(event.getImportCompleted());
        dto.setEvtContext(event.getContext());
        dto.setEvtTarget(event.getTarget());
        dto.setEvtScenario(event.getScenario().getName());
        dto.setEvtStage(event.getStage());
        return dto;
    }

    /**
     * Creates AuditEvent builder from CoreEvent and user DTO
     * @param event core event
     * @param dto user DTO
     * @return AuditEvent builder
     */
    private AuditEvent.AuditEventBuilder generateEvent(CoreEvent event, com.mckesson.oktaclient.dto.OktaUser dto) {
        return AuditEvent.generateEvent(event)
                .status("SUCCESS")
                .module(getModule())
                .newValues(ConverterUtils.writeValueAsString(dto))
                .message("Success");
    }

    /**
     * Creates AuditEvent builder from PassportAction and user DTO
     * @param action passport action
     * @param dto user DTO
     * @return AuditEvent builder
     */
    private AuditEvent.AuditEventBuilder generateEvent(PassportAction action, com.mckesson.oktaclient.dto.OktaUser dto) {
        final String bodyString = action.getEventBody();
        PassportAction.OktaEventBody eventBody = ConverterUtils.readSimpleJson(bodyString, PassportAction.OktaEventBody.class, null);
        return AuditEvent.generateEvent(eventBody)
                .module(getModule())
                .status("SUCCESS")
                .situation(EVENT_ACTION)
                .newValues(ConverterUtils.writeValueAsString(dto))
                .message("Success");
    }
}
