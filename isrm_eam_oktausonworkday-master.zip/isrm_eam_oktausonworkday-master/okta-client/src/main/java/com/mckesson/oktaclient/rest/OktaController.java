package com.mckesson.oktaclient.rest;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.oktaclient.service.OktaProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/okta")
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(name="rest.controller.enabled", havingValue = "true")
public class OktaController {
    private final OktaProcessor oktaProcessor;

    @PostMapping("/process")
    public ResponseEntity<Object> processEvent(@RequestBody CoreEvent event) {
        oktaProcessor.processEvent(event);
        return ResponseEntity.ok().build();
    }
}
