package com.mckesson.oktaclient.service;

import com.mckesson.common.MessageBrokerPublisher;
import com.mckesson.common.audit.AuditService;
import com.mckesson.common.domain.CommonGroup;
import com.mckesson.common.domain.CommonUser;
import com.mckesson.common.model.SyncCheck;
import com.mckesson.common.model.AuditEvent;
import com.mckesson.common.model.ModuleEnum;
import com.mckesson.oktaclient.dto.OktaGroupResponse;
import com.mckesson.oktaclient.dto.OktaUser;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

@Component
@Slf4j
public class OktaUserSyncChecker {
    private final MessageBrokerPublisher messageBrokerPublisher;
    private final OktaUserService oktaUserService;
    private final AuditService auditService;
    private final String groupName;

    public OktaUserSyncChecker(
            MessageBrokerPublisher messageBrokerPublisher,
            OktaUserService oktaUserService,
            AuditService auditService,
            @Value("${oktaclient.check.group-name}") String groupName
    ) {
        this.messageBrokerPublisher = messageBrokerPublisher;
        this.oktaUserService = oktaUserService;
        this.auditService = auditService;
        this.groupName = groupName;
    }

    @Scheduled(cron = "${oktaclient.check.cron.expression}")
    public void runCheck() {
        log.info("Start check");
        Consumer<Exception> onError = (ex) -> log.error("Unexpected exception", ex);
        List<OktaGroupResponse> groups = oktaUserService.findGroups(groupName, onError);
        if (!groups.isEmpty()) {
            var totalCount = new AtomicLong();
            var affectedCount = new AtomicLong();
            OktaGroupResponse group = groups.get(0);
            StreamSupport.stream(Spliterators.spliteratorUnknownSize(oktaUserService.getGroupUsers(group.getId()), 0), false)
                    .forEach(response -> {
                        totalCount.getAndIncrement();
                        if (StringUtils.isNotEmpty(response.getProfile().getAdOuSelector())) {
                            if (!isSynced(response.getProfile())) {
                                affectedCount.getAndIncrement();
                                var auditEvent = AuditEvent.builder()
                                        .date(new Date())
                                        .app(AuditEvent.Application.PASSPORT)
                                        .oktaUserId(response.getId())
                                        .message("ERROR")
                                        .situation("Sync check")
                                        .status("ERROR")
                                        .module(ModuleEnum.OKTA_CLIENT)
                                        .newValues(printDiff(response.getProfile()))
                                        .build();
                                auditService.audit(auditEvent);
                            } else {
                                var user = response.getProfile();
                                var userGroups = oktaUserService.getUserGroups(response.getId(), onError);
                                var logonHours = new byte[21];
                                if (user.getAdActive() == Boolean.TRUE && user.getAdLeaveOfAbsence() == Boolean.TRUE) {
                                    Arrays.fill(logonHours, (byte) 255);
                                }
                                var syncCheck = SyncCheck.builder()
                                        .oktaUserId(response.getId())
                                        .user(CommonUser.builder()
                                                .dn(user.getDn())
                                                .userPrincipalName(user.getAdUserPrincipalName())
                                                .samAccountName(user.getAdUserId())
                                                .city(user.getAdCity())
                                                .firstName(user.getAdFirstName())
                                                .primaryGroupId(user.getAdPrimaryGroupId())
                                                .mail(user.getAdEmail())
                                                .proxyAddresses(
                                                        Stream.of(
                                                                        user.getAdEmail(),
                                                                        user.getAdEmailPrimary(),
                                                                        user.getAdEmailSecondary(),
                                                                        user.getAdEmailSecondaryAdditional()
                                                                ).filter(Objects::nonNull)
                                                                .map(item -> "SMTP:" + item)
                                                                .sorted().distinct()
                                                                .collect(Collectors.toList())
                                                )
                                                .physicalDeliveryOfficeName(user.getAdPhysicalDeliveryOfficeName())
                                                .country(user.getAdCountry())
                                                .lastName(user.getAdLastName())
                                                .cn(user.getAdCn())
                                                .description(user.getAdDescription())
                                                .displayName(user.getAdDisplayName())
                                                .fax(user.getAdFax())
                                                .middleName(user.getAdMiddleName())
                                                .address(user.getAdAddress())
                                                .postalCode(user.getAdPostalCode())
                                                .mobile(user.getAdMobile())
                                                .telephoneNumber(user.getAdTelephoneNumber())
                                                .state(user.getAdState())
                                                .workerType(user.getAdWorkerType())
                                                .title(user.getAdTitle())
                                                .workerId(user.getAdWorkerId())
                                                .postalAddress(user.getAdPostalAddress())
                                                .homeDrive(user.getAdHomeDrive())
                                                .scriptPath(user.getAdScriptPath())
                                                .homeDirectory(user.getAdHomeDirectory())
                                                .msExchRecipientTypeDetails(user.getAdMsExchRecipientTypeDetails())
                                                .company(user.getAdCompany())
                                                .accountExpires(user.getAdAccountExpires())
                                                .terminalServicesProfilePath(user.getAdTerminalServicesProfilePath())
                                                .showInAddressBook(Arrays.asList(user.getAdShowInAddressBook()
                                                        .replace("[\"", "")
                                                        .replace("\"]", "")
                                                        .split("\",\""))
                                                )
                                                .info(user.getAdInfo())
                                                .manager(user.getAdManager())
                                                .logonHours(Hex.encodeHexString(logonHours))
                                                .active(user.getAdActive())
                                                .memberOf(userGroups.stream()
                                                        .filter(item -> "OKTA_GROUP" .equals(item.getType()) &&
                                                                (StringUtils.startsWithIgnoreCase(item.getProfile().getDescription(), "OU=") ||
                                                                        StringUtils.startsWithIgnoreCase(item.getProfile().getDescription(), "CN=")))
                                                        .map(item -> new CommonGroup(item.getProfile().getName(), item.getProfile().getDescription()))
                                                        .sorted(Comparator.comparing(CommonGroup::getDn))
                                                        .collect(Collectors.toList()))
                                                .build())
                                        .build();
                                messageBrokerPublisher.send(ModuleEnum.ACTIVE_DIRECTORY, syncCheck);
                            }
                        }
                    });
            System.out.println("Affected users " + affectedCount.get() + ", Total users " + totalCount.get());
        } else {
            throw new IllegalStateException();
        }
        log.info("End check");
    }

    private boolean isSynced(OktaUser profile) {
        return equals(profile, OktaUser::getAdActive, OktaUser::getWdActive) &&
                equals(profile, OktaUser::getAdAddress, OktaUser::getWdAddress) &&
                equals(profile, OktaUser::getAdCity, OktaUser::getWdCity) &&
                equals(profile, OktaUser::getAdCn, OktaUser::getWdCn) &&
                equals(profile, OktaUser::getAdCompanyId, OktaUser::getWdCompanyId) &&
                equals(profile, OktaUser::getAdCountry, OktaUser::getWdCountry) &&
                equals(profile, OktaUser::getAdDescription, OktaUser::getWdDescription) &&
                //equals(profile, OktaUser::getAdDisplayName, OktaUser::getWdDisplayName) &&
                equals(profile, OktaUser::getAdEmail, OktaUser::getWdEmail) &&
                equals(profile, OktaUser::getAdEmailPrimary, OktaUser::getWdEmailPrimary) &&
                equals(profile, OktaUser::getAdEmailSecondary, OktaUser::getWdEmailSecondary) &&
                equals(profile, OktaUser::getAdEmailSecondaryAdditional, OktaUser::getWdEmailSecondaryAdditional) &&
                equals(profile, OktaUser::getAdEmployee, OktaUser::getWdEmployee) &&
                equals(profile, OktaUser::getAdExecutiveDirector, OktaUser::getWdExecutiveDirector) &&
                equals(profile, OktaUser::getAdExecutiveDirectorHRBU, OktaUser::getWdExecutiveDirectorHRBU) &&
                equals(profile, OktaUser::getAdExecutiveDirectorUserId, OktaUser::getWdExecutiveDirectorUserId) &&
                equals(profile, OktaUser::getAdFax, OktaUser::getWdFax) &&
                equals(profile, OktaUser::getAdFirstName, OktaUser::getWdFirstName) &&
                equals(profile, OktaUser::getAdHRBU, OktaUser::getWdHRBU) &&
                equals(profile, OktaUser::getAdLastName, OktaUser::getWdLastName) &&
                equals(profile, OktaUser::getAdLeaveOfAbsence, OktaUser::getWdLeaveOfAbsence) &&
                equals(profile, OktaUser::getAdLegalName, OktaUser::getWdLegalName) &&
                equals(profile, OktaUser::getAdLegalPrefix, OktaUser::getWdLegalPrefix) &&
                equals(profile, OktaUser::getAdLegalSuffix, OktaUser::getWdLegalSuffix) &&
                equals(profile, OktaUser::getAdManagerHRBU, OktaUser::getWdManagerHRBU) &&
                equals(profile, OktaUser::getAdManagerId, OktaUser::getWdManagerId) &&
                equals(profile, OktaUser::getAdManagerUserId, OktaUser::getWdManagerUserId) &&
                equals(profile, OktaUser::getAdMiddleName, OktaUser::getWdMiddleName) &&
                equals(profile, OktaUser::getAdMobile, OktaUser::getWdMobile) &&
                equals(profile, OktaUser::getAdPhysicalDeliveryOfficeName, OktaUser::getWdPhysicalDeliveryOfficeName) &&
                equals(profile, OktaUser::getAdPostalAddress, OktaUser::getWdPostalAddress) &&
                equals(profile, OktaUser::getAdPostalCode, OktaUser::getWdPostalCode) &&
                equals(profile, OktaUser::getAdPreferredFirstName, OktaUser::getWdPreferredFirstName) &&
                equals(profile, OktaUser::getAdPreferredLastName, OktaUser::getWdPreferredLastName) &&
                equals(profile, OktaUser::getAdPreferredPrefix, OktaUser::getWdPreferredPrefix) &&
                equals(profile, OktaUser::getAdPreferredSuffix, OktaUser::getWdPreferredSuffix) &&
                equals(profile, OktaUser::getAdState, OktaUser::getWdState) &&
                equals(profile, OktaUser::getAdTelephoneNumber, OktaUser::getWdTelephoneNumber) &&
                equals(profile, OktaUser::getAdTerminated, OktaUser::getWdTerminated) &&
                equals(profile, OktaUser::getAdTitle, OktaUser::getWdTitle) &&
                //equals(profile, OktaUser::getAdUserId, OktaUser::getWdUserId) &&
                equals(profile, OktaUser::getAdUserPrincipalName, OktaUser::getWdUserPrincipalName) &&
                equals(profile, OktaUser::getAdWorkerId, OktaUser::getWdWorkerId) &&
                equals(profile, OktaUser::getAdWorkerType, OktaUser::getWdWorkerType) &&
                equals(profile, OktaUser::getAdWorkerTypeDescriptor, OktaUser::getWdWorkerTypeDescriptor);
    }

    private boolean equals(OktaUser profile, Function<OktaUser, Object> adGetter, Function<OktaUser, Object> wdGetter) {
        return Objects.equals(adGetter.apply(profile), wdGetter.apply(profile));
    }

    private String printDiff(OktaUser profile) {
        var sb = new StringBuilder();
        addDiff(sb, "Active", profile.getAdActive(), profile.getWdActive());
        addDiff(sb, "Address", profile.getAdAddress(), profile.getWdAddress());
        addDiff(sb, "City", profile.getAdCity(), profile.getWdCity());
        addDiff(sb, "Cn", profile.getAdCn(), profile.getWdCn());
        addDiff(sb, "CompanyId", profile.getAdCompanyId(), profile.getWdCompanyId());
        addDiff(sb, "Country", profile.getAdCountry(), profile.getWdCountry());
        addDiff(sb, "Description", profile.getAdDescription(), profile.getWdDescription());
        //addDiff(sb, "DisplayName", profile.getAdDisplayName(), profile.getWdDisplayName());
        addDiff(sb, "Email", profile.getAdEmail(), profile.getWdEmail());
        addDiff(sb, "EmailPrimary", profile.getAdEmailPrimary(), profile.getWdEmailPrimary());
        addDiff(sb, "EmailSecondary", profile.getAdEmailSecondary(), profile.getWdEmailSecondary());
        addDiff(sb, "EmailSecondaryAdditional", profile.getAdEmailSecondaryAdditional(), profile.getWdEmailSecondaryAdditional());
        addDiff(sb, "Employee", profile.getAdEmployee(), profile.getWdEmployee());
        addDiff(sb, "ExecutiveDirector", profile.getAdExecutiveDirector(), profile.getWdExecutiveDirector());
        addDiff(sb, "ExecutiveDirectorHRBU", profile.getAdExecutiveDirectorHRBU(), profile.getWdExecutiveDirectorHRBU());
        addDiff(sb, "ExecutiveDirectorUserId", profile.getAdExecutiveDirectorUserId(), profile.getWdExecutiveDirectorUserId());
        addDiff(sb, "Fax", profile.getAdFax(), profile.getWdFax());
        addDiff(sb, "FirstName", profile.getAdFirstName(), profile.getWdFirstName());
        addDiff(sb, "HRBU", profile.getAdHRBU(), profile.getWdHRBU());
        addDiff(sb, "LastName", profile.getAdLastName(), profile.getWdLastName());
        addDiff(sb, "LeaveOfAbsence", profile.getAdLeaveOfAbsence(), profile.getWdLeaveOfAbsence());
        addDiff(sb, "LegalName", profile.getAdLegalName(), profile.getWdLegalName());
        addDiff(sb, "LegalPrefix", profile.getAdLegalPrefix(), profile.getWdLegalPrefix());
        addDiff(sb, "LegalSuffix", profile.getAdLegalSuffix(), profile.getWdLegalSuffix());
        addDiff(sb, "ManagerHRBU", profile.getAdManagerHRBU(), profile.getWdManagerHRBU());
        addDiff(sb, "ManagerId", profile.getAdManagerId(), profile.getWdManagerId());
        addDiff(sb, "ManagerUserId", profile.getAdManagerUserId(), profile.getWdManagerUserId());
        addDiff(sb, "MiddleName", profile.getAdMiddleName(), profile.getWdMiddleName());
        addDiff(sb, "Mobile", profile.getAdMobile(), profile.getWdMobile());
        addDiff(sb, "PhysicalDeliveryOfficeName", profile.getAdPhysicalDeliveryOfficeName(), profile.getWdPhysicalDeliveryOfficeName());
        addDiff(sb, "PostalAddress", profile.getAdPostalAddress(), profile.getWdPostalAddress());
        addDiff(sb, "PostalCode", profile.getAdPostalCode(), profile.getWdPostalCode());
        addDiff(sb, "PreferredFirstName", profile.getAdPreferredFirstName(), profile.getWdPreferredFirstName());
        addDiff(sb, "PreferredLastName", profile.getAdPreferredLastName(), profile.getWdPreferredLastName());
        addDiff(sb, "PreferredPrefix", profile.getAdPreferredPrefix(), profile.getWdPreferredPrefix());
        addDiff(sb, "PreferredSuffix", profile.getAdPreferredSuffix(), profile.getWdPreferredSuffix());
        addDiff(sb, "State", profile.getAdState(), profile.getWdState());
        addDiff(sb, "TelephoneNumber", profile.getAdTelephoneNumber(), profile.getWdTelephoneNumber());
        addDiff(sb, "Terminated", profile.getAdTerminated(), profile.getWdTerminated());
        addDiff(sb, "Title", profile.getAdTitle(), profile.getWdTitle());
        //addDiff(sb, "UserId", profile.getAdUserId(), profile.getWdUserId());
        addDiff(sb, "UserPrincipalName", profile.getAdUserPrincipalName(), profile.getWdUserPrincipalName());
        addDiff(sb, "WorkerId", profile.getAdWorkerId(), profile.getWdWorkerId());
        addDiff(sb, "WorkerType", profile.getAdWorkerType(), profile.getWdWorkerType());
        addDiff(sb, "WorkerTypeDescriptor", profile.getAdWorkerTypeDescriptor(), profile.getWdWorkerTypeDescriptor());
        return sb.toString();
    }

    private void addDiff(StringBuilder sb, String field, Object adValue, Object wdValue) {
        if (!Objects.equals(adValue, wdValue)) {
            if (sb.length() > 0) sb.append("\n");
            sb.append(field).append(" ad: `").append(adValue).append("` wd: `").append(wdValue).append("`");
        }
    }
}
