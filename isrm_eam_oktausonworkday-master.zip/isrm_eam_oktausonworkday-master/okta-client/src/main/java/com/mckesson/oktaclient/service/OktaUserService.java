package com.mckesson.oktaclient.service;

import com.mckesson.common.model.CoreEvent;
import com.mckesson.common.rest.AbstractRestClient;
import com.mckesson.common.security.VeracodeUtils;
import com.mckesson.common.workday.converter.ConverterUtils;
import com.mckesson.oktaclient.OktaClientConfiguration;
import com.mckesson.oktaclient.dto.OktaGroupResponse;
import com.mckesson.oktaclient.dto.OktaUser;
import com.mckesson.oktaclient.dto.OktaUserRequest;
import com.mckesson.oktaclient.dto.OktaUserResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.*;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;
import java.util.function.Consumer;

/**
 * Implements Java client for REST OKTA User API
 *
 * @see <a href="https://developer.okta.com/docs/reference/api/users/">User API</a>
 */
@Service
@Slf4j
public class OktaUserService extends AbstractRestClient {

    private static final String TARGET_OWF = "owf";
    private final OktaClientConfiguration config;
    private final RetryTemplate retryTemplate;

    public OktaUserService(RestTemplateBuilder restTemplateBuilder,
                           OktaClientConfiguration config,
                           RetryTemplate retryTemplate) {
        super(config.getBaseUrl(), configure(restTemplateBuilder, config.getTimeout()));
        this.config = config;
        this.retryTemplate = retryTemplate;
    }

    /**
     * Lists users in your organization with pagination in most cases
     *
     * @param limit Specifies the number of results returned (maximum 200)
     * @return Array of User
     * @see <a href="https://developer.okta.com/docs/reference/api/users/#list-users">List Users</a>
     */
    public OktaUserResponse[] getAllOktaUsers(int limit) {
        final ResponseEntity<OktaUserResponse[]> response = processRequest("users?limit={limit}", HttpMethod.GET, null, createHeaders(), OktaUserResponse[].class,
                Map.of("limit", limit));
        if (response.getStatusCode() == HttpStatus.OK) {
            return response.getBody();
        } else if (response.getStatusCode() == HttpStatus.FORBIDDEN) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Cannot read Okta users");
        } else {
            throw new ResponseStatusException(response.getStatusCode(), response.getStatusCode().getReasonPhrase());
        }
    }

    /**
     * Fetches a specific user when you know the user's id
     *
     * @param userId  user's id
     * @param onError error handler
     * @return Fetched User
     * @see <a href="https://developer.okta.com/docs/reference/api/users/#get-user">Get User</a>
     */
    public OktaUser getOktaUser(final String userId, Consumer<Exception> onError) {
        String id = VeracodeUtils.encode4java(userId);
        log.debug("Reading user by id: {}", id);
        final ResponseEntity<OktaUserResponse> response = processRequestWithRetry(retryTemplate,
                () -> processRequest("users/{userId}", HttpMethod.GET, null, createHeaders(), OktaUserResponse.class,
                        Map.of("userId", VeracodeUtils.encode4url(userId))),
                onError);
        if (response.getStatusCode() == HttpStatus.OK) {
            final OktaUser oktaUser = Objects.requireNonNull(response.getBody()).getProfile();
            log.debug("User Read: {}", oktaUser);
            return oktaUser;
        } else if (response.getStatusCode() == HttpStatus.FORBIDDEN) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Cannot read Okta user with id=" + id);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Okta user is not found for id=" + id);
        }
    }

    /**
     * Sets target field of user and updates it.
     *
     * @param id         user's id
     * @param updateUser modified user object
     * @param ce         CoreEvent object
     * @param sendToOwf  send event about user modification to OKTA workflows
     * @param onError    error handler
     * @return updated Okta user
     */
    public OktaUser setTargetAndUpdateUser(final String id, final OktaUser updateUser, final CoreEvent ce, boolean sendToOwf, Consumer<Exception> onError) {
        if (sendToOwf) {
            updateUser.setEvtOwfTrigger(UUID.randomUUID().toString());
        }
        updateUser.setEvtTarget(TARGET_OWF);
        updateUser.resetFlowInfo(ce, false);
        return updateUser(VeracodeUtils.encode4java(id), updateUser, onError);
    }

    /**
     * Updates a user's profile and/or credentials using strict-update semantics. It makes a partial update.
     *
     * @param userId     ID of user to update
     * @param updateUser Updated profile for user
     * @param onError    error handler
     * @return Updated User
     * @see <a href="https://developer.okta.com/docs/reference/api/users/#update-user">Update user</a>
     */
    public OktaUser updateUser(String userId, final OktaUser updateUser, Consumer<Exception> onError) {
        String id = VeracodeUtils.encode4java(userId);
        log.debug("Updating Okta user by ID {}: {}", id, ConverterUtils.writeValueAsString(updateUser));
        final ResponseEntity<OktaUserResponse> response = processRequestWithRetry(retryTemplate,
                () -> processRequest("users/{userId}", HttpMethod.POST, new OktaUserRequest(updateUser), createHeaders(), OktaUserResponse.class,
                        Map.of("userId", VeracodeUtils.encode4url(userId))),
                onError);
        if (response.getStatusCode() == HttpStatus.OK) {
            final OktaUser oktaUser = Objects.requireNonNull(response.getBody()).getProfile();
            log.debug("Updated Okta user ID {}: {}", id, ConverterUtils.writeValueAsString(oktaUser));
            return oktaUser;
        } else if (response.getStatusCode() == HttpStatus.FORBIDDEN) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Cannot update Okta user with id=" + id);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Okta user is not found for id=" + id);
        }
    }

    /**
     * Find groups by query.
     *
     * @param query query
     * @return Found groups
     * @see <a href="https://developer.okta.com/docs/reference/api/groups/#find-groups">Find groups</a>
     */
    public List<OktaGroupResponse> findGroups(String query, Consumer<Exception> onError) {
        final ResponseEntity<OktaGroupResponse[]> response = processRequestWithRetry(retryTemplate,
                () -> processRequest("groups?q={query}", HttpMethod.GET, null, createHeaders(), OktaGroupResponse[].class,
                        Map.of("query", VeracodeUtils.encode4java(query))),
                onError);
        if (response.getStatusCode() == HttpStatus.OK) {
            return Arrays.asList(Objects.requireNonNull(response.getBody()));
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Groups are not found");
        }
    }

    /**
     * Get user groups
     *
     * @param userId userId
     * @return User groups
     * @see <a href="https://developer.okta.com/docs/reference/api/users/#get-user-s-groups">Get User's Groups</a>
     */
    public List<OktaGroupResponse> getUserGroups(String userId, Consumer<Exception> onError) {
        final ResponseEntity<OktaGroupResponse[]> response = processRequestWithRetry(retryTemplate,
                () -> processRequest("users/" + userId + "/groups", HttpMethod.GET, null, createHeaders(), OktaGroupResponse[].class),
                onError);
        if (response.getStatusCode() == HttpStatus.OK) {
            return Arrays.asList(Objects.requireNonNull(response.getBody()));
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Groups are not found");
        }
    }

    public Iterator<OktaUserResponse> getGroupUsers(String groupId) {
        return new PaginatedResponseIterator<>(getEndpointUrl("/groups/" + groupId + "/users"), OktaUserResponse[].class) {

            @Override
            protected ResponseEntity<OktaUserResponse[]> exchange(String url, Class<OktaUserResponse[]> responseType) {
                final ResponseEntity<OktaUserResponse[]> response = processRequestWithRetry(retryTemplate,
                        () -> OktaUserService.this.exchange(url, HttpMethod.GET, null, createHeaders(), OktaUserResponse[].class, Collections.emptyMap()),
                        (ex) -> log.error("Unexpected exception", ex));
                if (response.getStatusCode() == HttpStatus.OK) {
                    return response;
                } else {
                    throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Groups are not found");
                }
            }
        };
    }

    /**
     * Creates OKTA API request headers
     *
     * @return headers
     */
    private HttpHeaders createHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Authorization", "SSWS " + config.getToken());
        return headers;
    }
}
