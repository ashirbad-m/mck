package com.mckesson.oktaclient.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class PaginatedResponseIterator<T> implements Iterator<T> {

    private final Class<T[]> responseType;

    private Iterator<T> iterator;
    private String nextUrl;

    public PaginatedResponseIterator(String url, Class<T[]> responseType) {
        this.responseType = responseType;

        loadData(url);
    }

    protected abstract ResponseEntity<T[]> exchange(String url, Class<T[]> responseType);

    protected void loadData(String url) {
        final ResponseEntity<T[]> response = exchange(url, responseType);
        if (response.getStatusCode() == HttpStatus.OK) {
            iterator = Arrays.asList(Objects.requireNonNull(response.getBody())).iterator();
            nextUrl = null;
            List<String> linkHeaders = response.getHeaders().get("link");
            if (linkHeaders != null) {
                linkHeaders.stream().filter(value -> value.endsWith("; rel=\"next\""))
                        .findFirst()
                        .ifPresent(link -> nextUrl = getNextLink(link));
            }
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, response.getStatusCode().toString());
        }
    }

    private static String getNextLink(String link) {
        Pattern pattern = Pattern.compile("<(.+)>; rel=\"next\"");
        Matcher matcher = pattern.matcher(link);
        if (matcher.matches()) {
            return matcher.group(1);
        } else {
            return null;
        }
    }

    @Override
    public boolean hasNext() {
        boolean hasNext = iterator.hasNext();
        if (!hasNext && StringUtils.isNotBlank(nextUrl)) {
            loadData(nextUrl);
            return iterator.hasNext();
        } else {
            return hasNext;
        }
    }

    @Override
    public T next() {
        if (hasNext()) {
            return iterator.next();
        } else {
            return null;
        }
    }
}
