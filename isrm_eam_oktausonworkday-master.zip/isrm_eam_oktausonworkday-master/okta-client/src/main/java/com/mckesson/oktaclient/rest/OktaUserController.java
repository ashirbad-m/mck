package com.mckesson.oktaclient.rest;

import com.mckesson.common.security.VeracodeUtils;
import com.mckesson.oktaclient.dto.OktaUser;
import com.mckesson.oktaclient.service.OktaUserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.*;

import java.util.function.Consumer;

@RestController
@RequestMapping("user")
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(name = "rest.controller.enabled", havingValue = "true")
public class OktaUserController {
    private final OktaUserService service;

    private Consumer<Exception> onError = (ex) -> {
    };

    @GetMapping("{id}")
    public OktaUser getUser(@PathVariable String id) {
        id = VeracodeUtils.encode4java(id);
        log.debug("read okta user by id: {}", id);
        return service.getOktaUser(id, onError);
    }

    @PostMapping("{id}")
    public OktaUser updateUser(@PathVariable String id, @RequestBody final OktaUser oktaUser) {
        id = VeracodeUtils.encode4java(id);
        log.debug("update okta user: {}", oktaUser);
        return service.setTargetAndUpdateUser(id, oktaUser, null, true, onError);
    }
}
