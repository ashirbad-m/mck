package com.mckesson.mail;

import org.springframework.context.annotation.Configuration;

@Configuration
public class MailServiceConfiguration {
}
