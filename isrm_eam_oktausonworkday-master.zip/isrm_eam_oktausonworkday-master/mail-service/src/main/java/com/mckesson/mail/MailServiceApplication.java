package com.mckesson.mail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.mckesson.mail", "com.mckesson.common", "com.mckesson.common.workday.converter"})
public class MailServiceApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(MailServiceApplication.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(MailServiceApplication.class, args);
    }
}
