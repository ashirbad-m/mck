package com.mckesson.mail.rest;

import com.mckesson.common.model.EmailMessage;
import com.mckesson.mail.service.EmailSenderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * It allows sending of email from other services
 */
@RestController
@RequestMapping("/email")
@RequiredArgsConstructor
@Slf4j
public class EmailSenderController {

    private final EmailSenderService emailSenderService;

    @PostMapping("/send")
    public ResponseEntity<Object> send(@RequestBody EmailMessage message) {
        emailSenderService.send(message);
        return ResponseEntity.ok().build();
    }
}