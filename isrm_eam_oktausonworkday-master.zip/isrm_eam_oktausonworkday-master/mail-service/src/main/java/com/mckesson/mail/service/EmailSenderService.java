package com.mckesson.mail.service;

import com.mckesson.common.model.EmailMessage;
import com.mckesson.common.model.EmailMessageAttachment;
import com.mckesson.mail.config.EmailServerConfiguration;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.retry.RecoveryCallback;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;

/**
 * Implements email sending by Spring javamail
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class EmailSenderService {
    private static final String DEF_ENCODING = "UTF-8";

    private final EmailServerConfiguration emailServerConfiguration;
    private final JavaMailSender javaMailSender;
    private final RetryTemplate retryTemplate;

    public void send(EmailMessage message) {
        send(message, retryContext -> null);
    }

    public <T> void send(EmailMessage message, RecoveryCallback<T> recoveryCallback) {
        if (!emailServerConfiguration.isEnabled()) {
            log.debug("email-sender is not configured");
        } else {
            retryTemplate.execute(context -> {
                log.debug("Send email: retryCount {}", context.getRetryCount());

                try {
                    final String altAddress = StringUtils.trimToNull(emailServerConfiguration.getAltAddress());
                    javaMailSender.send(mimeMessage -> {
                        final MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, message.getAttachments() != null, DEF_ENCODING);
                        helper.setFrom(emailServerConfiguration.getFrom());
                        for (String to : message.getTo()) {
                            helper.addTo(to);
                        }
                        if (altAddress != null) {
                            for (String cc : altAddress.split(",")) {
                                helper.addCc(cc);
                            }
                        }
                        helper.setSubject(message.getSubject());
                        helper.setText(message.getBody(), true);
                        if (message.getAttachments() != null) {
                            for (EmailMessageAttachment attachment : message.getAttachments()) {
                                helper.addAttachment(attachment.getFilename(), new ByteArrayResource(attachment.getData()), attachment.getContentType());
                            }
                        }
                    });
                    log.debug("Email was sent: retryCount {}", context.getRetryCount());
                } catch (Exception ex) {
                    log.debug("Email sent error", ex);
                    throw ex;
                }
                return null;
            }, context -> {
                log.warn("Cannot send message after {} attempts", context.getRetryCount());
                return recoveryCallback.recover(context);
            });
        }
    }
}
