package com.mckesson.mail.service;

import com.mckesson.common.model.EmailMessage;
import com.mckesson.common.model.EmailMessageAttachment;
import com.mckesson.mail.config.EmailServerConfiguration;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.retry.support.RetryTemplate;

import javax.mail.Message;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Set;

class EmailSenderServiceTest {

    @Test
    void send() throws Exception {
        var emailServerConfiguration = new EmailServerConfiguration();
        var javaMailSender = Mockito.mock(JavaMailSender.class);
        var retryTemplate = new RetryTemplate();

        var instance = new EmailSenderService(emailServerConfiguration, javaMailSender, retryTemplate);

        var message = Mockito.mock(EmailMessage.class);
        instance.send(message);
        Mockito.verifyNoInteractions(javaMailSender);

        emailServerConfiguration.setEnabled(true);
        emailServerConfiguration.setFrom("from@mail.test");

        emailServerConfiguration.setAltAddress("");
        var mimeMessage = Mockito.mock(MimeMessage.class);
        javaMailSender = new JavaMailSender() {

            @Override
            public void send(SimpleMailMessage simpleMessage) throws MailException {
                throw new UnsupportedOperationException();
            }

            @Override
            public void send(SimpleMailMessage... simpleMessages) throws MailException {
                throw new UnsupportedOperationException();
            }

            @Override
            public MimeMessage createMimeMessage() {
                throw new UnsupportedOperationException();
            }

            @Override
            public MimeMessage createMimeMessage(InputStream contentStream) throws MailException {
                throw new UnsupportedOperationException();
            }

            @Override
            public void send(MimeMessage mimeMessage) throws MailException {
                throw new UnsupportedOperationException();
            }

            @Override
            public void send(MimeMessage... mimeMessages) throws MailException {
                throw new UnsupportedOperationException();
            }

            @Override
            public void send(MimeMessagePreparator mimeMessagePreparator) throws MailException {
                try {
                    mimeMessagePreparator.prepare(mimeMessage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            @Override
            public void send(MimeMessagePreparator... mimeMessagePreparators) throws MailException {
                throw new UnsupportedOperationException();
            }
        };
        message = EmailMessage.builder()
                .to(Set.of("to1@mail.test", "to2@mail.test"))
                .subject("Subject")
                .body("Body")
                .build();
        instance = new EmailSenderService(emailServerConfiguration, javaMailSender, retryTemplate);
        instance.send(message);
        Mockito.verify(mimeMessage, Mockito.atLeast(1)).setFrom(InternetAddress.parse(emailServerConfiguration.getFrom())[0]);
        for (String to : message.getTo()) {
            Mockito.verify(mimeMessage, Mockito.atLeast(1)).addRecipient(Message.RecipientType.TO, InternetAddress.parse(to)[0]);
        }

        Mockito.verify(mimeMessage, Mockito.never()).addRecipient(Mockito.eq(Message.RecipientType.CC), Mockito.any());
        Mockito.verify(mimeMessage, Mockito.atLeast(1)).setSubject(message.getSubject(), "UTF-8");
        Mockito.verify(mimeMessage, Mockito.atLeast(1)).setContent(message.getBody(), "text/html;charset=UTF-8");


        Mockito.reset(mimeMessage);
        var attachment = new EmailMessageAttachment("text.txt", "text/plain", "".getBytes());
        message.setAttachments(Arrays.asList(attachment));
        emailServerConfiguration.setAltAddress("alt1@mail.test,alt2@mail.test");
        instance = new EmailSenderService(emailServerConfiguration, javaMailSender, retryTemplate);
        instance.send(message);
        Mockito.verify(mimeMessage, Mockito.atLeast(1)).setFrom(InternetAddress.parse(emailServerConfiguration.getFrom())[0]);
        for (String to : message.getTo()) {
            Mockito.verify(mimeMessage, Mockito.atLeast(1)).addRecipient(Message.RecipientType.TO, InternetAddress.parse(to)[0]);
        }

        for (String cc : emailServerConfiguration.getAltAddress().split(",")) {
            Mockito.verify(mimeMessage, Mockito.atLeast(1)).addRecipient(Message.RecipientType.CC, InternetAddress.parse(cc)[0]);
        }
        Mockito.verify(mimeMessage, Mockito.atLeast(1)).setSubject(message.getSubject(), "UTF-8");
        //Mockito.verify(mimeMessage, Mockito.atLeast(1)).setText(message.getBody());

        javaMailSender =  Mockito.mock(JavaMailSender.class);
        Mockito.doThrow(new RuntimeException()).when(javaMailSender).send(Mockito.any(MimeMessagePreparator.class));
        instance = new EmailSenderService(emailServerConfiguration, javaMailSender, retryTemplate);
        instance.send(message);
    }
}