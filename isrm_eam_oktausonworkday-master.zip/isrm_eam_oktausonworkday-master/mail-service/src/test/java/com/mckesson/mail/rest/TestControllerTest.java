package com.mckesson.mail.rest;

import com.mckesson.common.config.OAuth2ResourceConfiguration;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Map;

@Disabled
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = {"spring.profiles.active=local"})
class TestControllerTest {

    @Value("${security.oauth2.base-url}/v1/token")
    private String accessTokenUri;
    @Value("${security.oauth2.client.client-id}")
    private String clientId;
    @Value("${security.oauth2.client.client-secret}")
    private String clientSecret;
    @Autowired
    private OAuth2ResourceConfiguration oauth2ResourceConfiguration;
    @LocalServerPort
    private int localServerPort;
    @Value("${server.servlet.context-path}")
    private String contextPath;

    private final TestRestTemplate testRestTemplate = new TestRestTemplate();
    private final RestTemplate restTemplate = new RestTemplate();

    private String getOauth2Token(String scope) {
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setBasicAuth(clientId, clientSecret);
        requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("grant_type", "client_credentials");
        params.add("scope", scope);

        HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(params, requestHeaders);

        Map<String, Object> body = restTemplate.exchange(accessTokenUri, HttpMethod.POST, httpEntity, Map.class).getBody();
        if (body != null) {
            return body.get("access_token").toString();
        } else {
            return "";
        }
    }

    private String getOauth2Token() {
        return getOauth2Token(oauth2ResourceConfiguration.getScope());
    }

    @Test
    public void testActuator() {
        ResponseEntity<String> result = testRestTemplate.exchange(String.format("http://localhost:%d%s/actuator", localServerPort, contextPath), HttpMethod.GET, new HttpEntity<>(null), String.class);
        Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
        Assertions.assertNotNull(result.getBody());
        Assertions.assertFalse(result.getBody().isBlank());
    }

    //@Deprecated
    @Test
    public void testOauth2Post() {
        URI url = URI.create(String.format("http://localhost:%d%s/test/status", localServerPort, contextPath));
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<Object> httpEntity = new HttpEntity<>(null, requestHeaders);
        ResponseEntity<String> result = testRestTemplate.exchange(url, HttpMethod.POST, httpEntity, String.class);
        Assertions.assertEquals(HttpStatus.UNAUTHORIZED, result.getStatusCode());

        requestHeaders.setBearerAuth(getOauth2Token("power-shell-connector"));

        httpEntity = new HttpEntity<>(null, requestHeaders);
        result = testRestTemplate.exchange(url, HttpMethod.POST, httpEntity, String.class);
        Assertions.assertEquals(HttpStatus.FORBIDDEN, result.getStatusCode());

        requestHeaders.setBearerAuth(getOauth2Token());
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("var1", "1");
        params.add("var2", 2);
        httpEntity = new HttpEntity<>(params, requestHeaders);
        result = testRestTemplate.exchange(url, HttpMethod.POST, httpEntity, String.class);
        Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
    }
}