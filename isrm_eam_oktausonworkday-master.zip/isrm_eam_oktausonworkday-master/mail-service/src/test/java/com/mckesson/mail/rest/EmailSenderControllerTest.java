package com.mckesson.mail.rest;

import com.mckesson.common.model.EmailMessage;
import com.mckesson.mail.service.EmailSenderService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class EmailSenderControllerTest {

    @Test
    void send() {
        var emailSenderService = Mockito.mock(EmailSenderService.class);
        var message = Mockito.mock(EmailMessage.class);

        EmailSenderController instance = new EmailSenderController(emailSenderService);
        instance.send(message);
        Mockito.verify(emailSenderService).send(Mockito.eq(message));
    }
}