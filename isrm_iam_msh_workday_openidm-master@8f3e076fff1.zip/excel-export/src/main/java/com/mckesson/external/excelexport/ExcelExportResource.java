package com.mckesson.external.excelexport;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.ConfigurationPolicy;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.SpreadsheetVersion;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.util.CellRangeAddress;
import org.forgerock.json.fluent.JsonValue;
import org.forgerock.json.resource.JsonResource;
import org.forgerock.openidm.config.JSONEnhancedConfig;
import org.forgerock.openidm.objset.BadRequestException;
import org.forgerock.openidm.objset.ObjectSetException;
import org.forgerock.openidm.objset.ObjectSetJsonResource;
import org.osgi.framework.BundleContext;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceReference;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.mail.util.MailSSLSocketFactory;

/**
 * Hello world!
 * 
 */

@Component(name = ExcelExportResource.PID, immediate = false, policy = ConfigurationPolicy.IGNORE)
@Service
@Properties({
		@Property(name = "service.description", value = ExcelExportResource.SERVICE_TITLE),
		@Property(name = "service.vendor", value = "Exadel Inc."),
		@Property(name = "openidm.router.prefix", value = ExcelExportResource.OPENIDM_ROUTER_PREFIX) })
public class ExcelExportResource extends ObjectSetJsonResource {

	private final static Logger logger = LoggerFactory.getLogger(ExcelExportResource.class);

	public static final String PID = "com.mckesson.ExcelExportResource";
	public static final String SERVICE_TITLE = "Excel Export Service";
	public static final String OPENIDM_ROUTER_PREFIX = "external/excelExport";

	private volatile Session session;
	
	@Reference(target = "(component.name=org.forgerock.openidm.external.email)")
	public JsonResource emailService;
	
	private static final Session getSession(JsonValue config) {
		String host;
		String port;
		java.util.Properties props = new java.util.Properties();
        if (config.get("host").asString() != null) {
            host = config.get("host").asString();
            props.put("mail.smtp.host", host);
        }
        if (config.get("port").asString() != null) {
            port = config.get("port").asString();
            props.put("mail.smtp.port", port);
        }

        if (config.get("mail.smtp.starttls.enable").asString().equalsIgnoreCase("true")) {
            props.put("mail.smtp.starttls.enable", "true");

            // temporary hack to avoid cert check
            try {
                MailSSLSocketFactory sf = new MailSSLSocketFactory();
                sf.setTrustAllHosts(true);
                props.put("mail.smtp.ssl.socketFactory", sf);
            } catch (Exception e) {
            }
        }

        return Session.getInstance(props);
	}
	
	private final String toCellValue(Object o) {
		if (o == null) {
			return "";
		}

		String s = String.valueOf(o);
		if (s.length() > SpreadsheetVersion.EXCEL97.getMaxTextLength()) {
			s = s.substring(0, SpreadsheetVersion.EXCEL97.getMaxTextLength());
		}
		
		return s;
	}

	private final byte[] exportData(List<String> columnsList, List<Map<String, Object>> rows) throws IOException {
		String[] columns = columnsList.toArray(new String[0]);
		ByteArrayOutputStream result = new ByteArrayOutputStream();

		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet worksheet = workbook.createSheet("Report");

		HSSFRow headerRow = worksheet.createRow(0);
		for (int i = 0; i < columns.length; i++) {
			HSSFCell headerCell = headerRow.createCell(i);
			headerCell.setCellValue(toCellValue(columns[i]));
		}

		for (int i = 0; i < rows.size(); i++) {
			Map<String, Object> row = rows.get(i);
			HSSFRow dataRow = worksheet.createRow(i + 1);
			for (int j = 0; j < columns.length; j++) {
				HSSFCell cell = dataRow.createCell(j);
				cell.setCellType(Cell.CELL_TYPE_STRING);
				cell.setCellValue(toCellValue(row.get(columns[j])));
			}
		}

		worksheet.setAutoFilter(new CellRangeAddress(0, rows.size(), 0, columns.length - 1));
		worksheet.createFreezePane(0, 1, 0, 1);

		workbook.write(result);

		result.flush();
		return result.toByteArray();
	}

	private final MimeBodyPart zipAttachment(String fileName, byte[] data) throws IOException, MessagingException {
		ByteArrayOutputStream compressed = new ByteArrayOutputStream();
		ZipOutputStream zos = new ZipOutputStream(compressed);
		ZipEntry entry = new ZipEntry(fileName + ".xls");
		zos.putNextEntry(entry);
		zos.write(data);
		zos.closeEntry();
		zos.close();

		MimeBodyPart messageBodyPart = new MimeBodyPart();
		DataSource source = new ByteArrayDataSource(compressed.toByteArray(), "application/zip");
		messageBodyPart.setDataHandler(new DataHandler(source));
		messageBodyPart.setFileName(fileName + ".zip");

		return messageBodyPart;
	}

	@Override
	public Map<String, Object> action(String fullId, Map<String, Object> params) throws ObjectSetException {
		Map<String, Object> result = new HashMap<String, Object>();

		String to = (String) params.get("to");
		String from = (String) params.get("from");
		String baseFileName = (String) params.get("baseFileName");
		List<String> columns = (List<String>) params.get("columns");
		List<Map<String, Object>> data = (List<Map<String, Object>>) params.get("data");

		try {
			byte[] excelBytes = exportData(columns, data);
			String fileName = baseFileName + "-" + new SimpleDateFormat("yyyyMMdd").format(new Date());
			MimeBodyPart attachment = zipAttachment(fileName, excelBytes);
			send(from, to, fileName, attachment);
		} catch (IOException e) {
			throw new ObjectSetException(e.getMessage(), e);
		} catch (AddressException e) {
			throw new ObjectSetException(e.getMessage(), e);
		} catch (MessagingException e) {
			throw new ObjectSetException(e.getMessage(), e);
		}
		
		result.put("status", "OK");
		return result;
	}

    protected void send(String fromStr, String toStr, String subjectStr, MimeBodyPart body) throws BadRequestException, AddressException {
        // _from : the From: address
        // _to : The To: recipients - a comma separated email address strings 
        // _cc: The Cc: recipients - a comma separated email address strings 
        // _bcc: The Bcc: recipients - a comma separated email address strings 
        // _subject: The subject
        // _body : the message body

    	InternetAddress from = new InternetAddress(fromStr);
    	InternetAddress[] to = InternetAddress.parse(toStr);

        try {
			Message message = new MimeMessage(session);
            message.setFrom(from);
            message.setRecipients(Message.RecipientType.TO, to);
            message.setSubject(subjectStr);

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(body);
            message.setContent(multipart);
            
            Transport transport = session.getTransport("smtp");

            transport.connect();

            message.saveChanges();
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();

        } catch (MessagingException e) {
            throw new BadRequestException(e);
        }
    }	

    
    @Activate
    public void activate(ComponentContext compContext) {
    	BundleContext bundleContext = compContext.getBundleContext();
    	
		try {
			ServiceReference<?> sr = bundleContext.getServiceReferences(JsonResource.class.getName(), "(component.name=org.forgerock.openidm.external.email)")[0];
	    	Dictionary<String, Object> props = new Hashtable<String, Object>();
	    	for (String propKey: sr.getPropertyKeys()) {
	    		props.put(propKey, sr.getProperty(propKey));
	    	}
	    	
	    	JsonValue config = JSONEnhancedConfig.newInstance().getConfiguration(props, bundleContext, "org.forgerock.openidm.external.email");
	    	session = getSession(config);
		} catch (InvalidSyntaxException e) {
			throw new IllegalStateException(e.getMessage(), e);
		}
    	
    }

    public @Deactivate
    void deactivate(ComponentContext compContext) {
    	session = null;
    }

}
