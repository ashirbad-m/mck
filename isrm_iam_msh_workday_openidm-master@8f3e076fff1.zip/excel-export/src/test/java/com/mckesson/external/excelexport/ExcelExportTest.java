package com.mckesson.external.excelexport;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.util.CellRangeAddress;
import org.junit.Test;


public class ExcelExportTest {

	@Test
	public void testExcelGeneration() throws IOException {
		ByteArrayOutputStream result = new ByteArrayOutputStream();

		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet worksheet = workbook.createSheet("Report");

		HSSFRow headerRow = worksheet.createRow(0);
		HSSFCell headerCell = headerRow.createCell(0);
		headerCell.setCellValue("Test");
		
		HSSFRow dataRow = worksheet.createRow(1);
		HSSFCell cell = dataRow.createCell(0);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		cell.setCellValue("Te \\r st");

		worksheet.setAutoFilter(new CellRangeAddress(0, 1, 0, 0));
		worksheet.createFreezePane(0, 1, 0, 1);

		workbook.write(result);

		result.flush();
		
		byte[] excelBytes = result.toByteArray();
		System.out.println(new String(excelBytes, 0, 10));
		FileOutputStream fos = new FileOutputStream("test.xlsx");
		fos.write(excelBytes);
		fos.close();
	}

}
