
ALTER TABLE `msh_idm_repo`.`uson_user_attributes` ADD `accountExpiredNotificationTimestamp` VARCHAR(19) DEFAULT NULL AFTER `companyId`;
ALTER TABLE `msh_idm_repo`.`uson_user_attributes_staging` ADD `accountExpiredNotificationTimestamp` VARCHAR(19) DEFAULT NULL AFTER `companyId`;

ALTER TABLE `msh_idm_repo`.`manageduser_future` 
CHANGE COLUMN `address` `address` VARCHAR(255) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' DEFAULT NULL,
CHANGE COLUMN `postalAddress` `postalAddress` VARCHAR(255) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' DEFAULT NULL;

ALTER TABLE `msh_idm_repo`.`manageduser` 
CHANGE COLUMN `address` `address` VARCHAR(255) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' DEFAULT NULL,
CHANGE COLUMN `postalAddress` `postalAddress` VARCHAR(255) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' DEFAULT NULL;

ALTER TABLE `msh_idm_repo`.`manageduser_correlated` 
CHANGE COLUMN `address` `address` VARCHAR(255) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' DEFAULT NULL,
CHANGE COLUMN `postalAddress` `postalAddress` VARCHAR(255) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' DEFAULT NULL;

ALTER TABLE `msh_idm_repo`.`hrbu` ADD `contingentworkertype_outside_worker_groups` text DEFAULT NULL AFTER `groups`;
ALTER TABLE `msh_idm_repo`.`hrbu` ADD `contingentworkertype_x_groups` text DEFAULT NULL AFTER `contingentworkertype_outside_worker_groups`;

ALTER TABLE `msh_idm_repo`.`hrbu_city_street` ADD `contingentworkertype_outside_worker_groups` text DEFAULT NULL AFTER `groups`;
ALTER TABLE `msh_idm_repo`.`hrbu_city_street` ADD `contingentworkertype_x_groups` text DEFAULT NULL AFTER `contingentworkertype_outside_worker_groups`;

ALTER TABLE `msh_idm_repo`.`manageduser` ADD `workerTypeDescriptor` varchar(255) DEFAULT NULL;
ALTER TABLE `msh_idm_repo`.`manageduser_correlated` ADD `workerTypeDescriptor` varchar(255) DEFAULT NULL;
ALTER TABLE `msh_idm_repo`.`manageduser_future` ADD `workerTypeDescriptor` varchar(255) DEFAULT NULL;
ALTER TABLE `msh_idm_repo`.`uson_user_attributes` ADD `workerTypeDescriptor` varchar(255) DEFAULT NULL;
ALTER TABLE `msh_idm_repo`.`uson_user_attributes_staging` ADD `workerTypeDescriptor` varchar(255) DEFAULT NULL;

USE `msh_idm_repo`;
DROP procedure IF EXISTS `correlate_users`;

DELIMITER $$
USE `msh_idm_repo`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `correlate_users`()
    DETERMINISTIC
    SQL SECURITY INVOKER
BEGIN
  DECLARE `objectid` varchar(38);
  DECLARE `rev` varchar(38);
  DECLARE `uid` varchar(38);
  DECLARE `country` varchar(255);
  DECLARE `middleName` varchar(255);
  DECLARE `postalCode` varchar(255);
  DECLARE `addressLastModified` varchar(255);
  DECLARE `employee` varchar(255);
  DECLARE `email` varchar(255);
  DECLARE `address` varchar(255);
  DECLARE `postalAddress` varchar(255);
  DECLARE `legalName` varchar(255);
  DECLARE `workerType` varchar(255);
  DECLARE `userID` varchar(255);
  DECLARE `city` varchar(255);
  DECLARE `state` varchar(255);
  DECLARE `workerID` varchar(255);
  DECLARE `managerID` varchar(255);
  DECLARE `firstName` varchar(255);
  DECLARE `hrbu` varchar(255);
  DECLARE `title` varchar(255);
  DECLARE `lastName` varchar(255);
  DECLARE `active` varchar(255);
  DECLARE `fax` varchar(255);
  DECLARE `mobile` varchar(255);
  DECLARE `telephoneNumber` varchar(255);
  DECLARE `trm` varchar(255);
  DECLARE `dateActivated` varchar(255);
  DECLARE `positionEffectiveDate` varchar(255);
  DECLARE `legalPrefix` varchar(255);
  DECLARE `legalSuffix` varchar(255);
  DECLARE `preferredFirstName` varchar(255);
  DECLARE `preferredLastName` varchar(255);
  DECLARE `preferredPrefix` varchar(255);
  DECLARE `preferredSuffix` varchar(255);
  DECLARE `hrPartner` varchar(255);
  DECLARE `hireDate` varchar(255);
  DECLARE `leaveOfAbsence` varchar(5);
  DECLARE `executiveDirector` varchar(255);
  DECLARE `jobFamily` varchar(255);
  DECLARE `ssn` varchar(255);
  DECLARE `homePostalCode` varchar(255);
  DECLARE `companyId` varchar(38);
  DECLARE `workerTypeDescriptor` varchar(255);
  DECLARE `futureUser` varchar(255);
  
  DECLARE done INT DEFAULT FALSE;
  DECLARE currentWorkerID VARCHAR(255) DEFAULT "";
  
  DECLARE users CURSOR FOR 
  
  SELECT * FROM(
  SELECT mu.*, 'false' AS futureUser FROM manageduser mu
  UNION ALL
  SELECT muf.*, 'true' AS futureUser FROM manageduser_future muf WHERE muf.trm = "false" and muf.hireDate is not null 
      AND EXISTS(SELECT 1 FROM manageduser LIMIT 1) 
      AND muf.workerID not in (SELECT distinct u.workerID FROM manageduser u WHERE u.trm = "false") 
  ) AS result ORDER BY result.workerID, result.trm ASC, result.futureUser ASC, result.positionEffectiveDate DESC;
  
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  
  START TRANSACTION;
  delete from manageduser_correlated; 
  OPEN users;
  
  process_loop: LOOP
  FETCH users into objectid,rev,uid,country,middleName,postalCode,addressLastModified,employee,email,address,postalAddress,legalName,workerType,userID,city,state,workerID,managerID,firstName,hrbu,title,lastName,active,fax,mobile,telephoneNumber,trm,dateActivated,positionEffectiveDate,legalPrefix,legalSuffix,preferredFirstName,preferredLastName,preferredPrefix,preferredSuffix,hrPartner,hireDate,leaveOfAbsence,executiveDirector,jobFamily,ssn,homePostalCode,companyId,workerTypeDescriptor,futureUser;  


  IF done THEN
  LEAVE process_loop;
  END IF;
  
  IF IFNULL(currentWorkerID, '') <> IFNULL(workerID, '') THEN
      SET currentWorkerID := workerID;
  
      IF futureUser = "true" THEN
          SET active := "false";
          SET leaveOfAbsence := "false";
      END IF;
  
      INSERT INTO manageduser_correlated VALUES(objectid,rev,uid,country,middleName,postalCode,addressLastModified,employee,email,address,postalAddress,legalName,workerType,userID,city,state,workerID,managerID,firstName,hrbu,title,lastName,active,fax,mobile,telephoneNumber,trm,dateActivated,positionEffectiveDate,legalPrefix,legalSuffix,preferredFirstName,preferredLastName,preferredPrefix,preferredSuffix,hrPartner,futureUser,leaveOfAbsence,executiveDirector,jobFamily,ssn,homePostalCode,companyId,workerTypeDescriptor);
  END IF;
  
  END LOOP;
  CLOSE users;
  COMMIT;
  SELECT true AS result;
  
  END$$

DELIMITER ;

 
use msh_idm_repo;


/*!50001 DROP TABLE IF EXISTS `hrbu_view`*/;
/*!50001 DROP VIEW IF EXISTS `hrbu_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hrbu_view` AS select `h`.`hrbu` AS `hrbu`,`hcs`.`city` AS `city`,`hcs`.`street` AS `street`,(case when `h`.`city` then `hcs`.`ou` else `h`.`ou` end) AS `ou`,(case when `h`.`city` then `hcs`.`home_drive` else `h`.`home_drive` end) AS `home_drive`,(case when `h`.`city` then `hcs`.`home_dir` else `h`.`home_dir` end) AS `home_dir`,(case when `h`.`city` then `hcs`.`login_script` else `h`.`login_script` end) AS `login_script`,(case when `h`.`city` then `hcs`.`groups` else `h`.`groups` end) AS `groups`,(case when `h`.`city` then `hcs`.`contingentworkertype_outside_worker_groups` else `h`.`contingentworkertype_outside_worker_groups` end) AS `contingentworkertype_outside_worker_groups`,(case when `h`.`city` then `hcs`.`contingentworkertype_x_groups` else `h`.`contingentworkertype_x_groups` end) AS `contingentworkertype_x_groups`,(case when `h`.`city` then `hcs`.`active_sync` else `h`.`active_sync` end) AS `active_sync`,(case when (`h`.`city` and isnull(`hcs`.`city`)) then 'true' else 'false' end) AS `notify_manager`,`h`.`mail_suffix` AS `mail_suffix`,`h`.`secondary_mail_suffix` AS `secondary_mail_suffix`, (case when `h`.`city` then `hcs`.`itc_mail` else `h`.`itc_mail` end) AS `itc_mail`  from (`hrbu` `h` left join `hrbu_city_street` `hcs` on((`h`.`city` = 1))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;


/*!50001 DROP TABLE IF EXISTS `sync_report`*/;
/*!50001 DROP VIEW IF EXISTS `sync_report`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `sync_report` AS select `aar`.`id` AS `id`,`aar`.`objectid` AS `objectid`,`aar`.`eventdate` AS `eventdate`,`aar`.`reconid` AS `reconid`,`aar`.`mapping` AS `mapping`,`aar`.`sourceid` AS `sourceid`,`aar`.`action` AS `action`,`aar`.`situation` AS `situation`,`aar`.`status` AS `status`,replace(replace(replace(`aar`.`message`,'\\\\','\\'),'\\n','\n'),'\\r','\r') AS `message`,replace(replace(replace(`aar`.`target`,'\\\\','\\'),'\\n','\n'),'\\r','\r') AS `target`,`mu`.`rev` AS `rev`,`mu`.`uid` AS `uid`,`mu`.`country` AS `country`,`mu`.`middleName` AS `middleName`,`mu`.`postalCode` AS `postalCode`,`mu`.`addressLastModified` AS `addressLastModified`,`mu`.`employee` AS `employee`,`mu`.`email` AS `email`,replace(replace(`mu`.`address`,'\\n','\n'),'\\r','\r') AS `address`,replace(replace(`mu`.`postalAddress`,'\\n','\n'),'\\r','\r') AS `postalAddress`,`mu`.`workerType` AS `workerType`,`mu`.`userID` AS `userID`,`mu`.`city` AS `city`,`mu`.`state` AS `state`,`mu`.`workerID` AS `workerID`,`mu`.`managerID` AS `managerID`,`mu`.`hrbu` AS `hrbu`,`mu`.`title` AS `title`,`mu`.`legalPrefix` AS `legalPrefix`,`mu`.`firstName` AS `firstName`,`mu`.`lastName` AS `lastName`,`mu`.`legalSuffix` AS `legalSuffix`,`mu`.`legalName` AS `legalName`,`mu`.`preferredPrefix` AS `preferredPrefix`,`mu`.`preferredFirstName` AS `preferredFirstName`,`mu`.`preferredLastName` AS `preferredLastName`,`mu`.`preferredSuffix` AS `preferredSuffix`,`mu`.`active` AS `active`,`mu`.`fax` AS `fax`,`mu`.`mobile` AS `mobile`,`mu`.`telephoneNumber` AS `telephoneNumber`,`mu`.`trm` AS `trm`,`mu`.`hrPartner` AS `hrPartner`,`mu`.`leaveOfAbsence` AS `leaveOfAbsence`,`mu`.`executiveDirector` AS `executiveDirector`,`mu`.`companyId` AS `companyId`,`mu`.`workerTypeDescriptor` AS `workerTypeDescriptor`,`mu`.`futureUser` AS `futureUser` from (`msh_idm_repo`.`audit_async_recon` `aar` left join `msh_idm_repo`.`manageduser_correlated` `mu` on((`aar`.`sourceid` = `mu`.`objectid`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;


DROP TABLE IF EXISTS `msh_idm_repo`.`schemaversion`;
CREATE TABLE `msh_idm_repo`.`schemaversion` (
  `version` varchar(255) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

UPDATE `msh_idm_repo`.`schemaversion` SET `version`="20160805";

ALTER TABLE `msh_idm_audit`.`auditrecon` 
ADD COLUMN `mapping` TEXT NULL DEFAULT NULL AFTER `message`;

/*!50001 DROP TABLE IF EXISTS `msh_idm_repo`.`auditrecon`*/;
/*!50001 DROP VIEW IF EXISTS `msh_idm_repo`.`auditrecon`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY INVOKER */
/*!50001 VIEW `msh_idm_repo`.`auditrecon` AS select `msh_idm_audit`.`auditrecon`.`objectid` AS `objectid`,`msh_idm_audit`.`auditrecon`.`entrytype` AS `entrytype`,`msh_idm_audit`.`auditrecon`.`rootactionid` AS `rootactionid`,`msh_idm_audit`.`auditrecon`.`reconid` AS `reconid`,`msh_idm_audit`.`auditrecon`.`reconciling` AS `reconciling`,`msh_idm_audit`.`auditrecon`.`sourceobjectid` AS `sourceobjectid`,`msh_idm_audit`.`auditrecon`.`targetobjectid` AS `targetobjectid`,`msh_idm_audit`.`auditrecon`.`ambiguoustargetobjectids` AS `ambiguoustargetobjectids`,`msh_idm_audit`.`auditrecon`.`activitydate` AS `activitydate`,`msh_idm_audit`.`auditrecon`.`situation` AS `situation`,`msh_idm_audit`.`auditrecon`.`activity` AS `activity`,`msh_idm_audit`.`auditrecon`.`status` AS `status`,`msh_idm_audit`.`auditrecon`.`message` AS `message`,`msh_idm_audit`.`auditrecon`.`mapping` AS `mapping` from `msh_idm_audit`.`auditrecon` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
 
UPDATE `msh_idm_repo`.`schemaversion` SET `version`="20160830";

ALTER TABLE `msh_idm_repo`.`hrbu` ADD `contractor_groups` text DEFAULT NULL AFTER `groups`;
ALTER TABLE `msh_idm_repo`.`hrbu_city_street` ADD `contractor_groups` text DEFAULT NULL AFTER `groups`;

/*!50001 DROP TABLE IF EXISTS `hrbu_view`*/;
/*!50001 DROP VIEW IF EXISTS `hrbu_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hrbu_view` AS select `h`.`hrbu` AS `hrbu`,`hcs`.`city` AS `city`,`hcs`.`street` AS `street`,(case when `h`.`city` then `hcs`.`ou` else `h`.`ou` end) AS `ou`,(case when `h`.`city` then `hcs`.`home_drive` else `h`.`home_drive` end) AS `home_drive`,(case when `h`.`city` then `hcs`.`home_dir` else `h`.`home_dir` end) AS `home_dir`,(case when `h`.`city` then `hcs`.`login_script` else `h`.`login_script` end) AS `login_script`,(case when `h`.`city` then `hcs`.`groups` else `h`.`groups` end) AS `groups`,(case when `h`.`city` then `hcs`.`contractor_groups` else `h`.`contractor_groups` end) AS `contractor_groups`,(case when `h`.`city` then `hcs`.`contingentworkertype_outside_worker_groups` else `h`.`contingentworkertype_outside_worker_groups` end) AS `contingentworkertype_outside_worker_groups`,(case when `h`.`city` then `hcs`.`contingentworkertype_x_groups` else `h`.`contingentworkertype_x_groups` end) AS `contingentworkertype_x_groups`,(case when `h`.`city` then `hcs`.`active_sync` else `h`.`active_sync` end) AS `active_sync`,(case when (`h`.`city` and isnull(`hcs`.`city`)) then 'true' else 'false' end) AS `notify_manager`,`h`.`mail_suffix` AS `mail_suffix`,`h`.`secondary_mail_suffix` AS `secondary_mail_suffix`, (case when `h`.`city` then `hcs`.`itc_mail` else `h`.`itc_mail` end) AS `itc_mail`,`h`.`enabled` as `enabled`,`h`.`manager_lookup_strategy` as `manager_lookup_strategy`  from (`hrbu` `h` left join `hrbu_city_street` `hcs` on((`h`.`city` = 1))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

UPDATE `msh_idm_repo`.`schemaversion` SET `version`="20170104";
