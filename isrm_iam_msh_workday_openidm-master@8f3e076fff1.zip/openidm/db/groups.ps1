Import-Module ActiveDirectory

$hrbuData = Import-Csv "hrbu.csv"
$hrbuCityStreetData = Import-Csv "hrbu_city_street.csv"

$groupMappings = Import-Csv "group_mapping.csv"
$groupMappings | % { $_.id = [int]$_.id }

$maxId = ($groupMappings | Sort-Object Id -Descending)[0].id

$newGroupMappings = New-Object System.Collections.ArrayList
$updatedHrbuEntries = New-Object System.Collections.ArrayList
$updatedHrbuCityStreetEntries = New-Object System.Collections.ArrayList

function findGroup 
{
  Param ([String] $name)

  $groupMappings | Where-Object {$_.name -eq $name}
}
function findNewGroup 
{
  Param ([String] $name)

  $newGroupMappings | Where-Object {$_.name -eq $name}
}

function processGroups
{
  Param ([String] $name, [String] $groupsString)

  If ($groupsString -eq "NULL")
  {
    return $groupsString
  }

  $groups = $groupsString.split(",") | % { $_.trim() }
  $matchedGroups = New-Object System.Collections.ArrayList

  ForEach ($group in $groups)
  {
    $match = findGroup $group

    if ($group -eq "Domain Users")
    {
      continue
    }

    if ($match -eq $Null)
    {
      $match = findNewGroup $group
      if ($match -eq $null)
      {
        $adGroup = Get-ADGroup -Server uson.usoncology.int -Filter {SamAccountName -eq $group}
        if ($adGroup -eq $null)
        {
          $adGroup = Get-ADGroup -Server mshps.usoncology.int -Filter {SamAccountName -eq $group}
        }
        if ($adGroup -eq $null)
        {
          throw ("Group not found " + $group + " " + $groups)
        }
  
        $match = New-Object -TypeName PsObject -Property @{id = ++$maxId; name = $adGroup.SamAccountName; dn = $adGroup.DistinguishedName; type = "hrbu"}
  
        $newGroupMappings.Add($match) | Out-Null
      }
    } 

    if ($match.type -eq "hrbu")
    {
      $matchedGroups.Add($match.name) | Out-Null
    }
  }

  return $matchedGroups -Join ","
}

ForEach ($hrbu in $hrbuData)
{
    $newGroups = processGroups $hrbu.hrbu $hrbu.groups;
    $newContractorGroups = processGroups $hrbu.hrbu $hrbu.contractor_groups;
    $newOutsideWorkerGroups = processGroups $hrbu.hrbu $hrbu.contingentworkertype_outside_worker_groups;
    $newContingentWorkerGroups = processGroups $hrbu.hrbu $hrbu.contingentworkertype_x_groups;

    If (($newGroups -ne $hrbu.groups) -or 
      ($newContractorGroups -ne $hrbu.contractor_groups) -or 
      ($newOutsideWorkerGroups -ne $hrbu.contingentworkertype_outside_worker_groups) -or 
      ($newContingentWorkerGroups -ne $hrbu.contingentworkertype_x_groups))
    {
      $groupObject = New-Object -TypeName PsObject -Property @{id = $hrbu.hrbu; groups = $newGroups; contractor_groups = $newContractorGroups; contingentworkertype_outside_worker_groups = $newOutsideWorkerGroups; contingentworkertype_x_groups = $newContingentWorkerGroups}
      $updatedHrbuEntries.Add($groupObject) | Out-Null
    }
}

ForEach ($hrbu in $hrbuCityStreetData)
{
    $newGroups = processGroups $hrbu.hrbu $hrbu.groups;
    $newContractorGroups = processGroups $hrbu.hrbu $hrbu.contractor_groups;
    $newOutsideWorkerGroups = processGroups $hrbu.hrbu $hrbu.contingentworkertype_outside_worker_groups;
    $newContingentWorkerGroups = processGroups $hrbu.hrbu $hrbu.contingentworkertype_x_groups;

    If (($newGroups -ne $hrbu.groups) -or 
      ($newContractorGroups -ne $hrbu.contractor_groups) -or 
      ($newOutsideWorkerGroups -ne $hrbu.contingentworkertype_outside_worker_groups) -or 
      ($newContingentWorkerGroups -ne $hrbu.contingentworkertype_x_groups))
    {
      $groupObject = New-Object -TypeName PsObject -Property @{city = $hrbu.city; street = $hrbu.street; groups = $newGroups; contractor_groups = $newContractorGroups; contingentworkertype_outside_worker_groups = $newOutsideWorkerGroups; contingentworkertype_x_groups = $newContingentWorkerGroups}
      $updatedHrbuCityStreetEntries.Add($groupObject) | Out-Null
    }
}

Write-Output "Updated HRBU entries:"
$updatedHrbuEntries | Select-Object id,groups,contractor_groups,contingentworkertype_outside_worker_groups,contingentworkertype_x_groups | ConvertTo-Csv

Write-Output "Updated HRBU city/street entries:"
$updatedHrbuCityStreetEntries | Select-Object city,street,groups,contractor_groups,contingentworkertype_outside_worker_groups,contingentworkertype_x_groups | ConvertTo-Csv

Write-Output "New entries:"
$newGroupMappings | Select-Object id,name,dn,type | ConvertTo-Csv
