CREATE DATABASE  IF NOT EXISTS `msh_idm_audit` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `msh_idm_audit`;
-- ------------------------------------------------------
-- Server version	5.6.13-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- Table structure for table `audit_async_recon`
--

DROP TABLE IF EXISTS `audit_async_recon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_async_recon` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `objectid` varchar(38) NOT NULL,
  `eventdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reconid` varchar(38) DEFAULT NULL,
  `mapping` varchar(255) DEFAULT NULL,
  `sourceid` varchar(38) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `situation` varchar(255) DEFAULT NULL,
  `status` varchar(7) DEFAULT NULL,
  `message` text,
  `target` text,
  PRIMARY KEY (`id`),
  KEY `audit_async_recon_idx` (`eventdate`,`reconid`,`sourceid`)
) ENGINE=InnoDB AUTO_INCREMENT=46395 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auditaccess`
--

DROP TABLE IF EXISTS `auditaccess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditaccess` (
  `objectid` varchar(38) NOT NULL,
  `activitydate` varchar(29) DEFAULT NULL COMMENT 'Date format: 2011-09-09T14:58:17.654+02:00',
  `activity` varchar(24) DEFAULT NULL,
  `ip` varchar(40) DEFAULT NULL,
  `principal` text,
  `roles` varchar(1024) DEFAULT NULL,
  `status` varchar(7) DEFAULT NULL,
  PRIMARY KEY (`objectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auditactivity`
--

DROP TABLE IF EXISTS `auditactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditactivity` (
  `objectid` varchar(38) NOT NULL,
  `rootactionid` varchar(255) DEFAULT NULL,
  `parentactionid` varchar(255) DEFAULT NULL,
  `activityid` varchar(255) DEFAULT NULL,
  `activitydate` varchar(29) DEFAULT NULL COMMENT 'Date format: 2011-09-09T14:58:17.654+02:00',
  `activity` varchar(24) DEFAULT NULL,
  `message` text,
  `subjectid` varchar(255) DEFAULT NULL,
  `subjectrev` varchar(38) DEFAULT NULL,
  `requester` text,
  `approver` text,
  `subjectbefore` mediumtext,
  `subjectafter` mediumtext,
  `status` varchar(7) DEFAULT NULL,
  `changedfields` varchar(255) DEFAULT NULL,
  `passwordchanged` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`objectid`),
  KEY `idx_auditactivity_rootactionid` (`rootactionid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auditrecon`
--

DROP TABLE IF EXISTS `auditrecon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditrecon` (
  `objectid` varchar(38) NOT NULL,
  `entrytype` varchar(7) DEFAULT NULL,
  `rootactionid` varchar(255) DEFAULT NULL,
  `reconid` varchar(36) DEFAULT NULL,
  `reconciling` varchar(12) DEFAULT NULL,
  `sourceobjectid` varchar(255) DEFAULT NULL,
  `targetobjectid` varchar(255) DEFAULT NULL,
  `ambiguoustargetobjectids` mediumtext,
  `activitydate` varchar(29) DEFAULT NULL COMMENT 'Date format: 2011-09-09T14:58:17.654+02:00',
  `situation` varchar(24) DEFAULT NULL,
  `activity` varchar(24) DEFAULT NULL,
  `status` varchar(7) DEFAULT NULL,
  `message` text,
  `mapping` text DEFAULT NULL
  PRIMARY KEY (`objectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'msh_idm_audit'
--
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-06-23 21:17:44
CREATE DATABASE  IF NOT EXISTS `msh_idm_repo` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `msh_idm_repo`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: directory.iam.mckesson.com    Database: msh_idm_repo
-- ------------------------------------------------------
-- Server version	5.6.13-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- Temporary table structure for view `audit_async_recon`
--

DROP TABLE IF EXISTS `audit_async_recon`;
/*!50001 DROP VIEW IF EXISTS `audit_async_recon`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `audit_async_recon` (
  `id` tinyint NOT NULL,
  `objectid` tinyint NOT NULL,
  `eventdate` tinyint NOT NULL,
  `reconid` tinyint NOT NULL,
  `mapping` tinyint NOT NULL,
  `sourceid` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `situation` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `message` tinyint NOT NULL,
  `target` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `auditaccess`
--

DROP TABLE IF EXISTS `auditaccess`;
/*!50001 DROP VIEW IF EXISTS `auditaccess`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `auditaccess` (
  `objectid` tinyint NOT NULL,
  `activitydate` tinyint NOT NULL,
  `activity` tinyint NOT NULL,
  `ip` tinyint NOT NULL,
  `principal` tinyint NOT NULL,
  `roles` tinyint NOT NULL,
  `status` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `auditactivity`
--

DROP TABLE IF EXISTS `auditactivity`;
/*!50001 DROP VIEW IF EXISTS `auditactivity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `auditactivity` (
  `objectid` tinyint NOT NULL,
  `rootactionid` tinyint NOT NULL,
  `parentactionid` tinyint NOT NULL,
  `activityid` tinyint NOT NULL,
  `activitydate` tinyint NOT NULL,
  `activity` tinyint NOT NULL,
  `message` tinyint NOT NULL,
  `subjectid` tinyint NOT NULL,
  `subjectrev` tinyint NOT NULL,
  `requester` tinyint NOT NULL,
  `approver` tinyint NOT NULL,
  `subjectbefore` tinyint NOT NULL,
  `subjectafter` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `changedfields` tinyint NOT NULL,
  `passwordchanged` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `auditrecon`
--

DROP TABLE IF EXISTS `auditrecon`;
/*!50001 DROP VIEW IF EXISTS `auditrecon`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `auditrecon` (
  `objectid` tinyint NOT NULL,
  `entrytype` tinyint NOT NULL,
  `rootactionid` tinyint NOT NULL,
  `reconid` tinyint NOT NULL,
  `reconciling` tinyint NOT NULL,
  `sourceobjectid` tinyint NOT NULL,
  `targetobjectid` tinyint NOT NULL,
  `ambiguoustargetobjectids` tinyint NOT NULL,
  `activitydate` tinyint NOT NULL,
  `situation` tinyint NOT NULL,
  `activity` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `message` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `configobjectproperties`
--

DROP TABLE IF EXISTS `configobjectproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configobjectproperties` (
  `configobjects_id` bigint(20) unsigned NOT NULL,
  `propkey` varchar(255) NOT NULL,
  `proptype` varchar(32) DEFAULT NULL,
  `propvalue` text,
  KEY `fk_configobjectproperties_configobjects` (`configobjects_id`),
  KEY `idx_configobjectproperties_prop` (`propkey`,`propvalue`(23)),
  CONSTRAINT `fk_configobjectproperties_configobjects` FOREIGN KEY (`configobjects_id`) REFERENCES `configobjects` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `configobjects`
--

DROP TABLE IF EXISTS `configobjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configobjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `objecttypes_id` bigint(20) unsigned NOT NULL,
  `objectid` varchar(255) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `fullobject` mediumtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_configobjects_object` (`objecttypes_id`,`objectid`),
  KEY `fk_configobjects_objecttypes` (`objecttypes_id`),
  CONSTRAINT `fk_configobjects_objecttypes` FOREIGN KEY (`objecttypes_id`) REFERENCES `objecttypes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deferred_email`
--

DROP TABLE IF EXISTS `deferred_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deferred_email` (
  `objectid` varchar(255) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`objectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deferred_email_staging`
--

DROP TABLE IF EXISTS `deferred_email_staging`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deferred_email_staging` (
  `objectid` varchar(255) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`objectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `genericobjectproperties`
--

DROP TABLE IF EXISTS `genericobjectproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genericobjectproperties` (
  `genericobjects_id` bigint(20) unsigned NOT NULL,
  `propkey` varchar(255) NOT NULL,
  `proptype` varchar(32) DEFAULT NULL,
  `propvalue` text,
  KEY `fk_genericobjectproperties_genericobjects` (`genericobjects_id`),
  KEY `idx_genericobjectproperties_prop` (`propkey`,`propvalue`(23)),
  CONSTRAINT `fk_genericobjectproperties_genericobjects` FOREIGN KEY (`genericobjects_id`) REFERENCES `genericobjects` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `genericobjects`
--

DROP TABLE IF EXISTS `genericobjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genericobjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `objecttypes_id` bigint(20) unsigned NOT NULL,
  `objectid` varchar(255) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `fullobject` mediumtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_genericobjects_object` (`objecttypes_id`,`objectid`),
  KEY `fk_genericobjects_objecttypes` (`objecttypes_id`),
  CONSTRAINT `fk_genericobjects_objecttypes` FOREIGN KEY (`objecttypes_id`) REFERENCES `objecttypes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `group_mapping`
--

DROP TABLE IF EXISTS `group_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_mapping` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dn` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hrbu`
--

DROP TABLE IF EXISTS `hrbu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hrbu` (
  `hrbu` varchar(38) NOT NULL,
  `ou` varchar(255) DEFAULT NULL,
  `home_drive` varchar(255) DEFAULT NULL,
  `home_dir` varchar(255) DEFAULT NULL,
  `login_script` varchar(255) DEFAULT NULL,
  `groups` text,
  `active_sync` tinyint(1) DEFAULT NULL,
  `city` tinyint(1) DEFAULT NULL,
  `mail_suffix` varchar(255) DEFAULT NULL,  
  PRIMARY KEY (`hrbu`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

ALTER TABLE `hrbu` ADD `secondary_mail_suffix` varchar(255) DEFAULT NULL;
ALTER TABLE `hrbu` ADD `itc_mail` varchar(255) DEFAULT NULL;
ALTER TABLE `hrbu` ADD `contingentworkertype_outside_worker_groups` text DEFAULT NULL AFTER `groups`;
ALTER TABLE `hrbu` ADD `contingentworkertype_x_groups` text DEFAULT NULL AFTER `contingentworkertype_outside_worker_groups`;

ALTER TABLE `hrbu` ADD `contractor_groups` text DEFAULT NULL AFTER `groups`;

--
-- Table structure for table `hrbu_city_street`
--

DROP TABLE IF EXISTS `hrbu_city_street`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hrbu_city_street` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `city` varchar(38) DEFAULT NULL,
  `street` varchar(38) DEFAULT NULL,
  `ou` varchar(255) DEFAULT NULL,
  `home_drive` varchar(255) DEFAULT NULL,
  `home_dir` varchar(255) DEFAULT NULL,
  `login_script` varchar(255) DEFAULT NULL,
  `groups` text,
  `active_sync` tinyint(1) DEFAULT NULL,
  `itc_mail` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=269 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

ALTER TABLE `hrbu_city_street` ADD `contingentworkertype_outside_worker_groups` text DEFAULT NULL AFTER `groups`;
ALTER TABLE `hrbu_city_street` ADD `contingentworkertype_x_groups` text DEFAULT NULL AFTER `contingentworkertype_outside_worker_groups`;

ALTER TABLE `hrbu_city_street` ADD `contractor_groups` text DEFAULT NULL AFTER `groups`;

--
-- Temporary table structure for view `hrbu_view`
--

DROP TABLE IF EXISTS `hrbu_view`;
/*!50001 DROP VIEW IF EXISTS `hrbu_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hrbu_view` (
  `hrbu` tinyint NOT NULL,
  `city` tinyint NOT NULL,
  `street` tinyint NOT NULL,
  `ou` tinyint NOT NULL,
  `home_drive` tinyint NOT NULL,
  `home_dir` tinyint NOT NULL,
  `login_script` tinyint NOT NULL,
  `groups` tinyint NOT NULL,
  `active_sync` tinyint NOT NULL,
  `notify_manager` tinyint NOT NULL,
  `mail_suffix` tinyint NOT NULL,
  `secondary_mail_suffix` tinyint NOT NULL,
  `itc_mail` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `internaluser`
--

DROP TABLE IF EXISTS `internaluser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `internaluser` (
  `objectid` varchar(254) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `pwd` varchar(510) DEFAULT NULL,
  `roles` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`objectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `links` (
  `objectid` varchar(38) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `linktype` varchar(255) NOT NULL,
  `firstid` varchar(255) NOT NULL,
  `secondid` varchar(255) NOT NULL,
  PRIMARY KEY (`objectid`),
  UNIQUE KEY `idx_links_first` (`linktype`,`firstid`),
  UNIQUE KEY `idx_links_second` (`linktype`,`secondid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `managedobjectproperties`
--

DROP TABLE IF EXISTS `managedobjectproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `managedobjectproperties` (
  `managedobjects_id` bigint(20) unsigned NOT NULL,
  `propkey` varchar(255) NOT NULL,
  `proptype` varchar(32) DEFAULT NULL,
  `propvalue` text,
  KEY `fk_managedobjectproperties_managedobjects` (`managedobjects_id`),
  KEY `idx_managedobjectproperties_prop` (`propkey`,`propvalue`(23)),
  CONSTRAINT `fk_managedobjectproperties_managedobjects` FOREIGN KEY (`managedobjects_id`) REFERENCES `managedobjects` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `managedobjects`
--

DROP TABLE IF EXISTS `managedobjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `managedobjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `objecttypes_id` bigint(20) unsigned NOT NULL,
  `objectid` varchar(255) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `fullobject` mediumtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx-managedobjects_object` (`objecttypes_id`,`objectid`),
  KEY `fk_managedobjects_objectypes` (`objecttypes_id`),
  CONSTRAINT `fk_managedobjects_objectypes` FOREIGN KEY (`objecttypes_id`) REFERENCES `objecttypes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `manageduser`
--

DROP TABLE IF EXISTS `manageduser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manageduser` (
  `objectid` varchar(38) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `uid` varchar(38) NOT NULL,
  `country` varchar(255) DEFAULT NULL,
  `middleName` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `addressLastModified` varchar(255) DEFAULT NULL,
  `employee` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `postalAddress` varchar(255) DEFAULT NULL,
  `legalName` varchar(255) DEFAULT NULL,
  `workerType` varchar(255) DEFAULT NULL,
  `userID` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `workerID` varchar(255) DEFAULT NULL,
  `managerID` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `hrbu` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `active` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `telephoneNumber` varchar(255) DEFAULT NULL,
  `trm` varchar(255) DEFAULT NULL,
  `dateActivated` varchar(255) DEFAULT NULL,
  `positionEffectiveDate` varchar(255) DEFAULT NULL,
  `legalPrefix` varchar(255) DEFAULT NULL,
  `legalSuffix` varchar(255) DEFAULT NULL,
  `preferredFirstName` varchar(255) DEFAULT NULL,
  `preferredLastName` varchar(255) DEFAULT NULL,
  `preferredPrefix` varchar(255) DEFAULT NULL,
  `preferredSuffix` varchar(255) DEFAULT NULL,
  `hrPartner` varchar(255) DEFAULT NULL,
  `hireDate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`objectid`),
  KEY `worker_id_idx` (`workerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `manageduser_correlated`
--

DROP TABLE IF EXISTS `manageduser_correlated`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manageduser_correlated` (
  `objectid` varchar(38) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `uid` varchar(38) NOT NULL,
  `country` varchar(255) DEFAULT NULL,
  `middleName` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `addressLastModified` varchar(255) DEFAULT NULL,
  `employee` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `postalAddress` varchar(255) DEFAULT NULL,
  `legalName` varchar(255) DEFAULT NULL,
  `workerType` varchar(255) DEFAULT NULL,
  `userID` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `workerID` varchar(255) DEFAULT NULL,
  `managerID` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `hrbu` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `active` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `telephoneNumber` varchar(255) DEFAULT NULL,
  `trm` varchar(255) DEFAULT NULL,
  `dateActivated` varchar(255) DEFAULT NULL,
  `positionEffectiveDate` varchar(255) DEFAULT NULL,
  `legalPrefix` varchar(255) DEFAULT NULL,
  `legalSuffix` varchar(255) DEFAULT NULL,
  `preferredFirstName` varchar(255) DEFAULT NULL,
  `preferredLastName` varchar(255) DEFAULT NULL,
  `preferredPrefix` varchar(255) DEFAULT NULL,
  `preferredSuffix` varchar(255) DEFAULT NULL,
  `hrPartner` varchar(255) DEFAULT NULL,
  `futureUser` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`objectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `manageduser_future`
--

DROP TABLE IF EXISTS `manageduser_future`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manageduser_future` (
  `objectid` varchar(38) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `uid` varchar(38) NOT NULL,
  `country` varchar(255) DEFAULT NULL,
  `middleName` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `addressLastModified` varchar(255) DEFAULT NULL,
  `employee` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `postalAddress` varchar(255) DEFAULT NULL,
  `legalName` varchar(255) DEFAULT NULL,
  `workerType` varchar(255) DEFAULT NULL,
  `userID` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `workerID` varchar(255) DEFAULT NULL,
  `managerID` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `hrbu` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `active` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `telephoneNumber` varchar(255) DEFAULT NULL,
  `trm` varchar(255) DEFAULT NULL,
  `dateActivated` varchar(255) DEFAULT NULL,
  `positionEffectiveDate` varchar(255) DEFAULT NULL,
  `legalPrefix` varchar(255) DEFAULT NULL,
  `legalSuffix` varchar(255) DEFAULT NULL,
  `preferredFirstName` varchar(255) DEFAULT NULL,
  `preferredLastName` varchar(255) DEFAULT NULL,
  `preferredPrefix` varchar(255) DEFAULT NULL,
  `preferredSuffix` varchar(255) DEFAULT NULL,
  `hrPartner` varchar(255) DEFAULT NULL,
  `hireDate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`objectid`),
  KEY `worker_id_idx` (`workerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `objecttypes`
--

DROP TABLE IF EXISTS `objecttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `objecttypes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `objecttype` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_objecttypes_objecttype` (`objecttype`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schedulerobjectproperties`
--

DROP TABLE IF EXISTS `schedulerobjectproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedulerobjectproperties` (
  `schedulerobjects_id` bigint(20) unsigned NOT NULL,
  `propkey` varchar(255) NOT NULL,
  `proptype` varchar(32) DEFAULT NULL,
  `propvalue` text,
  KEY `fk_schedulerobjectproperties_schedulerobjects` (`schedulerobjects_id`),
  KEY `idx_schedulerobjectproperties_prop` (`propkey`,`propvalue`(23)),
  CONSTRAINT `fk_schedulerobjectproperties_schedulerobjects` FOREIGN KEY (`schedulerobjects_id`) REFERENCES `schedulerobjects` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schedulerobjects`
--

DROP TABLE IF EXISTS `schedulerobjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedulerobjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `objecttypes_id` bigint(20) unsigned NOT NULL,
  `objectid` varchar(255) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `fullobject` mediumtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx-schedulerobjects_object` (`objecttypes_id`,`objectid`),
  KEY `fk_schedulerobjects_objectypes` (`objecttypes_id`),
  CONSTRAINT `fk_schedulerobjects_objectypes` FOREIGN KEY (`objecttypes_id`) REFERENCES `objecttypes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `sync_report`
--

DROP TABLE IF EXISTS `sync_report`;
/*!50001 DROP VIEW IF EXISTS `sync_report`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `sync_report` (
  `id` tinyint NOT NULL,
  `objectid` tinyint NOT NULL,
  `eventdate` tinyint NOT NULL,
  `reconid` tinyint NOT NULL,
  `mapping` tinyint NOT NULL,
  `sourceid` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `situation` tinyint NOT NULL,
  `status` tinyint NOT NULL,
  `message` tinyint NOT NULL,
  `target` tinyint NOT NULL,
  `rev` tinyint NOT NULL,
  `uid` tinyint NOT NULL,
  `country` tinyint NOT NULL,
  `middleName` tinyint NOT NULL,
  `postalCode` tinyint NOT NULL,
  `addressLastModified` tinyint NOT NULL,
  `employee` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `address` tinyint NOT NULL,
  `postalAddress` tinyint NOT NULL,
  `workerType` tinyint NOT NULL,
  `userID` tinyint NOT NULL,
  `city` tinyint NOT NULL,
  `state` tinyint NOT NULL,
  `workerID` tinyint NOT NULL,
  `managerID` tinyint NOT NULL,
  `hrbu` tinyint NOT NULL,
  `title` tinyint NOT NULL,
  `legalPrefix` tinyint NOT NULL,
  `firstName` tinyint NOT NULL,
  `lastName` tinyint NOT NULL,
  `legalSuffix` tinyint NOT NULL,
  `legalName` tinyint NOT NULL,
  `preferredPrefix` tinyint NOT NULL,
  `preferredFirstName` tinyint NOT NULL,
  `preferredLastName` tinyint NOT NULL,
  `preferredSuffix` tinyint NOT NULL,
  `active` tinyint NOT NULL,
  `fax` tinyint NOT NULL,
  `mobile` tinyint NOT NULL,
  `telephoneNumber` tinyint NOT NULL,
  `trm` tinyint NOT NULL,
  `hrPartner` tinyint NOT NULL,
  `futureUser` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `uinotification`
--

DROP TABLE IF EXISTS `uinotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uinotification` (
  `objectid` varchar(38) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `notificationType` varchar(255) NOT NULL,
  `createDate` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `requester` varchar(255) DEFAULT NULL,
  `receiverId` varchar(38) NOT NULL,
  `requesterId` varchar(38) DEFAULT NULL,
  `notificationSubtype` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`objectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `uson_user_attributes`
--

DROP TABLE IF EXISTS `uson_user_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uson_user_attributes` (
  `objectid` varchar(255) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `ismanagerlinked` varchar(5) NOT NULL,
  `ispasswordset` varchar(5) NOT NULL,
  `active` varchar(5) NOT NULL,
  `hrbu` varchar(255) NOT NULL,
  `employee` varchar(5) NOT NULL,
  `sourceid` varchar(38) NOT NULL,
  `namedata` mediumtext NOT NULL,
  PRIMARY KEY (`objectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `uson_user_attributes_staging`
--

DROP TABLE IF EXISTS `uson_user_attributes_staging`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uson_user_attributes_staging` (
  `objectid` varchar(255) NOT NULL,
  `rev` varchar(38) NOT NULL,
  `ismanagerlinked` varchar(5) NOT NULL,
  `ispasswordset` varchar(5) NOT NULL,
  `active` varchar(5) NOT NULL,
  `hrbu` varchar(255) NOT NULL,
  `employee` varchar(5) NOT NULL,
  `sourceid` varchar(38) NOT NULL,
  `namedata` mediumtext NOT NULL,
  PRIMARY KEY (`objectid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

ALTER TABLE `manageduser` ADD `leaveOfAbsence` varchar(5) DEFAULT "false";
ALTER TABLE `manageduser_correlated` ADD `leaveOfAbsence` varchar(5) DEFAULT "false";
ALTER TABLE `manageduser_future` ADD `leaveOfAbsence` varchar(5) DEFAULT "false";
ALTER TABLE `uson_user_attributes` ADD `leaveOfAbsence` varchar(5) DEFAULT "false";
ALTER TABLE `uson_user_attributes_staging` ADD `leaveOfAbsence` varchar(5) DEFAULT "false";

ALTER TABLE `manageduser` ADD `executiveDirector` varchar(255) DEFAULT NULL;
ALTER TABLE `manageduser_correlated` ADD `executiveDirector` varchar(255) DEFAULT NULL;
ALTER TABLE `manageduser_future` ADD `executiveDirector` varchar(255) DEFAULT NULL;

ALTER TABLE `manageduser` ADD `jobFamily` varchar(255) DEFAULT NULL;
ALTER TABLE `manageduser_correlated` ADD `jobFamily` varchar(255) DEFAULT NULL;
ALTER TABLE `manageduser_future` ADD `jobFamily` varchar(255) DEFAULT NULL;

ALTER TABLE `manageduser` ADD `ssn` varchar(255) DEFAULT NULL;
ALTER TABLE `manageduser_correlated` ADD `ssn` varchar(255) DEFAULT NULL;
ALTER TABLE `manageduser_future` ADD `ssn` varchar(255) DEFAULT NULL;

ALTER TABLE `manageduser` ADD `homePostalCode` varchar(255) DEFAULT NULL;
ALTER TABLE `manageduser_correlated` ADD `homePostalCode` varchar(255) DEFAULT NULL;
ALTER TABLE `manageduser_future` ADD `homePostalCode` varchar(255) DEFAULT NULL;

ALTER TABLE `manageduser` ADD `companyId` varchar(38) DEFAULT NULL;
ALTER TABLE `manageduser_correlated` ADD `companyId` varchar(38) DEFAULT NULL;
ALTER TABLE `manageduser_future` ADD `companyId` varchar(38) DEFAULT NULL;
ALTER TABLE `uson_user_attributes` ADD `companyId` varchar(38) DEFAULT NULL;
ALTER TABLE `uson_user_attributes_staging` ADD `companyId` varchar(38) DEFAULT NULL;

ALTER TABLE `manageduser` ADD `workerTypeDescriptor` varchar(255) DEFAULT NULL;
ALTER TABLE `manageduser_correlated` ADD `workerTypeDescriptor` varchar(255) DEFAULT NULL;
ALTER TABLE `manageduser_future` ADD `workerTypeDescriptor` varchar(255) DEFAULT NULL;
ALTER TABLE `uson_user_attributes` ADD `workerTypeDescriptor` varchar(255) DEFAULT NULL;
ALTER TABLE `uson_user_attributes_staging` ADD `workerTypeDescriptor` varchar(255) DEFAULT NULL;

DROP TABLE IF EXISTS `prevent_loa_job_codes`;
CREATE TABLE `prevent_loa_job_codes` (  
  `objectid` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `code` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO prevent_loa_job_codes (code, description)  VALUES('945', '945-Network - Physician - All');


--
-- Dumping routines for database 'msh_idm_repo'
--
/*!50003 DROP PROCEDURE IF EXISTS `correlate_users` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `correlate_users`()
    DETERMINISTIC
    SQL SECURITY INVOKER
BEGIN
DECLARE `objectid` varchar(38);
DECLARE `rev` varchar(38);
DECLARE `uid` varchar(38);
DECLARE `country` varchar(255);
DECLARE `middleName` varchar(255);
DECLARE `postalCode` varchar(255);
DECLARE `addressLastModified` varchar(255);
DECLARE `employee` varchar(255);
DECLARE `email` varchar(255);
DECLARE `address` varchar(255);
DECLARE `postalAddress` varchar(255);
DECLARE `legalName` varchar(255);
DECLARE `workerType` varchar(255);
DECLARE `userID` varchar(255);
DECLARE `city` varchar(255);
DECLARE `state` varchar(255);
DECLARE `workerID` varchar(255);
DECLARE `managerID` varchar(255);
DECLARE `firstName` varchar(255);
DECLARE `hrbu` varchar(255);
DECLARE `title` varchar(255);
DECLARE `lastName` varchar(255);
DECLARE `active` varchar(255);
DECLARE `fax` varchar(255);
DECLARE `mobile` varchar(255);
DECLARE `telephoneNumber` varchar(255);
DECLARE `trm` varchar(255);
DECLARE `dateActivated` varchar(255);
DECLARE `positionEffectiveDate` varchar(255);
DECLARE `legalPrefix` varchar(255);
DECLARE `legalSuffix` varchar(255);
DECLARE `preferredFirstName` varchar(255);
DECLARE `preferredLastName` varchar(255);
DECLARE `preferredPrefix` varchar(255);
DECLARE `preferredSuffix` varchar(255);
DECLARE `hrPartner` varchar(255);
DECLARE `hireDate` varchar(255);
DECLARE `leaveOfAbsence` varchar(5);
DECLARE `executiveDirector` varchar(255);
DECLARE `jobFamily` varchar(255);
DECLARE `ssn` varchar(255);
DECLARE `homePostalCode` varchar(255);
DECLARE `companyId` varchar(38);
DECLARE `workerTypeDescriptor` varchar(255);
DECLARE `futureUser` varchar(255);

DECLARE done INT DEFAULT FALSE;
DECLARE currentWorkerID VARCHAR(255) DEFAULT "";

DECLARE users CURSOR FOR 

SELECT * FROM(
SELECT mu.*, 'false' AS futureUser FROM manageduser mu
UNION ALL
SELECT muf.*, 'true' AS futureUser FROM manageduser_future muf WHERE muf.trm = "false" and muf.hireDate is not null 
    AND EXISTS(SELECT 1 FROM manageduser LIMIT 1) -- manageduser table is not empty
    AND muf.workerID not in (SELECT distinct u.workerID FROM manageduser u WHERE u.trm = "false") -- there are no non-terminated users in manageduser table with this workerID
) AS result ORDER BY result.workerID, result.trm ASC, result.futureUser ASC, result.positionEffectiveDate DESC;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

START TRANSACTION;
delete from manageduser_correlated; 
OPEN users;

process_loop: LOOP
FETCH users into objectid,rev,uid,country,middleName,postalCode,addressLastModified,employee,email,address,postalAddress,legalName,workerType,userID,city,state,workerID,managerID,firstName,hrbu,title,lastName,active,fax,mobile,telephoneNumber,trm,dateActivated,positionEffectiveDate,legalPrefix,legalSuffix,preferredFirstName,preferredLastName,preferredPrefix,preferredSuffix,hrPartner,hireDate,leaveOfAbsence,executiveDirector,jobFamily,ssn,homePostalCode,companyId,workerTypeDescriptor,futureUser;

IF done THEN
LEAVE process_loop;
END IF;

IF IFNULL(currentWorkerID, '') <> IFNULL(workerID, '') THEN
    SET currentWorkerID := workerID;

    IF futureUser = "true" THEN
        SET active := "false";
        SET leaveOfAbsence := "false";
    END IF;

    INSERT INTO manageduser_correlated VALUES(objectid,rev,uid,country,middleName,postalCode,addressLastModified,employee,email,address,postalAddress,legalName,workerType,userID,city,state,workerID,managerID,firstName,hrbu,title,lastName,active,fax,mobile,telephoneNumber,trm,dateActivated,positionEffectiveDate,legalPrefix,legalSuffix,preferredFirstName,preferredLastName,preferredPrefix,preferredSuffix,hrPartner,futureUser,leaveOfAbsence,executiveDirector,jobFamily,ssn,homePostalCode,companyId,workerTypeDescriptor);
END IF;

END LOOP;
CLOSE users;
COMMIT;
SELECT true AS result;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `dry_run_prepare` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `dry_run_prepare`()
    DETERMINISTIC
    SQL SECURITY INVOKER
BEGIN
    DELETE FROM `msh_idm_repo`.`uson_user_attributes_staging`; 
    INSERT INTO `msh_idm_repo`.`uson_user_attributes_staging` SELECT * FROM `msh_idm_repo`.`uson_user_attributes`;
    SELECT true AS result;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `audit_async_recon`
--

/*!50001 DROP TABLE IF EXISTS `audit_async_recon`*/;
/*!50001 DROP VIEW IF EXISTS `audit_async_recon`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY INVOKER */
/*!50001 VIEW `audit_async_recon` AS select `msh_idm_audit`.`audit_async_recon`.`id` AS `id`,`msh_idm_audit`.`audit_async_recon`.`objectid` AS `objectid`,`msh_idm_audit`.`audit_async_recon`.`eventdate` AS `eventdate`,`msh_idm_audit`.`audit_async_recon`.`reconid` AS `reconid`,`msh_idm_audit`.`audit_async_recon`.`mapping` AS `mapping`,`msh_idm_audit`.`audit_async_recon`.`sourceid` AS `sourceid`,`msh_idm_audit`.`audit_async_recon`.`action` AS `action`,`msh_idm_audit`.`audit_async_recon`.`situation` AS `situation`,`msh_idm_audit`.`audit_async_recon`.`status` AS `status`,`msh_idm_audit`.`audit_async_recon`.`message` AS `message`,`msh_idm_audit`.`audit_async_recon`.`target` AS `target` from `msh_idm_audit`.`audit_async_recon` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `auditaccess`
--

/*!50001 DROP TABLE IF EXISTS `auditaccess`*/;
/*!50001 DROP VIEW IF EXISTS `auditaccess`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY INVOKER */
/*!50001 VIEW `auditaccess` AS select `msh_idm_audit`.`auditaccess`.`objectid` AS `objectid`,`msh_idm_audit`.`auditaccess`.`activitydate` AS `activitydate`,`msh_idm_audit`.`auditaccess`.`activity` AS `activity`,`msh_idm_audit`.`auditaccess`.`ip` AS `ip`,`msh_idm_audit`.`auditaccess`.`principal` AS `principal`,`msh_idm_audit`.`auditaccess`.`roles` AS `roles`,`msh_idm_audit`.`auditaccess`.`status` AS `status` from `msh_idm_audit`.`auditaccess` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `auditactivity`
--

/*!50001 DROP TABLE IF EXISTS `auditactivity`*/;
/*!50001 DROP VIEW IF EXISTS `auditactivity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY INVOKER */
/*!50001 VIEW `auditactivity` AS select `msh_idm_audit`.`auditactivity`.`objectid` AS `objectid`,`msh_idm_audit`.`auditactivity`.`rootactionid` AS `rootactionid`,`msh_idm_audit`.`auditactivity`.`parentactionid` AS `parentactionid`,`msh_idm_audit`.`auditactivity`.`activityid` AS `activityid`,`msh_idm_audit`.`auditactivity`.`activitydate` AS `activitydate`,`msh_idm_audit`.`auditactivity`.`activity` AS `activity`,`msh_idm_audit`.`auditactivity`.`message` AS `message`,`msh_idm_audit`.`auditactivity`.`subjectid` AS `subjectid`,`msh_idm_audit`.`auditactivity`.`subjectrev` AS `subjectrev`,`msh_idm_audit`.`auditactivity`.`requester` AS `requester`,`msh_idm_audit`.`auditactivity`.`approver` AS `approver`,`msh_idm_audit`.`auditactivity`.`subjectbefore` AS `subjectbefore`,`msh_idm_audit`.`auditactivity`.`subjectafter` AS `subjectafter`,`msh_idm_audit`.`auditactivity`.`status` AS `status`,`msh_idm_audit`.`auditactivity`.`changedfields` AS `changedfields`,`msh_idm_audit`.`auditactivity`.`passwordchanged` AS `passwordchanged` from `msh_idm_audit`.`auditactivity` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `auditrecon`
--

/*!50001 DROP TABLE IF EXISTS `auditrecon`*/;
/*!50001 DROP VIEW IF EXISTS `auditrecon`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY INVOKER */
/*!50001 VIEW `auditrecon` AS select `msh_idm_audit`.`auditrecon`.`objectid` AS `objectid`,`msh_idm_audit`.`auditrecon`.`entrytype` AS `entrytype`,`msh_idm_audit`.`auditrecon`.`rootactionid` AS `rootactionid`,`msh_idm_audit`.`auditrecon`.`reconid` AS `reconid`,`msh_idm_audit`.`auditrecon`.`reconciling` AS `reconciling`,`msh_idm_audit`.`auditrecon`.`sourceobjectid` AS `sourceobjectid`,`msh_idm_audit`.`auditrecon`.`targetobjectid` AS `targetobjectid`,`msh_idm_audit`.`auditrecon`.`ambiguoustargetobjectids` AS `ambiguoustargetobjectids`,`msh_idm_audit`.`auditrecon`.`activitydate` AS `activitydate`,`msh_idm_audit`.`auditrecon`.`situation` AS `situation`,`msh_idm_audit`.`auditrecon`.`activity` AS `activity`,`msh_idm_audit`.`auditrecon`.`status` AS `status`,`msh_idm_audit`.`auditrecon`.`message` AS `message`,`msh_idm_audit`.`auditrecon`.`mapping` AS `mapping` from `msh_idm_audit`.`auditrecon` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hrbu_view`
--

/*!50001 DROP TABLE IF EXISTS `hrbu_view`*/;
/*!50001 DROP VIEW IF EXISTS `hrbu_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hrbu_view` AS select `h`.`hrbu` AS `hrbu`,`hcs`.`city` AS `city`,`hcs`.`street` AS `street`,(case when `h`.`city` then `hcs`.`ou` else `h`.`ou` end) AS `ou`,(case when `h`.`city` then `hcs`.`home_drive` else `h`.`home_drive` end) AS `home_drive`,(case when `h`.`city` then `hcs`.`home_dir` else `h`.`home_dir` end) AS `home_dir`,(case when `h`.`city` then `hcs`.`login_script` else `h`.`login_script` end) AS `login_script`,(case when `h`.`city` then `hcs`.`groups` else `h`.`groups` end) AS `groups`,(case when `h`.`city` then `hcs`.`contractor_groups` else `h`.`contractor_groups` end) AS `contractor_groups`,(case when `h`.`city` then `hcs`.`contingentworkertype_outside_worker_groups` else `h`.`contingentworkertype_outside_worker_groups` end) AS `contingentworkertype_outside_worker_groups`,(case when `h`.`city` then `hcs`.`contingentworkertype_x_groups` else `h`.`contingentworkertype_x_groups` end) AS `contingentworkertype_x_groups`,(case when `h`.`city` then `hcs`.`active_sync` else `h`.`active_sync` end) AS `active_sync`,(case when (`h`.`city` and isnull(`hcs`.`city`)) then 'true' else 'false' end) AS `notify_manager`,`h`.`mail_suffix` AS `mail_suffix`,`h`.`secondary_mail_suffix` AS `secondary_mail_suffix`, (case when `h`.`city` then `hcs`.`itc_mail` else `h`.`itc_mail` end) AS `itc_mail`  from (`hrbu` `h` left join `hrbu_city_street` `hcs` on((`h`.`city` = 1))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `sync_report`
--

/*!50001 DROP TABLE IF EXISTS `sync_report`*/;
/*!50001 DROP VIEW IF EXISTS `sync_report`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `sync_report` AS select `aar`.`id` AS `id`,`aar`.`objectid` AS `objectid`,`aar`.`eventdate` AS `eventdate`,`aar`.`reconid` AS `reconid`,`aar`.`mapping` AS `mapping`,`aar`.`sourceid` AS `sourceid`,`aar`.`action` AS `action`,`aar`.`situation` AS `situation`,`aar`.`status` AS `status`,replace(replace(replace(`aar`.`message`,'\\\\','\\'),'\\n','\n'),'\\r','\r') AS `message`,replace(replace(replace(`aar`.`target`,'\\\\','\\'),'\\n','\n'),'\\r','\r') AS `target`,`mu`.`rev` AS `rev`,`mu`.`uid` AS `uid`,`mu`.`country` AS `country`,`mu`.`middleName` AS `middleName`,`mu`.`postalCode` AS `postalCode`,`mu`.`addressLastModified` AS `addressLastModified`,`mu`.`employee` AS `employee`,`mu`.`email` AS `email`,replace(replace(`mu`.`address`,'\\n','\n'),'\\r','\r') AS `address`,replace(replace(`mu`.`postalAddress`,'\\n','\n'),'\\r','\r') AS `postalAddress`,`mu`.`workerType` AS `workerType`,`mu`.`userID` AS `userID`,`mu`.`city` AS `city`,`mu`.`state` AS `state`,`mu`.`workerID` AS `workerID`,`mu`.`managerID` AS `managerID`,`mu`.`hrbu` AS `hrbu`,`mu`.`title` AS `title`,`mu`.`legalPrefix` AS `legalPrefix`,`mu`.`firstName` AS `firstName`,`mu`.`lastName` AS `lastName`,`mu`.`legalSuffix` AS `legalSuffix`,`mu`.`legalName` AS `legalName`,`mu`.`preferredPrefix` AS `preferredPrefix`,`mu`.`preferredFirstName` AS `preferredFirstName`,`mu`.`preferredLastName` AS `preferredLastName`,`mu`.`preferredSuffix` AS `preferredSuffix`,`mu`.`active` AS `active`,`mu`.`fax` AS `fax`,`mu`.`mobile` AS `mobile`,`mu`.`telephoneNumber` AS `telephoneNumber`,`mu`.`trm` AS `trm`,`mu`.`hrPartner` AS `hrPartner`,`mu`.`leaveOfAbsence` AS `leaveOfAbsence`,`mu`.`executiveDirector` AS `executiveDirector`,`mu`.`companyId` AS `companyId`,`mu`.`workerTypeDescriptor` AS `workerTypeDescriptor`,`mu`.`futureUser` AS `futureUser` from (`msh_idm_repo`.`audit_async_recon` `aar` left join `msh_idm_repo`.`manageduser_correlated` `mu` on((`aar`.`sourceid` = `mu`.`objectid`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-06-23 21:17:57
ALTER TABLE `group_mapping` ADD UNIQUE INDEX (name);

ALTER TABLE `uson_user_attributes` ADD `accountExpiredNotificationTimestamp` VARCHAR(19) DEFAULT NULL AFTER `companyId`;
ALTER TABLE `uson_user_attributes_staging` ADD `accountExpiredNotificationTimestamp` VARCHAR(19) DEFAULT NULL AFTER `companyId`;

ALTER TABLE `manageduser_future` 
CHANGE COLUMN `address` `address` VARCHAR(255) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' DEFAULT NULL,
CHANGE COLUMN `postalAddress` `postalAddress` VARCHAR(255) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' DEFAULT NULL;


ALTER TABLE `manageduser` 
CHANGE COLUMN `address` `address` VARCHAR(255) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' DEFAULT NULL,
CHANGE COLUMN `postalAddress` `postalAddress` VARCHAR(255) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' DEFAULT NULL;


ALTER TABLE `manageduser_correlated` 
CHANGE COLUMN `address` `address` VARCHAR(255) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' DEFAULT NULL,
CHANGE COLUMN `postalAddress` `postalAddress` VARCHAR(255) CHARACTER SET 'utf8' COLLATE 'utf8_general_ci' DEFAULT NULL;
