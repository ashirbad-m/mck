CREATE DATABASE  IF NOT EXISTS `msh_idm_repo` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `msh_idm_repo`;
-- ------------------------------------------------------
-- Server version	5.6.13-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- Table structure for table `hrbu`
--

DROP TABLE IF EXISTS `hrbu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hrbu` (
  `hrbu` varchar(38) NOT NULL,
  `ou` varchar(255) DEFAULT NULL,
  `home_drive` varchar(255) DEFAULT NULL,
  `home_dir` varchar(255) DEFAULT NULL,
  `login_script` varchar(255) DEFAULT NULL,
  `groups` text,
  `active_sync` tinyint(1) DEFAULT NULL,
  `city` tinyint(1) DEFAULT NULL,
  `mail_suffix` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`hrbu`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

ALTER TABLE `hrbu` ADD `secondary_mail_suffix` varchar(255) DEFAULT NULL;
ALTER TABLE `hrbu` ADD `itc_mail` varchar(255) DEFAULT NULL;

--
-- Table structure for table `hrbu_city_street`
--

DROP TABLE IF EXISTS `hrbu_city_street`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hrbu_city_street` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `city` varchar(38) DEFAULT NULL,
  `street` varchar(38) DEFAULT NULL,
  `ou` varchar(255) DEFAULT NULL,
  `home_drive` varchar(255) DEFAULT NULL,
  `home_dir` varchar(255) DEFAULT NULL,
  `login_script` varchar(255) DEFAULT NULL,
  `groups` text,
  `active_sync` tinyint(1) DEFAULT NULL,
  `itc_mail` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=281 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `group_mapping`
--

DROP TABLE IF EXISTS `group_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_mapping` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dn` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-06-23 21:29:40

ALTER TABLE `uson_user_attributes` ADD COLUMN `currentCity` VARCHAR(255);
ALTER TABLE `uson_user_attributes` ADD COLUMN `currentAddress` VARCHAR(255);
ALTER TABLE `uson_user_attributes_staging` ADD COLUMN `currentCity` VARCHAR(255);
ALTER TABLE `uson_user_attributes_staging` ADD COLUMN `currentAddress` VARCHAR(255);

CALL `correlate_users`;
UPDATE `uson_user_attributes` uua LEFT JOIN `manageduser_correlated` muc ON uua.sourceid = muc.objectid
SET currentCity = muc.city, currentAddress = muc.address;
UPDATE `uson_user_attributes_staging` uua LEFT JOIN `manageduser_correlated` muc ON uua.sourceid = muc.objectid
SET currentCity = muc.city, currentAddress = muc.address;

ALTER TABLE `hrbu` ADD COLUMN `enabled` tinyint(1) DEFAULT 1;
ALTER TABLE `hrbu` ADD COLUMN `manager_lookup_strategy` VARCHAR(255) DEFAULT "vantage";

DROP TABLE IF EXISTS `hrbu_view`;
DROP VIEW IF EXISTS `hrbu_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `msh_idm_repo`.`hrbu_view` AS 
select `h`.`hrbu` AS `hrbu`,
	`hcs`.`city` AS `city`,
	`hcs`.`street` AS `street`,
	(case when `h`.`city` then `hcs`.`ou` else `h`.`ou` end) AS `ou`,
	(case when `h`.`city` then `hcs`.`home_drive` else `h`.`home_drive` end) AS `home_drive`,
	(case when `h`.`city` then `hcs`.`home_dir` else `h`.`home_dir` end) AS `home_dir`,
	(case when `h`.`city` then `hcs`.`login_script` else `h`.`login_script` end) AS `login_script`,
	(case when `h`.`city` then `hcs`.`groups` else `h`.`groups` end) AS `groups`,
	(case when `h`.`city` then `hcs`.`contractor_groups` else `h`.`contractor_groups` end) AS `contractor_groups`,
	(case when `h`.`city` then `hcs`.`contingentworkertype_outside_worker_groups` else `h`.`contingentworkertype_outside_worker_groups` end) AS `contingentworkertype_outside_worker_groups`,
	(case when `h`.`city` then `hcs`.`contingentworkertype_x_groups` else `h`.`contingentworkertype_x_groups` end) AS `contingentworkertype_x_groups`,
	(case when `h`.`city` then `hcs`.`active_sync` else `h`.`active_sync` end) AS `active_sync`,
	(case when (`h`.`city` and isnull(`hcs`.`city`)) then 'true' else 'false' end) AS `notify_manager`,
	`h`.`mail_suffix` AS `mail_suffix`,
	`h`.`secondary_mail_suffix` AS `secondary_mail_suffix`,
	(case when `h`.`city` then `hcs`.`itc_mail` else `h`.`itc_mail` end) AS `itc_mail`,
	`h`.`enabled` as `enabled`,
	`h`.`manager_lookup_strategy` as `manager_lookup_strategy`
from (`msh_idm_repo`.`hrbu` `h` left join `msh_idm_repo`.`hrbu_city_street` `hcs` on((`h`.`city` = 1)));

