TRUNCATE msh_idm_repo.hrbu;

LOAD DATA LOCAL INFILE "hrbu.csv" INTO TABLE msh_idm_repo.hrbu
COLUMNS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY '' LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS
(@hrbu, @ou, @home_drive, @home_dir, @login_script, @active_sync, @city, @mail_suffix,
@secondary_mail_suffix, @itc_mail, @enabled, @manager_lookup_strategy, @groups, @contractor_groups, @contingentworkertype_outside_worker_groups, @contingentworkertype_x_groups)
SET 
	`hrbu`=IF(@hrbu="NULL", NULL, @hrbu),
	`ou`=IF(@ou="NULL", NULL, @ou),
	`home_drive`=IF(@home_drive="NULL", NULL, @home_drive),
	`home_dir`=IF(@home_dir="NULL", NULL, @home_dir),
	`login_script`=IF(@login_script="NULL", NULL, @login_script),
	`groups`=IF(@groups="NULL", NULL, @groups),
	`contractor_groups`=IF(@contractor_groups="NULL", NULL, @contractor_groups),
	`contingentworkertype_outside_worker_groups`=IF(@contingentworkertype_outside_worker_groups="NULL", NULL, @contingentworkertype_outside_worker_groups),
	`contingentworkertype_x_groups`=IF(@contingentworkertype_x_groups="NULL", NULL, @contingentworkertype_x_groups),
	`active_sync`=IF(@active_sync="NULL", NULL, @active_sync),
	`city`=IF(@city="NULL", NULL, @city),
	`mail_suffix`=IF(@mail_suffix="NULL", NULL, @mail_suffix),
	`secondary_mail_suffix`=IF(@secondary_mail_suffix="NULL", NULL, @secondary_mail_suffix),
	`itc_mail`=IF(@itc_mail="NULL", NULL, @itc_mail),
	`enabled`=IF(@enabled="NULL", NULL, @enabled),
	`manager_lookup_strategy`=IF(@manager_lookup_strategy="NULL", NULL, @manager_lookup_strategy);

TRUNCATE msh_idm_repo.hrbu_city_street;

LOAD DATA LOCAL INFILE "hrbu_city_street.csv" INTO TABLE msh_idm_repo.hrbu_city_street
COLUMNS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY '' LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS
(@id, @city, @street, @ou, @home_drive, @home_dir, @login_script, @active_sync, @itc_mail, @groups, @contractor_groups, @contingentworkertype_outside_worker_groups, @contingentworkertype_x_groups)
SET 
	`id`=IF(@id="NULL", NULL, @id),
	`city`=IF(@city="NULL", NULL, @city),
	`street`=IF(@street="NULL", NULL, @street),
	`ou`=IF(@ou="NULL", NULL, @ou),
	`home_drive`=IF(@home_drive="NULL", NULL, @home_drive),
	`home_dir`=IF(@home_dir="NULL", NULL, @home_dir),
	`login_script`=IF(@login_script="NULL", NULL, @login_script),
	`groups`=IF(@groups="NULL", NULL, @groups),
	`contractor_groups`=IF(@contractor_groups="NULL", NULL, @contractor_groups),
	`contingentworkertype_outside_worker_groups`=IF(@contingentworkertype_outside_worker_groups="NULL", NULL, @contingentworkertype_outside_worker_groups),
	`contingentworkertype_x_groups`=IF(@contingentworkertype_x_groups="NULL", NULL, @contingentworkertype_x_groups),
	`active_sync`=IF(@active_sync="NULL", NULL, @active_sync),
	`itc_mail`=IF(@itc_mail="NULL", NULL, @itc_mail);

TRUNCATE msh_idm_repo.group_mapping;
LOAD DATA LOCAL INFILE "group_mapping.csv" INTO TABLE msh_idm_repo.group_mapping
COLUMNS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY '' LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS
(@id, @name, @dn, @type)
SET 
	`id`=IF(@id="NULL", NULL, @id),
	`name`=IF(@name="NULL", NULL, @name),
	`dn`=IF(@dn="NULL", NULL, @dn),
	`type`=IF(@type="NULL", NULL, @type);

