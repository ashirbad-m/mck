# Command parameters:
#
# $userName - user name WITHOUT domain specifier
# $linkName - DFS link name
# $computerNames - array of names of the servers that contains DFS share

$code = @"
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Runtime.InteropServices;

	namespace DFSEnumerate
	{
		public static class DFSEnumerate
		{
			const int DFS_LEVEL = 3;

			const int DFS_VOLUME_STATE_OK = 0x00000001;
			const int DFS_STORAGE_STATE_ONLINE = 0x00000002;

			[DllImport("Netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
			public static extern int NetDfsGetInfo
				(
				[MarshalAs(UnmanagedType.LPWStr)] string EntryPath,
				[MarshalAs(UnmanagedType.LPWStr)] string ServerName,
				[MarshalAs(UnmanagedType.LPWStr)] string ShareName,
				int Level,
				ref IntPtr Buffer
				);

			[DllImport("Netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
			public static extern int NetApiBufferFree(IntPtr Buffer);

			#pragma warning disable 0649
			public struct DFS_INFO_3
			{
				[MarshalAs(UnmanagedType.LPWStr)]
				public string EntryPath;
				[MarshalAs(UnmanagedType.LPWStr)]
				public string Comment;
				public UInt32 State;
				public UInt32 NumberOfStorages;
				public IntPtr Storages;
			}

			public struct DFS_STORAGE_INFO
			{
				public Int32 State;
				[MarshalAs(UnmanagedType.LPWStr)]
				public string ServerName;
				[MarshalAs(UnmanagedType.LPWStr)]
				public string ShareName;
			}
			#pragma warning restore 0649

			public static string[] EnumerateActiveShares(string dfsLinkName)
			{
				List<string> result = new List<string>();

				IntPtr pBuffer = new IntPtr();
				int iResult = NetDfsGetInfo(dfsLinkName, null, null, DFS_LEVEL, ref pBuffer);
				if (iResult == 0)
				{
					DFS_INFO_3 oDFSInfo = (DFS_INFO_3)Marshal.PtrToStructure(pBuffer, typeof(DFS_INFO_3));

					if (oDFSInfo.State == DFS_VOLUME_STATE_OK)
					{
						for (int i = 0; i < oDFSInfo.NumberOfStorages; i++)
						{
							IntPtr pStorage = new IntPtr(oDFSInfo.Storages.ToInt64() + i * Marshal.SizeOf(typeof(DFS_STORAGE_INFO)));
							DFS_STORAGE_INFO oStorageInfo = (DFS_STORAGE_INFO) Marshal.PtrToStructure(pStorage, typeof(DFS_STORAGE_INFO));

							if (oStorageInfo.State == DFS_STORAGE_STATE_ONLINE)
							{
								string share = "\\\\" + oStorageInfo.ServerName + "\\" + oStorageInfo.ShareName;
								result.Add(share);
							}
						}
					}

					if (pBuffer != IntPtr.Zero)
					{
						NetApiBufferFree(pBuffer);
					}
				}
				else
				{
					throw new Exception("Error obtaining DFS info: " + iResult);
				}

				return result.ToArray();
			}
		}
	}
"@


function Forced-Remove-Item($targetPath) {
    $numberOfRetry = 5;
	$waitBeforeRetry = 3;

    $currentRetry = 0;
    $success = $false;
    do {
        try
        {

			If (Test-Path $targetPath){
  		   & Remove-Item $targetPath -Force -ErrorAction Stop -Recurse:$true -Confirm:$false;
			  Write-Debug "Successfully removed [$targetPath]. Number of entries: $currentRetry";
			}Else{
			  Write-Debug "Item does  not exists! [$targetPath]";
			}
            $success = $true;

        }
        catch [System.Exception]
        {
            $message = 'Exception occurred while trying to remove item [$targetPath]:' + $_.Exception.ToString();
            Write-Error $message;
            if ($currentRetry -gt $numberOfRetry) {
                $message = "Can not remove item  [$targetPath] after [$numberOfRetry] retries : " + $_.Exception.ToString();
                throw $message;
            } else {
                Write-Debug "Sleeping before $currentRetry retry to remove item [$targetPath]";
                Start-Sleep -s $waitBeforeRetry;
            }
            $currentRetry = $currentRetry + 1;
        }
    } while (!$success);
}


try {
	$ErrorActionPreference = "Stop";
	$Error.clear();

	if ($userName -eq $null -or $userName.length -eq 0)
	{
		throw "Undefined userName!";
	}


	#get first working server from array
	foreach ($s in $computerNames)
	{
		Write-Debug("Checking Exchange server: $s");
		if (Test-Connection -ComputerName $s -quiet -count 1)
		{
			Write-Debug("Server $s is available");
			$computerName = $s;
			break;
		}
		else
		{
			Write-Debug("Server $s is not available");
		}
	}
	##another way to get working server with the minimal ping time
	## $computerName = $(Test-Connection -count 1 -ComputerName $computerNames  -ErrorAction SilentlyContinue | sort ResponseTime)[0].Address

	if ($computerName -eq $null -or $computerName.length -eq 0)
	{
		throw "Server Not Found!";
	}

	$refs = @("System.Core")

	if (-not ([System.Management.Automation.PSTypeName]'DFSEnumerate.DFSEnumerate').Type)
	{
		Add-Type -ReferencedAssemblies $refs -TypeDefinition $code -Language CSharp
	}

	$targets = [DFSEnumerate.DFSEnumerate]::EnumerateActiveShares("\\$computerName\$linkName");

	if ($targets -eq $null -or $targets.count -eq 0)
	{
		throw "No active DFS link has been found!";
	}

	$errorMessage = "";

	foreach ($target in $targets)
	{
		if ($target -eq $null -or $target.length -eq 0)
		{
			continue;
		}

		foreach ($childDirectory in @($userName, ($userName + ".V2")))
		{
			try
			{
				$targetPath = "$target\$childDirectory"
				if (Test-Path $targetPath)
				{
					Write-Debug("Deleting $targetPath");
					Forced-Remove-Item($targetPath);
					Write-Debug("Deleted $targetPath");
				}
				else
				{
					Write-Debug("Path $targetPath does not exist");
				}
			}
			catch
			{
				Write-Debug("ERROR: " + $_.ToString() + $_.InvocationInfo.PositionMessage);
				$errorMessage = $errorMessage + "`n" + $_.ToString() + $_.InvocationInfo.PositionMessage;
			}
		}
	}

	if ($errorMessage.length -eq 0)
	{
		Write-Output("Success");
	}
	else
	{
		throw $errorMessage;
	}
}
catch {
    throw "ERROR: " + $error[0].ToString() + $error[0].InvocationInfo.PositionMessage;
}
