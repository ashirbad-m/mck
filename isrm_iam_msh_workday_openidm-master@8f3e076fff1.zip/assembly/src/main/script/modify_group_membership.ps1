# Command parameters:
#
# $user - user dn
# $groupsToAdd - groups to add user to
# $groupsToRemove - groups to remove user from
# $server - AD DC to use

function escapeDNForPath($dn)
{
    # https://social.technet.microsoft.com/wiki/contents/articles/5312.active-directory-characters-to-escape.aspx#ADSI
    # ADSI requires that the forward slash character "/" also be escaped in distinguished names.
    # The ten characters in the table at the top of this page, plus the forward slash, must be escaped in most scripts where
    # distinguished names are used to bind to objects in Active Directory.
    return $dn -replace "/", "\/"
}

function getADSIObject($dc, $dn)
{
    $escapedDC = escapeDNForPath $dc
    $escapedDN = escapeDNForPath $dn

    $objectPath = [string]::Format("LDAP://{0}/{1}", $escapedDC, $escapedDN)

    return [adsi]$objectPath
}

try {
    $ErrorActionPreference = "Stop";
    $Error.clear();

    $userObject = getADSIObject -dc $server -dn $user

    foreach ($group in $groupsToAdd)
    {
        $groupServer = $group.Get_Item("server")
        $groupDN = $group.Get_Item("dn")
        $groupObject = getADSIObject -dc $groupServer -dn $groupDN

        if (-not $groupObject.IsMember($userObject.ADsPath))
        {
            $groupObject.Add($userObject.ADsPath) | Out-Null
        }
    }

    foreach ($group in $groupsToRemove)
    {
        $groupServer = $group.Get_Item("server")
        $groupDN = $group.Get_Item("dn")
        $groupObject = getADSIObject -dc $groupServer -dn $groupDN

        if ($groupObject.IsMember($userObject.ADsPath))
        {
            $groupObject.Remove($userObject.ADsPath) | Out-Null
        }
    }

    Write-Output("Success")
}
catch {
    throw "ERROR: " + $error[0].ToString() + $error[0].InvocationInfo.PositionMessage;
}

