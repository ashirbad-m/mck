/* globals request: false */

load.call(this, "script/info/infoSyncUtil.js");
InfoSyncUtil.reconCheck(request.params);
