/* globals request: false */
/* globals healthinfo: false */

load.call(this, "script/common/config.js");
load.call(this, "script/common/util.js");

(function() {
    var result = {};

    if (request.parent.path == "/openidm/info/adcheck") {
        Util.apply(Config.getDomainConfigurations(), function(configuration) {
            Util.apply(configuration.workersOU, function(ou) {
                var data = openidm.read("system/" + configuration.name + "/organizationalUnit/" + ou) || {};
                if (!data.__NAME__ || data.__NAME__.toLowerCase() != ou.toLowerCase()) {
                    throw "Failed: " + ou;
                }
            });
        });

        result.ad ="Ok";
    } else if(request.parent.path == "/openidm/info/idmcheck") {
        var data = healthinfo;

        if (data.state && data.state == "ACTIVE_READY") {
            result.idm ="Ok";
        } else {
            result.idm ="Failed";
        }
    }

    return result;
}());

