/* globals request: false */
/* globals com: false */

InfoSyncUtil = (
    function(){
        return {

            _result: function (resourceName, state, desc) {
                var res = {
                    "state": state ? "SUCCESS" : "FAILED",
                    "shortDesc": resourceName + ": " + desc
                };
                if (state) {
                    logger.info("InfoSync-check-good-result: {}", res);
                } else {
                    logger.error("InfoSync-check-wrong-result: {}", res);
                }
                return res;
            },

            failedResult: function(resourceName, message){
                return InfoSyncUtil._result(resourceName, false, message || "failed");
            },

            successResult: function(resourceName) {
                return InfoSyncUtil._result(resourceName, true, "success");
            },

            notStartedResult: function(resourceName) {
                return InfoSyncUtil._result(resourceName, false, "not started");
            },

            notFinishedResult: function(resourceName, ok) {
                return InfoSyncUtil._result(resourceName, ok, "not finished");
            },

            _checkRequest: function(resourceName) {
                if (request.method !== "query") {
                    throw "Unsupported operation on check service: " + request.method;
               }

               if((!resourceName) || resourceName.length == 0){
                    throw "Resource-name not found";
               }
            },

            reconCheck: function(parameters){
                var resourceName = parameters.mapping;
                InfoSyncUtil._checkRequest(resourceName);

                var result;

                try{

                    var queryParameters = {
                        "mapping": resourceName,
                        "_queryId": "audit-last-date-recon"
                    };

                    if (
                        !(
                            parameters &&
                            parameters.times &&
                            parameters.duration
                        )
                    ) {
                        throw "times & duration not found";
                    }

                    var info = com.mckesson.ScriptUtil.nearestReconInfo(parameters.times, parameters.duration);

                    logger.debug("nearestReconInfo ({}): date={} / isShouldBeFinish={}", resourceName, info.getStartDate(), info.isShouldBeFinish());

                    queryParameters.date = info.getStartDate();
                    logger.debug("reconCheck: queryParameters is: {}", queryParameters);

                    result = openidm.query("managed/auditrecon", queryParameters);
                    if (!(result && result.result && result.result.length != 0)) {
                        return InfoSyncUtil.notStartedResult(resourceName);
                    }

                    result = result.result[0];

                    if(result.entryType != "summary"){
                        return InfoSyncUtil.notFinishedResult(resourceName, !info.isShouldBeFinish());
                    }

                    if (result.status == "SUCCESS"){
                        return InfoSyncUtil.successResult(resourceName);
                    }
                    result = InfoSyncUtil.failedResult(resourceName);
                }catch(ex){
                    logger.error("reconCheck-check-exception: {}/{}", resourceName, ex);
                    result = InfoSyncUtil.failedResult(resourceName, ex.message || ex);
                }

                return result;
            }
        };
    }()
);