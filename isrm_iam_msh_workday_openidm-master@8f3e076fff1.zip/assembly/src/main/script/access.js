var httpAccessConfig =
{
    "configs" : [
        {
           "pattern"    : "info/*",
           "roles"      : "openidm-admin",
           "methods"    : "read,query",
           "actions"    : "*"
        },
        {
            "pattern"    : "endpoint/workdayToUson",
            "roles"      : "openidm-admin",
            "methods"    : "read,query,action",
            "actions"    : "*"
        },
        {
             "pattern"    : "endpoint/testRemedyforceIncidents",
             "roles"      : "openidm-admin",
             "methods"    : "read,query,action",
             "actions"    : "*"
        },
        {
            "pattern"    : "endpoint/oktaBlackList",
            "roles"      : "openidm-admin",
            "methods"    : "read,query,action",
            "actions"    : "*"
        }
    ]
};

// Additional custom authorization functions go here

