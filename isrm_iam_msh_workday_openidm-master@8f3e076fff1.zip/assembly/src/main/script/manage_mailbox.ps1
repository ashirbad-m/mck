# Requires Exchange administrator privileges
#
# Command parameters:
#
# $office365AddressSuffix - address suffix to use for O365
# $exchangeServers - array of Exchange servers to be used
# $action - name of the action to execute
# $userName - user name in the format DOMAIN\USER
# $mailNickname - Exchange mailbox identifier
# $mail - e-mail to set for the user
# $mails - e-mails to set for the user as secondary
# $server - AD DC to use

try {
    $ErrorActionPreference = "Stop";
    $Error.clear();

    Import-Module InvokeInExchangeSession -Force -Global

    [string[]] $requiredCommands = @(
        'Disable-RemoteMailbox',
        'Disable-Mailbox',
        'Enable-Mailbox',
        'Enable-RemoteMailbox',
        'Set-CASMailbox',
        'Set-Mailbox',
        'Set-RemoteMailbox',
        'Get-MobileDevice',
        'Get-MobileDeviceStatistics',
        'Remove-MobileDevice'
    );

    Invoke-InExchangeOnPremSession -Servers $exchangeServers -Commands $requiredCommands -ScriptBlock {
        $sAMAccountName = $userName.split('\')[1]

        switch ($action)
        {
            "enable"
            {
                Write-Debug("Enable mailbox for $userName");
                Enable-Mailbox -ErrorAction Stop -Identity $userName -PrimarySmtpAddress $mail -DomainController $server | Out-Null
                Set-CASMailbox -ErrorAction Stop -Identity $userName -ActiveSyncEnabled $false -PopEnabled $false -ImapEnabled $false -DomainController $server | Out-Null
                Write-Debug("Mailbox for $userName has been enabled");

                break;
            }

            "enableRemote"
            {
                Write-Debug("Enable remote mailbox for $userName");
                $remoteRoutingAddress = $sAMAccountName + "@" + $office365AddressSuffix
                Enable-RemoteMailbox -ErrorAction Stop -Identity $userName -PrimarySmtpAddress $mail -RemoteRoutingAddress $remoteRoutingAddress -DomainController $server | Out-Null
                Write-Debug("Mailbox for $userName has been enabled");

                break;
            }

            "disable"
            {
                Write-Debug("Disable mailbox for $userName");
                Disable-Mailbox -ErrorAction Stop -Identity $userName -Confirm:$false -DomainController $server | Out-Null
                Write-Debug("Mailbox for $userName has been disabled");

                break;
            }

            "disableRemote"
            {
                Write-Debug("Disable remote mailbox for $userName");
                # TODO - should we remove EOL license first?
                # https://docs.microsoft.com/en-us/powershell/module/exchange/federation-and-hybrid/disable-remotemailbox?view=exchange-ps
                Disable-RemoteMailbox -ErrorAction Stop -Identity $userName -Confirm:$false -DomainController $server | Out-Null
                Write-Debug("Mailbox for $userName has been disabled");

                break;
            }

            "setPrimaryEmail"
            {
                Write-Debug("Setting $mail as PrimaryEmailAddress for $userName");
                Set-Mailbox -ErrorAction Stop -Identity $userName -Confirm:$false -PrimarySmtpAddress $mail -DomainController $server | Out-Null
                Write-Debug("PrimaryEmailAddress for $userName was set to $mail");

                break;
            }

            "setPrimaryEmailRemote"
            {
                Write-Debug("Setting $mail as PrimaryEmailAddress for $userName");
                Set-RemoteMailbox -ErrorAction Stop -Identity $userName -Confirm:$false -PrimarySmtpAddress $mail -DomainController $server | Out-Null
                Write-Debug("PrimaryEmailAddress for $userName was set to $mail");

                break;
            }

            "setSecondaryEmail"
            {
                foreach ($mail in $mails) {
                    Write-Debug("Setting $mail as SecondaryEmailAddress for $userName");
                    Set-Mailbox -ErrorAction Stop -Identity $userName -Confirm:$false -EmailAddresses @{Add=$mail} -DomainController $server | Out-Null
                    Write-Debug("SecondaryEmailAddress for $userName was set to $mail");
                }
                break;
            }

            "setSecondaryEmailRemote"
            {
                foreach ($mail in $mails) {
                    Write-Debug("Setting $mail as SecondaryEmailAddress for $userName");
                    Set-RemoteMailbox -ErrorAction Stop -Identity $userName -Confirm:$false -EmailAddresses @{Add=$mail} -DomainController $server | Out-Null
                    Write-Debug("SecondaryEmailAddress for $userName was set to $mail");
                }
                break;
            }

            "hideFromAddressLists"
            {
                Write-Debug("hidden from address lists $mail for $userName");
                Set-Mailbox -ErrorAction Stop -Identity $userName -HiddenFromAddressListsEnabled $true -DomainController $server

                break;
            }

            "hideFromAddressListsRemote"
            {
                Write-Debug("hidden from address lists $mail for $userName");
                Set-RemoteMailbox -ErrorAction Stop -Identity $userName -HiddenFromAddressListsEnabled $true -DomainController $server

                break;
            }

            "showInAddressLists"
            {
                Write-Debug("hidden from address lists $mail for $userName");
                Set-Mailbox -ErrorAction Stop -Identity $userName -HiddenFromAddressListsEnabled $false -DomainController $server

                break;
            }

            "showInAddressListsRemote"
            {
                Write-Debug("hidden from address lists $mail for $userName");
                Set-RemoteMailbox -ErrorAction Stop -Identity $userName -HiddenFromAddressListsEnabled $false -DomainController $server

                break;
            }

            "disableActiveSyncDevice"
            {
                Get-MobileDevice -ErrorAction Stop -Mailbox $mailNickname -DomainController $server | Get-MobileDeviceStatistics -ErrorAction Stop -DomainController $server | Remove-MobileDevice -ErrorAction Stop -Confirm:$false -DomainController $server
                Write-Debug("*MobileDevice* - commands found. Used new interface");

                break;
            }

            default
            {
                throw "Action $action is not supported";
            }
        }

        Write-Output("Success");
    }
}
catch
{
    throw "ERROR: " + $error[0].ToString() + $error[0].InvocationInfo.PositionMessage;
}

