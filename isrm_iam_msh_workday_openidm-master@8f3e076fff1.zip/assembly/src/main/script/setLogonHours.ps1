#
# Command parameters:
#
# $user - user
# $server - AD server name
# $logon- true/false

if (-not (Get-Module ActiveDirectory)){
    Import-Module ActiveDirectory -Cmdlet Rename-ADObject,Get-ADUser,Set-ADUser | Out-Null
}

[byte[]]$allowHours = @(255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255)
[byte[]]$denyHours = @(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)


if ($logon -eq $true)
{
    Get-ADUser -Identity $user -Server $server |
    Set-ADUser -Replace @{logonhours = $allowHours} -Server $server
}
else
{
    Get-ADUser -Identity $user -Server $server |
     Set-ADUser -Replace @{logonhours = $denyHours} -Server $server
}
