# Requires domain administrator privileges
# 
# Command parameters:
#
# $userName - user name in the format DOMAIN\USER
# $target - target directory to be created. It must be UNC path, otherwise owner can't be changed


try {
	$ErrorActionPreference = "Stop";
	$Error.clear();
	
	$split = $userName.split('\');
	$domain = $split[0];
	$user = $split[1];

	$userIdentity = New-Object System.Security.Principal.NTAccount($domain, $user);

	New-Item -ErrorAction Stop -Path $target -ItemType directory | out-null;

	$targetAcl = Get-Acl -ErrorAction Stop $target;

	#Remove inheritance
	$targetAcl.SetAccessRuleProtection($True, $False);

	$fullControlUsers = @();
	$fullControlUsers += New-Object System.Security.Principal.NTAccount("NT AUTHORITY", "SYSTEM");
	$fullControlUsers += New-Object System.Security.Principal.NTAccount($domain, "Domain Admins");
	$fullControlUsers += New-Object System.Security.Principal.NTAccount($domain, "Administrators_G");
	$fullControlUsers += New-Object System.Security.Principal.NTAccount($domain, "Security Admins");

	$changeUsers = @();
	$changeUsers += $userIdentity;

	Write-Debug("Waiting for replication to complete");
	Start-Sleep -s 30

	foreach ($user in $fullControlUsers) {
	#TBD: show user name in case of failure
		$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($user, "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow");
		$targetAcl.AddAccessRule($accessRule);
	}

	foreach ($user in $changeUsers) {
		$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($user, "Modify", "ContainerInherit, ObjectInherit", "None", "Allow");
		$targetAcl.AddAccessRule($accessRule);
	}

	foreach ($rule in $targetAcl.GetAccessRules($true, $true, [System.Security.Principal.NTAccount])) {
		if ($fullControlUsers -contains $rule.IdentityReference) {
			continue;
		}

		if ($changeUsers -contains $rule.IdentityReference) {
			continue;
		}

		$targetAcl.RemoveAccessRule($rule) | Out-Null;
	}

	$targetAcl.SetOwner($userIdentity);

	Set-Acl -ErrorAction Stop -Path $target -AclObject $targetAcl

	Write-Output("Success");
}
catch {
    throw "ERROR: " + $error[0].ToString() + $error[0].InvocationInfo.PositionMessage;
}



