load.call(this, "script/common/config.js");
load.call(this, "script/common/uson.js");
load.call(this, "script/common/util.js");
load.call(this, "script/common/staging.js");

PShell = (function() {

    var defaultSleepTime = 30;

    var sleepTimeBeforeActions = {
        "enable": defaultSleepTime,
        "enableRemote": defaultSleepTime,
        "setPrimaryEmail": defaultSleepTime,
        "setPrimaryEmailRemote": defaultSleepTime,
        "setSecondaryEmail": defaultSleepTime,
        "setSecondaryEmailRemote": defaultSleepTime
    };

    var isO365Mailbox = function(trg) {
        return trg.msExchRecipientTypeDetails && trg.msExchRecipientTypeDetails == Config.REMOTE_MAILBOX_VALUE;
    };

    var paramEnhancers = {

        generic: function(params) {
            var domain = params.domain;

            return {
                server: Uson.getServerName(domain)
            };
        },

        exchange: function(params) {
            var domain = params.domain;

            return {
                server: Uson.getServerName(domain),
                exchangeServers: Config.getExchangeServers(domain),
                office365AddressSuffix: Config.getOffice365AddressSuffix(domain)
            };
        },

        o365: function(params) {
            var domain = params.domain;

            return {
                url: Config.getOffice365Url(domain),
                credentialAddress: Config.getOffice365CredentialsAddress(domain)
            };
        }

    };

    var invokePowershell = function(scriptId, params, paramEnhancer) {
        var result = {scriptId: scriptId};

        var lock = Staging.getSynchronizationLock();
        try {
            var sleepTime = sleepTimeBeforeActions[params.action];
            if (sleepTime > 0) {
                if (!isDryRunMode()) {
                    java.lang.Thread.sleep(sleepTime * 1000);
                }
            }

            lock.lock();

            if (!params.domain) {
                throw "Domain is missing";
            }

            result.psparams = Util.mergeRecursive(Util.mergeRecursive({}, params), paramEnhancer(params));
            var psparams = Util.mergeRecursive({}, result.psparams);

            psparams._action = "script";
            psparams._scriptId = scriptId;

            if (!isDryRunMode()) {
                var psresponse = openidm.action("system/" + params.domain + "/account", psparams);
                if (psresponse.actions[0].error) {
                    throw psresponse.actions[0].error;
                }
                result.psresponse = psresponse;
            }
        } catch (e) {
            result.errorMessage = e;
            logger.debug("  On execution powershell script => {} {}", scriptId, params);
        } finally {
            lock.unlock();
        }

        return result;
    };

    return {
        createMail : function(params, data) {
            logger.debug("  PShell.createMail => ");
            var domain = data.provisioner;
            var psparams = {
                "domain": domain,
                "userName" : domain + "\\" + data.sAMAccountName,
                "action" : "enable",
                "mail" : data.mail
            };
            var result = invokePowershell("ManageMailbox", psparams, paramEnhancers.exchange);
            Managed.createAuditRecord(params, "PShell.createMail", result, result.errorMessage);
            return result;
        },

        createRemoteMail : function(params, data) {
            logger.debug("  PShell.createRemoteMail => ");
            var domain = data.provisioner;
            var psparams = {
                "domain": domain,
                "userName" : domain + "\\" + data.sAMAccountName,
                "action" : "enableRemote",
                "mail" : data.mail
            };
            var result = invokePowershell("ManageMailbox", psparams, paramEnhancers.exchange);
            Managed.createAuditRecord(params, "PShell.createRemoteMail", result, result.errorMessage);
            return result;
        },

        setCAS : function(params, data) {
            logger.debug("  PShell.setCAS => ");
            var domain = data.provisioner;

            var psparams = {
                "domain": domain,
                "userPrincipalName": data.userPrincipalName,
                "action" : "setCAS"
            };
            var result = invokePowershell("ManageO365Mailbox", psparams, paramEnhancers.o365);
            Managed.createAuditRecord(params, "PShell.setCAS", result, result.errorMessage);
            return result;
        },

        setPrimaryMail : function(params, data) {
            logger.debug("  PShell.setPrimaryMail => ");
            var domain = data.provisioner;
            var psparams = {
                "domain": domain,
                "userName" : domain + "\\" + data.sAMAccountName,
                "action" : isO365Mailbox(data) ? "setPrimaryEmailRemote" : "setPrimaryEmail",
                "mail" : data.mail
            };
            var result = invokePowershell("ManageMailbox", psparams, paramEnhancers.exchange);
            Managed.createAuditRecord(params, "PShell.setPrimaryEmail", result,
                    result.errorMessage);
            return result;
        },

        setSecondaryMail : function(params, data) {
            logger.debug("  PShell.setSecondaryMail => ");
            var domain = data.provisioner;
            var mails = [];
            if(data.secondaryMail){
                mails.push(data.secondaryMail);
            }
            if(data.secondaryMailAdditional){
                mails.push(data.secondaryMailAdditional);
            }
            var psparams = {
                "domain": domain,
                "userName" : domain + "\\" + data.sAMAccountName,
                "action" : isO365Mailbox(data) ? "setSecondaryEmailRemote" : "setSecondaryEmail",
                "mails" : mails
            };
            var result = invokePowershell("ManageMailbox", psparams, paramEnhancers.exchange);
            Managed.createAuditRecord(params, "PShell.setSecondaryEmail", result,
                    result.errorMessage);
            return result;
        },

        hideFromAddressLists : function(params, data) {
            logger.debug("  PShell.hideFromAddressLists => ");
            var domain = data.provisioner;
            var psparams = {
                "domain": domain,
                "userName" : domain + "\\" + data.sAMAccountName,
                "action" : isO365Mailbox(data) ? "hideFromAddressListsRemote" : "hideFromAddressLists",
                "mail" : data.mail
            };
            var result = invokePowershell("ManageMailbox", psparams, paramEnhancers.exchange);
            Managed.createAuditRecord(params, "PShell.hideFromAddressLists", result,
                    result.errorMessage);
            return result;
        },

        showInAddressLists : function(params, data) {
            logger.debug("  PShell.showInAddressLists => ");
            var domain = data.provisioner;
            var psparams = {
                "domain": domain,
                "userName" : domain + "\\" + data.sAMAccountName,
                "action" : isO365Mailbox(data) ? "showInAddressListsRemote" : "showInAddressLists",
                "mail" : data.mail
            };
            var result = invokePowershell("ManageMailbox", psparams, paramEnhancers.exchange);
            Managed.createAuditRecord(params, "PShell.showInAddressLists", result,
                    result.errorMessage);
            return result;
        },

        deleteMail : function(params, data) {
            logger.debug("  PShell.deleteMail => ");
            var domain = data.provisioner;
            var psparams = {
                "domain": domain,
                "userName" : domain + "\\" + data.sAMAccountName,
                "action" : isO365Mailbox(data) ? "disableRemote" : "disable",
                "mail" : data.mail
            };
            var result = invokePowershell("ManageMailbox", psparams, paramEnhancers.exchange);
            Managed.createAuditRecord(params, "PShell.deleteMail", result,
                    result.errorMessage);
            return result;
        },

        disableActiveSyncDevice : function(params, data) {
            logger.debug("  PShell.disableActiveSyncDevice => ");
            var domain = data.provisioner;
            var o365Mailbox = isO365Mailbox(data);

            var action = o365Mailbox ? "disableActiveSyncDeviceInO365" : "disableActiveSyncDevice";
            var scriptId = o365Mailbox ? "ManageO365Mailbox" : "ManageMailbox";
            var paramEnhancer = o365Mailbox ? paramEnhancers.o365 : paramEnhancers.exchange;

            var psparams = {
                "domain": domain,
                "action" : action
            };

            if (o365Mailbox) {
                psparams = Util.mergeRecursive(psparams, {
                    "userPrincipalName": data.userPrincipalName
                });
            } else {
                psparams = Util.mergeRecursive(psparams, {
                    "userName" : domain + "\\" + data.sAMAccountName,
                    "mailNickname" : data.mailNickname
                });
            }

            var result = invokePowershell(scriptId, psparams, paramEnhancer);
            Managed.createAuditRecord(params, "PShell.disableActiveSyncDevice", result,
                    result.errorMessage);
            return result;
        },

        createHome : function(params, data) {
            logger.debug("  PShell.createHome => ");
            var domain = data.provisioner;
            var psparams = {
                "domain": domain,
                "userName" : domain + "\\" + data.sAMAccountName,
                "target" : data.homeDirectory
            };
            var result = invokePowershell("SetHomeDirectory", psparams, paramEnhancers.generic);
            Managed.createAuditRecord(params, "PShell.createHome", result,
                    result.errorMessage);
            return result;
        },

        archiveHome : function(params, data) {
            logger.debug("  PShell.archiveHome => ");
            var domain = data.provisioner;
            var psparams = {
                "domain": domain,
                "source" : data.homeDirectory,
                "target" : data.archivedHomeDirectory
            };
            var result = invokePowershell("MoveItem", psparams, paramEnhancers.generic);
            Managed.createAuditRecord(params, "PShell.archiveHome", result,
                    result.errorMessage);
            return result;
        },

        deleteTerminalServerProfile : function(params, data) {
            logger.debug("  PShell.deleteTerminalServerProfile => ");
            var domain = data.provisioner;
            var dfsSservers = Config.getDFSServers(domain);

            if (!dfsSservers || dfsSservers.length == 0) {
                return;
            }

            var psparams = {
                "domain": domain,
                "userName" : data.sAMAccountName,
                "linkName" : Uson.USER_PROFILE_LOCATION + data.sAMAccountName.charAt(0),
                "computerNames" : dfsSservers
            };

            var result = invokePowershell("DeleteDFSDirectories", psparams, paramEnhancers.generic);
            Managed.createAuditRecord(params,
                    "PShell.deleteTerminalServerProfile", result,
                    result.errorMessage);
            return result;
        },

        setLogonHours : function(params, logon, data) {
            logger.debug("  PShell.setLogonHours => ");
            var domain = data.provisioner;
            var psparams = {
                "domain": domain,
                "user" : data.sAMAccountName,
                "logon" : logon
            };
            var result = invokePowershell("SetLogonHours", psparams, paramEnhancers.generic);
            Managed.createAuditRecord(params, "PShell.setLogonHours", result,
                    result.errorMessage);
            return result;
        },

        nameChange : function(params, dn, newName, data) {
            logger.debug("  PShell.nameChange => ");
            var domain = data.provisioner;
            var psparams = {
                "domain": domain,
                "dn" : dn,
                "newName" : newName
            };
            var result = invokePowershell("NameChange", psparams, paramEnhancers.generic);
            Managed.createAuditRecord(params, "PShell.nameChange", result,
                    result.errorMessage);
            return result;
        },

        modifyGroupMembership: function(params, user, groupsToAdd, groupsToRemove) {
            logger.debug("  PShell.modifyGroupMembership => ");
            var domain = user.provisioner;

            var buildGroupObject = function(dn) {
                return {server: Uson.getServerName(Uson.getDomain(dn)), dn: dn};
            };

            groupsToAdd = Util.apply(groupsToAdd || [], buildGroupObject);
            groupsToRemove = Util.apply(groupsToRemove || [], buildGroupObject);

            var psparams = {
                "domain": domain,
                "user": user.distinguishedName,
                "groupsToAdd": groupsToAdd,
                "groupsToRemove" : groupsToRemove
            };
            var result = invokePowershell("ModifyGroupMembership", psparams, paramEnhancers.generic);
            Managed.createAuditRecord(params, "PShell.modifyGroupMembership", result,
                    result.errorMessage);
            return result;
        }

    };
}());
