load.call(this, "script/handlebars.runtime.js");
load.call(this, "script/templates/templates.js");

var templates = {};

Handlebars.registerHelper('mailto', function(mail, text) {
    var args = [];
    var idx;
    args[0] = "mailto:" + mail;
    if (arguments.length > 2) {
        args[1] = text;
        idx = 2;
    } else {
        args[1] = mail;
        idx = 1;
    }

    for (var i = 2; idx < arguments.length; idx++) {
        args[i++] = arguments[idx];
    }

    return Handlebars.helpers['link'].apply(this, args);
});

Handlebars.registerHelper('link', function(url, text) {
    url  = Handlebars.Utils.escapeExpression(url);

    if (arguments.length > 2) {
        text = Handlebars.Utils.escapeExpression(text);
    } else {
        text = url;
    }

    var result = '<a href="' + url + '">' + text + '</a>';

    return new Handlebars.SafeString(result);
});
Handlebars.registerHelper('define', function(context, options) {
    templates[context] = options.fn;
    return "";
});
Handlebars.registerHelper('execute', function(context, options) {
    return templates[context].call(this, this, options);
});
