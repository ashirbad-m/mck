/* globals Group: false */
/* globals User: false */
/* globals StartJobRequest: false */

importPackage(Packages.com.mckesson.batch.o365.entity);

load.call(this, "script/common/util.js");
load.call(this, "script/common/staging.js");
load.call(this, "script/common/managed.js");
load.call(this, "script/common/uson.js");
load.call(this, "script/common/groupHelper.js");

Office365 = (function() {

    var apiClient = com.mckesson.batch.o365.JobClientFactory.createClient();

    var groupObjectsCache = {};

    var addAll = function(collection, elements) {
        Util.apply(elements, function(element) {
            collection.add(element);
        });
    };

    var convertGroups = function(groups) {
        return Util.filter(Util.apply(groups, function(group) {
            var groupData = groupObjectsCache[group];
            if (!groupData) {
                var groupObject = Uson.findGroupByDN(group);

                if (groupObject) {
                    groupData = toGroupObject(groupObject);
                } else {
                    logger.error("Group not found: {}", group);
                    //special case - missing group, return empty object
                    groupData = {};
                }

                groupObjectsCache[group] = groupData;
            }

            return groupData;
        }), function(group){
            return group instanceof Group;
        });
    };

    var toUserObject = function(trg) {
        var result = new User();

        result.userPrincipalName = trg.originalUserPrincipalName || trg.userPrincipalName || null;
        result.displayName = trg.displayName || null;
        result.mail = trg.mail || null;
        result.employeeId = trg.workerID;
        addAll(result.groups, convertGroups(GroupHelper.getGroups(trg) || []));

        return result;
    };

    var toGroupObject = function(group) {
        var result = new Group();

        result.displayName = group.displayName || null;
        result.onPremisesSecurityIdentifier = group.objectSid;

        return result;
    };

    return {
        startJob: function(params) {
            var errorMessage = "";
            var jobUrl = null;

            try {
                var dryRun = params.isDryRun;

                var users = [];

                if (dryRun) {
                    users = Staging.getRepo().getStoredUsers();
                    users = Util.filter(users, function(user) {
                        //pass only users that are in scope (i.e. excluding account such as a-accounts) or users that are terminated
                        return Uson.isUserInScope(user) || Uson.isUserTerminated(user);
                    });
                }

                var jobRequest = new StartJobRequest(params.reconId);

                addAll(jobRequest.users, Util.apply(users || [], toUserObject));

                jobUrl = apiClient.startJob(dryRun, jobRequest);
            } catch (e) {
                logger.error("Failed to start O365 job!");
                errorMessage = e.message;
            }

            Managed.createAuditRecord(params, "O365.startJob", {jobUrl: Util.getUrlPathAndQueryPart(jobUrl)}, errorMessage);

            return jobUrl;
        },

        waitForJobCompletion: function(params, jobStatusUrl, timeout) {
            var errorMessage = "";
            var result = null;

            try {
                result = '' + apiClient.waitForJobCompletion(jobStatusUrl, timeout);

                if (result == "FAILURE") {
                    errorMessage = "Failed to wait for O365 job completion";
                }

            } catch (e) {
                logger.error("Failed to wait for O365 job completion! {}", jobStatusUrl);
                errorMessage = e.message;
            }

            Managed.createAuditRecord(params, "O365.waitForJobCompletion", {result: result, jobUrl: Util.getUrlPathAndQueryPart(jobStatusUrl), timeout: timeout}, errorMessage);

            return result;
        }
    };

}());
