com.mckesson.ScriptUtil.setRequestVar("cache", new java.util.concurrent.ConcurrentHashMap());

Cache = (function() {

    return {
        get: function(type, key, producer) {
            var map = com.mckesson.ScriptUtil.getRequestVar("cache");

            var cacheKey = type + "/" + key;

            if (map.containsKey(cacheKey)) {
                return map.get(cacheKey);
            }

            var result = producer(key);
            map.put(cacheKey, result);

            return result;
        }
    };

}());

GroupDescriptionCache = {
    get: function(groupDN, producer) {
        return Cache.get("groupDescription", groupDN, producer);
    }
};
