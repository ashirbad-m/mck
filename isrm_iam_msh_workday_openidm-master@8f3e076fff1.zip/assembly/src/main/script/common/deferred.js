load.call(this, "script/common/config.js");
load.call(this, "script/common/deferredTasksIterator.js");
load.call(this, "script/common/phase.js");

Deferred = (function() {

    var executors = {};

    return {

        registerExecutor: function(name, executor) {
            executors[name] = executor;
        },

        defer: function(name, params) {
            var errorMessage = null;

            var result = {
                name: name,
                sourceId: (params.sourceObject || {})._id,
                targetId: (params.targetObject || {})._id
            };

            try {
                var args = Util.toArray(arguments);
                Managed.createDeferredTask(args);
            } catch (e) {
                errorMessage = e;
                logger.debug("  Deferred.defer => {} {} {}", name, result.sourceId, result.targetId);
            }

            Managed.createAuditRecord(params, "Deferred.defer", result, errorMessage);
        },

        executeAll: function() {
            Phase.create("execute deferred", Phase.iteratorToProducer(new DeferredTasksIterator()), function(task) {
                var taskData = com.mckesson.ScriptUtil.fromJSON(task.data);

                var name = taskData[0];
                var params = taskData[1];

                try {
                    executors[name].apply(this, Util.toArray(taskData).splice(1));
                } catch (e) {
                    Managed.reportFailure(params, "Error invoking deferred action: " + e.message);
                    throw e;
                }
            }).execute();
        }
    };

}());