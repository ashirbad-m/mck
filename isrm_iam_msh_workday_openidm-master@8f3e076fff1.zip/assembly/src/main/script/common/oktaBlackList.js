load.call(this, "script/common/uson.js");
load.call(this, "script/common/util.js");
load.call(this, "script/common/config.js");

OktaBlackList = (function() {

    var UPDATE_URL = "system/" + Config.getWorkdayProvisionerName() + "/__ACCOUNT__/";
    
    var getWorkerID = function(user) {
        return user.workerID;
    };

    var hasEmptyWorkerID = function(user) {
        return !user.workerID;
    };

    var getAllADUsers = function() {
        var adUsers = Uson.queryAllUsersInScope();

        if (!adUsers || adUsers.length == 0) {
            throw "AD users not found";
        }

        return adUsers;
    };

    var arrayToHash = function(users) {
        var result = {};

        Util.apply(users, function(user) {
            var workerID = getWorkerID(user);

            if (!workerID) {
                throw "WorkerID is undefined";
            }

            if (!result[workerID]) {
                result[workerID] = [];
            }

            result[workerID].push(user);
        });

        return result;
    };

    var canonizeValue = function(sourceValue) {
        var sourceValue0 = Util.trim(sourceValue);
        if ((!sourceValue0) || sourceValue0.length == 0) {
            throw "Empty Source Value";
        }
        return sourceValue0;
    };

    var getCurrentTime = function() {
        var now = new java.util.Date();
        var sdf = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
        var tz = java.util.TimeZone.getTimeZone("UTC");
        sdf.setTimeZone(tz);
        return sdf.format(now);
    };

    return {
        addHrbu2BlackList: function (locationPrefix) {
            var locationPrefix0 = canonizeValue(locationPrefix);

            var batchId = java.util.UUID.randomUUID().toString();
            var oidPrefix = "okta_" + batchId;

            logger.warn("#addHrbu2BlackList. oidPrefix = {}", oidPrefix);

            logger.warn("#addHrbu2BlackList. Updating blacklists...");
            openidm.query("managed/user_correlated",{"_queryId": "okta-hrbu-blacklist", "location_prefix" : locationPrefix0, "new_openid" : oidPrefix});
            logger.warn("#addHrbu2BlackList. Updating blacklists finished");


            logger.warn("#addHrbu2BlackList. Get All AD Users...");
            var adUsers = Util.filter(getAllADUsers(), Util.not(hasEmptyWorkerID));
            var adUsersByWorkerID = arrayToHash(adUsers);
            logger.warn("#addHrbu2BlackList. Get All AD Users finished. Count: {}", adUsers.length);

            logger.warn("#addHrbu2BlackList. Ping users for update...");
            var updateUsers = openidm.query("managed/okta_update_blacklist",{"_queryId": "get-new-okta-update-users", "openID" : oidPrefix}).result;
            logger.warn("#addHrbu2BlackList. ===========================");
            logger.warn("#addHrbu2BlackList. Count of users for update: {}", updateUsers.length);
            var createUsers = 0;
            var synchronizeUsers = 0;
            for (var jj = 0; jj < updateUsers.length; jj++) {
                var dbUser = updateUsers[jj];
                var openID = oidPrefix + "_" + getCurrentTime();
                logger.warn("#addHrbu2BlackList. ping {} --- {} --- {} --- {}...", dbUser._id, dbUser.workerID, dbUser.userID, openID);
                var action;
                if (adUsersByWorkerID[getWorkerID(dbUser)]) {
                    action = "SYNCHRONIZE";
                    synchronizeUsers++;
                } else {
                    action = "CREATE";
                    openidm['delete']('managed/okta_update_blacklist/' +  dbUser._id, dbUser._rev);
                    createUsers++;
                }
                openidm.update(UPDATE_URL + dbUser._id, null, {uid: dbUser._id, userID: " " + openID});
                logger.warn("#addHrbu2BlackList. ping for {} {} finished", action, dbUser._id);
            }
            logger.warn(
                "#addHrbu2BlackList. Ping users for update finished. Count of pings (COUNT = CREATE + SYNCHRONIZE): {} = {} + {}",
                createUsers + synchronizeUsers, createUsers, synchronizeUsers
            );
            logger.warn("#addHrbu2BlackList. ===========================");

        },
        isOktaUpdateBlackListed: function (uid) {
            var objectid = canonizeValue(uid);
            var res = openidm.query("managed/okta_update_blacklist",{"_queryId": "is-okta-update-blacklisted", "objectid" : objectid}).result;
            return res[0]._id !== "0";
        },
        isOktaCreateBlackListed: function (location) {
            var location0 = canonizeValue(location);
            var res = openidm.query("managed/okta_create_blacklist",{"_queryId": "is-okta-create-blacklisted", "location" : location0}).result;
            return res[0]._id !== "0";
        }
    };
}());
