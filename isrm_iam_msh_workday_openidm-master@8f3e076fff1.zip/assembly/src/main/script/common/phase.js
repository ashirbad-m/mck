load.call(this, "script/common/arrayIterator.js");

Phase = (function() {

    var getNumberOfThreads = function() {
        return parseInt(identityServer.getProperty("com.mckesson.JavaScript.asyncThreadsNumber"), 10);
    };

    return {

        create: function(name, producer, consumer) {
            return new com.mckesson.Phase(name, getNumberOfThreads(), producer, consumer);
        },

        abort: function() {
            com.mckesson.Phase.abort();
        },

        arrayToProducer: function(items) {
            return new JavaAdapter(java.util.Iterator, new ArrayIterator(items || []));
        },

        iteratorToProducer: function(iterator) {
            return new JavaAdapter(java.util.Iterator, iterator);
        }

    };

} ());