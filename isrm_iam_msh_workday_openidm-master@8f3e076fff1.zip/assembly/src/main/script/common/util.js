Util = (function() {

    //remove all whitespace chars
    function normalizeValue(value) {
        value = value || '';
        var normalizedValue = value.toLowerCase().replace(/\s/g, '');
        return normalizedValue;
    }

    function isObject(e) {
        return !!e && Object.prototype.toString.call(e) === "[object Object]";
    }

    function isEqual(a, b) {
        for(var p in a){
            var av = a[p], bv = b[p];
            //recursion
            if (isObject(av) || isObject(bv) ) {
                if (Util.compare(av,bv) !== true){
                    return false;
                }
            } else { //simple comparisons
                if(a[p] !== b[p]){
                    return false;
                }
            }
        }
        return true;
    }

    return {

        buildArrayDiff: function(oldValue, newValue) {
            var toString = function(o) { return String(o).toLowerCase(); };
            oldValue = Util.apply(Util.toArray(oldValue), toString);
            newValue = Util.apply(Util.toArray(newValue), toString);

            oldValue.sort();
            newValue.sort();

            var result = {
                added: [],
                removed: [],
                unchanged: []
            };

            if (oldValue.length == 0 || newValue.length == 0) {
                return {added: newValue, removed: oldValue, unchanged: []};
            }

            var i = 0;
            var j = 0;

            while (i < oldValue.length && j < newValue.length) {
                var o = oldValue[i];
                var n = newValue[j];

                if (o > n) {
                    result.added.push(n);
                    j++;
                } else if (o < n) {
                    result.removed.push(o);
                    i++;
                } else {
                    result.unchanged.push(n);
                    i++;
                    j++;
                }
            }

            if (i < oldValue.length) {
                result.removed = result.removed.concat(oldValue.slice(i, oldValue.length));
            }

            if (j < newValue.length) {
                result.added = result.added.concat(newValue.slice(j, newValue.length));
            }

            return result;
        },

        isScriptableListOrArray: function(o) {
            if (!o) {
                return false;
            }

            if (String(o) == "[object ScriptableList]") {
                return true;
            }

            if (o.constructor && o.constructor.toString() && o.constructor.toString().indexOf("Array") > -1) {
                return true;
            }

            return false;
        },

        toArray: function(scriptableList) {
            if (!scriptableList) {
                return null;
            }

            var result = [];
            for (var i = 0; i < scriptableList.length; i++) {
                result.push(scriptableList[i]);
            }

            return result;
        },

        asArray: function(scriptableList) {
            if (!scriptableList) {
                return null;
            }

            if (Util.isScriptableListOrArray(scriptableList)) {
                return scriptableList;
            }

            return [scriptableList];
        },

        validateMatch: function(a, b) {
            return normalizeValue(a) == normalizeValue(b);
        },

        validateProperty: function(resourceId, propName, propValue) {
            var param = { "_action" : "validateProperty" },
            value = {},
            result = { "result" : true, "failedPolicyRequirements" : [] },
            failedPolicy;

            value[propName] = propValue;

            failedPolicy = openidm.action("policy/" + resourceId, param, value);

            for (var p in failedPolicy.failedPolicyRequirements) {
                result.result = false;
                result.failedPolicyRequirements.push(failedPolicy.failedPolicyRequirements[p]);
            }

            return result;
        },

        secureRandom: function(n) {
            return java.security.SecureRandom.getInstance("SHA1PRNG").nextInt(n);
        },

        isNestedWithin: function(testedDN, baseDN) {
            var idx = testedDN.lastIndexOf(baseDN);

            if (idx < 0) {
                return false;
            }

            return (idx === 0 || testedDN[idx - 1] == ',') && (idx + baseDN.length) == testedDN.length;
        },

        appendToLdapName: function(dn, type, value) {
            var name = new javax.naming.ldap.LdapName(dn);
            name.add(new javax.naming.ldap.Rdn(type, value));
            return name.toString();
        },

        getParentDN: function(dn) {
            var name = new javax.naming.ldap.LdapName(dn);
            if (name.size() == 0) {
                return null;
            }

            return name.getPrefix(name.size() - 1).toString();
        },

        dnToOU: function(dn) {
            var rdns= new javax.naming.ldap.LdapName(dn).getRdns();
            var ou="";

            for (var itr = rdns.iterator(); itr.hasNext(); ){
                var rdn = itr.next();
                if (rdn.getType().toUpperCase() == "OU"){
                    ou = ou.concat("\\").concat(rdn.getValue());
                }
            }
            return ou;
        },

        dnToRDNValue: function(dn) {
            var ldapName = new javax.naming.ldap.LdapName(dn);
            if (ldapName.size() == 0) {
                return null;
            }

            return ldapName.getRdn(ldapName.size() - 1).getValue();
        },

        getMarket: function(dn) {
            var rdns= new javax.naming.ldap.LdapName(dn).getRdns();
            var market="";
            var index = 0;
            for (var itr = rdns.iterator(); itr.hasNext(); ){
                var rdn = itr.next();
                if (rdn.getType().toUpperCase() == "OU"){
                    index++;
                    market = rdn.getValue();
                    if (index == 2) {
                        return market;
                    }
                }
            }
            return market;
        },

        flatten: function(array) {
            if (!array) {
                return array;
            }

            var result = [];
            var collector = function(array) {
                for (var i = 0; i < array.length; i++) {
                    if (Util.isScriptableListOrArray(array[i])) {
                        collector(array[i]);
                    } else {
                        result.push(array[i]);
                    }
                }
            };

            collector(array);

            return result;
        },

        apply: function(array, processor) {
            if (!array) {
                return array;
            }

            var result = [];

            for (var i = 0; i < array.length; i++) {
                var elt = array[i];
                result.push(processor(elt));
            }

            return result;
        },

        applyAndMerge: function(array, processor) {
            var results = Util.apply(array, processor);
            return Util.flatten(results);
        },

        filter: function(array, predicate) {
            if (!array) {
                return array;
            }

            var result = [];

            for (var i = 0; i < array.length; i++) {
                var elt = array[i];
                if (predicate(elt)) {
                    result.push(elt);
                }
            }

            return result;
        },

        sortByProjection: function(array, projection) {
            var treeMap = new java.util.TreeMap();

            for (var i = 0; i < array.length; i++) {
                var elt = array[i];
                var key = projection(elt) || '';

                treeMap.put(key, elt);
            }

            var result = [];
            var itr = treeMap.values().iterator();
            while (itr.hasNext()) {
                result.push(itr.next());
            }

            return result;
        },

        arrayToHash: function(values, keyExtractor) {
            var result = {};
            for (var i = 0; i < values.length; i++) {
                var value = values[i];

                result[keyExtractor(value)] = value;
            }

            return result;
        },

        has: function(array, predicate) {
            if (!array) {
                return false;
            }

            for (var i = 0; i < array.length; i++) {
                var elt = array[i];
                if (predicate(elt)) {
                    return true;
                }
            }

            return false;
        },

        contains: function(array, val) {
            if (!array) {
                return false;
            }

            for (var i = 0; i < array.length; i++) {
                var elt = array[i];
                if (elt == val) {
                    return true;
                }
            }

            return false;
        },

        createPropertyFilter: function(props) {
            return function(obj) {
                if (!obj) {
                    return obj;
                }

                var result = {};

                for (var i = 0; i < props.length; i++) {
                    var name = props[i];
                    if (obj.hasOwnProperty && obj.hasOwnProperty(name) && obj[name]) {
                        result[name] = obj[name];
                    }
                }

                return result;
            };
        },

        paramString: function(data) {
            if (!data) {
                return null;
            }

            var segments = [];

            for (var key in data) {
                var encodedKey = java.net.URLEncoder.encode(key, 'UTF-8');

                var value = data[key];
                if (value) {
                    segments.push(encodedKey + '=' + java.net.URLEncoder.encode(value, 'UTF-8'));
                } else {
                    segments.push(encodedKey);
                }
            }

            return segments.join('&');
        },

        unique: function(keyExtractor) {
            var result = [];
            var keys = {};

            //keyExtractor is the first argument
            for (var i = 1; i < arguments.length; i++) {
                var array = arguments[i];

                if (!array) {
                    continue;
                }

                for (var j = 0; j < array.length; j++) {
                    var elt = array[j];
                    var eltKey = keyExtractor(elt);

                    if (!eltKey || keys[eltKey]) {
                        continue;
                    }

                    keys[eltKey] = true;
                    result.push(elt);
                }
            }

            return result;
        },

        IdProjection: function(elt) {
            return elt ? elt._id : null;
        },

        NameProjection: function(elt) {
            return elt ? elt.name : null;
        },

        SelfProjection: function(elt) {
            return elt;
        },

        Filters: (function() {

            return {
                or: function(values) {
                    if (values.length == 1) {
                        return values[0];
                    }

                    return {
                        OR: values
                    };
                },

                and: function(values) {
                    if (values.length == 1) {
                        return values[0];
                    }

                    return {
                        AND: values
                    };
                },

                equals: function(field, value) {
                    return {
                        Equals: {
                            field: field,
                            values: [value]
                        }
                    };
                },

                contains: function(field, value) {
                    return {
                        Contains: {
                            field: field,
                            values: [value]
                        }
                    };
                },

                startsWith: function(field, value) {
                    return {
                        StartsWith: {
                            field: field,
                            values: [value]
                        }
                    };
                }
            };
        }()),

        Locks: {
            createLock: function(name) {
                com.mckesson.ScriptUtil.setRequestVar(name, new java.util.concurrent.locks.ReentrantLock());
            },

            getLock: function(name) {
                return com.mckesson.ScriptUtil.getRequestVar(name);
            }
        },

        /**
         * Compares two objects to determine if they are identical.
         * @param {Object} o1
         * @param {Object} o2
         * @return Boolean
         * @link http://www.sencha.com/forum/showthread.php?59240-Compare-javascript-objects
         */
        compare: function(o1, o2){
            //can't use json encoding in case objects contain functions - recursion will fail

            //can't compare non-objects
            if (!(isObject(o1) && isObject(o2))) {
                return false;
            }

            if (isEqual(o1,o2) !== true) {
                return false;
            }

            if (isEqual(o2,o1) !== true) {
                return false;
            }

            return true;
        },

        proxy: function(callback, context) {
            var proxyFunc = function() {
                callback(context);
            };

            return proxyFunc;
        },

        workdayDateShift: function(workdayDate, daysToShift) {
            //expecting date as "2013-12-16"
            if (!workdayDate) {
                return null;
            }

						var parts = workdayDate.split('-');
						var wdd = new Date(+parts[0], parts[1]-1 , parts[2]);
											wdd.setDate(wdd.getDate() + daysToShift);

            return wdd;
        },

        currentDateShift: function(daysToShift) {
            var result = new Date();
            result.setHours(0, 0, 0);
            result.setDate(result.getDate() + daysToShift);
            return result;
        },

        daysDifference: function(date1, date2) {
            date1 = new Date(date1);
            date2 = new Date(date2);

            date1.setHours(0, 0, 1, 0);
            date2.setHours(0, 0, 0, 0);

            return Math.floor(((date1 - date2)/(1000*60*60*24)).toString());
        },

        mergeRecursive : function (obj1, obj2) {
            //http://jsperf.com/merge-objects-vs-jquery-externd/3
            for (var p in obj2) {
                try {
                    // Property in destination object set; update its value.
                    if (obj2[p] && obj2[p].constructor==Object ) {
                        obj1[p] = Util.mergeRecursive(obj1[p], obj2[p]);
                    } else {
                        obj1[p] = obj2[p];
                    }
                } catch(e) {
                    // Property in destination object not set; create it and set its value.
                    obj1[p] = obj2[p];
                }
            }
            return obj1;
        },

        isEmpty : function(obj) {
            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    return false;
                }
            }

            return true;
        },

        differ: function(a, b) {
            if (a == b) {
                return false;
            }

            if ((a == null || typeof a == "undefined" || a === "") && (b == null || typeof b == "undefined" || b === "")) {
                return false;
            }

            return true;
        },

        buildDiffObject: function(obj, newProps) {
            var result = {};
            obj = obj || {};
            for (var name in newProps) {
                var oldValue = obj[name];
                var newValue = newProps[name];

                if (oldValue !== newValue) {
                    if ("groups" == name && Util.isScriptableListOrArray(oldValue) && Util.isScriptableListOrArray(newValue)) {
                        result[name] = Util.buildArrayDiff(oldValue, newValue);
                    } else {
                        result[name] = {
                            'old': oldValue,
                            'new': newValue

                        };
                    }
                } else {
                    result[name] = newValue;
                }
            }

            return result;
        },

        createClass: function(init, methods) {
            var clazz = function() {
                if (init) {
                    init.apply(this, [].slice.call(arguments));
                }
            };

            for (var methodName in methods) {
                clazz.prototype[methodName] = methods[methodName];
            }

            return clazz;
        },

        formatString: function(template, properties) {
            if (!template || !properties) {
                return template;
            }

            return template.replace(/\{([^\}]+)\}/g, function(str, param) {
                var value = properties[param];
                if (typeof value != "undefined") {
                    return value;
                }

                return "{" + param + "}";
            });
        },

        formatDate: function(dt, format) {
            return new java.text.SimpleDateFormat(format).format(dt);
        },

        parseDate: function(dateStr) {
            var sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm");
            sdf.setLenient(false);

            return sdf.parse(dateStr).getTime();
        },

        join: function(array, separator) {
            if (!array) {
                return null;
            }

            if (!array.join) {
                var realArray = new Array();
                for (var i = 0; i < array.length; i++) {
                    var elt = array[i];
                    realArray.push(elt);
                }
                array = realArray;
            }

            return array.join(separator);
        },

        concat: function() {
            var result = [];

            for (var i = 0; i < arguments.length; i++) {
                var array = arguments[i];
                for (var j = 0; j < array.length; j++) {
                    result.push(array[j]);
                }
            }

            return result;
        },

        without: function(array, values) {
            var result = [];

            for (var i = 0; i < array.length; i++) {
                var itm = array[i];

                if (!Util.contains(values, itm)) {
                    result.push(itm);
                }
            }

            return result;
        },

        withoutIgnoreCase: function(array, values) {
            var valuesMap = Util.arrayToHash(values || [], Util.toLowerCase);

            var result = [];

            for (var i = 0; i < array.length; i++) {
                var itm = Util.toLowerCase(array[i]);

                if (itm && !valuesMap[itm]) {
                    result.push(array[i]);
                }
            }

            return result;
        },

        nullifyEmptyString: function(s) {
            var str = String(s);
            if (str.length == 0) {
                return null;
            }

            return s;
        },

        equalsIgnoreCase: function(s1, s2) {
            return (s1 || '').toLowerCase() == (s2 || '').toLowerCase();
        },

        not: function(fn) {
            return function () {
                return !fn.apply(this, arguments);
            };
        },

        retry: function(action, retryLimit, coolDownInterval) {
            var lastException = null;

            for (var i = 0; i < retryLimit; i++) {
                try {
                    return action.call(this);
                } catch (e) {
                    lastException = e;
                    logger.error("{}", lastException);

                    if (lastException.javaException && lastException.javaException.printStackTrace) {
                        lastException.javaException.printStackTrace();
                    } else if (lastException.cause && lastException.cause.javaException && lastException.cause.javaException.printStackTrace) {
                        lastException.cause.javaException.printStackTrace();
                    }

                    if (coolDownInterval && coolDownInterval > 0) {
                        java.lang.Thread.sleep(coolDownInterval);
                    }
                }
            }

            throw lastException;
        },

        wrapInRetry: function(action, retryLimit, coolDownInterval) {
            var that = this;

            return function() {
                var args = Util.apply(arguments, Util.SelfProjection);

                return Util.retry(function() {
                    return action.apply(that, args);
                }, retryLimit, coolDownInterval);
            };
        },

        toISOString: function(d) {
            //https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/toISOString
            var pad = function(number) {
                if ( number < 10 ) {
                    return '0' + number;
                }
                return number;
            };

            return d.getUTCFullYear() +
                '-' + pad(d.getUTCMonth() + 1) +
                '-' + pad(d.getUTCDate()) +
                'T' + pad(d.getUTCHours()) +
                ':' + pad(d.getUTCMinutes()) +
                ':' + pad(d.getUTCSeconds()) +
                '.' + (d.getUTCMilliseconds() / 1000).toFixed(3).slice(2, 5) +
                'Z';
        },

        getExceptionMessage: function(exc) {
            var result = exc.message || "<empty>";

            var javaExc = exc.javaException;

            for (var i = 0; i < 5 && javaExc; i++) {
                result += "\nCaused by: ";
                result += javaExc.getMessage();
                javaExc = javaExc.getCause();
            }

            return result;
        },

        trim1024: function (s, ending) {
            var len = 1024;

            if (s.length < len) {
              return s;
            }
            else {
              var str = s.substring(0,len-ending.length);
              str = str + ending;
              return str;
            }
        },

        trimToSize: function (s, limit) {
            s = s || "";
            var ending = "...";

            if (s.length <= limit) {
                return s;
            }

            return s.substring(0, limit - ending.length) + ending;
        },

        trim: function (s) {
            if (!s) {
                return s;
            }

            return s.replace(/^\s+|\s+$/g, '');
        },

        toLowerCase: function(s) {
            if (!s) {
                return s;
            }

            return String(s).toLowerCase();
        },

        waitAll: function(futures) {
            while (true) {
                var future = futures.shift();
                if (!future) {
                    break;
                }

                try {
                    future();
                } catch (e) {
                    logger.error("{}", e);
                }
            }
        },

        //https://support.microsoft.com/en-us/help/325648/how-to-convert-a-string-formatted-guid-to-a-hexadecimal-string-form-fo
        convertStringGUIDToHexStringGUID: function(guid) {
            return ('{' +
                (guid.substr(6, 2) + guid.substr(4, 2) + guid.substr(2, 2) + guid.substr(0, 2)) + '-' +
                (guid.substr(10, 2) + guid.substr(8, 2)) + '-' +
                (guid.substr(14, 2) + guid.substr(12, 2)) + '-' +
                (guid.substr(16, 2) + guid.substr(18, 2)) + '-' +
                guid.substr(20) +
            '}').toUpperCase();
        },

        getUrlPathAndQueryPart: function(url) {
            if (!url) {
                return url;
            }

            return new java.net.URL(url).getFile();
        }
    };
}());
