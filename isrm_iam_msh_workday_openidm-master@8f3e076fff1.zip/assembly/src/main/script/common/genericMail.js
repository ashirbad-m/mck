load.call(this, "script/common/config.js");
load.call(this, "script/common/util.js");
load.call(this, "script/common/templates.js");

GenericMail = {

    sendSyncStatusMail: function(subject, body) {
        var emailParams = {};
        emailParams._type = "text/plain";
        emailParams._from = "provisioning@usoncology.com";
        emailParams._to = Config.getEmailConfiguration().syncStatusRecipients;
        emailParams._subject = subject + ". Host: " + com.mckesson.ScriptUtil.getHostName() + ". Time: " + Util.toISOString(new Date());
        emailParams._body = body;

        openidm.action("external/email", emailParams);
    },

    sendGenericMail: function(from, to, subject, body) {
        var emailParams = {};
        emailParams._type = "text/html";
        emailParams._from = from;
        emailParams._to = Config.getEmailConfiguration().redirectAddress || to;
        emailParams._subject = subject;
        emailParams._body = body;

        var altAddress = Config.getEmailCC();
        if (altAddress && altAddress.toString()[0] != '&') {
            emailParams._cc = altAddress.toString();
        }

        if (!isDryRunMode()) {
            openidm.action("external/email", emailParams);
        }
    }
};
