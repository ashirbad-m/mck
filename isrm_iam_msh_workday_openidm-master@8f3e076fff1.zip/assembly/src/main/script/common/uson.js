load.call(this, "script/common/config.js");
load.call(this, "script/common/cache.js");
load.call(this, "script/common/util.js");
load.call(this, "script/passwordGenerator.js");
load.call(this, "script/common/managed.js");
load.call(this, "script/common/staging.js");
load.call(this, "script/common/groupHelper.js");

Uson = (function() {

    var ROOT_OU = "rootOU";
    var WORKERS_OU = "workersOU";
    var ADMINS_OU = "adminsOU";
    var QUEST_OU = "questOU";
    var TERMINATED_OU = "terminatedOU";
    var STAGING_OU = "stagingOU";

    var domainConfigurations = Config.getDomainConfigurations();
    var domainConfigurationsMap = Util.arrayToHash(domainConfigurations, Util.NameProjection);

    var retryCount = Config.getRetryCount();
    var retryCoolDownInterval = Config.getRetryCoolDownInterval();

    var wrapInRetry = function(processor) {
        return Util.wrapInRetry(processor, retryCount, retryCoolDownInterval);
    };

    var retry = function(processor) {
        return Util.retry(processor, retryCount, retryCoolDownInterval);
    };

    var getServerNameFromConfiguration = function(domain) {
        var configurations = openidm.read("config").configurations;
        var serverNames = Util.apply(configurations, function(configuration) {
            var id = configuration._id;
            if (!id.match(/^provisioner\.openicf\//)) {
                return null;
            }

            var provisionerConfiguration = openidm.read("config/" + id);
            if (provisionerConfiguration.name != domain) {
                return null;
            }

            return provisionerConfiguration.configurationProperties.LDAPHostName;
        });

        return Util.filter(serverNames, Util.SelfProjection)[0];
    };

    var getAccountContainers = function(containerProperty) {
        return Util.applyAndMerge(domainConfigurations, function(domainConfiguration) {
            return Util.apply(Util.asArray(domainConfiguration[containerProperty]), Util.toLowerCase);
        });
    };

    var isDistinguishedNameInContainers = function(name, containers) {
        name = Util.toLowerCase(name || "");

        return Util.has(containers, function(container) {
            return name.indexOf(container) != -1;
        });
    };

    var isAccountInContainers = function(account, containers) {
        return isDistinguishedNameInContainers(account.distinguishedName, containers);
    };

    var queryAllAccounts = function(containerProperty, query, asyncGroupResolution) {
        var accountContainers = getAccountContainers(containerProperty);

        var accounts = Util.applyAndMerge(domainConfigurations, function(domainConfiguration) {
            var containers = Util.asArray(domainConfiguration[containerProperty]);

            return Util.applyAndMerge(containers, wrapInRetry(function(containerOU) {
                return openidm.query("system/" + domainConfiguration.name + "/account", {
                    query: query,
                    params: {queryContainerUid: containerOU, asyncGroupResolution: asyncGroupResolution}
                }).result;
            }));
        });

        var accountNotInContainersPredicate = function(account) {
            return !isAccountInContainers(account, accountContainers);
        };

        if (Util.has(accounts, accountNotInContainersPredicate)) {
            throw "One of accounts is not in containers";
        }

        return accounts;
    };

    var DIFF_FOR_DATES = 11644473600000;

    return {

        //TODO - company name?
        COMPANY : "US Oncology",
        USER_PROFILE_LOCATION: "profiles\\",
        TXO_HRBU: ["hr017", "hr064", "hr080", "hr081", "hr082", "hr083", "hr084", "hr085","hr087", "hr098", "hr099"],
        MCKHRBU: "hr065",
        ZERO_VALUE : "0",
        ACCOUNT_NEVER_EXPIRE_VALUE : "9223372036854775807",

        CWT_REGULAR : "Regular",
        CWT_EMPLOYEE : "Employee",

        CWT_CONTRACTOR : "Contractor",
        CWT_OUTSIDE : "Outside Company Worker",
        CWT_X : "Contracted Access (IT Use Only)",

        cwtValue : function (workerTypeDescriptor, isEmployee) {
            if (isEmployee == 'true' || Util.equalsIgnoreCase(workerTypeDescriptor, Uson.CWT_REGULAR)) {
                return Uson.CWT_EMPLOYEE;
            }
            if (workerTypeDescriptor) {
                if (Util.equalsIgnoreCase(workerTypeDescriptor, Uson.CWT_OUTSIDE)) {
                    return Uson.CWT_OUTSIDE;
                }
                if (Util.equalsIgnoreCase(workerTypeDescriptor, Uson.CWT_X)) {
                    return Uson.CWT_X;
                }
            }
            return Uson.CWT_CONTRACTOR;
        },

        cwtIndex : function (workerTypeDescriptor, isEmployee) {
            return [Uson.CWT_EMPLOYEE, Uson.CWT_CONTRACTOR, Uson.CWT_OUTSIDE, Uson.CWT_X].indexOf(Uson.cwtValue(workerTypeDescriptor, isEmployee));
        },

        cwtGroup : function (workerTypeDescriptor, isEmployee) {
            return ['groups', 'contractor_groups', 'contingentworkertype_outside_worker_groups', 'contingentworkertype_x_groups'][Uson.cwtIndex(workerTypeDescriptor, isEmployee)];
        },

        cwtName : function (workerTypeDescriptor, isEmployee) {
            if (isEmployee == 'true' || !workerTypeDescriptor) {
                return Uson.cwtValue(workerTypeDescriptor, isEmployee);
            }
            return workerTypeDescriptor;
        },

        cwtGenerateGroups : function (hrbuProp, workerTypeDescriptor, isEmployee, lastName) {
            return Uson.generateGroups(hrbuProp[Uson.cwtGroup(workerTypeDescriptor, isEmployee)], isEmployee, lastName);
        },

        cwtChangeGroups : function (
            hrbuProp,
            workerTypeDescriptorOld,
            workerTypeDescriptorNew,
            lastName,
            existentGroups
        ) {
            var _gMap = function (arr) {
                var res = {};
                if (arr && arr.length > 0) {
                    for (var i = 0; i < arr.length; i++) {
                        res[Util.toLowerCase(arr[i])] = true;
                    }
                }
                return res;
            };

            var oldMap = _gMap(Uson.cwtGenerateGroups(hrbuProp, workerTypeDescriptorOld, '', lastName));
            var newMap = _gMap(Uson.cwtGenerateGroups(hrbuProp, workerTypeDescriptorNew, '', lastName));
            var existentMap = _gMap(existentGroups);
            var resultMap = {};

            for (var key0 in existentMap) {
                if (existentMap.hasOwnProperty(key0) && !(oldMap[key0] || newMap[key0])) {
                    resultMap[key0] = true;
                }
            }

            for (var key1 in newMap) {
                if (newMap.hasOwnProperty(key1) && !resultMap[key1]) {
                    resultMap[key1] = true;
                }
            }

            var resultArray = [];

            for (var key2 in resultMap) {
                if (resultMap.hasOwnProperty(key2)) {
                    resultArray.push(key2);
                }
            }
            return resultArray;
        },

        getServerName: function(domain) {
            return Cache.get("domainServerName", domain, getServerNameFromConfiguration);
        },

        getUserPrincipalNameSuffix: function(domain) {
            return '@' + domainConfigurationsMap[domain].fullName;
        },

        getPrimaryGroupID: function(domain) {
            return domainConfigurationsMap[domain].primaryGroupID;
        },

        getTerminatedUsersPrimaryGroupID: function(domain) {
            return domainConfigurationsMap[domain].terminatedUsersPrimaryGroupID;
        },

        getTerminatedUsersGroup: function(domain) {
            return domainConfigurationsMap[domain].terminatedUsersGroup;
        },

        getDefaultAddressBook: function(domain) {
            return domainConfigurationsMap[domain].defaultAddressBook;
        },

        findFirst: function(name, value, filter) {
            if (!value) {
                return null;
            }

            var data;

            if (isDryRunMode()) {
                data = Staging.getRepo().find(name, value).result;
            } else {
                var query = Util.Filters.equals(name, value);
                data = Util.applyAndMerge(Config.getDomainConfigurations(), wrapInRetry(function(domainConfiguration) {
                    return openidm.query("system/" + domainConfiguration.name + "/account", {query: query}).result || [];
                }));
            }

            if (filter) {
                data = Util.filter(data, filter);
            }

            var user = (data && data.length > 0) ? data[0] : null;
            return user;
        },

        findByUID: function(uid) {
            var user;
            if (isDryRunMode()) {
                user = Staging.getRepo().read(uid);
            } else {
                for (var i = 0; i < domainConfigurations.length; i++) {
                    /*jshint loopfunc: true */
                    user = retry(function() {
                        return openidm.read("system/" + domainConfigurations[i].name + "/account/" + uid);
                    });

                    if (user) {
                        break;
                    }
                }
            }

            var attr = Managed.findUserAttrByUID(uid);
            if (user && attr) {
                Util.mergeRecursive(user, attr);
            }

            return user;
        },

        findGroupByDN : function(dn) {
            if (!dn) {
                return null;
            }

            var query = Util.Filters.equals("dn", dn);
            var result = Util.applyAndMerge(Config.getDomainConfigurations(), wrapInRetry(function(domainConfiguration) {
                return openidm.query("system/" + domainConfiguration.name + "/group", {query: query}).result || [];
            }));

            return result[0];
        },

        findByDN : function(dn) {
            return Uson.findFirst("distinguishedName", dn);
        },

        findByWorkerID : function(managerId) {
            return Uson.findFirst("workerID", managerId);
        },

        findGroupsManagedByDN : function(managerDN) {
            if (!managerDN) {
                return [];
            }

            var query = Util.Filters.equals("managedby", managerDN);
            var data = Util.applyAndMerge(Config.getDomainConfigurations(), wrapInRetry(function(domainConfiguration) {
                return openidm.query("system/" + domainConfiguration.name + "/group", {query: query}).result || [];
            }));

            return (data && data.length > 0) ? data : [];
        },

        findAdminsManagedByDN : function(managerDN) {
            if (!managerDN) {
                return [];
            }

            var query = Util.Filters.and([Util.Filters.equals("manager", managerDN), Util.Filters.startsWith("sAMAccountName", "a-")]);
            var data = queryAllAccounts(ADMINS_OU, query, false);
            return (data && data.length > 0) ? data : [];
        },

        findServiceAccountsManagedByDN : function(managerDN) {
            if (!managerDN) {
                return [];
            }

            var query = Util.Filters.equals("manager", managerDN);
            var data = Util.applyAndMerge(Config.getDomainConfigurations(), wrapInRetry(function(domainConfiguration) {
                return openidm.query("system/" + domainConfiguration.name + "/account", {query: query}).result || [];
            }));

            data = Util.filter(data, function(account) {
                if (Uson.isUserInScope(account) || Uson.isUserTerminated(account)) {
                    return false;
                }

                //account exists and account.sAMAccountName != 'a-*'
                return account && account.sAMAccountName && !/^a-/i.test(account.sAMAccountName);
            });

            return (data && data.length > 0) ? data : [];
        },

        findManagedServers: function(dn){
            var query = Util.Filters.and(
                [
                    Util.Filters.equals("managedBy", dn),
                    Util.Filters.or(
                        [
                            Util.Filters.contains("operatingSystem", "server"),
                            Util.Filters.contains("operatingSystem", "linux"),
                            Util.Filters.contains("operatingSystem", "redhat"),
                            Util.Filters.contains("operatingSystem", "sunos"),
                            Util.Filters.contains("operatingSystem", "ontap"),
                            Util.Filters.contains("operatingSystem", "sles"),
                            Util.Filters.contains("operatingSystem", "centos")
                        ]
                    )
                ]
            );

            var data = Util.applyAndMerge(Config.getDomainConfigurations(), wrapInRetry(function(domainConfiguration) {
                return openidm.query("system/" + domainConfiguration.name + "/computer", {query: query}).result || [];
            }));
            return (data && data.length > 0) ? data : [];
        },

        updateComputerManager: function(params, server, manager){
            var data = {"managedBy": manager.distinguishedName};
            logger.debug("  Uson.updateComputerManager => {}", data);

            var errorMessage = "";
            var targetPath = "system/" + server.provisioner + "/computer/" + server._id;
            var target = null;
            var lock = Staging.getSynchronizationLock();

            try {
                lock.lock();

                if (!server.provisioner) {
                    throw "Provisioner is missing";
                }

                target = retry(function() {
                    return openidm.read(targetPath);
                });
                if (!isDryRunMode()) {
                    openidm.update(targetPath, null, data);
                }
            } catch (e) {
                logger.error("  Can't update computer! target => {}", data);
                logger.error("  Exception! target => {}", e);
                errorMessage = e.message;
            } finally {
                lock.unlock();
            }

            var diff = Util.buildDiffObject(target, data);
            diff.ID = {
                _id: server._id,
                dn: target ? target.dn : "N/A"
            };
            Managed.createAuditRecord(params, "AD.updateComputer", diff, errorMessage);
        },

        generateBaseCN: function(src) {
            var uid = src.lastName + ", " + src.firstName;
            if (src.middleName) {
                uid += " " + src.middleName.charAt(0);
            }

            return uid;
        },

        normalizeCN: function(cn) {
            return String(cn).replace(/ ?[0-9]+$/, '');
        },

        generateDN: function(uid, ou) {
            var lock = Staging.getSynchronizationLock();
            try {
                uid = Uson.normalizeCN(uid);
                lock.lock();

                var cn = uid;
                var dn = Util.appendToLdapName(ou, "cn", cn);
                var counter = 1;

                while ((Uson.findByDN(dn) || !Staging.getRepo().putGeneratedDNIfAbsent(dn)) && counter < 1000) {
                    cn = uid + " " + counter;
                    dn = Util.appendToLdapName(ou, "cn", cn);
                    counter++;
                }

                return dn;
            } finally {
                lock.unlock();
            }
        },

        generateStagingUserDN: function(trg) {
            var domain = trg.provisioner;
            return Uson.generateDN(trg.commonName, domainConfigurationsMap[domain][STAGING_OU]);
        },

        generateTerminatedUserDN: function(trg) {
            var domain = trg.provisioner;
            return Uson.generateDN(trg.commonName, domainConfigurationsMap[domain][TERMINATED_OU]);
        },

        generateTerminalServicesProfilePath: function(domain, uid) {
            return domainConfigurationsMap[domain].terminalServicesProfileRoot + "\\" + uid.charAt(0) + "\\" + uid;
        },

        generatePassword : function() {
            return PasswordGenerator.generate();
        },

        generateUID : function(givenName, familyName) {
            var lock = Staging.getSynchronizationLock();
            try {
                lock.lock();

                var counter = 0;
                var fChars = new RegExp("[^a-zA-Z0-9]", "g"),
                uidBase = familyName.substring(0, Math.min(5, familyName.length)) + givenName.substring(0,1);
                uidBase = uidBase.toLowerCase().replace(fChars, "");

                while (counter < 1000) {
                    /*jshint loopfunc: true */

                    var uid = uidBase + (counter > 0 ? counter : "");
                    var query = Util.Filters.equals("sAMAccountName", uid);

                    var users = Util.applyAndMerge(Config.getDomainConfigurations(), wrapInRetry(function(domainConfiguration) {
                        return openidm.query("system/" + domainConfiguration.name + "/account", {query: query}).result || [];
                    }));

                    if (users.length == 0 && Staging.getRepo().putGeneratedUIDIfAbsent(uid)) {
                        return uid;
                    }

                    counter++;
                }
            } finally {
                lock.unlock();
            }
        },

        generateHomeDirectory: function(home, userName) {
            if (home) {
                return home + userName;
            }
        },

        generateArchivedHomeDirectory: function(homeDirectory) {
            if (homeDirectory) {
                //generate home directory, insert 2ARCHIVENETSEC before the last segment of home directory path
                return homeDirectory.replace(/\\([^\\]+)$/, "\\2ARCHIVENETSEC\\$1");
            }
        },

        generateDisplayName: function(src) {
            var lastName = src.preferredLastName || src.lastName;
            var firstName = src.preferredFirstName || src.firstName;

            var suffix;
            var prefix;

            if (src.preferredFirstName || src.preferredLastName) {
                suffix = src.preferredSuffix;
                prefix = src.preferredPrefix;
            } else {
                suffix = src.preferredSuffix || src.legalSuffix;
                prefix = src.preferredPrefix || src.legalPrefix;
            }

            var result = lastName;
            result += ", ";
            result += firstName;

            if (suffix) {
                result += " ";
                result += suffix;
            }

            if (prefix) {
                result += ", ";
                result += prefix;
            }

            return result;
        },

        sanitizeEmailPortion: function(s) {
            s = s.replace(/[ '\u2019]/g, '');

            var idx = s.search(/[^-\._A-Za-z0-9]/);
            var result = (idx < 0) ? s : s.substring(0, idx);

            result = result.replace(/\./g, '');

            return result;
        },

        generateEmails: function(hrbuProp, domain, src, trg) {
            var primaryEmailBase = null;
            var primaryEmail = null;
            var secondaryEmail = null;
            var secondaryEmailAdditional = null;

            var defaultMailDomain = domainConfigurationsMap[domain].defaultMailDomain;

            if (src.preferredFirstName || src.preferredLastName) {
                primaryEmailBase = Uson.sanitizeEmailPortion(src.preferredFirstName || src.firstName) + "." + Uson.sanitizeEmailPortion(src.preferredLastName || src.lastName);
            } else {
                primaryEmailBase = Uson.sanitizeEmailPortion(src.firstName) + "." + Uson.sanitizeEmailPortion(src.lastName);
            }

            primaryEmail = primaryEmailBase + "@" + (hrbuProp.mail_suffix || defaultMailDomain);

            //always generate usoncology.com e-mail
            var secondaryEmailBase = Uson.sanitizeEmailPortion(src.firstName) + "." + Uson.sanitizeEmailPortion(src.lastName);
            secondaryEmail = secondaryEmailBase + "@" + defaultMailDomain;

            if (hrbuProp.secondary_mail_suffix) {
                var secondaryEmailAdditionalBase = Uson.sanitizeEmailPortion(src.firstName) + "." + Uson.sanitizeEmailPortion(src.lastName);
                secondaryEmailAdditional = secondaryEmailAdditionalBase + "@" + hrbuProp.secondary_mail_suffix;
            }

            var result = {
                primary: Uson.generateUniqueMail(primaryEmail, trg)
            };

            if (secondaryEmail && primaryEmail != secondaryEmail) {
                result.secondary = Uson.generateUniqueMail(secondaryEmail, trg);
            }

            if (secondaryEmailAdditional && primaryEmail != secondaryEmailAdditional && secondaryEmail != secondaryEmailAdditional) {
                result.secondaryAdditional = Uson.generateUniqueMail(secondaryEmailAdditional, trg);
            }

            return result;
        },

        generateUniqueMail: function(emailParam, trg) {
            if (!emailParam) {
                return emailParam;
            }

            var lock = Staging.getSynchronizationLock();
            try {
                lock.lock();
                trg = trg || {};

                var split = emailParam.split(/@/);
                var emailBase = split[0];
                var emailDomain = split[1];

                var result = null;
                var counter = 0;

                while (!result && counter < 1000) {
                    /*jshint loopfunc: true */

                    var email = emailBase + (counter > 0 ? counter : "") + "@" + emailDomain;

                    var query = Util.Filters.or([Util.Filters.equals("userPrincipalName", email), Util.Filters.equals("mail", email), Util.Filters.equals("proxyAddresses", "smtp:" + email)]);

                    var results = Util.applyAndMerge(domainConfigurations, wrapInRetry(function(domainConfiguration) {
                        return openidm.query("system/" + domainConfiguration.name + "/top", {query: query}).result;
                    }));

                    if (results.length == 0) {
                        if (Staging.getRepo().putGeneratedMailIfAbsent(email)) {
                            result = email;
                        }
                    } else if (trg._id && results.length == 1 && results[0]._id == trg._id) {
                        if (Staging.getRepo().putGeneratedMailIfAbsent(email)) {
                            result = email;
                        }
                    }

                    counter++;
                }

                return result;
            } finally {
                lock.unlock();
            }
        },

        generateGroups: function (hrbuKeys, employee, lastName) {
           var groups = Managed.findDefaultGroups().concat(Managed.findHRBUGroups(hrbuKeys));
            if (employee == 'true') {
                groups = groups.concat(Managed.findCSAGroups(lastName));
            }
            return groups;
        },

        getManagerByWorkerID: function(managerID, filter) {
            return Uson.findFirst("workerID", managerID, filter || Uson.isUserInScope);
        },

        getManagerByWorkerIDForVantage: function(managerID) {
            //find manager inside RM or CSA
            var manager = Uson.getManagerByWorkerID(managerID);

            if (!manager) {
                //need to find QCS object if manager is in McKesson Corporate HRBU
                var managerCandidate = Managed.findByWorkerID(managerID);
                if (managerCandidate && Uson.isMCKHRBU(managerCandidate.hrbu)) {
                    manager = Uson.findFirst("commonName", managerCandidate.userID, Uson.isUserInQuestOU);
                }
            }

            return manager;
        },

        getManagerByDN: function(dn, filter) {
            return Uson.findFirst("distinguishedName", dn, filter || Uson.isUserInScope);
        },

        getDefaultManager: function(domain) {
            var defaultManagerData = domainConfigurationsMap[domain].defaultManager;

            var defaultManager = Uson.findByDN(defaultManagerData.distinguishedName) || {};
            Util.mergeRecursive(defaultManager, defaultManagerData);
            return defaultManager;
        },

        getManager: function(domain, dn, eid, hrbu, executiveDirectorId) {
            logger.debug(" Uson.getManager => {}, {}, {}, {}, {}", domain, dn, eid, hrbu, executiveDirectorId);

            var hrbuData = Managed.getHRBU(hrbu) || {};
            var isVantageManagerLookupStrategy = !hrbuData.manager_lookup_strategy || hrbuData.manager_lookup_strategy == "vantage";

            var isManager = true;
            var manager = null;

            if (dn) {
                if (isVantageManagerLookupStrategy) {
                    manager = Uson.getManagerByDN(dn, Uson.isUserInScopeOrInQuestOU);
                } else {
                    manager = Uson.getManagerByDN(dn);
                }
            }

            if (!manager && eid) {
                if (isVantageManagerLookupStrategy) {
                    //find manager using Vantage lookup
                    manager = Uson.getManagerByWorkerIDForVantage(eid);
                } else {
                    //find manager inside OUs in scope (CSA & RM)
                    manager = Uson.getManagerByWorkerID(eid);
                }
            }

            if (!manager) {
                isManager = false;

                var executiveDirector = executiveDirectorId != null ? Managed.findByWorkerID(executiveDirectorId) : null;
                if (executiveDirector != null && executiveDirector.hrbu && Uson.isMCKHRBU(executiveDirector.hrbu) && executiveDirector.userID != null) {
                    //manager = Uson.getUserByUserIdFromQuest(executiveDirector.userID);
                    manager = Uson.findFirst("commonName", executiveDirector.userID, Uson.isUserInQuestOU);
                } else {
                    //manager = manager || ( (hrbu) ? Uson.getManagerByHRBU(hrbu) : null);
                    manager = ( (executiveDirectorId) ? Uson.getManagerByWorkerID(executiveDirectorId, Uson.isUserNotTerminated) : null);
                }

                manager = manager || Uson.getDefaultManager(domain);
            }

            logger.debug(" Uson.getManager, manager found => {}", manager.distinguishedName);
            manager.isManager = isManager;

            return manager;
        },

        createUser: function(params, data, password) {
            logger.debug("  Uson.createUser => {}", data);
            var result = null;
            var errorMessage = "";

            var lock = Staging.getSynchronizationLock();
            try {
                lock.lock();

                if (!data.provisioner) {
                    throw "Provisioner is missing";
                }

                if (!isDryRunMode()) {
                    /* THIS IS A HACK!
                     * we have delete-permissions in TEMPORARY OU Only!!!
                     * in case of exception idm can't delete broken user,
                     * so we perform creation in two steps:
                     * 1. create user in OU where we have delete-permissions
                     * 2. in case if the user was created successfully - move it in the business OU */

                    var hrbuDN = data.dn,                                       //save real DN
                        tmpDN = Uson.generateStagingUserDN(data);  //generate tmp DN

                    //create user in temporary OU
                    data.dn = tmpDN;
                    data.commonName = Util.dnToRDNValue(tmpDN);

                    var dataWithPassword = Util.mergeRecursive({}, data);
                    dataWithPassword.password = password;

                    result = openidm.create("system/" + data.provisioner + "/account", dataWithPassword);
                    result.password = undefined;
                    result.provisioner = data.provisioner;
                    //move user in OU that is defined by HRBU
                    var d = {
                        dn: hrbuDN,
                        "_id" : tmpDN
                    };
                    openidm.update("system/" + data.provisioner + "/account/" + result._id, null, d);

                    data._id = result._id;
                    data.dn = hrbuDN;
                    data.distinguishedName = data.dn;
                    data.commonName = Util.dnToRDNValue(hrbuDN);
                } else {
                    data.distinguishedName = data.dn;
                    result = Staging.getRepo().create(java.util.UUID.randomUUID().toString(), data);
                }

                //create uson user attributes link
                Managed.createUsonUserAttributesLink(params, data);
            } catch (e) {
                logger.error("  Can't create user! target => {}", data);
                logger.error("  Exception! target => {}", e);
                errorMessage = e.message;
            } finally {
                lock.unlock();
            }

            Managed.createAuditRecord(params, "AD.createUser", data, errorMessage);
            return result;
        },

        updateUserGroups: function(params, data, groupsToAdd, groupsToRemove) {
            var lock = Staging.getSynchronizationLock();

            try {
                lock.lock();

                if (!data._id) {
                    throw "Id is missing";
                }

                if (!data.provisioner) {
                    throw "Provisioner is missing";
                }

                if (!data.distinguishedName) {
                    throw "Distinguished name is missing";
                }

                var groups = Util.toArray(GroupHelper.getGroups(data) || []).concat(groupsToAdd);
                GroupHelper.setGroups(data, Util.without(groups, groupsToRemove));

                if (isDryRunMode()) {
                    var stagingRepo = Staging.getRepo();
                    stagingRepo.update(data._id, data);
                }
            } catch (e) {
                logger.error("  Can't update user groups! target => {} {} {}", data, groupsToAdd, groupsToRemove);
                logger.error("  Exception! target => {}", e);
            } finally {
                lock.unlock();
            }
        },

        updateUserPassword: function(params, user, password) {
            var errorMessage = "";
            var lock = Staging.getSynchronizationLock();
            var auditData = {
                _id: user._id,
                dn: user.distinguishedName || "N/A"
            };

            try {
                lock.lock();

                if (!user._id) {
                    throw "Id is missing";
                }

                if (!user.provisioner) {
                    throw "Provisioner is missing";
                }

                var targetPath = "system/" + user.provisioner + "/account/" + user._id;
                if (!isDryRunMode()) {
                    openidm.update(targetPath, null, {password: password});
                }

            } catch (e) {
                logger.error("  Can't update user! target => {}", user);
                logger.error("  Exception! target => {}", e);
                errorMessage = e.message;
            } finally {
                lock.unlock();
            }

            Managed.createAuditRecord(params, "AD.updateUserPassword", auditData, errorMessage);
        },

        updateUser: function(params, data) {
            logger.debug("  Uson.updateUser => {}", data);
            var result =  null,
                errorMessage = "";
            var target = null;
            var targetPath = "system/" + data.provisioner + "/account/" + data._id;
            var lock = Staging.getSynchronizationLock();

            try {
                lock.lock();

                if (!data._id) {
                    throw "Id is missing";
                }

                if (!data.provisioner) {
                    throw "Provisioner is missing";
                }

                if (!isDryRunMode()) {
                    target = retry(function() {
                        return openidm.read(targetPath);
                    });
                    openidm.update(targetPath, null, data);
                } else {
                    var stagingRepo = Staging.getRepo();
                    target = stagingRepo.read(data._id);
                    stagingRepo.update(data._id, data);
                }

                //update uson user attributes link
                Managed.updateUsonUserAttributesLink(params, data);

                result = data;

            } catch (e) {
                logger.error("  Can't update user! target => {}", data);
                logger.error("  Exception! target => {}", e);
                errorMessage = e.message;
            } finally {
                lock.unlock();
            }

            var diff = Util.buildDiffObject(target, data);
            diff.ID = {
                _id: data._id,
                dn: target ? target.distinguishedName : "N/A"
            };

            Managed.createAuditRecord(params, "AD.updateUser", diff, errorMessage);
            if (
                data.workerTypeDescriptor &&
                data.workerTypeDescriptor != Uson.cwtName(data.workerTypeDescriptor, data.isEmployee)
            ) {
                errorMessage = "Warning: workerTypeDescriptor is incorrect or unknown.";
                params = Util.mergeRecursive({severity: "WARNING"}, params);
                Managed.createAuditRecord(params, "AD.updateUser", diff, errorMessage);
            }

            return result;
        },

        moveUser: function(params, data, newDN) {
            logger.debug("  Uson.moveUser => {}", newDN);
            var result = null;
            var d = {
                dn : newDN,
                "_id" : data.distinguishedName
            };
            var errorMessage = "";

            var lock = Staging.getSynchronizationLock();
            try {
                lock.lock();

                if (!data.provisioner) {
                    throw "Provisioner is missing";
                }

                if (!isDryRunMode()) {
                    result = openidm.update("system/" + data.provisioner + "/account/" + data._id, null, d);
                } else {
                    d.distinguishedName = newDN;

                    Staging.getRepo().update(data._id, d);
                    result = data;
                }
                data.distinguishedName = newDN;
                data.dn = newDN;
            } catch (e) {
                errorMessage = e.message;
                logger.error("  Can't update user! target => id = {}, data = {}", data._id, d);
            } finally {
                lock.unlock();
            }

            Managed.createAuditRecord(params, "AD.moveUser", d, errorMessage);
            return result;
        },

        updateGroup : function(params, data) {
            var result = null;
            var errorMessage = "";
            logger.debug("  Uson.updateGroup => {}", data);
            var targetPath = "system/" + data.provisioner + "/group/" + data._id;
            var lock = Staging.getSynchronizationLock();
            try {
                lock.lock();

                if (!data.provisioner) {
                    throw "Provisioner is missing";
                }

                //TODO - consume read value
                retry(function() {
                    openidm.read(targetPath);
                });
                if (!isDryRunMode()) {
                    result = openidm.update(targetPath, null, data);
                } else {
                    result = data;
                }
            } catch (e) {
                errorMessage = e.message;
                logger.error("  Can't update group! target => {}", data);
            } finally {
                lock.unlock();
            }

            Managed.createAuditRecord(params, "AD.updateGroup", data, errorMessage);
            return result;
        },

        convertDateToADInterval : function(d) {
            var m = d.getTime() + DIFF_FOR_DATES,
                i = m + "0000"; //i = m * 10000;
            return i;
        },

        convertADIntervalToDate : function(i) {
            var ivl = i.substring(0, i.length - 4),//NON-STANDARD AD format!!!
                ms = java.math.BigInteger(ivl).subtract(java.math.BigInteger(DIFF_FOR_DATES)).toString(),
                d = new Date(parseInt(ms));
            return d;
        },

        isUserNotTerminated : function(user) {
            return !Uson.isUserTerminated(user);
        },

        isUserTerminated : function(user) {
            return isAccountInContainers(user, getAccountContainers(TERMINATED_OU));
        },

        isUserInScope : function(user) {
            return isAccountInContainers(user, getAccountContainers(WORKERS_OU));
        },

        isUserInQuestOU: function(user) {
            return isAccountInContainers(user, getAccountContainers(QUEST_OU));
        },

        isUserInScopeOrInQuestOU: function(user) {
            return Uson.isUserInScope(user) || Uson.isUserInQuestOU(user);
        },

        isUserNeverExpires: function(user) {
            return !user.accountExpires || user.accountExpires == Uson.ZERO_VALUE || user.accountExpires == Uson.ACCOUNT_NEVER_EXPIRE_VALUE;
        },

        isTXOHRBU: function(hrbuCode) {
            var normalHRBUCode = hrbuCode.substring(0,5).toLowerCase();
            return Util.contains(Uson.TXO_HRBU, normalHRBUCode);
        },

        isMCKHRBU: function(hrbuCode) {
            return hrbuCode.substring(0,5).toLowerCase() == Uson.MCKHRBU;
        },

        isSVRGroup: function(group) {
            return (group || "").match(/^cn=svr-/i);
        },

        getPrimaryDomainEmail: function(domain) {
            var defaultMailDomain = domainConfigurationsMap[domain].defaultMailDomain;

            for (var i = 1; i < arguments.length; i++) {
                var email = arguments[i];
                if ((email + "").toLowerCase().indexOf('@' + defaultMailDomain) != -1) {
                    return email;
                }
            }

            return null;
        },

        isHRBUChangeSuppressed: function(hrbu) {
            if (!hrbu) {
                return false;
            }

            return Util.has(Staging.getExceptions(), function(exception) {
                return Util.contains(exception.data.suppressHRBUTransfer || [], hrbu);
            });
        },

        isCompanyChangeSuppressed: function(companyId) {
            if (!companyId) {
                return false;
            }

            return Util.has(Staging.getExceptions(), function(exception) {
                return Util.contains(exception.data.suppressClinicalTransfer || [], companyId);
            });
        },

        queryAllUsersInScope: function() {
            return queryAllAccounts(WORKERS_OU, Util.Filters.startsWith("objectClass", ""), true);
        },

        isHRBUEnabled: function(hrbu) {
            hrbu = (hrbu || "").substring(0,5).toUpperCase();

            var hrbuData = Managed.getHRBU(hrbu) || {};

            return Uson.isMCKHRBU(hrbu) || hrbuData.enabled == "1" || hrbuData.enabled == 1;
        },

        getCompany: function(domain) {
            return domainConfigurationsMap[domain].company;
        },

        getDomain: function(dn) {
            var matchingConfigurations = Util.filter(domainConfigurations, function(configuration) {
                return isDistinguishedNameInContainers(dn, [Util.toLowerCase(configuration[ROOT_OU])]);
            });

            if (matchingConfigurations.length == 0) {
                throw "Matching provisioner not found: " + dn;
            }
            if (matchingConfigurations.length > 1) {
                throw "Multiple provisioner configurations found: " + dn;
            }

            return matchingConfigurations[0].name;
        },

        checkADAvailability: function(domain) {
            if (domain && domainConfigurationsMap[domain] && domainConfigurationsMap[domain][STAGING_OU]) {
                var ouName = domainConfigurationsMap[domain][STAGING_OU];

                retry(function() {
                    var query = Util.Filters.equals("__NAME__", ouName);
                    openidm.query("system/" + domain + "/organizationalUnit", {query: query});
                });
            }
        }

    };

}());
