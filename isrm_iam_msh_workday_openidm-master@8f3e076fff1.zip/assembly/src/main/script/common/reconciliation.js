load.call(this, "script/common/config.js");
load.call(this, "script/common/uson.js");
load.call(this, "script/common/workday.js");
load.call(this, "script/common/managed.js");
load.call(this, "script/common/pshell.js");
load.call(this, "script/common/remedyForce.js");
load.call(this, "script/common/util.js");
load.call(this, "script/common/mail.js");
load.call(this, "script/common/staging.js");
load.call(this, "script/common/deferred.js");
load.call(this, "script/common/groupHelper.js");

Reconciliation = (function() {

    var TICKET_BASIC_TRANSFER = 0;
    var TICKET_CLINICAL_TRANSFER = 1;
    var TICKET_TERMINATION = 2;

    var modifyGroupMembership = function(params, trg, groupsToAdd, groupsToRemove) {
        PShell.modifyGroupMembership(params, trg, groupsToAdd, groupsToRemove);
        Uson.updateUserGroups(params, trg, groupsToAdd, groupsToRemove);
    };

    var getUserGroups = function (trg) {
        var userGroups = {
            txoHelp: [],
            centricity: [],
            security: [],
            tigerB: [],
            tigerC: [],
            iknowmed: [],
            salesforce: [],
            workday: [],
            databaseInfo: [],
            telecom: []
        };

        var groups = GroupHelper.getGroups(trg);

        Util.apply(groups, function(group) {
            if (group.lastIndexOf("MEDICVISION") >= 0) {
                userGroups.txoHelp.push(group);
            } else if (group.lastIndexOf("CX_GECENTRICITY") >= 0 || group.lastIndexOf("CTX_Centricity") >= 0) {
                userGroups.centricity.push(group);
            }  else if (Util.toLowerCase(group).indexOf("cn=nia_8x8,") == 0) {
                userGroups.telecom.push(group);
            }  else if (group.lastIndexOf("NIA_Saleforce") >= 0) {
                userGroups.salesforce.push(group);
            }  else if (group.lastIndexOf("NIA_KDW") >= 0) {
                userGroups.iknowmed.push(group);
            }  else if (group.lastIndexOf("NIA_Workday") >= 0) {
                userGroups.workday.push(group);
            }  else if (group.lastIndexOf("NIA") >= 0) {
                userGroups.security.push(group);
            }  else if (group.lastIndexOf("CX_MEDICTIGER_B") >= 0 || group.lastIndexOf("CTX_Tiger B") >= 0) {
                userGroups.tigerB.push(group);
            }  else if (group.lastIndexOf("CX_MEDICTIGER_C") >= 0 || group.lastIndexOf("CTX_Tiger C") >= 0) {
                userGroups.tigerC.push(group);
            }
        });

        return userGroups;
    };

    var updateManagedServers = function(params, trg, manager){
        var servers = Uson.findManagedServers(trg.distinguishedName);
        if (trg.originalDistinguishedName) {
            servers = Util.unique(Util.IdProjection, servers, Uson.findManagedServers(trg.originalDistinguishedName));
        }
        var i;
        for (i = 0; i < servers.length; i++) {
            Uson.updateComputerManager(params, servers[i], manager);
        }

        var serverNames = Util.apply(servers || [], function (server) {
            return server.commonName;
        });

        if (serverNames.length > 0) {
            Mail.sendMailToManager(params, "YouAreNowTheOwnerOfServer", manager, trg, {"servers": serverNames});
        }
    };

    return {

        generateAccountRemedyTicketsAndEmails: function(params, src, trg, originalManager, ticketMode) {
            var terminationInfo = trg.associatedAccountsTermination;
            var serviceAccountsInfo = new Array();
            var serviceAccountsManager = terminationInfo.manager;
            var remedyFN;
            switch (ticketMode) {
                case TICKET_BASIC_TRANSFER:
                    remedyFN = RemedyForce.transferBasic;
                    break;

                case TICKET_CLINICAL_TRANSFER:
                    remedyFN = RemedyForce.clinicalTransferBasic;
                    break;

                case TICKET_TERMINATION:
                    remedyFN = RemedyForce.terminationBasic;
                    break;

                default:
                    throw "Unsupported mode: " + ticketMode;
            }

            Util.apply(terminationInfo.adminAccounts || [], function(adminAccountData) {
                var originalAccount = adminAccountData.original;
                var updatedAccount = adminAccountData.updated;

                var adminAccountParams = Util.mergeRecursive({}, params);
                Util.mergeRecursive(adminAccountParams, {targetObject: originalAccount});

                remedyFN(adminAccountParams, updatedAccount, originalManager, {
                    adminAccount: updatedAccount.distinguishedName
                });
            });

            Util.apply(terminationInfo.serviceAccounts || [], function(itm) { serviceAccountsInfo.push(itm.distinguishedName); });
            Util.apply(terminationInfo.serviceGroups || [], function(itm) { serviceAccountsInfo.push(itm.dn); });

            var incidentData = remedyFN(params, trg, originalManager, {
                serviceAccounts: serviceAccountsInfo,
                serviceAccountsManager: (serviceAccountsManager || {}).distinguishedName
            });

            RemedyForce.terminationTXO(params, trg, originalManager, incidentData, trg.applicationGroupsTermination.txoHelp);

            //Centricity termination tickets generation has been disabled because of IAMMSH-322
            //RemedyForce.terminationCentricity(params, trg, originalManager, incidentData, trg.applicationGroupsTermination.centricity);

            RemedyForce.terminationERPSecurity(params, trg, originalManager, incidentData, trg.applicationGroupsTermination.security);
            RemedyForce.terminationTelecom(params, trg, originalManager, incidentData, trg.applicationGroupsTermination.telecom);
            RemedyForce.terminationTiger(params, trg, originalManager, incidentData, trg.applicationGroupsTermination.tigerB);
            RemedyForce.terminationTiger(params, trg, originalManager, incidentData, trg.applicationGroupsTermination.tigerC);
            RemedyForce.terminationIknowmed(params, trg, originalManager, incidentData, trg.applicationGroupsTermination.iknowmed);
            RemedyForce.terminationSalesforce(params, trg, originalManager, incidentData, trg.applicationGroupsTermination.salesforce);
            RemedyForce.terminationWorkday(params, trg, originalManager, incidentData, trg.applicationGroupsTermination.workday);

            //Database termination tickets has been disabled because of IAMMSH-646
            //RemedyForce.terminationDatabase(params, trg, originalManager, incidentData);

            switch (ticketMode) {
                case TICKET_BASIC_TRANSFER:
                    //Open  Ticket from currentManagerFirst, currentManagerLasst (even if manager not
                    //active/terminated). Send current user groups and location of archived home directory
                    Mail.sendMailToManager(params, "UserTransferBU_OldManager", originalManager, trg, {
                        archivedHomeDirectory: trg.archivedHomeDirectory || "",
                        incidentData: incidentData
                    });

                    //Send email to newManagerMail containing currentGroups, AD.homeDirectory and homeDirectory
                    //tpl:UserTransferBU_NewManager
                    Mail.deferredSendMailToManager(params, "UserTransferBU_NewManager", trg, src, {
                        incidentData: incidentData
                    });
                    break;

                case TICKET_CLINICAL_TRANSFER:
                    Mail.sendMailToManager(params, "UserTransferBU_OldManager", originalManager, trg, {
                        archivedHomeDirectory: trg.archivedHomeDirectory || "",
                        incidentData: incidentData
                    });

                    //Send email to newManagerMail containing currentGroups, AD.homeDirectory and homeDirectory
                    //tpl:UserTransferBU_NewManager
                    Mail.deferredSendMailToManager(params, "ClinicalTransfer", trg, src, {
                        incidentData: incidentData
                    });
                    break;

                case TICKET_TERMINATION:
                    //Open  Ticket from currentManagerFirst, currentManagerLasst (even if manager not
                    //active/terminated). Send current user groups and location of archived home directory
                    Mail.sendMailToManager(params, "UserTermination", originalManager, trg, {
                        archivedHomeDirectory: trg.archivedHomeDirectory || "",
                        incidentData: incidentData
                    });
            }

            return incidentData;
        },

        verifyMappingGroupsValidity: function(params) {
            var problems = [];
            var errorMessage = null;

            try {
                var groupMappingsArray = Managed.queryAllGroupMappings();
                var groupMappings = {};

                var groupMapping;
                var groupName;

                for (var i = 0; i < groupMappingsArray.length; i++) {
                    groupMapping = groupMappingsArray[i];
                    groupName = groupMapping.name;
                    if (groupMappings[groupName]) {
                        problems.push({
                            groupName: groupName,
                            groupDN: groupMapping.dn,
                            message: "Group name is not unique"
                        });
                    } else {
                        groupMappings[groupName] = groupMapping;
                    }
                }

                var hrbuArray = Managed.queryAllHRBU();

                var checkGroups = function (attrName) {
                    for (var i = 0; i < hrbuArray.length; i++) {
                        var hrbu = hrbuArray[i];
                        var hrbuGroupsString = hrbu[attrName];

                        if (!hrbuGroupsString) {
                            continue;
                        }

                        var hrbuGroups = hrbuGroupsString.split(/\s*,\s*/g);

                        for (var j = 0; j < hrbuGroups.length; j++) {
                            var hrbuGroup = hrbuGroups[j];

                            if (!hrbuGroup) {
                                continue;
                            }

                            if (!groupMappings[hrbuGroup]) {
                                //if group is missing, add empty entry now and process it later
                                //there may be multiple entries referring to missing group
                                groupMappings[hrbuGroup] = {};
                            }
                        }
                    }
                };

                checkGroups('groups');
                checkGroups('contractor_groups');
                checkGroups('contingentworkertype_outside_worker_groups');
                checkGroups('contingentworkertype_x_groups');

                for (groupName in groupMappings) {
                    groupMapping = groupMappings[groupName];
                    var group = Uson.findGroupByDN(groupMapping.dn);

                    if (!group) {
                        problems.push({
                            groupName: groupMapping.name || groupName,
                            groupDN: groupMapping.dn,
                            message: "Group not found"
                        });
                    }
                }
            } catch (e) {
                logger.error("Error verifying groups validity => {}", e);
                errorMessage = e.message;
            }

            if (problems.length > 0 || errorMessage) {
                Managed.createAuditRecord(params, "AD.verifyMappingGroupsValidity", problems, errorMessage || "There are group configuration issues");
            }
        },

        updateLeaveOfAbsence: function(params, src, trg) {
            var srcLeaveOfAbsence = src.leaveOfAbsence || "false";
            var trgLeaveOfAbsence = trg.leaveOfAbsence || "false";

            if (Util.differ(srcLeaveOfAbsence, trgLeaveOfAbsence)) {
                var updateData = {
                    _id: trg._id,
                    provisioner: trg.provisioner,
                    leaveOfAbsence: srcLeaveOfAbsence
                };
                var jobCode = Reconciliation.getJobCode(src.jobFamily);
                if (jobCode == null || Managed.isJobCodeInPreventLoAJobCodes(jobCode) == false) {
                    if (srcLeaveOfAbsence == "true") {
                        updateData.enable = false;
                        Uson.updateUser(params, updateData);
                        Mail.deferredSendMailToManager(params,
                                "LeaveOfAbsence", trg, src);
                        PShell.setLogonHours(params, false, trg);
                        PShell.hideFromAddressLists(params, trg);
                    } else {
                        updateData.enable = true;
                        Uson.updateUser(params, updateData);
                        Mail.deferredSendMailToManager(params,
                                "LeaveOfAbsenceEnd", trg, src);
                        PShell.setLogonHours(params, true, trg);
                        PShell.showInAddressLists(params, trg);
                    }
                }
            }
        },

        getJobCode : function(jobFamily) {
            var result = null;
            if (jobFamily != null) {
                var arr = jobFamily.split("-");
                if (arr.length > 0) {
                    result = arr[0];
                }
            }
            return result;
        },

        updateCommonAttributes: function(src, trg, delta) {
            if (Util.differ(trg.middleName, src.middleName)) {
                delta.middleName = src.middleName;
            }

            var initials = src.middleName ? src.middleName.substring(0,1) : null;
            if (Util.differ(trg.initials, initials)) {
                delta.initials = initials;
            }
            if (Util.differ(trg.state, src.state)) {
                delta.state = src.state;
            }
            if (Util.differ(trg.st, src.state)) {
                delta.st = src.state;
            }
            if (Util.differ(trg.streetAddress, src.address)) {
                delta.streetAddress = src.address;
            }
            if (Util.differ(trg.street, src.address)) {
                delta.street = src.address;
            }
            if (Util.differ(trg.country, src.country)) {
                delta.country = src.country;
            }
            if (Util.differ(trg.postalCode, src.postalCode)) {
                delta.postalCode = src.postalCode;
            }
            if (Util.differ(trg.postalAddress, src.postalAddress)) {
                delta.postalAddress = src.postalAddress;
            }
            if (Util.differ(trg.workerType, src.workerType)) {
                delta.workerType = src.workerType;
            }
            if (Util.differ(trg.city, src.city)) {
                delta.city = src.city;
            }
            if (Util.differ(trg.facsimileTelephoneNumber, src.fax)) {
                delta.facsimileTelephoneNumber = Util.nullifyEmptyString(src.fax);
            }
            if (Util.differ(trg.mobilePhone, src.mobile)) {
                delta.mobilePhone = Util.nullifyEmptyString(src.mobile);
            }
            if (Util.differ(trg.telephoneNumber, src.telephoneNumber)) {
                delta.telephoneNumber = Util.nullifyEmptyString(src.telephoneNumber);
            }

            var descriptionPrefix = (src.employee == "false") ? "CONTRACTOR: " : "";
            var description = descriptionPrefix + src.title + ", " + src.city + ", " + src.state;
            if (Util.differ(trg.description, description)) {
                delta.description = description;
            }

            var physicalDeliveryOfficeName = "" + src.hrbu.substring(0,5) + "," + src.city + "," + src.address;
            if (Util.differ(trg.physicalDeliveryOfficeName, physicalDeliveryOfficeName)) {
                delta.physicalDeliveryOfficeName = physicalDeliveryOfficeName;
            }
        },

        create : function (params, src) {
            logger.debug("Reconciliation.create => begin");
            logger.debug("  source => {}", src);

            var hrbuProp = Managed.findHRBU(src.hrbu, src.city, src.address);
            if (!hrbuProp) {
                logger.debug("  HRBU NOT FOUND! source => {}", src);

                //create report
                Managed.createAuditRecord(params, "Reconciliation.HrbuNotFound", src, "Reconciliation Hrbu not found");
                return null;
            }
            if (hrbuProp.notify_manager == "true") {
                //tpl:NewCityForTXOFoundWithoutMapping
                Mail.sendMailForMissingCityMapping(params, {newCityForTXO: src.city});
            }
            logger.debug("  hrbuProp => {}", hrbuProp.hrbu);

            var userName = Uson.generateUID(src.firstName, src.lastName);
            var homeDirectory = Uson.generateHomeDirectory(hrbuProp.home_dir, userName);

            var trg = {
                userName : userName,
                hrbu : hrbuProp.hrbu,
                homeDrive : hrbuProp.home_drive || null,
                scriptPath : hrbuProp.login_script,
                homeDirectory : homeDirectory || null
            };

            var domain = Uson.getDomain(hrbuProp.ou);

            trg.provisioner = domain;
            trg.dn = Uson.generateDN(Uson.generateBaseCN(src), hrbuProp.ou);
            trg.commonName = Util.dnToRDNValue(trg.dn);

            Reconciliation.updateCommonAttributes(src, trg, trg);

            trg.displayName = Uson.generateDisplayName(src);

            if (src.workerID) {
                trg.workerID = src.workerID;
            }
            if (src.firstName) {
                trg.firstName = src.firstName;
            }
            if (src.title) {
                trg.title = src.title;
            }
            if (src.lastName) {
                trg.lastName = src.lastName;
            }
            if (src.active != "true") {
                trg.enable = false;
            }

            // managed attrs
            trg.active = src.active;

            //assume LoA is always false for new users
            trg.leaveOfAbsence = "false";

            trg.isManagerLinked = "false";
            trg.isPasswordSet = "false";
            trg.employee = src.employee;
            trg.nameData = Managed.buildNameData(src);
            trg.currentCity = src.city;
            trg.currentAddress = src.address;
            trg.sourceId = src._id;

            var emails = Uson.generateEmails(hrbuProp, domain, src);
            trg.mail = emails.primary;
            trg.secondaryMail = emails.secondary;
            trg.secondaryMailAdditional = emails.secondaryAdditional;

            trg.showInAddressBook = Uson.getDefaultAddressBook(domain);
            trg.userPrincipalName = Uson.getPrimaryDomainEmail(domain, emails.primary, emails.secondary, emails.secondaryAdditional);
            trg.sAMAccountName = userName;
            trg.company = Uson.getCompany(domain);
            trg.primaryGroupID = Uson.getPrimaryGroupID(domain);
            trg.workerTypeDescriptor = src.workerTypeDescriptor;
            trg.pwdExpired = true;
            trg.terminalServicesProfilePath = Uson.generateTerminalServicesProfilePath(domain, userName);

            trg.companyId = src.companyId;

            var result = Uson.createUser(params, trg, Uson.generatePassword());

            if (result) {
                var userGroups = Uson.cwtGenerateGroups(hrbuProp, trg.workerTypeDescriptor, trg.employee, trg.lastName);
                java.lang.Thread.sleep(20000);
                modifyGroupMembership(params, trg, userGroups, []);

                if (hrbuProp.o365 == "1") {
                    PShell.createRemoteMail(params, result);
                    Deferred.defer("PShell.setCAS", params, result);

                    result.msExchRecipientTypeDetails = Config.REMOTE_MAILBOX_VALUE;
                    trg.msExchRecipientTypeDetails = Config.REMOTE_MAILBOX_VALUE;
                } else {
                    PShell.createMail(params, result);

                    result.msExchRecipientTypeDetails = Config.LOCAL_MAILBOX_VALUE;
                    trg.msExchRecipientTypeDetails = Config.LOCAL_MAILBOX_VALUE;
                }

                if (trg.secondaryMail || trg.secondaryMailAdditional) {
                    PShell.setSecondaryMail(params, trg);
                }

                if (result.homeDirectory) {
                    PShell.createHome(params, result);
                }

                Workday.update(params, {
                    uid: src.uid,
                    userID : result.sAMAccountName.toLowerCase()
                });

                Workday.update(params, {
                    uid: src.uid,
                    email : result.mail
                });

                if (src.active == 'true') {
                    Reconciliation.activate(params, src, trg);
                }
            } else {
                Managed.createAuditRecord(params, "Reconciliation.exceptionDuringUserCreation", trg, "Reconciliation exception during user creation");
            }

            logger.debug("Reconciliation.create => end");

            return result;
        },

        changeManager: function(params, trg, src, newManager) {
            var updateData = {
                _id: trg._id,
                provisioner: trg.provisioner,
                isManagerLinked: "true"
            };

            if (trg.manager != newManager.distinguishedName) {
                //Send email to the currentManagerMail with all user groups
                var currentManager = Uson.getManager(trg.provisioner, trg.manager, null, trg.hrbu, src.executiveDirector);

                if (trg.isPasswordSet != "false") {
                    //tpl:UserTransferSupervisorChange_OldManager
                    Mail.sendMailToManager(params, "UserTransferSupervisorChange_OldManager", currentManager, trg);

                    //Send email to new manager (managerMail) including all user groups
                    //tpl:UserTransferSupervisorChange_NewManager
                    Mail.sendMailToManager(params, "UserTransferSupervisorChange_NewManager", newManager, trg);
                }

                updateData.manager = newManager.distinguishedName;

                Util.mergeRecursive(trg, updateData);
                Uson.updateUser(params, updateData);
            } else {
                Managed.updateUsonUserAttributesLink(params, updateData);
            }
        },

        generatePassword : function (params, src, trg) {
            logger.debug("Reconciliation.generatePassword => begin");

            var manager = Uson.getManager(trg.provisioner, trg.manager, null, trg.hrbu, src.executiveDirector);

            //Set AD.manager = managerDN
            //Generate & Set NEW AD.userPassword
            //Set pwdMustChange = TRUE
            var data = {
                _id : trg._id,
                provisioner: trg.provisioner,
                pwdExpired : true,
                isPasswordSet: "true"
            };

            var password = Uson.generatePassword();
            var incidentData;

            //send e-mail with password to the manager
            //check if manager is direct manager
            //tpl:1.NewUserWithManager (add generated password to params)
            //else
            //tpl:2.NewUserWithoutManager
            if (manager.isManager) {
                incidentData = RemedyForce.createAccount(params, trg, manager);
                Mail.sendPasswordToManager(params, "NewUserWithManager", manager, trg, password, {
                    incidentData: incidentData
                });
            } else {
                incidentData = RemedyForce.createAccountWithoutManager(params, trg, manager);
                Mail.sendMailToManager(params, "NewUserWithoutManager", manager, trg, {
                    incidentData: incidentData
                });
            }

            Uson.updateUserPassword(params, trg, password);

            var templateName = "NewUserForBusinessPartner";
            var templates = openidm.read("config/custom/workday_email_templates");
            var template = templates.templates[templateName];
            if (templates == null || template == null) {
                logger.error("Can't read email template: {}", templateName);
                throw "Can't read email templates.";
            }
            var emails = [];
            var hrBusinessPartner = null;
            if(src.hrPartner){
                hrBusinessPartner = Managed.findByWorkerID(src.hrPartner);
                if (hrBusinessPartner != null && hrBusinessPartner.email != null && hrBusinessPartner.email.length > 0){
                    emails.push(hrBusinessPartner.email);
                }
            }
            if(hrBusinessPartner == null || hrBusinessPartner.email == null || hrBusinessPartner.email.length == 0){
                emails.push(templates.partnerEmail);
            }
            var hrbuProp = Managed.findHRBU(src.hrbu, src.city, src.address);
            if (hrbuProp) {
                if(hrbuProp.itc_mail){
                    emails.push(hrbuProp.itc_mail);
                }
                else{
                    emails.push(templates.itSecurityEmail);
                }

            }
            if(emails.length > 0){
                var email = Util.join(emails, ",");
                Mail.sendMailToBusinessPartner(params, templateName, {mail:email}, trg, {
                    incidentData: incidentData
                });
            }

            Util.mergeRecursive(trg, data);
            Uson.updateUser(params, data);

            logger.debug("Reconciliation.generatePassword => end");
        },

        linkManager : function (params, src, trg) {
            logger.debug("Reconciliation.linkManager => begin");

            //GetManagerInfo
            //IN:Worker.ManagerID
            //OUT: managerDN, managerMail
            var newManager = Uson.getManager(trg.provisioner, null, src.managerID, src.hrbu.substring(0,5), src.executiveDirector);
            Reconciliation.changeManager(params, trg, src, newManager);

            logger.debug("Reconciliation.linkManager => end");
        },

        updateTXOLocation: function(params, src, trg, hrbuProp) {
            //Update login script if needed (see HRBU-specific provisioning)
            if (trg.scriptPath != hrbuProp.login_script) {
                var result = {};
                result._id = trg._id;
                result.provisioner = trg.provisioner;
                result.scriptPath = hrbuProp.login_script;

                Util.mergeRecursive(trg, result);
                Uson.updateUser(params, result);
            }

            var accountGroups = GroupHelper.getGroups(trg) || [];
            var groupsToAdd = Managed.findHRBUGroups(hrbuProp.groups) || [];

            var trgHrbuProp = Managed.findHRBU(trg.hrbu, trg.currentCity, trg.currentAddress) || {};
            var groupsToRemove = Managed.findHRBUGroups(trgHrbuProp.groups) || [];

            //check if we need to add user to SVR-* group
            if (Util.has(groupsToAdd, Uson.isSVRGroup)) {
                //add all current user's SVR-* groups to the removal list
                groupsToRemove = Util.concat(groupsToRemove, Util.filter(accountGroups, Uson.isSVRGroup));
            }

            modifyGroupMembership(params, trg, Util.withoutIgnoreCase(groupsToAdd, groupsToRemove), Util.withoutIgnoreCase(groupsToRemove, groupsToAdd));

            //tpl:UserTransferLocationchange
            Mail.deferredSendMailToManager(params, "UserTransferLocationchange", trg, src);
        },

        update : function (params, src, trg, hrbuProp) {
            logger.debug("Reconciliation.update => begin");
            logger.debug("  source => {} {}", src._id, src.legalName);
            var result = {};
            var workerHRBU = hrbuProp.hrbu;

            //check managed attrs. in case of null - this is the first pass
            if (trg.isManagerLinked === null) {
                var attr = Managed.createUsonUserAttributesLink(params, {
                    _id : trg._id,
                    isManagerLinked: "false",
                    isPasswordSet: "true",
                    active : src.active,
                    hrbu : workerHRBU,
                    employee : src.employee,
                    sourceId : src._id,
                    nameData: Managed.buildNameData(src),
                    leaveOfAbsence: "false",
                    currentCity: src.city,
                    currentAddress: src.address,
                    companyId: src.companyId,
                    workerTypeDescriptor: src.workerTypeDescriptor,
                    accountExpiredNotificationTimestamp: null
                });
                Util.mergeRecursive(trg, attr);
            }

            //Worker.isActive AND !IDMUser.isActive?
            if (src.active == "true" && trg.active != "true") {
                Reconciliation.activate(params, src, trg);
            }

            if (!hrbuProp) {
                logger.debug("  HRBU NOT FOUND! source => {}", src);
                //create report
                Managed.createAuditRecord(params, "Reconciliation.HrbuNotFound", src, "Reconciliation Hrbu not found");
                return null;
            }

            if (hrbuProp.notify_manager == "true") {
                //tpl:NewCityForTXOFoundWithoutMapping
                Mail.sendMailForMissingCityMapping(params, {newCityForTXO: src.city});
            }

            var hrbuChangeSupressed = Uson.isHRBUChangeSuppressed(trg.hrbu) || Uson.isHRBUChangeSuppressed(workerHRBU);
            var companyChangeSuppressed = Uson.isCompanyChangeSuppressed(src.companyId) || Uson.isCompanyChangeSuppressed(trg.companyId);

            //Worker.OU != AD.OU
            if (!hrbuChangeSupressed && trg.distinguishedName.toLowerCase().indexOf(hrbuProp.ou.toLowerCase()) == -1) {
                trg.originalDistinguishedName = trg.distinguishedName;

                //move user to new OU if needed
                var newDN = Uson.generateDN(trg.commonName, hrbuProp.ou);
                Uson.moveUser(params, trg, newDN);
            }

            var companyIdUpdated = (src.companyId != null && trg.companyId != null && src.companyId != trg.companyId);
            if (src.companyId != trg.companyId) {
                result.companyId = src.companyId;
            }
            if (companyIdUpdated) {
                logger.debug("CompanyId Updated for {}(id={})", src.userID, src.companyId);
            }

            //Worker.HRBU.substring(0,5)
            var hrbuUpdated = trg.hrbu != workerHRBU;
            if (hrbuUpdated) {
                result.hrbu = workerHRBU;
            }

            if (hrbuUpdated || companyIdUpdated) {
                var txoTransfer = Uson.isTXOHRBU(trg.hrbu) && Uson.isTXOHRBU(workerHRBU);
                if (hrbuUpdated && !txoTransfer) {
                    if (!hrbuChangeSupressed) {
                        Reconciliation.updateHRBU(params, src, trg, hrbuProp, false);
                    } else {
                        Managed.createAuditRecord(params, "Suppressed.HRBUTransfer", {to: workerHRBU, from: trg.hrbu});
                    }
                } else if (companyIdUpdated) {
                    if (!companyChangeSuppressed) {
                        Reconciliation.updateHRBU(params, src, trg, hrbuProp, true);
                    } else {
                        Managed.createAuditRecord(params, "Suppressed.ClinicalTransfer", {to: src.companyId, from: trg.companyId});
                    }
                } else {
                    Reconciliation.updateTXOLocation(params, src, trg, hrbuProp);
                }
            } else if (Uson.isTXOHRBU(workerHRBU) && (src.city != trg.currentCity || src.address != trg.currentAddress)) {
                Reconciliation.updateTXOLocation(params, src, trg, hrbuProp);
            }

            if (src.city != trg.currentCity || src.address != trg.currentAddress) {
                result.currentCity = src.city;
                result.currentAddress = src.address;
            }

            var manager = Uson.getManager(trg.provisioner, null, src.managerID, workerHRBU, src.executiveDirector);
            if (!manager.isManager || manager.distinguishedName != trg.manager) {
                result.isManagerLinked = "false";
            }

            //Worker.Title != AD.title
            if (src.title != trg.title) {
                result.title = src.title;
                //Send email to currentManagerMail including user groups
                //tpl:UserTransferTitleChange
                Mail.deferredSendMailToManager(params, "UserTransferTitleChange", trg, src);
            }

            var workerTypeDescriptorUpdated = (
                src.workerTypeDescriptor != null &&
                trg.workerTypeDescriptor != null &&
                Uson.cwtValue(src.workerTypeDescriptor, src.employee) !== Uson.cwtValue(trg.workerTypeDescriptor, trg.employee)
            );

            if (src.workerTypeDescriptor !== trg.workerTypeDescriptor) {
                result.workerTypeDescriptor = src.workerTypeDescriptor;
            }
            if (workerTypeDescriptorUpdated) {
                logger.debug("WorkerTypeDescriptor Updated for {}(descriptor={})", src.userID, src.workerTypeDescriptor);
            }


            //Worker.WorkerType != AD.extensionAttribute3
            if (src.employee != trg.employee || workerTypeDescriptorUpdated) {
                Reconciliation.conversion(params, src, trg, hrbuProp);
            }

            if (Managed.nameDataChanged(Managed.buildNameData(src), trg.nameData)) {
                Reconciliation.nameChange(params, hrbuProp, src, trg);
            } else if (trg.mail && !Util.equalsIgnoreCase(src.email, trg.mail)) {
                //check whether Workday e-mail is current and update it if not
                //this is required because Workday blocks update for e-mails
                //if there are pending workflow approvals for the user
                Workday.update(params, {
                    uid: src.uid,
                    email: trg.mail
                });
            }

            if (trg.sAMAccountName && !Util.equalsIgnoreCase(src.userID, trg.sAMAccountName)) {
                Workday.update(params, {
                    uid: src.uid,
                    userID : trg.sAMAccountName.toLowerCase()
                });
            }

            Reconciliation.updateLeaveOfAbsence(params, src, trg);

            Reconciliation.updateCommonAttributes(src, trg, result);

            if (!Util.isEmpty(result)) {
                Util.mergeRecursive(trg, result);
                result._id = trg._id;
                result.provisioner = trg.provisioner;

                Uson.updateUser(params, result);
                //logger.debug("  target => {}", result);
            } else {
                logger.debug("  target => no changes");
            }

            logger.debug("Reconciliation.update => end");

            return result;
        },

        activate : function (params, src, trg) {
            logger.debug("Reconciliation.activate => begin");
            var result = {};
            if (src.employee == "false") {
                //AD.accountExpires = Worker.DateActivated + 90 days (Epoch time)
                result.accountExpires = Uson.convertDateToADInterval(Util.currentDateShift(90));
            }
            //result.userAccountControl = trg.userAccountControl & 0xFFFD;
            result.enable = true;
            result.active = "true";

            Util.mergeRecursive(trg, result);
            result._id = trg._id;
            result.provisioner = trg.provisioner;

            Uson.updateUser(params, result);

            //sendToCurrentManager
            //tpl:NewUserAccountActivation!!!
            Mail.deferredSendMailToManager(params, "NewUserAccountActivation", trg, src);
            logger.debug("Reconciliation.activate => end");
        },

        commonTermination : function (params, src, trg, manager) {
            logger.debug("Reconciliation.commonTermination => begin");

            trg.archivedHomeDirectory = Uson.generateArchivedHomeDirectory(trg.homeDirectory);

            updateManagedServers(params, trg, manager);

            //Move user home directory with all contents to directory 2ARCHIVENETSEC
            //on the same parent. I.e. ..\$USER ->..\2ARCHIVENETSEC
            if (trg.homeDirectory) {
                PShell.archiveHome(params, trg);
            }

            //Delete Terminal Server Profile
            //Using DFS cmdlet find all targets (folders)
            //that mapped to the profile name \\uson.usoncology.int\profiles\%sn[0]%
            //and delete 2 folders in each:
            //%sAMAccountName%
            //%sAMAccountName%.V2

            //TODO - MSHPS domain?
            PShell.deleteTerminalServerProfile(params, trg);

            trg.associatedAccountsTermination = {
                manager: manager
            };

            trg.applicationGroupsTermination = getUserGroups(trg);

            //Disable all admin accounts managed by this person
            var a = null;
            var account = null;
            var adminAccountsTerminationData = [];
            var adminsManagedByDN = Uson.findAdminsManagedByDN(trg.distinguishedName);
            if (trg.originalDistinguishedName) {
                adminsManagedByDN = Util.unique(Util.IdProjection, adminsManagedByDN, Uson.findAdminsManagedByDN(trg.originalDistinguishedName));
            }

            for (a in adminsManagedByDN) {
                account = adminsManagedByDN[a];

                var originalAdminAccount = Util.mergeRecursive({}, account);
                var updateData = {
                    _id : account._id,
                    provisioner: account.provisioner,
                    enable : false
                };
                var updatedAdminAccount = Util.mergeRecursive(Util.mergeRecursive({}, account), updateData);

                Uson.updateUser(params, updateData);
                modifyGroupMembership(params, account, [], GroupHelper.getGroups(account) || []);

                adminAccountsTerminationData.push({
                    original: originalAdminAccount,
                    updated: updatedAdminAccount
                });
            }

            trg.associatedAccountsTermination.adminAccounts = adminAccountsTerminationData;

            //Find all groups managed by this person
            var groupsManagedByDN = Uson.findGroupsManagedByDN(trg.distinguishedName);
            if (trg.originalDistinguishedName) {
                groupsManagedByDN = Util.unique(Util.IdProjection, groupsManagedByDN, Uson.findGroupsManagedByDN(trg.originalDistinguishedName));
            }

            for (var g in groupsManagedByDN) {
                var group = groupsManagedByDN[g];
                Uson.updateGroup(params, {
                    _id : group._id,
                    provisioner : group.provisioner,
                    managedby : manager.distinguishedName
                });
            }

            trg.associatedAccountsTermination.serviceGroups = groupsManagedByDN;

            //Find all other accounts managed by this person
            var accountsManagedByDN = Uson.findServiceAccountsManagedByDN(trg.distinguishedName);
            if (trg.originalDistinguishedName) {
                accountsManagedByDN = Util.unique(Util.IdProjection, accountsManagedByDN, Uson.findServiceAccountsManagedByDN(trg.originalDistinguishedName));
            }

            for (a in accountsManagedByDN) {
                account = accountsManagedByDN[a];
                Uson.updateUser(params, {
                    _id : account._id,
                    provisioner: account.provisioner,
                    manager : manager.distinguishedName});
            }

            trg.associatedAccountsTermination.serviceAccounts = accountsManagedByDN;

            logger.debug("Reconciliation.commonTermination => end");
        },

        terminate : function (params, src, trg) {
            logger.debug("Reconciliation.terminate => begin");

            if (!Uson.isUserTerminated(trg)) {
                if (trg.isManagerLinked === null) {
                    var attr = Managed.createUsonUserAttributesLink(params, {
                        _id : trg._id,
                        isManagerLinked: "true",
                        isPasswordSet: "true",
                        active : src.active,
                        hrbu : src.hrbu.substring(0,5),
                        employee : src.employee,
                        sourceId : src._id,
                        nameData: Managed.buildNameData(src),
                        currentCity: src.city,
                        currentAddress: src.address
                    });
                    Util.mergeRecursive(trg, attr);
                }

                var manager = Uson.getManager(trg.provisioner, trg.manager, null, trg.hrbu, src.executiveDirector);
                var workerID = trg.workerID;

                Reconciliation.commonTermination(params, src, trg, manager, TICKET_TERMINATION);
                PShell.disableActiveSyncDevice(params, trg);
                PShell.deleteMail(params, trg);

                //write back workerID deleted from user's profile after Exchange mailbox disconnect
                //write back userPrincipalName to <sAMAccountName>@usoncology.int
                var workerIDAndPrincipalUpdate = {
                    _id: trg._id,
                    provisioner: trg.provisioner,
                    workerID: workerID,
                    userPrincipalName: trg.sAMAccountName + Uson.getUserPrincipalNameSuffix(trg.provisioner)
                };

                //Office 365 uses UPN to find users, need to preserve original UPN to pass it to O365 synchronization batch API
                workerIDAndPrincipalUpdate.originalUserPrincipalName = trg.userPrincipalName;

                logger.debug("User - principal changing from {} ({}) to {} ...", trg.userPrincipalName, trg._id, workerIDAndPrincipalUpdate.userPrincipalName);

                Util.mergeRecursive(trg, workerIDAndPrincipalUpdate);
                Uson.updateUser(params, workerIDAndPrincipalUpdate);

                logger.debug("User - principal changed to {}  ({})...", trg.userPrincipalName, trg._id);

                var accountGroups = GroupHelper.getGroups(trg) || [];
                var terminatedGroup = Uson.getTerminatedUsersGroup(trg.provisioner);

                var infoArr = Util.apply(accountGroups, Util.dnToRDNValue);
                var info = Util.join(infoArr,", ");
                info = Util.trim1024(info, "...");

                if (info != null && info.length == 0) {
                    info = null;
                }

                modifyGroupMembership(params, trg, [terminatedGroup], accountGroups);
                java.lang.Thread.sleep(20000);

                var result = {
                    _id : trg._id,
                    provisioner: trg.provisioner,
                    enable : false,
                    active : "false",
                    pwdExpired : true,
                    description : "TERM " + (new Date()).toDateString() + " " + (trg.description ? trg.description[0] : ""),
                    homeDirectory : trg.archivedHomeDirectory || null,
                    homeDrive : null,
                    scriptPath : null,
                    //terminalServicesProfilePath is cleared when empty string is assigned,
                    //setting this property to null causes illegal argument exception */
                    terminalServicesProfilePath: "",
                    info: info
                };

                Util.mergeRecursive(trg, result);
                Uson.updateUser(params, result);
                Uson.updateUserPassword(params, trg, Uson.generatePassword());

                java.lang.Thread.sleep(5000);

                var primaryGroupUpdate = {
                    _id: trg._id,
                    provisioner: trg.provisioner,
                    primaryGroupID: Uson.getTerminatedUsersPrimaryGroupID(trg.provisioner)
                };

                Util.mergeRecursive(trg, primaryGroupUpdate);
                Uson.updateUser(params, primaryGroupUpdate);

                java.lang.Thread.sleep(20000);
                modifyGroupMembership(params, trg, [], [terminatedGroup]);

                //move user to new OU
                var newDN = Uson.generateTerminatedUserDN(trg);
                Uson.moveUser(params, trg, newDN);

                Deferred.defer("RemedyForce.generateAccountRemedyTicketsAndEmails", params, src, trg, manager, TICKET_TERMINATION);
            }
            //tpl:UserTermination
            logger.debug("Reconciliation.terminate => end");
        },

        ensureDisabled : function (params, src, trg) {
            logger.debug("Reconciliation.ensureDisabled => begin");

            if (trg.enable || trg.active == "true") {
                Uson.updateUser(params, {
                    _id: trg._id,
                    provisioner: trg.provisioner,
                    enable: false,
                    active: "false"
                });
            }

            logger.debug("Reconciliation.ensureDisabled => end");
        },

        updateHRBU : function (params, src, trg, hrbuProp, companyTransfer) {
            logger.debug("Reconciliation.updateHRBU => begin");
            logger.debug("  => src.HRBU = {}, trg.HRBU = {}", src.hrbu, trg.hrbu);

            var manager = Uson.getManager(trg.provisioner, trg.manager, null, trg.hrbu, src.executiveDirector);
            Reconciliation.commonTermination(params, src, trg, manager);

            logger.debug("  hrbuProp => {}", hrbuProp.hrbu);

            //move user to new OU if needed
            if (trg.distinguishedName.toLowerCase().indexOf(hrbuProp.ou.toLowerCase()) == -1) {
                var newDN = Uson.generateDN(trg.commonName, hrbuProp.ou);
                Uson.moveUser(params, trg, newDN);
            }

            var homeDirectory = Uson.generateHomeDirectory(hrbuProp.home_dir, trg.sAMAccountName),
            result = {
                _id : trg._id,
                provisioner: trg.provisioner,
                hrbu : hrbuProp.hrbu,
                homeDrive : hrbuProp.home_drive || null,
                scriptPath : hrbuProp.login_script,
                homeDirectory : homeDirectory || null
            };

            Util.mergeRecursive(trg, result);
            Uson.updateUser(params, result);

            var currentGroups = GroupHelper.getGroups(trg);
            // add user to groups
            var newGroups = Uson.cwtGenerateGroups(hrbuProp, src.workerTypeDescriptor, trg.employee, trg.lastName);
            modifyGroupMembership(params, trg, Util.withoutIgnoreCase(newGroups, currentGroups), Util.withoutIgnoreCase(currentGroups, newGroups));

            if (trg.homeDirectory) {
                PShell.createHome(params, trg);
            }

            var ticketMode = companyTransfer ? TICKET_CLINICAL_TRANSFER : TICKET_BASIC_TRANSFER;
            Deferred.defer("RemedyForce.generateAccountRemedyTicketsAndEmails", params, src, trg, manager, ticketMode);
            logger.debug("Reconciliation.updateHRBU => end");
        },

        conversion : function (params, src, trg, hrbuProp) {
            logger.debug("Reconciliation.conversion => begin");
            logger.debug("  => src.employee = {}, trg.employee = {}", src.employee, trg.employee);
            logger.debug("  => src.workerTypeDescriptor = {}, trg.workerTypeDescriptor = {}", src.workerTypeDescriptor, trg.workerTypeDescriptor);
            var groups = [], result = {};

            var shift = Uson.convertDateToADInterval(Util.currentDateShift(90));

            var f_own = function () {
                return Uson.cwtGenerateGroups(hrbuProp, src.workerTypeDescriptor, src.employee, trg.lastName);
            };

            var userGroups = GroupHelper.getGroups(trg);

            var f_empl_contr = function () {
                return Uson.cwtChangeGroups(
                    hrbuProp,
                    Uson.CWT_REGULAR,
                    Uson.CWT_CONTRACTOR,
                    trg.lastName,
                    userGroups
                );
            };

            var f_contr_empl = function () {
                return Uson.cwtChangeGroups(
                    hrbuProp,
                    Uson.CWT_CONTRACTOR,
                    Uson.CWT_REGULAR,
                    trg.lastName,
                    userGroups
                );
            };

            var cwtConversionTable = [
                  [
                      /* CWT_EMPLOYEE --> CWT_EMPLOYEE */
                      null,

                      /* CWT_EMPLOYEE --> CWT_CONTRACTOR */
                      {template: "UserConversionToContractor", gFunc: f_empl_contr, expire: shift},

                      /* CWT_EMPLOYEE --> CWT_OUTSIDE */
                      {template: "UserConversionToContractor", gFunc: f_own, expire: shift},

                      /* CWT_EMPLOYEE --> CWT_X */
                      {template: "UserConversionToContractor", gFunc: f_own, expire: Uson.ACCOUNT_NEVER_EXPIRE_VALUE}
                  ],

                  [
                      /* CWT_CONTRACTOR --> CWT_EMPLOYEE */
                      {template: "UserConversionToEmployee",   gFunc: f_contr_empl, expire: Uson.ACCOUNT_NEVER_EXPIRE_VALUE},

                      /* CWT_CONTRACTOR --> CWT_CONTRACTOR */
                      null,

                      /* CWT_CONTRACTOR --> CWT_OUTSIDE */
                      {template: "UserConversionToContractor", gFunc: f_own, expire: shift},

                      /* CWT_CONTRACTOR --> CWT_X */
                      {template: "UserConversionToContractor", gFunc: f_own, expire: Uson.ACCOUNT_NEVER_EXPIRE_VALUE}
                  ],

                  [
                      /* CWT_OUTSIDE --> CWT_EMPLOYEE */
                      {template: "UserConversionToEmployee",   gFunc: f_own, expire: Uson.ACCOUNT_NEVER_EXPIRE_VALUE},

                      /* CWT_OUTSIDE --> CWT_CONTRACTOR */
                      {template: "UserConversionToContractor", gFunc: f_own, expire: shift},

                      /* CWT_OUTSIDE --> CWT_OUTSIDE */
                      null,

                      /* CWT_OUTSIDE --> CWT_X */
                      {template: "UserConversionToContractor", gFunc: f_own, expire: Uson.ACCOUNT_NEVER_EXPIRE_VALUE}
                  ],

                  [
                      /* CWT_X --> CWT_EMPLOYEE */
                      {template: "UserConversionToEmployee",   gFunc: f_own, expire: Uson.ACCOUNT_NEVER_EXPIRE_VALUE},

                      /* CWT_X --> CWT_CONTRACTOR */
                      {template: "UserConversionToContractor", gFunc: f_own, expire: shift},

                      /* CWT_X --> CWT_OUTSIDE */
                      {template: "UserConversionToContractor", gFunc: f_own, expire: shift},

                      /* CWT_X --> CWT_X */
                      null
                  ]
            ];

            var control = cwtConversionTable[Uson.cwtIndex(trg.workerTypeDescriptor, trg.employee)][Uson.cwtIndex(src.workerTypeDescriptor, src.employee)];

            groups = control.gFunc();
//            logger.debug("conversion#generateGroups for {} finished. Groups: {}", src.sAMAccountName, groups);
            result = {
                _id : trg._id,
                provisioner: trg.provisioner,
                accountExpires : control.expire,
                workerID : src.workerID,
                workerType : src.workerType,
                employee : src.employee,
                workerTypeDescriptor: src.workerTypeDescriptor
            };
            Util.mergeRecursive(trg, result);
            Uson.updateUser(params, result);

            modifyGroupMembership(params, trg, Util.withoutIgnoreCase(groups, userGroups), Util.withoutIgnoreCase(userGroups, groups));

            Mail.deferredSendMailToManager(
                params,
                control.template,
                trg,
                src,
                {
                    usrOldWorkerType: Uson.cwtName(trg.workerTypeDescriptor, trg.employee),
                    usrNewWorkerType: Uson.cwtName(src.workerTypeDescriptor, src.employee)
                }
            );

            logger.debug("Reconciliation.conversion => end");
        },

        nameChange : function (params, hrbuProp, src, trg) {
            logger.debug("Reconciliation.nameChange => begin");
            logger.debug("  => src.firstName = {}, trg.firstName = {}", src.firstName, trg.firstName);
            logger.debug("  => src.lastName = {}, trg.lastName = {}", src.lastName, trg.lastName);
            var result = {
                _id : trg._id,
                provisioner: trg.provisioner,
                firstName : src.firstName,
                lastName : src.lastName,
                legalName: src.legalName
            };

            //Worker.LastName != AD.sn ???
            if (src.employee == "true" &&
                    (src.lastName || "").charAt(0).toUpperCase() != (trg.lastName || "").charAt(0).toUpperCase()) {
                //Remove user from old last name group.
                var groupsToRemove = Util.filter(GroupHelper.getGroups(trg) || [], function(group) {
                    return group.lastIndexOf("CSA Network") != -1;
                });

                //Add user to new last name group
                var groupsToAdd = Managed.findCSAGroups(src.lastName);
                modifyGroupMembership(params, trg, groupsToAdd, groupsToRemove);
            }
            //Create new unique email address,
            //make it primary and keep previous address as secondary Attribute proxyAddresses ????
            var emails = Uson.generateEmails(hrbuProp, trg.provisioner, src, trg);
            result.mail = emails.primary;
            result.secondaryMail = emails.secondary;
            result.secondaryMailAdditional = emails.secondaryAdditional;

            result.displayName = Uson.generateDisplayName(src);
            result.nameData = Managed.buildNameData(src);

            Util.mergeRecursive(trg, result);
            Uson.updateUser(params, result);
            PShell.setPrimaryMail(params, trg);

            if (trg.secondaryMail || trg.secondaryMailAdditional) {
                PShell.setSecondaryMail(params, trg);
            }

            Workday.update(params, {
                uid: src.uid,
                email : result.mail
            });

            var baseCN = Uson.generateBaseCN(src);
            if (!Util.equalsIgnoreCase(Uson.normalizeCN(trg.commonName), baseCN)) {
                var newDN = Uson.generateDN(baseCN, Util.getParentDN(trg.distinguishedName));

                var renameResult = PShell.nameChange(params, trg.distinguishedName, Util.dnToRDNValue(newDN), trg);

                if (isDryRunMode()) {
                    var d = {dn: newDN, distinguishedName: newDN, "_id" : trg.distinguishedName};
                    Staging.getRepo().update(trg._id, d);
                }

                if (!renameResult.errorMessage) {
                    trg.distinguishedName = newDN;
                    trg.dn = newDN;
                }
            }

            logger.debug("Reconciliation.nameChange => end");
        },

        unassigned : function (params, trg) {
            logger.debug("Reconciliation.unassigned => begin");
            logger.debug("  => id = {}, firstName = {}, lastName = {}, dn = {}", trg._id, trg.firstName, trg.lastName, trg.distinguishedName);
            if (!Uson.isUserTerminated(trg)) {
                if (Uson.isUserNeverExpires(trg)) {
                    var result = {};
                    result._id = trg._id;
                    result.provisioner = trg.provisioner;
                    result.accountExpires = Uson.convertDateToADInterval(Util.currentDateShift(30));

                    Util.mergeRecursive(trg, result);
                    Uson.updateUser(params, result);
                }

                Managed.createAuditRecord(params, "Reconciliation.ADUserNotFoundInWorkday", trg);
            }
            logger.debug("Reconciliation.unassigned => end");
        },

        reconcileAD : function (params, src, trg) {
            logger.debug("Reconciliation.reconcileAD => begin");

            var managerNotificationEnabled = false;
            var remedyforceNotificationEnabled = false;

            //IDMUser.Employee = FALSE -> Contractors
            //process contractors that are in CSA OU ONLY
            if (!Uson.isUserInScope(trg) || trg.employee == 'true') {
                logger.debug("Reconciliation.reconcileAD => end");
                return;
            }

            var result = {};
            //AD.accountExpired is NULL?
            logger.debug("  => AD.accountExpired: {}", trg.accountExpires);
            if (Uson.isUserNeverExpires(trg)) {
                //Update AD.accountExpires = Worker.DateActivated + 90 days (Epoch time)
                result.accountExpires = Uson.convertDateToADInterval(Util.workdayDateShift(src.dateActivated, 90));
                trg.accountExpires = result.accountExpires;
            }

            //Read manager's email from AD
            var manager = Uson.getManager(trg.provisioner, trg.manager, null, trg.hrbu, src.executiveDirector);

            var accountExpiresDate = Uson.convertADIntervalToDate(trg.accountExpires);
            var currentDate = new Date();
            logger.debug("  => accountExpiresDate: {}", accountExpiresDate.toString());
            var daysBetweenExpiredAndToday = Util.daysDifference(accountExpiresDate, currentDate);
            logger.debug("  => daysBetweenExpiredAndToday: {}", daysBetweenExpiredAndToday);

            if (accountExpiresDate > currentDate) {
                if (daysBetweenExpiredAndToday > 190) {
                    var newExpirationPeriod = 30;
                    result.accountExpires = Uson.convertDateToADInterval(Util.currentDateShift(newExpirationPeriod));

                    if (managerNotificationEnabled) {
                        Mail.sendMailToManager(params, "AccountExpiration190", manager, trg, {
                            initialExpirationPeriod: daysBetweenExpiredAndToday,
                            initialExpirationDate: accountExpiresDate.toLocaleDateString(),
                            newExpirationPeriod: newExpirationPeriod
                        });
                    }
                }
                //AD.accountExpired - TODAY == 0d?
                if (daysBetweenExpiredAndToday == 0) {

                    if (managerNotificationEnabled) {
                        //Send email to manager
                        //tpl:UserAccountExpiringNoticeToManager
                        Mail.sendMailToManager(params, "UserAccountExpiringTodayNoticeToManager", manager, trg, {
                            noticeDays: daysBetweenExpiredAndToday
                        });
                    }
                //AD.accountExpired - TODAY < 14d?
                } else if (daysBetweenExpiredAndToday < 14) {

                    //Send email to manager
                    //tpl:UserAccountExpiringDailyNoticeToManager // not expired yet  but going to
                    if (managerNotificationEnabled) {
                        Mail.sendMailToManager(params, "UserAccountExpiringDailyNoticeToManager", manager, trg, {
                            noticeDays: daysBetweenExpiredAndToday,
                            noticeNum: (14 - daysBetweenExpiredAndToday)
                        });
                    }
                }
            } else {
                //Number of days
                var accountExpiredRemedyNotificationWindow = 4;
                //Open  Ticket
                var incidentData = null;

                if (-daysBetweenExpiredAndToday < accountExpiredRemedyNotificationWindow) {
                    if (trg.accountExpires != trg.accountExpiredNotificationTimestamp && remedyforceNotificationEnabled) {
                        result.accountExpiredNotificationTimestamp = trg.accountExpires;
                        incidentData = RemedyForce.accountExpired(params, trg, manager);
                    }
                }

                if (managerNotificationEnabled) {
                    //tpl:UserAccountDisabledDailyNoticeToManager //already expired
                    Mail.sendMailToManager(params, "UserAccountDisabledDailyNoticeToManager", manager, trg, {
                        noticeDays: -daysBetweenExpiredAndToday,
                        incidentData: incidentData
                    });
                }

                //TODAY - AD.accountExpired >= 30d?
                if ( (-1) * daysBetweenExpiredAndToday >= 30) {

                    if (managerNotificationEnabled) {
                        //Send email to DLDirectoryServices@USONCOLOGY.COM
                        //tpl:UserAccountExpiredITSecurityDaily
                        Mail.sendMailToManager(params, "UserAccountExpiredITSecurityDaily", manager, trg, {
                            noticeDays: -daysBetweenExpiredAndToday
                        });
                    }

                //TODAY - AD.accountExpired >= 14d?
                } else if ((-1) * daysBetweenExpiredAndToday >= 14) {

                    var partnerEmail = null;
                    var partnerFirstname = null;

                    if (src.hrPartner) {
                        var hrPartner = Uson.findFirst("workerID", src.hrPartner, Util.not(Uson.isUserTerminated));
                        if (hrPartner && hrPartner.mail) {
                            partnerEmail = hrPartner.mail;
                            partnerFirstname = hrPartner.firstName;
                        }
                    }

                    //Send email to HR
                    //tpl:UserAccountExpiredHRNotice
                    Mail.sendMailToHRPartner(params, "UserAccountExpiredHRNotice", manager, trg, {
                        noticeDays: -daysBetweenExpiredAndToday,
                        partnerEmail: partnerEmail,
                        partnerFirstname: partnerFirstname
                    });
                }
            }

            if (!Util.isEmpty(result)) {
                result._id = trg._id;
                result.provisioner = trg.provisioner;

                Uson.updateUser(params, result);
                //logger.debug("  target => {}", result);
            }

            logger.debug("Reconciliation.reconcileAD => end");
        }
    };
}());
