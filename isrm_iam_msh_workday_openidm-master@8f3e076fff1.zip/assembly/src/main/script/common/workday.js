load.call(this, "script/common/config.js");
load.call(this, "script/passwordGenerator.js");
load.call(this, "script/common/util.js");
load.call(this, "script/common/managed.js");
load.call(this, "script/common/staging.js");

Workday = (function() {

    var WORKDAY_ACCOUNT_URL = "system/" + Config.getWorkdayProvisionerName() + "/__ACCOUNT__/";

    return {

        isUserIDSet: function(uid) {
            return !!(Managed.findByUID(uid) || {}).userID;
        },

        findByUID: function(uid) {
            return openidm.read(WORKDAY_ACCOUNT_URL + uid);
        },

        update: function(params, data) {
            logger.debug("  Workday.updateUser =>");

            var dataClone = Util.mergeRecursive({}, data);
            var errorMessage = "";
            var lock = Staging.getSynchronizationLock();
            try {
                lock.lock();

                if (dataClone.userID && !Workday.isUserIDSet(data.uid)) {
                    //if Workday user does not have userID and we're providing userID to set,
                    //we need to generate and specify password as well
                    dataClone.password = PasswordGenerator.generate();
                }

                if (!isDryRunMode()) {
                    openidm.update(WORKDAY_ACCOUNT_URL + data.uid, null, dataClone);
                }
            } catch (e) {
                errorMessage = Util.getExceptionMessage(e);
                logger.debug("  Can't update user! target => {}", data);
            } finally {
                lock.unlock();
            }

            if (dataClone.password) {
                dataClone.password = "*****";
            }

            if (
                errorMessage &&
                (
                    errorMessage.indexOf("You cannot initiate this action because there are other pending or completed actions for the worker that conflict with this one.") > 0 ||
                    errorMessage.indexOf("Contact Information Events that change an Address must be done in order. To submit an event that changes an address with an earlier effective date you must rescind any Contact Information Events that change an address with a later effective date.") > 0 ||
                    errorMessage.indexOf("Effective Date Entered must be later than maximum address effective date. Please rescind latest Contact Information event in order to add an address with an earlier effective date.") > 0
                )
            ) {
                params = Util.mergeRecursive({severity: "WARNING"}, params);
            }

            Managed.createAuditRecord(params, "Workday.updateUser", dataClone, errorMessage);
            return null;
        }
    };

}());
