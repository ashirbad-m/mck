ArrayIterator = function(items) {
    this.items = items;
    this.index = 0;
};

ArrayIterator.prototype.hasNext = function() {
    return this.index < this.items.length;
};

ArrayIterator.prototype.next = function() {
    if (!this.hasNext()) {
        throw "No more items";
    }

    return this.items[this.index++];
};
