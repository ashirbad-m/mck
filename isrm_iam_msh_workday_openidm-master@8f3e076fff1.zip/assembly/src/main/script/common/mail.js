load.call(this, "script/common/config.js");
load.call(this, "script/common/cache.js");
load.call(this, "script/common/uson.js");
load.call(this, "script/common/managed.js");
load.call(this, "script/common/genericMail.js");
load.call(this, "script/common/util.js");
load.call(this, "script/common/groupHelper.js");
load.call(this, "script/common/deferred.js");

Mail = (function() {

    var groupDescriptionProducer = function(groupDN) {
        return (Uson.findGroupByDN(groupDN) || {}).description || "";
    };

    var buildGroupData = function(groupDN) {
        var description = GroupDescriptionCache.get(groupDN, groupDescriptionProducer);

        return {
            name: Util.dnToRDNValue(groupDN),
            description: description,
            hasDescription: (description + "").length != 0
        };
    };

    var populateUserParameters = function(params, user, userData, templateProperties) {
        templateProperties.noticeDays = "";
        templateProperties.noticeNum = "";
        templateProperties.initialExpirationPeriod = "";
        templateProperties.initialExpirationDate = "";
        templateProperties.newExpirationPeriod = "";
        templateProperties.ticketLink = "";
        templateProperties.ticketNumber = "";

        var hrUser = params.sourceObject || {};
        var groups = Util.apply(GroupHelper.getGroups(user) || [], buildGroupData);

        var originalUser = params.targetObject || {};
        var oldGroups = Util.apply(GroupHelper.getGroups(originalUser) || [], buildGroupData);

        Util.mergeRecursive(templateProperties, {
            usrDomain: (user.provisioner || "?").toUpperCase(),
            usrCellPhone: user.mobilePhone ? user.mobilePhone : "",
            usrCity: user.city || "",
            usrComments: "",
            usrDepartment: user.department || "",
            usrEffectiveDate: hrUser.positionEffectiveDate || "",
            usrEmail: user.mail ? user.mail : "",
            usrFax: user.facsimileTelephoneNumber || "",
            usrFirstname: user.firstName ? user.firstName : "",
            usrHomeDirectory: user.homeDirectory ? user.homeDirectory : "",
            usrLastname: user.lastName ? user.lastName : "",
            usrLoginScript:  user.scriptPath || "",
            usrOrganization: user.company || "",
            usrOU: user.dn ? Util.dnToOU(user.dn) : "",
            usrPager: "",
            usrSpeciality: "",
            usrSuffix: "",
            usrTitle: user.title || "",
            usrUID: user.sAMAccountName ? user.sAMAccountName : "",
            usrWorkAddress: user.streetAddress ? user.streetAddress : "",
            usrWorkerType: user.employee || user.employee == "true" ? "Employee" : "Contractor",
            usrWorkPhone: user.telephoneNumber ? user.telephoneNumber : "",
            usrZip: user.postalCode || "",
            usrGroupsList: groups,
            usrOldGroupsList: oldGroups,
            usrLegalName: hrUser.legalName
        });

        if (userData) {
            if (userData.archivedHomeDirectory || String(userData.archivedHomeDirectory).length == 0 /* empty string is now valid parameter value */) {
                templateProperties.usrHomeDirectory = userData.archivedHomeDirectory || "";
            }
            if (userData.noticeDays || userData.noticeDays == 0) {
                templateProperties.noticeDays = userData.noticeDays;
            }
            if (userData.noticeNum || userData.noticeNum == 0) {
                templateProperties.noticeNum = userData.noticeNum;
            }
            if (userData.initialExpirationPeriod) {
                templateProperties.initialExpirationPeriod = userData.initialExpirationPeriod;
            }
            if (userData.initialExpirationDate) {
                templateProperties.initialExpirationDate = userData.initialExpirationDate;
            }
            if (userData.newExpirationPeriod) {
                templateProperties.newExpirationPeriod = userData.newExpirationPeriod;
            }
            if (userData.servers) {
                templateProperties.servers = userData.servers;
            }
            if (userData.incidentData) {
                templateProperties.ticketLink = userData.incidentData.incidentUrl;
                templateProperties.ticketNumber = userData.incidentData.incidentName;
            }
            if (userData.usrOldWorkerType) {
                templateProperties.usrOldWorkerType = userData.usrOldWorkerType;
            }
            if (userData.usrNewWorkerType) {
                templateProperties.usrNewWorkerType = userData.usrNewWorkerType;
            }
            if (userData.usrFullname) {
                templateProperties.usrFullname = userData.usrFullname;
            }
            if (userData.newCityForTXO) {
                templateProperties.newCityForTXO = userData.newCityForTXO;
            }
        }
    };

    var populateManagerParameters = function(manager, templateProperties) {
        Util.mergeRecursive(templateProperties, {
            mgrEmail : manager.mail ? manager.mail : "",
            mgrFirstname : manager.firstName ? manager.firstName : "",
            mgrLastname : manager.lastName ? manager.lastName : "",
            mgrPhonenumber : manager.telephoneNumber ? manager.telephoneNumber : ""
        });
    };

    var populatePartnerParameters = function(userData, templateProperties) {
        templateProperties.partnerFirstname = userData.partnerFirstname || "";
        templateProperties.partnerEmail = userData.partnerEmail || templateProperties.partnerEmail;
    };

    var populateAllParameters = function(params, manager, user, userData) {
        var templateProperties = {};

        manager = manager || {};
        user = user || {};
        userData = userData || {};

        populateManagerParameters(manager, templateProperties);
        populateUserParameters(params, user, userData, templateProperties);
        populatePartnerParameters(userData, templateProperties);

        return templateProperties;
    };

    var EmailBuilder = function(actionParam, templateNameParam) {
        var manager;
        var user;
        var userData;

        var action = actionParam;
        var templateName = templateNameParam;

        this.manager = function(managerParam) {
            manager = managerParam || {};
            return this;
        };

        this.user = function(userParam) {
            user = userParam || {};
            return this;
        };

        this.userData = function(userDataParam) {
            userData = userDataParam || {};
            return this;
        };

        this.getAction = function() {
            return action;
        };

        this.getTemplate = function() {
            return templateName;
        };

        this.build = function(params) {
            var templates = openidm.read("config/custom/workday_email_templates");
            var template = templates.templates[templateName];
            if (templates == null || template == null) {
                logger.error("Can't read email template: {}", templateName);
                throw "Can't read email templates.";
            }

            var templateProperties = populateAllParameters(params, manager, user, userData);
            //fill static params defined in template
            templateProperties.today = Util.formatDate(new Date(), "EEE, MMM dd yyyy");
            templateProperties.helpdeskEmail = templates.helpdeskEmail;
            templateProperties.itSecurityEmail = templates.itSecurityEmail;
            templateProperties.cityManagerEmail = templates.cityManagerEmail;
            templateProperties.cityManagerName = templates.cityManagerName;
            templateProperties.partnerEmail = templateProperties.partnerEmail || templates.partnerEmail;
            templateProperties.provisioningEmail = templates.provisioningEmail;
            templateProperties.selfserviceResetURL = Config.getSelfserviceResetURL();

            var from = Util.formatString(template.from, templateProperties);
            var to = Util.formatString(template.to, templateProperties);
            var subject = Util.formatString(template.subject, templateProperties);

            var context = {};
            Handlebars.Utils.extend(context, templateProperties);
            context.templateName = "Mail-" + templateName;
            var body = Handlebars.templates.email(context);
            body = body.replace(/^\s*\r?\n$/gm, "");

            return {
                action: action,
                from: from,
                to: to,
                subject: subject,
                body: body
            };
        };
    };

    var enqueueMailAudited = function(params, emailBuilder) {
        logger.debug("  Mail.enqueueMailAudited => ");
        var errorMessage = "";
        try {
            Deferred.defer("Mail.deliverDeferredEmail", params, {templateName: emailBuilder.getTemplate(), emailData: emailBuilder.build(params)});
        } catch (e) {
            errorMessage = e.message;
            logger.error("  Catch exception Mail.enqueueMailAudited => {} {}", emailBuilder.getAction(), emailBuilder.getTemplate());
        }

        Managed.createAuditRecord(params, "Mail.enqueueMail", {action: emailBuilder.getAction(), template: emailBuilder.getTemplate()}, errorMessage);
    };

    var sendMailAudited = function(params, data) {
        logger.debug("  Mail.sendMailAudited => ");
        var errorMessage = "";
        try {
            GenericMail.sendGenericMail(data.from, data.to, data.subject, data.body);
        } catch (e) {
            errorMessage = e.message;
            logger.error("  Catch exception Mail.sendMailAudited => {}, {}, {}, {}", data.from, data.to, data.subject, data.body);
        }

        Managed.createAuditRecord(params, data.action, data, errorMessage);
    };

    return {

        sendMailForMissingCityMapping: function(params, userData) {
            return enqueueMailAudited(params, new EmailBuilder("Mail.sendMailForMissingCityMapping", "NewCityForTXOFoundWithoutMapping").userData(userData));
        },

        sendMailToBusinessPartner: function(params, templateName, manager, user, userData) {
            return enqueueMailAudited(params, new EmailBuilder("Mail.sendMailToBusinessPartner", templateName).manager(manager).user(user).userData(userData));
        },

        sendMailToManager: function(params, templateName, manager, user, userData) {
            return enqueueMailAudited(params, new EmailBuilder("Mail.sendMailToManager", templateName).manager(manager).user(user).userData(userData));
        },

        sendMailToHRPartner: function(params, templateName, manager, user, userData) {
            return enqueueMailAudited(params, new EmailBuilder("Mail.sendMailToHRPartner", templateName).manager(manager).user(user).userData(userData));
        },

        sendPasswordToManager: function(params, templateName, manager, user, password, userData) {
            var errorMessage = "";
            var auditData = {template: templateName};
            try {
                var emailBuilder = new EmailBuilder("Mail.sendMailToManager", templateName).manager(manager).user(user).userData(userData);
                var emailData = emailBuilder.build(params);
                auditData = emailData;

                GenericMail.sendGenericMail(emailData.from, emailData.to, emailData.subject, emailData.body.replace("###PASSWORD###", password));
            } catch (e) {
                errorMessage = e.message;
                logger.error("  Catch exception Mail.sendPasswordToManager => {}", auditData);
            }

            Managed.createAuditRecord(params, "Mail.sendMailToManager", auditData, errorMessage);
        },

        deferredSendMailToManager: function(params, templateName, user, src, userData) {
            logger.debug("  Mail.deferredSendMailToManager => ");
            var errorMessage = "";
            try {
                Deferred.defer("Mail.deliverDeferredEmail", params, {
                    params: params,
                    templateName: templateName,
                    user: user,
                    executiveDirector: src.executiveDirector,
                    userData: userData,
                    deferredToManager: true
                });
            } catch (e) {
                errorMessage = e.message;
                logger.error("  Catch exception Mail.deferredSendMailToManager => {}, {}", templateName, user);
            }
            Managed.createAuditRecord(params, "Mail.deferredSendMailToManager", {
                template: templateName
            }, errorMessage);
            return null;
        },

        deliverDeferredEmail: function(params, emailData) {
            logger.debug("  Mail.deliverDeferredEmail => ");
            var errorMessage = "";

            try {
                if (emailData.deferredToManager) {
                    var usonUser = Uson.findByUID(emailData.user._id) || {};
                    var manager = Uson.getManager(usonUser.provisioner, usonUser.manager, null, usonUser.hrbu, emailData.executiveDirector);

                    var emailBuilder = new EmailBuilder("Mail.sendMailToManager", emailData.templateName).manager(manager).user(emailData.user).userData(emailData.userData);

                    sendMailAudited(params, emailBuilder.build(params));
                } else {
                    sendMailAudited(params, emailData.emailData);
                }
            } catch (e) {
                errorMessage = e.message;
                logger.error("  Catch exception Mail.deliverDeferredEmail => {}", emailData);
            }
            Managed.createAuditRecord(params, "Mail.deliverDeferredEmail", {template: emailData.templateName}, errorMessage);
        }
    };
}());
