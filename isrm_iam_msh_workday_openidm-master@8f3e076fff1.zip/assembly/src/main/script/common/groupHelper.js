load.call(this, "script/common/config.js");
load.call(this, "script/common/util.js");
load.call(this, "script/common/staging.js");

GroupHelper = (function() {

    var getGroupHelperData = function() {
        return com.mckesson.ScriptUtil.getRequestVar("groupHelperData");
    };

    var readGroups = function(distinguishedName) {
        var query = Util.Filters.equals("member", '' + distinguishedName);

        var groupsData = Util.applyAndMerge(Config.getDomainConfigurations(), function(domainConfiguration) {
            return openidm.query("system/" + domainConfiguration.name + "/group", {query: query, params: {_fields: "dn"}}).result || [];
        });

        return Util.apply(groupsData, function(groupData) {
            return groupData.dn;
        });
    };

    var setGroups = function(trg, groups) {
        trg.groupsSet = true;
        trg.groups = groups || [];
    };

    return {

        setup: function() {
            com.mckesson.ScriptUtil.setRequestVar("groupHelperData", {});
        },

        getGroups: function(trg) {
            if (!trg.groupsSet) {
                var groupHelperData = getGroupHelperData();

                var lock = Staging.getSynchronizationLock();
                try {
                    lock.lock();

                    var id = '' + trg._id;

                    if (!groupHelperData[id]) {
                        groupHelperData[id] = readGroups(trg.distinguishedName) || [];
                    }

                    //set copy of groupHelperData array as trg object attribute
                    setGroups(trg, groupHelperData[id].slice());
                } finally {
                    lock.unlock();
                }
            }

            return trg.groups;
        },

        setGroups: function(trg, groups) {
            //force initial groups to load into getGroupHelperData before change
            GroupHelper.getGroups(trg);

            setGroups(trg, groups);
        }
    };
}());