load.call(this, "script/common/config.js");
load.call(this, "script/common/util.js");

Staging = Util.createClass(function() {
    this.idIndex = {};
    this.dnIndex = {};
    this.cnIndex = {};
    this.workerIDIndex = {};

    this.generatedDN = {};
    this.generatedUID = {};
    this.generatedMail = {};

    this.dnRenames = {};

    this.lock = new java.util.concurrent.locks.ReentrantLock();
}, {

    __readAccount: function(id) {
        var account = null;

        var domainConfigurations = Config.getDomainConfigurations();
        for (var i = 0; i < domainConfigurations.length; i++) {
            account = openidm.read("system/" + domainConfigurations[i].name + "/account/" + id);

            if (account) {
                break;
            }
        }

        return account;
    },

    __lock: function() {
        this.lock.lock();
    },

    __unlock: function() {
        this.lock.unlock();
    },

    __store: function(data) {
        this.idIndex[Util.toLowerCase(data._id)] = data;
        this.dnIndex[Util.toLowerCase(data.distinguishedName)] = data;
        this.workerIDIndex[Util.toLowerCase(data.workerID)] = data;
        this.cnIndex[Util.toLowerCase(data.commonName)] = data;
    },

    __update: function(oldValue, newValue) {
        var oldName = Util.toLowerCase(oldValue.distinguishedName);
        var newName = Util.toLowerCase(newValue.distinguishedName);

        if (newName && newName !== oldName) {
            delete this.dnIndex[oldName];
            this.dnRenames[oldName] = newName;
        }

        var oldWorkerID = Util.toLowerCase(oldValue.workerID);
        var newWorkerID = Util.toLowerCase(newValue.workerID);

        if (newWorkerID && newWorkerID !== oldWorkerID) {
            delete this.workerIDIndex[oldWorkerID];
        }
    },

    __updateReferences: function(obj) {
        if (obj && obj.manager) {
            var newManagerDN = this.dnRenames[Util.toLowerCase(obj.manager)];
            if (newManagerDN) {
                var objCopy = Util.mergeRecursive({}, obj);
                objCopy.manager = String(newManagerDN);
                return objCopy;
            }
        }

        return obj;
    },

    generateCN: function(base, offset) {
        var idx = offset;
        this.__lock();
        try {
            while (true) {
                var idxCN = base + (idx <= 0 ? "" : idx);

                if (this.cnIndex[Util.toLowerCase(idxCN)] == null) {
                    return idxCN;
                }

                idx++;
            }

            return base + idx;
        } finally {
            this.__unlock();
        }
    },

    create: function(id, data) {
        this.__lock();
        try {
            var existingObject = this.idIndex[Util.toLowerCase(id)];
            if (existingObject != null) {
                throw "Object already exists: " + id;
            }

            data._id = id;
            this.__store(data);

            return data;
        } finally {
            this.__unlock();
        }
    },

    read: function(id) {
        this.__lock();
        try {
            var localData = this.idIndex[Util.toLowerCase(id)];
            if (localData != null) {
                return this.__updateReferences(localData);
            }

            return this.__updateReferences(this.__readAccount(id));
        } finally {
            this.__unlock();
        }
    },

    update: function(id, data) {
        this.__lock();
        try {
            var initialData = this.idIndex[Util.toLowerCase(id)];
            if (initialData == null) {
                initialData = this.__readAccount(id);
                if (!initialData) {
                    throw "Object " + id + " does not exist";
                }
            }

            initialData = this.__updateReferences(initialData);

            var updatedData = Util.mergeRecursive({}, initialData);
            Util.mergeRecursive(updatedData, data);
            updatedData._id = id;

            this.__update(initialData, updatedData);
            this.__store(updatedData);

            return data;
        } finally {
            this.__unlock();
        }
    },

    find: function(field, value) {
        var localResult = null;
        var results = [];

        this.__lock();
        try {
            value = Util.toLowerCase(value);

            if (field == "_id") {
                localResult = this.idIndex[value];
            } else if (field == "dn" || field == "distinguishedName") {
                localResult = this.dnIndex[value];
            } else if (field == "workerID") {
                localResult = this.workerIDIndex[value];
            } else if (field == "commonName") {
                localResult = this.cnIndex[value];
            } else {
                logger.error("Field {} is not indexed, staging repository cannot search by this field", field);
            }
        } finally {
            this.__unlock();
        }

        if (localResult != null) {
            results.push(localResult);
        }

        var repoQuery = {
            query: Util.Filters.equals(field, value)
        };

        var repoObjects = Util.applyAndMerge(Config.getDomainConfigurations(), function(domainConfiguration) {
            return openidm.query("system/" + domainConfiguration.name + "/account", repoQuery).result || [];
        });

        this.__lock();
        try {
            for (var i = 0; i < repoObjects.length; i++) {
                var repoObject = repoObjects[i];
                if (this.idIndex[Util.toLowerCase(repoObject._id)] == null) {
                    results.push(repoObject);
                }
            }

            var that = this;
            Util.apply(results, function(itm) {
                return that.__updateReferences(itm);
            });

            return {
                result: results
            };
        } finally {
            this.__unlock();
        }
    },

    putGeneratedDNIfAbsent: function(dn) {
        this.__lock();
        try {
            dn = Util.toLowerCase(dn);

            if (!this.generatedDN[dn]) {
                this.generatedDN[dn] = true;
                return true;
            }

            return false;
        } finally {
            this.__unlock();
        }
    },

    putGeneratedUIDIfAbsent: function(uid) {
        this.__lock();
        try {
            uid = Util.toLowerCase(uid);

            if (!this.generatedUID[uid]) {
                this.generatedUID[uid] = true;
                return true;
            }

            return false;
        } finally {
            this.__unlock();
        }
    },

    putGeneratedMailIfAbsent: function(mail) {
        this.__lock();
        try {
            mail = Util.toLowerCase(mail);

            if (!this.generatedMail[mail]) {
                this.generatedMail[mail] = true;
                return true;
            }

            return false;
        } finally {
            this.__unlock();
        }
    },

    getStoredUsers: function() {
        var result = [];

        var index = this.idIndex;
        for (var id in index) {
            if (!index.hasOwnProperty(id)) {
                continue;
            }

            result.push(index[id]);
        }

        return result;
    }
});

Staging.prepareDryRun = function() {
    openidm.query("managed/usonuserattributes_staging", {
        _queryId: "dry_run_prepare"
    });
};

Staging.getRepo = function() {
    return com.mckesson.ScriptUtil.getRequestVar("stagingRepo");
};

Staging.setup = function() {
    com.mckesson.ScriptUtil.setRequestVar("originalTargetObjectsStorage", java.util.Collections.synchronizedMap(new java.util.HashMap()));
};

Staging.storeOriginalTargetObject = function(obj) {
    com.mckesson.ScriptUtil.getRequestVar("originalTargetObjectsStorage").put(obj._id, obj);
};

Staging.getOriginalTargetObject = function(obj) {
    return com.mckesson.ScriptUtil.getRequestVar("originalTargetObjectsStorage").get(obj._id);
};

Staging.setExceptions = function(exceptions) {
    com.mckesson.ScriptUtil.setRequestVar("configuredExceptions", exceptions);
};

Staging.getExceptions = function() {
    return com.mckesson.ScriptUtil.getRequestVar("configuredExceptions");
};

Staging.getSynchronizationLock = function() {
    return Util.Locks.getLock("synchronizationLock");
};