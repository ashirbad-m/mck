load.call(this, "script/common/config.js");
load.call(this, "script/common/cache.js");
load.call(this, "script/common/util.js");
load.call(this, "script/common/phase.js");

Managed = (function() {

    //10 retries in case of DB failure
    var DB_RETRY_COUNT = 10;

    //30 seconds wait in case of DB failure
    var DB_RECOVERY_WAIT_TIME = 30000;

    var LAST_NAME_KEY = "Last-Names-";
    var USER_ATTRIBUTES_URL = "managed/usonuserattributes";
    var STAGING_USER_ATTRIBUTES_URL = "managed/usonuserattributes_staging";
    var STAGING_DEFERRED_TASK_URL = "managed/deferredtask_staging";
    var DEFERRED_TASK_URL = "managed/deferredtask";

    var nameDataProperties = ["firstName", "lastName", "preferredFirstName", "preferredLastName", "preferredPrefix", "preferredSuffix", "legalPrefix", "legalSuffix", "legalName"];

    var getUserAttributesUrl = function() {
        return isDryRunMode() ? STAGING_USER_ATTRIBUTES_URL : USER_ATTRIBUTES_URL;
    };

    var getDeferredTaskUrl = function() {
        return isDryRunMode() ? STAGING_DEFERRED_TASK_URL : DEFERRED_TASK_URL;
    };

    var getO365LicenseUrl = function() {
        return "managed/" + (isDryRunMode() ? "o365license_dryrun" : "o365license");
    };

    return {

        buildNameData: function(src) {
            var result = {};

            for (var i = 0; i < nameDataProperties.length; i++) {
                var propertyName = nameDataProperties[i];
                result[propertyName] = src[propertyName] || "";
            }

            return result;
        },

        nameDataChanged: function(srcData, trgData) {
            for (var i = 0; i < nameDataProperties.length; i++) {
                var propertyName = nameDataProperties[i];

                var srcProperty = srcData[propertyName] || "";
                var trgProperty = trgData[propertyName] || "";

                if (srcProperty.toLowerCase() != trgProperty.toLowerCase()) {
                    return true;
                }
            }

            return false;
        },

        findUsersWithoutManager: function() {
            var data = openidm.query(getUserAttributesUrl(), {
                "_queryId": "find-user-without-manager"
            }).result;

            return data;
        },

        findUsersWithoutPassword: function() {
            var data = openidm.query(getUserAttributesUrl(), {
                "_queryId": "find-user-without-password"
            }).result;

            return data;
        },

        findUserAttrByUID: function(id) {
            var data = openidm.query(getUserAttributesUrl(), {
                "_queryId": "find-by-id",
                "id": id
            }).result;

            logger.debug("  ManagedUserAttr: found => {} rows. objectid='{}'", data.length, id);

            if (!data || data.length <= 0) {
                return {
                    _id : id,
                    _rev : null,
                    isManagerLinked : null,
                    isPasswordSet: null,
                    active : null,
                    hrbu : null,
                    employee : null,
                    sourceId : null,
                    nameData: {},
                    leaveOfAbsence: "false",
                    currentCity: null,
                    currentAddress: null,
                    companyId: null,
                    accountExpiredNotificationTimestamp: null,
                    workerTypeDescriptor: null
                };
            }

            var result = data[0];
            //this must be done in onRetrieve handler, but it doesn't work
            result.nameData = com.mckesson.ScriptUtil.fromJSON(result.nameData);
            return result;
        },

        findByUID: function(uid) {
            var data = openidm.query("managed/user_correlated", {
                "_queryId": "find-by-id",
                "id": uid
            }).result;

            logger.debug("  ManagedUser: found => {} rows. objectid='{}'", data.length, uid);

            if (!data || data.length <= 0) {
                return null;
            }

            return data[0];
        },


        isJobCodeInPreventLoAJobCodes : function(code) {
            var data = openidm.query("managed/prevent_loa_job_codes", {
                "_queryId" : "get-prevent_loa-job-code-by-code",
                "code" : code
            }).result;
            if (!data || data.length <= 0) {
                return false;
            }
            return true;
        },


        findByWorkerID: function(workerID) {
            var data = openidm.query("managed/user_correlated", {
                "_queryId": "find-by-workerID",
                "workerID": workerID
            }).result;

            logger.debug("  ManagedUser: found => {} rows. workerID='{}'", data.length, workerID);

            if (!data || data.length <= 0) {
                return null;
            }

            return data[0];
        },

        findSourceByTarget: function(uid) {
            var data = openidm.query("managed/user_correlated", {
                "_queryId": "find-source-by-target",
                "uid": uid
            }).result;

            logger.debug("  ManagedUser: found => {} rows. objectid='{}'", data.length, uid);

            if (!data || data.length <= 0) {
                return null;
            }

            return data[0];
        },

        queryAllUsers: function() {
            var data = openidm.query("managed/user_correlated", {
                "_queryId": "query-all"
            }).result;

            return data;
        },

        queryAllGroupMappings: function() {
            var data = openidm.query("managed/hrbugroup", {
                "_queryId": "query-all"
            }).result;

            return data;
        },

        queryAllHRBU: function() {
            var data = openidm.query("managed/hrbu", {
                "_queryId": "query-all"
            }).result;

            return data;
        },

        getHRBU: function(hrbu) {
            hrbu = (hrbu || "").substring(0,5).toUpperCase();
            if (!hrbu) {
                return null;
            }

            return com.mckesson.ScriptUtil.fromJSON(Cache.get("hrbu", hrbu, function() {
                return com.mckesson.ScriptUtil.toJSON(openidm.query("managed/hrbu", {_queryId: "find-hrbu-data-by-id", hrbu: hrbu}).result[0] || {});
            }));
        },

        findHRBU: function(hrbu, city, street) {
            if (!hrbu) {
                return hrbu;
            }
            var data = openidm.query("managed/hrbu", {
                "_queryId": "find-by-hrbu",
                "hrbu": hrbu,
                "city": city,
                "street": street
            }).result;

            logger.debug("  HRBU: found => {} rows. hrbu='{}', city='{}', street='{}'", data.length, hrbu, city, street);
            if (!data || data.length <= 0) {
                return null;
            }

            return data[0];
        },

        findHRBUGroups: function(groupKeys) {
            if (!groupKeys) {
                return [];
            }

            var data = openidm.query("managed/hrbugroup", {
                "_queryId": "find-hrbu-groups",
                "groups": groupKeys
            }).result;

            logger.debug("  HRBU GROUPS: found => {} rows for keys: {}", data.length, groupKeys);
            var result = [];
            for (var i=0; i < data.length; i++) {
                //logger.debug("  GROUPS: row {} => {}", i, data[i].dn);
                result.push(data[i].dn);
            }

            return result;
        },

        findLocationSpecificGroups: function(hrbu) {
            if (!hrbu) {
                return [];
            }

            var data = openidm.query("managed/hrbugroup", {
                "_queryId": "find-location-specific-groups",
                "hrbu": hrbu
            }).result;

            logger.debug("  Location-Specific Groups: found => {} rows for HRBU: {}", data.length, hrbu);
            var result = [];
            for (var i = 0; i < data.length; i++) {
                //logger.debug("  GROUPS: row {} => {}", i, data[i].dn);
                result.push(data[i].dn);
            }

            return result;
        },

        findCSAGroups: function(lastName) {
            if (!lastName) {
                return [];
            }
            var groupKeys = LAST_NAME_KEY + (lastName || "").charAt(0).toUpperCase();
            var data = openidm.query("managed/hrbugroup", {
                "_queryId": "find-csa-groups",
                "groups": groupKeys
            }).result;

            logger.debug("  CSA GROUPS: found => {} rows for keys: {}", data.length, groupKeys);
            var result = [];
            for (var i=0; i < data.length; i++) {
                //logger.debug("  GROUPS: row {} => {}", i, data[i].dn);
                result.push(data[i].dn);
            }

            return result;
        },

        findDefaultGroups: function() {
            var data = openidm.query("managed/hrbugroup", {
                "_queryId": "find-default-groups"
            }).result;

            logger.debug("  DEF GROUPS: found => {} rows", data.length);
            var result = [];
            for (var i=0; i < data.length; i++) {
                //logger.debug("  GROUPS: row {} => {}", i, data[i].dn);
                result.push(data[i].dn);
            }

            return result;
        },

        findO365Licenses: function(userPrincipalName) {
            return openidm.query(getO365LicenseUrl(), {
                "_queryId": "get-o365-licenses",
                "userPrincipalName" : userPrincipalName
            }).result;
        },

        getAuditErrorsReport: function(reconId, limit) {
            return openidm.query("managed/audit_errors_report", {
                "_queryId": "audit-errors-report-fill",
                "reconId": reconId,
                "limitValue" : limit
            }).result;
        },

        createUsonUserAttributesLink: function(params, data) {
            var userData = {
                _id : data._id,
                isManagerLinked: data.isManagerLinked,
                isPasswordSet: data.isPasswordSet,
                active : data.active,
                hrbu : data.hrbu,
                employee : data.employee,
                sourceId : data.sourceId,
                leaveOfAbsence : data.leaveOfAbsence,
                nameData : Util.mergeRecursive({}, data.nameData),
                currentCity : data.currentCity,
                currentAddress : data.currentAddress,
                companyId : data.companyId,
                accountExpiredNotificationTimestamp : data.accountExpiredNotificationTimestamp,
                workerTypeDescriptor : data.workerTypeDescriptor
            };
            logger.debug("  Managed.createUsonUserAttributesLink => {}", userData);
            /* create NoManagerLink/HrbuLink/ActiveLink */
            openidm.create(getUserAttributesUrl(), userData);

            return data;
        },

        createDeferredTask: function(data) {
            var taskData = {
                data : com.mckesson.ScriptUtil.toJSON(data)
            };
            openidm.create(getDeferredTaskUrl(), taskData);

            return data;
        },

        getDeferredTasksBatch: function() {
            return openidm.query(getDeferredTaskUrl(), {_queryId: "get-deferred-tasks-batch"}).result;
        },

        deleteDeferredTask: function(obj) {
            return Util.retry(function() {
                openidm['delete'](getDeferredTaskUrl() + '/' + obj._id, obj._rev);
            }, DB_RETRY_COUNT, DB_RECOVERY_WAIT_TIME);
        },

        updateUsonUserSourceId: function(params, data, sourceId) {
            var dbData = Managed.findUserAttrByUID(data._id);
            dbData.sourceId = sourceId;
            return openidm.update(getUserAttributesUrl() + "/" + data._id, dbData._rev, dbData);
        },

        updateUsonUserAttributesLink: function(params, data) {
            var filterManagedAttrs = Util.createPropertyFilter(['isManagerLinked', 'isPasswordSet', 'active', 'hrbu', 'employee',
                                                                'nameData', 'leaveOfAbsence', 'currentCity', 'currentAddress', 'companyId',
                                                                'accountExpiredNotificationTimestamp', 'workerTypeDescriptor']),
                managedAttrs = filterManagedAttrs(data);

            if (!Util.isEmpty(managedAttrs)) {
                var dbData = Managed.findUserAttrByUID(data._id);
                Util.mergeRecursive(dbData, managedAttrs);
                return openidm.update(getUserAttributesUrl() + "/" + data._id, dbData._rev, dbData);
            }
        },

        reportFailure: function(params, data) {
            logger.error("  Managed.reportFailure => {}, {}", params, data);

            try {
                var correlationCode = "" + java.util.UUID.randomUUID();
                com.mckesson.ScriptUtil.dumpStack("Correlation code: " + correlationCode + ", data: " + data);

                openidm.create('managed/audit', {
                    reconId : params.reconId,
                    mapping : params.mapping,
                    sourceId : params.sourceId,
                    situation : params.situation,
                    action : "Managed.reportFailure",
                    status: "FAILURE",
                    message: Util.trimToSize(data, 256),
                    target : {correlationCode: correlationCode, message: data}
                });
            } catch (e) {
                logger.error("  Catch exception Managed.reportFailure => {}, {}, {}", params, data, e);
            }
        },

        createAuditRecord: function(params, action, data, errorMessage) {
            var audit = {};
            try {
                Util.mergeRecursive(audit, data);
                if (audit.hasOwnProperty('password')) {
                    audit.password = '****';
                }

                var severity = params.severity;
                if (!severity) {
                    severity = (errorMessage && errorMessage != "") ? "FAILURE" : "SUCCESS";
                }

                return Util.retry(function() {
                    return openidm.create('managed/audit', {
                        reconId : params.reconId,
                        mapping : params.mapping,
                        sourceId : params.sourceId,
                        situation : params.situation,
                        action : action,
                        status: severity,
                        message: errorMessage,
                        target : audit
                    });
                }, DB_RETRY_COUNT, DB_RECOVERY_WAIT_TIME);
            } catch(ex) {
                logger.error("Exception creating audit record {} for {} caused by {} / {}", action, data, errorMessage, ex);

                Phase.abort();
            }
        }
    };

}());
