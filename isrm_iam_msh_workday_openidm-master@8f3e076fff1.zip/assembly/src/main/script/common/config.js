/* globals identityServer: false */
/* globals environment: false */

load.call(this, "script/common/util.js");

// Don't use 'const' instead of 'var', otherwise you'll get error concerning constant redeclaration!
Config = {

    LOCAL_MAILBOX_VALUE : "1",

    REMOTE_MAILBOX_VALUE : "2147483648",

    //domain-independent configuration begin
    getWorkdayProvisionerName: function() {
        return openidm.read("config/custom/workday_config").workdayProvisioner;
    },

    getSelfserviceResetURL : function() {
        return openidm.read("config/custom/workday_config").selfserviceResetURL;
    },

    getEmailConfiguration: function() {
        return openidm.read("config/custom/workday_config").email;
    },

    getExceptions: function() {
        var exceptions = openidm.read("config/custom/exception_config").exceptions;
        for (var i = 0; i < exceptions.length; i++) {
            var exception = exceptions[i];

            var now = Date.now();
            exception.active = Util.parseDate(exception.effectiveFrom) <= now && now <= Util.parseDate(exception.effectiveTo);
        }

        return exceptions;
    },
    //domain-independent configuration end

    getExchangeServers: function(domain) {
        return this.getDomainConfiguration(domain).exchangeServers;
    },

    getDFSServers: function(domain) {
        return this.getDomainConfiguration(domain).dfsServers;
    },

    getOffice365AddressSuffix: function(domain) {
        return this.getDomainConfiguration(domain).office365AddressSuffix;
    },

    getOffice365Url: function(domain) {
        return this.getDomainConfiguration(domain).office365Url;
    },

    getOffice365CredentialsAddress: function(domain) {
        return this.getDomainConfiguration(domain).office365CredentialsAddress;
    },

    //TODO - check that required domain configuration properties exist
    getDomainConfiguration: function(domain) {
        return Util.filter(this.getDomainConfigurations(), function(configuration) {
            return configuration.name == domain;
        })[0];
    },

    getDomainConfigurations: function() {
        return openidm.read("config/custom/workday_config").domains;
    },

    getO365JobWaitTimeout: function() {
        return parseInt(identityServer.getProperty("com.mckesson.o365.jobWaitTimeout"), 10);
    },

    getO365AADConnectWaitTime: function() {
        return parseInt(identityServer.getProperty("com.mckesson.o365.aadConnectSyncWaitTime"), 10);
    },

    getEmailCC: function() {
        return environment['com.mckesson.email.cc'];
    },

    getRetryCount: function() {
        return parseInt(identityServer.getProperty("com.mckesson.retryCount"), 10);
    },

    getRetryCoolDownInterval: function() {
        return parseInt(identityServer.getProperty("com.mckesson.retryCooldownInterval"), 10);
    }
};
