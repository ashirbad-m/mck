load.call(this, "script/common/util.js");

Reporting = (function () {

    var replaceEscapeCharacters = function(s) {
        if (!s) {
            return s;
        }

        return s.replace(/\\(.)/g, function(all, capture1) {
            switch (capture1) {
                case 'n':
                    return '\n';
                case 'r':
                    return '\r';
                case '\\':
                    return '\\';
                default:
                    return all;
            }
        });
    };

    return {
        preProcessReportData: function(reportData) {
            Util.apply(reportData, Reporting.processDataItem);
        },

        processDataItem: function(data) {
            data.message = replaceEscapeCharacters(data.message);
            data.target = replaceEscapeCharacters(data.target);
            data.address = replaceEscapeCharacters(data.address);
            data.postalAddress = replaceEscapeCharacters(data.postalAddress);
        }
    };

}());
