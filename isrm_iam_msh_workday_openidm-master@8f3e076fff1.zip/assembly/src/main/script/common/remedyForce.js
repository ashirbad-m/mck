load.call(this, "script/common/managed.js");
load.call(this, "script/common/uson.js");
load.call(this, "script/common/util.js");
load.call(this, "script/common/templates.js");
load.call(this, "script/common/groupHelper.js");

/* globals com: false */

RemedyForce = (function() {

    var DESCRIPTION_SIZE_LIMIT = 32000;

    var getTemplate = function(templateName) {
        var templates = openidm.read("config/custom/remedy_templates");

        if (!templates || !templates.templates[templateName]) {
            logger.error("Can't read template: {}", templateName);
            throw "Can't read template: " + templateName;
        }

        return templates.templates[templateName];
    };

    var getTaskParams = function(user) {
        return {
            firstName: user.firstName || "",
            lastName: user.lastName || "",
            usonId: user.sAMAccountName || ""
        };
    };

    var getIncidentParams = function(syncContext, changedUson, manager, params) {
        params = params || {};

        var hrUser = syncContext.sourceObject || {};

        var originalUson = syncContext.targetObject || {};

        /**
         * if changed user is undefined assume it is not a 'transfer' action and read all the data from original
         */
        if (!changedUson) {
            changedUson = originalUson;
        }

        var expires = changedUson.accountExpires || Uson.ACCOUNT_NEVER_EXPIRE_VALUE;

        var expirationDate;
        if (expires == Uson.ACCOUNT_NEVER_EXPIRE_VALUE || expires == Uson.ZERO_VALUE) {
            expirationDate = "never";
        } else {
            expirationDate = Util.formatDate(Uson.convertADIntervalToDate(expires), "EEE, MMM dd yyyy");
        }

        var groups = params.groups || GroupHelper.getGroups(changedUson) || [];
        var groupNames = Util.apply(groups, Util.dnToRDNValue);
        if (groupNames.length == 0) {
            groupNames = ["<NONE>"];
        }

        var oldGroups = params.oldGroups || GroupHelper.getGroups(originalUson) || [];
        var oldGroupNames = Util.apply(oldGroups, Util.dnToRDNValue);
        if (oldGroupNames.length == 0) {
            oldGroupNames = ["<NONE>"];
        }

        var bIfContractor = changedUson.employee && changedUson.employee == "false";

        return {
            /** all related to new user */
            accountStatus: changedUson.enable ? "enabled" : "disabled",
            //TODO - review
            adminAccount: params.adminAccount || "",
            archivedHomeDrive: changedUson.archivedHomeDirectory || "",
            cellPhone: changedUson.mobilePhone || "",
            city: changedUson.city || "",
            comments: "",
            department: changedUson.department || "",
            email: changedUson.mail,
            bIfContractor: bIfContractor,
            workerType: (bIfContractor) ? "contractor" : "employee",
            expirationDate: expirationDate,
            fax: changedUson.facsimileTelephoneNumber || "",
            firstName: changedUson.firstName || "",
            groups: groupNames,
            homeDrive:  changedUson.homeDirectory || "",
            inOU: changedUson.dn ? Util.dnToOU(changedUson.dn) : "",
            lastName: changedUson.lastName || "",
            loginScript:  changedUson.scriptPath || "",
            manager: manager.displayName || "",
            managerCellPhone: manager.mobilePhone || "",
            managerEmail: manager.mail || "",
            managerPhone: manager.telephoneNumber || "",
            market: Util.getMarket(changedUson.distinguishedName),
            o365Plan: params.o365Plan || "",
            oldGroups: oldGroupNames,
            organization: changedUson.company || "",
            pager: "",
            phone: changedUson.telephoneNumber || "",
            requestDate: Util.formatDate(new Date(), "EEE, MMM dd yyyy"),
            terminationDate: Util.formatDate(new Date(), "EEE, MMM dd yyyy"),
            serviceAccounts: params.serviceAccounts ? Util.join(params.serviceAccounts, ", ") : "",
            serviceAccountsManager: params.serviceAccountsManager || "",
            speciality: "",
            startDate: hrUser.positionEffectiveDate || "",
            streetAddress: changedUson.streetAddress || "",
            suffix: "",
            telephone: changedUson.telephoneNumber || "",
            title: changedUson.title || "",
            usonId: changedUson.sAMAccountName || "",
            wasOU: originalUson.dn ? Util.dnToOU(originalUson.dn) : "",
            zip:  changedUson.postalCode || "",

            group: params.actionGroup || ""
        };
    };

    var createGroupTerminationTasks = function (templateName, params, incidentData, user, groups) {
        Util.apply(Util.toArray(groups), function(group) {
            RemedyForce.createTask(templateName, params, incidentData, user, {group: Util.dnToRDNValue(group)});
        });
    };

    var getUserIdByFederationIdentifier = function (federationIdentifier) {
        return com.mckesson.RemedyForceUtil.api().getUserIdByFederationIdentifier(federationIdentifier);
    };

    var getUserId = function(user) {
        if (!user) {
            return null;
        }

        if (Uson.isUserInQuestOU(user)) {
            return user.commonName;
        }

        return user.sAMAccountName;
    };

    var getO365Plan = function(params, user) {
        var licenses = Managed.findO365Licenses(user.userPrincipalName) || [];

        var o365PlanLicenses = Util.filter(licenses || [], function(license) {
            return license.sku == "ENTERPPRISEPACK" || license.sku == "STANDARDPACK";
        });

        return (o365PlanLicenses[0] || {}).name;
    };

    return {

        createProvisioningErrorIncident: function(params, errorText) {
            var templateName = "provisioningActionFailed";
            var methodName = "RemedyForce." + templateName;
            var auditData = {};
            var errorMessage = "";

            try {
                var template = getTemplate(templateName);

                var incidentId;
                var incidentName;
                var incidentUrl;

                var clientId = com.mckesson.RemedyForceUtil.api().getDefaultOwnerId();

                var incidentAttributes = new java.util.HashMap();
                incidentAttributes.put('bmcClientId', clientId);
                incidentAttributes.put('bmcShortDescription', template.shortDescription);
                incidentAttributes.put('bmcIncidentDescription', Util.trimToSize(errorText, DESCRIPTION_SIZE_LIMIT));

                if (isDryRunMode()) {
                    incidentId = templateName + '_' + java.util.UUID.randomUUID();
                    incidentName = incidentId;
                    incidentUrl = "#" + incidentId;
                } else {
                    var incidentData = com.mckesson.RemedyForceUtil.api().createIncident(template.template, incidentAttributes, true);
                    incidentId = incidentData.id;
                    incidentName = incidentData.name;
                    incidentUrl = incidentData.url;
                }

                auditData.clientId = clientId;
                auditData.incidentId = incidentId;
                auditData.incidentName = incidentName;
                auditData.incidentUrl = incidentUrl;
            } catch (e) {
                errorMessage = e.message || "N/A";
                logger.error("RemedyForce.createProvisioningErrorIncident {}", e);
            }

            Managed.createAuditRecord(params, methodName, auditData, errorMessage);

            return auditData;
        },

        createIncident: function(templateName, params, ownerId, user, manager, data) {
            var methodName = "RemedyForceIncident." + templateName;
            var errorMessage;
            var auditData = {
                data: data
            };

            try {
                var template = getTemplate(templateName);
                var incidentTemplateParams = getIncidentParams(params, user, manager, data);

                incidentTemplateParams.o365Plan = getO365Plan(params, user) || "";

                var incidentTemplateName = template.template;

                var context = {};
                Handlebars.Utils.extend(context, incidentTemplateParams);
                context.templateName = "Remedyforce-" + templateName;
                var incidentDescription = Util.trim(Handlebars.templates.remedyForce(context));
                incidentDescription = Util.trimToSize(incidentDescription, DESCRIPTION_SIZE_LIMIT);
                var incidentShortDescription = template.shortDescription;

                auditData = {
                    incidentTemplate: incidentTemplateName,
                    incidentShortDescription: incidentShortDescription,
                    incidentDescription: incidentDescription
                };

                var incidentId;
                var incidentName;
                var incidentUrl;

                var clientId = ownerId ? getUserIdByFederationIdentifier(ownerId) : null;
                clientId = clientId || com.mckesson.RemedyForceUtil.api().getDefaultOwnerId();

                if (isDryRunMode()) {
                    incidentId = incidentTemplateName + '_' + java.util.UUID.randomUUID();
                    incidentName = incidentId;
                    incidentUrl = "#" + incidentId;
                } else {
                    var incidentAttributes = new java.util.HashMap();
                    incidentAttributes.put('bmcClientId', clientId);
                    incidentAttributes.put('bmcShortDescription', incidentShortDescription);
                    incidentAttributes.put('bmcIncidentDescription', incidentDescription);

                    var incidentData = com.mckesson.RemedyForceUtil.api().createIncident(incidentTemplateName, incidentAttributes, true);
                    incidentId = incidentData.id;
                    incidentName = incidentData.name;
                    incidentUrl = incidentData.url;
                }

                auditData.clientId = clientId;
                auditData.incidentId = incidentId;
                auditData.incidentName = incidentName;
                auditData.incidentUrl = incidentUrl;
            } catch (e) {
                errorMessage = e.message || "N/A";
                logger.error("  Catch exception {} => {}, {}", methodName, e, auditData);
            }

            Managed.createAuditRecord(params, methodName, auditData, errorMessage);

            return auditData;
        },

        createTask: function(templateName, params, incidentData, user, data) {
            var methodName = "RemedyForceTask." + templateName;
            var errorMessage;
            var auditData = {
                incidentData: incidentData,
                data: data
            };

            try {
                var template = getTemplate(templateName);
                var taskTemplateParams = Util.mergeRecursive(Util.mergeRecursive({}, data), getTaskParams(user));
                var taskTemplateName = template.template;

                var context = {};
                Handlebars.Utils.extend(context, taskTemplateParams);
                context.templateName = "Remedyforce-" + templateName;
                var taskDescription = Util.trim(Handlebars.templates.remedyForce(context));
                var incidentId = incidentData.incidentId;
                var clientId = incidentData.clientId;

                auditData = {
                    taskTemplate: taskTemplateName,
                    taskDescription: taskDescription,
                    incidentId: incidentId,
                    clientId: clientId
                };

                var taskId;

                if (isDryRunMode()) {
                    taskId = taskTemplateName + '_' + java.util.UUID.randomUUID();
                } else {
                    var taskAttributes = new java.util.HashMap();
                    taskAttributes.put('bmcClientId', clientId);
                    taskAttributes.put('bmcTaskDescription', taskDescription);
                    taskAttributes.put('taskDescription', taskDescription);

                    taskId = com.mckesson.RemedyForceUtil.api().createTask(taskTemplateName, incidentId, taskAttributes);
                }

                auditData.taskId = taskId;
            } catch (e) {
                errorMessage = e.message || "N/A";
                logger.error("  Catch exception {} => {}, {}", methodName, e, auditData);
            }

            Managed.createAuditRecord(params, methodName, auditData, errorMessage);

            return auditData;
        },

        createAccount: function(params, user, manager, data) {
            return RemedyForce.createIncident("newUser", params, getUserId(manager), user, manager, data);
        },

        createAccountWithoutManager: function(params, user, manager, data) {
            return RemedyForce.createIncident("newUserExecutive", params, getUserId(manager), user, manager, data);
        },

        terminationBasic: function(params, user, manager, data) {
            return RemedyForce.createIncident("termination", params, getUserId(manager), user, manager, data);
        },

        transferBasic: function(params, user, manager, data) {
            return RemedyForce.createIncident("hrbuTransfer", params, getUserId(manager), user, manager, data);
        },

        clinicalTransferBasic: function(params, user, manager, data) {
            return RemedyForce.createIncident("clinicalTransfer", params, getUserId(manager), user, manager, data);
        },

        accountExpired: function(params, user, manager, data) {
            return RemedyForce.createIncident("userAccountExpired", params, getUserId(manager), user, manager, data);
        },

        terminationTXO: function(params, user, manager, incidentData, groupsArray) {
            createGroupTerminationTasks("terminationTXO", params, incidentData, user, groupsArray);
        },

        terminationCentricity: function(params, user, manager, incidentData, groupsArray) {
            createGroupTerminationTasks("terminationCentricity", params, incidentData, user, groupsArray);
        },

        terminationERPSecurity: function(params, user, manager, incidentData, groupsArray) {
            createGroupTerminationTasks("terminationERPSecurity", params, incidentData, user, groupsArray);
        },

        terminationTelecom: function(params, user, manager, incidentData, groupsArray) {
            createGroupTerminationTasks("terminationTelecom", params, incidentData, user, groupsArray);
        },

        terminationTiger: function(params, user, manager, incidentData, groupsArray) {
            createGroupTerminationTasks("terminationTiger", params, incidentData, user, groupsArray);
        },

        terminationIknowmed: function(params, user, manager, incidentData, groupsArray) {
            createGroupTerminationTasks("terminationIknowmed", params, incidentData, user, groupsArray);
        },

        terminationSalesforce: function(params, user, manager, incidentData, groupsArray) {
            createGroupTerminationTasks("terminationSalesforce", params, incidentData, user, groupsArray);
        },

        terminationWorkday: function(params, user, manager, incidentData, groupsArray) {
            createGroupTerminationTasks("terminationWorkday", params, incidentData, user, groupsArray);
        },

        terminationDatabase: function(params, user, manager, incidentData) {
            RemedyForce.createTask("terminationDatabase", params, incidentData, user, {});
        },

        generateProvisioningErrorIncidents: function(params, errors, limit) {
            var actionsWithErrors = {};
            var errorsCount = {};

            Util.apply(errors, function(err) {
                var action = err.action;
                var count = err.count;
                var workerID = err.workerID || "N/A";
                var firstName = err.firstName || "N/A";
                var lastName = err.lastName || "N/A";

                errorsCount[action] = count;

                if (!actionsWithErrors[action]) {
                    actionsWithErrors[action] = [];
                }

                var errorMessage = "workerID: " + workerID + ", firstName: " + firstName + ", lastName: " + lastName;
                actionsWithErrors[action].push(errorMessage);
            });

            for (var actionType in actionsWithErrors) {
                if (!actionsWithErrors.hasOwnProperty(actionType)) {
                    continue;
                }

                var actionHeader = "Action of type " + actionType + " has failed, number of failures is " + errorsCount[actionType] + "\n";
                var actionBody = "First " + Math.min(limit, errorsCount[actionType]) + " affected users:\n" + actionsWithErrors[actionType].join("\n");

                RemedyForce.createProvisioningErrorIncident(params, actionHeader + actionBody);
            }
        }
    };
}());

