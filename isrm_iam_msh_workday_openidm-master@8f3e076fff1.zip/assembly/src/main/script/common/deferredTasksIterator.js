load.call(this, "script/common/managed.js");
load.call(this, "script/common/util.js");

DeferredTasksIterator = function() {
    this.index = 0;
    this.nextBatch = [];
};

DeferredTasksIterator.prototype.__adjust = function() {
    if (this.nextBatch == null) {
        //iteration done, can't adjust
        return;
    }

    if (this.index >= this.nextBatch.length) {
        this.nextBatch = Managed.getDeferredTasksBatch();
        this.index = 0;

        if (this.nextBatch.length == 0) {
            this.nextBatch = null;
        }
    }
};

DeferredTasksIterator.prototype.hasNext = function() {
    this.__adjust();

    return this.nextBatch != null && this.index < this.nextBatch.length;
};

DeferredTasksIterator.prototype.next = function() {
    this.__adjust();

    if (!this.hasNext()) {
        throw "No more items";
    }

    var task = this.nextBatch[this.index++];

    Managed.deleteDeferredTask(task);

    return task;
};
