#
# Command parameters:
#
# $dn - dn
# $server - AD server name
# $newName - new name

if (-not (Get-Module ActiveDirectory)) {
    Import-Module ActiveDirectory -Cmdlet Rename-ADObject,Get-ADUser,Set-ADUser | Out-Null
}

Rename-ADObject -Identity $dn -NewName $newName -Server $server