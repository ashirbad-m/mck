/* globals source: false */

(function() {
    var result = "";
    var array = source;

    if (array) {
        if (!array.join) {
            var realArray = new Array();
            for (var i = 0; i < array.length; i++) {
                realArray.push(array[i]);
            }

            array = realArray;
        }

        result = array.join(" ");
    }

    return result;
}());