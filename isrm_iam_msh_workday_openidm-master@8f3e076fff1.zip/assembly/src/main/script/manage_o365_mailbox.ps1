# Requires Exchange administrator privileges
# Requires StoredCredential module to be installed onto host: https://bitbucket.mckesson.com:8443/projects/ISRM/repos/isrm_iam_tools/browse/powershell/StoredCredential.psm1
#
# Command parameters:
#
# $url - URL of O365 PowerShell endpoint
# $credentialAddress - address of generic credential (stored in Windows Credential Manager) to use for connection to O365
# $action - name of the action to execute
# $userPrincipalName - user's UPN

try {
    $ErrorActionPreference = "Stop";
    $Error.clear();

    Import-Module InvokeInExchangeSession -Force -Global
    Import-Module ConvertToExchangeGUID -Force -Global

    [string[]] $requiredCommands = @(
        #Get-Mailbox is required for ConvertToExchangeGUID
        'Get-Mailbox',
        'Get-MobileDevice',
        'Get-MobileDeviceStatistics',
        'Remove-MobileDevice',
        'Set-CASMailbox'
    );

    if ($userPrincipalName -eq $null)
    {
        throw "No UPN specified";
    }

    Invoke-InExchangeOnlineSession -Endpoint $url -CredentialAddress $credentialAddress -Commands $requiredCommands -ScriptBlock {
        $identity = Convert-UserPrincipalNameToExchangeGUIDString -UserPrincipalName $userPrincipalName;

        if ($identity -eq $null)
        {
            throw "No identity specified";
        }

        switch ($action)
        {
            "disableActiveSyncDeviceInO365"
            {
                Get-MobileDevice -ErrorAction Stop -Mailbox $identity | Get-MobileDeviceStatistics -ErrorAction Stop | Remove-MobileDevice -ErrorAction Stop -Confirm:$false
                break;
            }

            "setCAS"
            {
                Set-CASMailbox -ErrorAction Stop -Identity $identity -ActiveSyncEnabled $false -PopEnabled $false -ImapEnabled $false | Out-Null
                break;
            }

            default
            {
                throw "Action $action is not supported";
            }
        }

        Write-Output("Success");
    }
}
catch
{
    throw "ERROR: " + $error[0].ToString() + $error[0].InvocationInfo.PositionMessage;
}
