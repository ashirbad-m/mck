/* globals reconId: false */
/* globals synchronizationModeMapping: false */

load.call(this, "script/common/config.js");
load.call(this, "script/common/managed.js");
load.call(this, "script/common/uson.js");
load.call(this, "script/common/util.js");
load.call(this, "script/common/phase.js");
load.call(this, "script/common/oktaBlackList.js");

SyncAssesment = (function() {

    var getWorkerID = function(user) {
        return user.workerID;
    };

    var hasEmptyWorkerID = function(user) {
        return !user.workerID;
    };

    var getAllDBUsers = function() {
        var dbUsers = Managed.queryAllUsers();

        dbUsers = Util.filter(dbUsers, function(dbUser) {
            return Uson.isHRBUEnabled(dbUser.hrbu);
        });

        if (!dbUsers || dbUsers.length == 0) {
            throw "DB users not found";
        }

        return dbUsers;
    };

    var getAllADUsers = function() {
        var adUsers = Uson.queryAllUsersInScope();

        if (!adUsers || adUsers.length == 0) {
            throw "AD users not found";
        }

        return adUsers;
    };

    var arrayToHash = function(users) {
        var result = {};

        Util.apply(users, function(user) {
            var workerID = getWorkerID(user);

            if (!workerID) {
                throw "WorkerID is undefined";
            }

            if (!result[workerID]) {
                result[workerID] = [];
            }

            result[workerID].push(user);
        });

        return result;
    };

    var removeAmbiguousUsers = function(adUsers, dbUsers) {
        var ambiguousUsers = [];
        var ambiguousUserID = [];

        for (var workerID in adUsers) {
            /*jshint loopfunc: true */

            if (adUsers[workerID].length > 1) {
                Util.apply(adUsers[workerID], function(user) {
                    ambiguousUsers.push(user);
                });

                ambiguousUserID.push(workerID);
            }
        }

        Util.apply(ambiguousUserID, function(workerID) {
            delete adUsers[workerID];
            delete dbUsers[workerID];
        });

        return ambiguousUsers;
    };

    var getSituation = function(source, target) {
        if (source && target) {
            return "FOUND";
        }

        if (source) {
            return "ABSENT";
        }

        if (target) {
            return "UNASSIGNED";
        }
    };

    var createParams = function(source, target) {
        var params = {};
        params.sourceObject = source ? Util.mergeRecursive({}, source) : null;
        params.sourceId = source ? source._id : null;
        params.targetObject = target ? Util.mergeRecursive({}, target) : null;
        params.reconId = reconId;
        params.mapping = synchronizationModeMapping;
        params.situation = getSituation(source, target);

        return params;
    };

    return {
        readAllUsers: function() {
            logger.info("Reading AD users...");
            var workerID;
            var adUsers = getAllADUsers();

            logger.info("Reading DB users...");
            var dbUsers = getAllDBUsers();

            var absentUsers = [];
            var existingUsers = [];

            //remove unassigned users first
            var unassignedUsers = Util.filter(adUsers, hasEmptyWorkerID);

            var adUsersByWorkerID = arrayToHash(Util.filter(adUsers, Util.not(hasEmptyWorkerID)));
            var dbUsersByWorkerID = arrayToHash(dbUsers);

            var ambiguousUsers = removeAmbiguousUsers(adUsersByWorkerID, dbUsersByWorkerID);

            for (workerID in dbUsersByWorkerID) {
                if (adUsersByWorkerID[workerID]) {
                    existingUsers.push({
                        source: dbUsersByWorkerID[workerID][0],
                        target: adUsersByWorkerID[workerID][0],
                    });
                } else {
                    absentUsers.push({
                        source: dbUsersByWorkerID[workerID][0]
                    });
                }

                delete adUsersByWorkerID[workerID];
            }

            for (workerID in adUsersByWorkerID) {
                unassignedUsers.push(adUsersByWorkerID[workerID][0]);
            }

            return {
                absentUsers: absentUsers,
                existingUsers: existingUsers,
                ambiguousUsers: ambiguousUsers,
                unassignedUsers: unassignedUsers
            };
        },

        processAbsentUser: function(source) {
            var domain = null;

            var hrbu = Managed.findHRBU(source.hrbu, source.city, source.address);
            if (hrbu) {
                domain = Uson.getDomain(hrbu.ou);
            }

            try {
                if (domain) {
                    Uson.checkADAvailability(domain);
                }
            } catch (e) {
                logger.error("AD server {} unavailable: {}, aborting phase", domain, e);
                Phase.abort();
            }

            var params = createParams(source, null);

            try {
                if (!Uson.isMCKHRBU(source.hrbu || "")) {
                    if (source.trm != "true") {
                        if (!domain) {
                            throw "Cannot determine domain for user";
                        }
                        if (OktaBlackList.isOktaCreateBlackListed(source.location)){
                            logger.warn("##Okta: processAbsentUser: User blacklisted: location: {}, workerID: {}, uid: {}", source.location, source.workerID, source.uid);	
                        } else {
                            Reconciliation.create(params, source);
                        }
                    } else {
                        // if user has been terminated, do not create it
                        logger.debug("async => user absent in AD has been already terminated, skipping further processing {}", source.uid);
                    }
                }
            } catch (e) {
                Managed.reportFailure(params, "Error processing absent user: " + e.message);
                throw e;
            }
        },

        processExistingUser: function(source, target) {
            var domain = target.provisioner;
            try {
                Uson.checkADAvailability(domain);
            } catch (e) {
                logger.error("AD server {} unavailable: {}, aborting phase", domain, e);
                Phase.abort();
            }

            var params = createParams(source, target);

            try {
                //no updates for future users, only creation
                if (source.futureUser == "true") {
                    return;
                }

                if (OktaBlackList.isOktaUpdateBlackListed(source.uid)) {
                    logger.warn("##Okta: processExistingUser: User blacklisted: location: {}, workerID: {}, uid: {}", source.location, source.workerID, source.uid);
                    return;
                }

                var relinkSourceId = false;

                var attr = Managed.findUserAttrByUID(target._id);
                if (attr.isManagerLinked !== null) {
                    Util.mergeRecursive(target, attr);
                } else {
                    attr = Managed.createUsonUserAttributesLink(params, {
                        _id : target._id,
                        isManagerLinked: "false",
                        isPasswordSet: "true",
                        active : source.active,
                        hrbu : source.hrbu.substring(0,5),
                        employee : source.employee,
                        sourceId : source._id,
                        nameData: Managed.buildNameData(source),
                        leaveOfAbsence: "false",
                        currentCity: source.city,
                        currentAddress: source.address,
                        companyId: source.companyId,
                        workerTypeDescriptor: source.workerTypeDescriptor,
                        accountExpiredNotificationTimestamp: null
                    });
                    Util.mergeRecursive(target, attr);
                }

                if (target.sourceId && target.sourceId != source._id) {
                    relinkSourceId = true;
                    target.sourceId = source._id;
                }

                var isTransferToMCKHRBU = (Uson.isMCKHRBU(source.hrbu || "") && !Uson.isMCKHRBU(target.hrbu || source.hrbu || ""));
                var isSourceMCKHRBU = Uson.isMCKHRBU(source.hrbu || "");

                if (isTransferToMCKHRBU || !isSourceMCKHRBU) {
                    if (isTransferToMCKHRBU) {
                        source.trm = "true";
                    }

                    Staging.storeOriginalTargetObject(params.targetObject);

                    if (source.trm != "true") {
                        var sourceHRBU = Managed.findHRBU((source.hrbu || "").substring(0,5), source.city, source.address);
                        var sourceDomainName = Uson.getDomain(sourceHRBU.ou);
                        var targetDomainName = Uson.getDomain(target.distinguishedName);

                        if (!sourceDomainName || !targetDomainName) {
                            throw "Cannot determine domain for user";
                        }

                        var crossDomainTransfer = !Util.validateMatch(sourceDomainName, targetDomainName);

                        if (crossDomainTransfer) {
                            Reconciliation.terminate(params, source, target);

                            var newParams = createParams(source, null);
                            Reconciliation.create(newParams, source);
                        } else {
                            Reconciliation.update(params, source, target, sourceHRBU);
                            Reconciliation.reconcileAD(params, source, target);
                        }
                    } else {
                        Reconciliation.terminate(params, source, target);
                    }
                }

                if (relinkSourceId) {
                    Managed.updateUsonUserSourceId(params, target, source._id);
                }
            } catch (e) {
                Managed.reportFailure(params, "Error processing existing user: " + e.message);
                throw e;
            }
        },

        processUnassignedUser: function(target) {
            var domain = target.provisioner;
            try {
                Uson.checkADAvailability(domain);
            } catch (e) {
                logger.error("AD server {} unavailable: {}, aborting phase", domain, e);
                Phase.abort();
            }

            var params = createParams(null, target);
            Staging.storeOriginalTargetObject(params.targetObject);

            try {
                Reconciliation.unassigned(params, target);
            } catch (e) {
                Managed.reportFailure(params, "Error processing unassigned user: " + e.message);
                throw e;
            }
        },

        processAmbiguousUsers: function(users) {
            if (!users || users.length == 0) {
                return;
            }

            var params = createParams(null, null);

            var userData = Util.apply(users, function(user) {
                return "sAMAccountName=" + user.sAMAccountName + ", displayName=" + user.displayName;
            });

            Managed.reportFailure(params, "Ambiguous users found. These users won't be updated: " + userData.join(';'));
        }
    };

}());
