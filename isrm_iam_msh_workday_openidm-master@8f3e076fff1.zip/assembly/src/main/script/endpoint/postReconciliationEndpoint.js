/**
 *  curl --header "X-OpenIDM-Username: openidm-admin" --header "X-OpenIDM-Password: workday" --request POST
 *  "http://localhost:8080/openidm/endpoint/postReconciliation?
 *      _action=[linkManager|reconcileAD]
 *      &isDryRun=[true|false]
 *      &reconId=fb9ecd7e-3a2c-4269-8508-0be335986d9d
 *      &mapping=managedUser_systemUsonAccounts_[dryrun|commit]
 *      &situation=[LINKMANAGER|RECONCILEAD]"
 */

/* globals request: false */

this.isDryRunMode = (function(dryRun) {
    return function() {
        return dryRun;
    };
}(request.params.isDryRun == "true" || request.params.isDryRun == true));

load.call(this, "script/common/staging.js");
load.call(this, "script/common/reconciliation.js");
load.call(this, "script/common/managed.js");
load.call(this, "script/common/uson.js");
load.call(this, "script/common/pshell.js");
load.call(this, "script/common/util.js");
load.call(this, "script/common/mail.js");
load.call(this, "script/common/phase.js");
load.call(this, "script/common/remedyForce.js");
load.call(this, "script/common/oktaBlackList.js");

(function () {
    logger.debug("postReconciliation endpoint => request: {}", request);
    if (request.method !== "action" && request.method !== "query") {
        throw {
            "openidmCode": 403,
            "message": "Unsupported operation."
        };
    }

    var response = {};
    var params = request.params;
    switch (request.params._action) {
    case "linkManager":
        Phase.create("link managers", Phase.arrayToProducer(Managed.findUsersWithoutManager()), function(userAttr) {
            var params2 = Util.mergeRecursive({}, params);

            try {
                var target = Uson.findByUID(userAttr._id);
                var source = Managed.findByUID(userAttr.sourceId);

                if (!target || !source) {
                    return;
                }

                if (OktaBlackList.isOktaUpdateBlackListed(source.uid)) {
                    logger.warn("##Okta: linkManager: User blacklisted: location: {}, workerID: {}, uid: {}", source.location, source.workerID, source.uid);
                    return;
                }

                var domain = target.provisioner;
                try {
                    Uson.checkADAvailability(domain);
                } catch (e) {
                    logger.error("AD server {} unavailable: {}, aborting phase", domain, e);
                    Phase.abort();
                }

                params2.sourceId = source._id;
                params2.sourceObject = Util.mergeRecursive({}, source);
                params2.targetObject = Staging.getOriginalTargetObject(target);

                Reconciliation.linkManager(params2, source, target);
            } catch (e) {
                Managed.reportFailure(params2, "Error linking manager: " + e.message);
                throw e;
            }
        }).execute();

        Phase.create("assign passwords", Phase.arrayToProducer(Managed.findUsersWithoutPassword()), function(userAttr) {
            var params2 = Util.mergeRecursive({}, params);

            try {
                var target = Uson.findByUID(userAttr._id);
                var source = Managed.findByUID(userAttr.sourceId);

                if (!target || !source) {
                    return;
                }

                if (OktaBlackList.isOktaUpdateBlackListed(source.uid)) {
                    logger.warn("##Okta: assign passwords: User blacklisted: location: {}, workerID: {}, uid: {}", source.location, source.workerID, source.uid);
                    return;
                }

                var domain = target.provisioner;
                try {
                    Uson.checkADAvailability(domain);
                } catch (e) {
                    logger.error("AD server {} unavailable: {}, aborting phase", domain, e);
                    Phase.abort();
                }

                params2.sourceId = source._id;
                params2.sourceObject = Util.mergeRecursive({}, source);
                params2.targetObject = Staging.getOriginalTargetObject(target);

                Reconciliation.generatePassword(params2, source, target);
            } catch (e) {
                Managed.reportFailure(params2, "Error generating password: " + e.message);
                throw e;
            }
        }).execute();

        Deferred.registerExecutor("PShell.setCAS", PShell.setCAS);
        Deferred.registerExecutor("RemedyForce.generateAccountRemedyTicketsAndEmails", Reconciliation.generateAccountRemedyTicketsAndEmails);
        Deferred.registerExecutor("Mail.deliverDeferredEmail", Mail.deliverDeferredEmail);

        Deferred.executeAll();

        var usersLimitForErrors = 50;
        var errors = Managed.getAuditErrorsReport(params.reconId, usersLimitForErrors);
        RemedyForce.generateProvisioningErrorIncidents(params, errors, usersLimitForErrors);

        break;
    case "reconcileAD":
        //TODO : see workflow ReconcileAD
        logger.debug("  reconcileAD: => TBD");
        break;
    default:
        throw {
            "openidmCode": 403,
            "message": "Unsupported action: " + request.params._action + "[_action=linkManager|reconcileAD]"
        };
    }

    return response;
} ());