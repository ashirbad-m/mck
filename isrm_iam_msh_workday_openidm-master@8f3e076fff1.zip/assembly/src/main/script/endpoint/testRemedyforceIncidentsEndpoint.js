/* globals request: false */

load.call(this, "script/common/remedyForce.js");
load.call(this, "script/common/managed.js");
load.call(this, "script/common/uson.js");
load.call(this, "script/common/groupHelper.js");

(function () {
    Util.Locks.createLock("synchronizationLock");

    GroupHelper.setup();

    var sourceId = request.params.sourceId;
    var targetId = sourceId;
    var managerId = request.params.managerId;

    logger.error("{} {}", sourceId, managerId);

    var params = {};

    this.isDryRunMode = function() {
        return false;
    };

    openidm.query("managed/user_correlated", {_queryId: "correlate_users"});

    var source = Managed.findByWorkerID(sourceId);
    var target = Uson.findByWorkerID(targetId);
    var manager = Uson.findByWorkerID(managerId);

    params.sourceObject = Util.mergeRecursive({}, source);
    params.sourceId = params.sourceObject._id;
    params.targetObject = Util.mergeRecursive({}, target);
    params.targetId = params.targetObject._id;

    var result = {};

    result.accountExpired = RemedyForce.accountExpired(params, target, manager, {});
    result.clinicalTransferBasic = RemedyForce.clinicalTransferBasic(params, target, manager, {});
    result.terminationBasic = RemedyForce.terminationBasic(params, target, manager, {});
    result.transferBasic = RemedyForce.transferBasic(params, target, manager, {});
    result.clinicalTransferBasic = RemedyForce.clinicalTransferBasic(params, target, manager, {});

    target.workerID = "999999";

    result.createAccount = RemedyForce.createAccount(params, target, manager, {});
    result.createAccountWithoutManager = RemedyForce.createAccountWithoutManager(params, target, manager, {});

    return result;
}());

