/**
 *  curl --header "X-OpenIDM-Username: openidm-admin" --header "X-OpenIDM-Password: workday" --request POST
 *  "http://localhost:8080/openidm/endpoint/workdayToUson?_action=dryrun|commit"
 */

/* globals request: false */
/* globals com: false */

load.call(this, "script/common/config.js");
load.call(this, "script/common/staging.js");
load.call(this, "script/common/genericMail.js");
load.call(this, "script/common/util.js");
load.call(this, "script/common/reconciliation.js");
load.call(this, "script/sync/syncAssesment.js");
load.call(this, "script/common/office365.js");
load.call(this, "script/common/phase.js");
load.call(this, "script/common/groupHelper.js");
load.call(this, "script/common/reporting.js");

var verifyMappingGroupsValidity = true;
var executeO365Phase = true;

var that = this;

(function () {
    logger.debug("w2u endpoint => request: {}", request);
    if (request.method !== "action" && request.method !== "query") {
        throw {
            "openidmCode": 403,
            "message": "Unsupported operation."
        };
    }

    var readWorkdayData = (request.params.readWorkdayData === "false" ? false : true);

    var exceptions = Config.getExceptions();
    Staging.setExceptions(Util.filter(exceptions, function(exception) {
        if (!exception.active) {
            logger.info("Exception {} is not active", exception.description);
        }

        return exception.active;
    }));

    logger.info("Active exceptions: {}", Util.apply(Staging.getExceptions(), function(exception) { return exception.description; }));

    var response = {};
    Staging.setup();
    GroupHelper.setup();

    switch (request.params._action) {
    case "dryrun":
        Staging.prepareDryRun();
        /* falls through */
    case "commit":
        Util.Locks.createLock("synchronizationLock");
        com.mckesson.ScriptUtil.setRequestVar("stagingRepo", new Staging());

        var timeBeforeSync = Util.toISOString(new Date());
        var lock = com.mckesson.ScriptUtil.getGlobalLock("workdayToUson");
        var lockAcquired = false;
        var statusString = "";

        try {
            lockAcquired = lock.tryLock();
            if (!lockAcquired) {
                throw "Synchronization lock held by another thread.";
            }

            that.reconId = java.util.UUID.randomUUID().toString();
            that.isDryRunMode = function() {
                return request.params._action == "dryrun";
            };
            that.synchronizationMode = that.isDryRunMode() ? "dryrun" : "commit";
            that.synchronizationModeMapping = "managedUser_systemUsonAccounts_" + that.synchronizationMode;

            var retryCount = 3;

            var reconBeforeSync = openidm.read("recon");
            logger.info("Synchronization started, current recon status: {}", com.mckesson.ScriptUtil.toJSON(reconBeforeSync));

            var date = new Date();
            var startPoint = new java.lang.Long(date.getTime());

            if (readWorkdayData) {
                Util.retry.call(this, function() {
                    //reconciliation workday -> db
                    openidm.action("recon", {
                        _action : "recon",
                        mapping : "systemWorkdayFutureAccounts_managedUserFuture",
                        waitForCompletion : true
                    });
                }, retryCount, 0);

                if(request.params.startTime){
                    com.mckesson.ScriptUtil.sleepToTime(request.params.startTime, startPoint);
                }

                Util.retry.call(this, function() {
                    //reconciliation workday -> db
                    openidm.action("recon", {
                        _action : "recon",
                        mapping : "systemWorkdayAccounts_managedUser",
                        waitForCompletion : true
                    });
                }, retryCount, 0);
            }

            openidm.query("managed/user_correlated", {
                _queryId: "correlate_users"
            });

            var dbToUs = {_id: that.reconId};

            if (verifyMappingGroupsValidity) {
                Reconciliation.verifyMappingGroupsValidity({
                    _action : "verifyMappingGroupsValidity",
                    isDryRun : that.isDryRunMode(),
                    reconId : dbToUs._id,
                    mapping : that.synchronizationModeMapping,
                    situation : "VERIFYGROUPS"
                });
            }

            var users = Util.retry(SyncAssesment.readAllUsers, retryCount, 0);

            SyncAssesment.processAmbiguousUsers(users.ambiguousUsers);

            Phase.create("absent users", Phase.arrayToProducer(users.absentUsers), function(user) {
                SyncAssesment.processAbsentUser(user.source);
            }).execute();

            Phase.create("existing users", Phase.arrayToProducer(users.existingUsers), function(user) {
                SyncAssesment.processExistingUser(user.source, user.target);
            }).execute();

            Phase.create("unassigned users", Phase.arrayToProducer(users.unassignedUsers), function(user) {
                SyncAssesment.processUnassignedUser(user);
            }).execute();

            if (executeO365Phase) {
                logger.info("Sleeping for some time to let Azure Active Directory Connect synchronize data from AD to Azure AD");

                if (!that.isDryRunMode()) {
                    try {
                        com.mckesson.ScriptUtil.sleep(Config.getO365AADConnectWaitTime());
                    } catch (e) {
                        logger.error("Sleep failed: {}", e);
                    }
                }

                logger.info("Starting Office 365 job...");
                var office365JobUrl = Office365.startJob({
                    _action : "startJob",
                    isDryRun : that.isDryRunMode(),
                    reconId : dbToUs._id,
                    mapping : that.synchronizationModeMapping,
                    situation : "O365JOB"
                });

                if (office365JobUrl) {
                    logger.info("Job started: {}", office365JobUrl);

                    Office365.waitForJobCompletion({
                        _action : "waitForJobCompletion",
                        isDryRun : that.isDryRunMode(),
                        reconId : dbToUs._id,
                        mapping : that.synchronizationModeMapping,
                        situation : "O365JOB"
                    }, office365JobUrl, Config.getO365JobWaitTimeout());

                    logger.info("Job wait done");
                } else {
                    logger.error("Office 365 job failed");
                }
            }

            //link manager
            openidm.action("endpoint/postReconciliation", {
                _action : "linkManager",
                isDryRun : request.params._action == "dryrun",
                reconId : dbToUs._id,
                mapping : that.synchronizationModeMapping,
                situation : "LINKMANAGER"
            });

            var syncReportData = openidm.query("managed/sync_report", {_queryId: "get_sync_report"}).result;
            Reporting.preProcessReportData(syncReportData);
            openidm.action("external/excelExport", {
                from: "provisioning@usoncology.com",
                to: Config.getEmailConfiguration().syncReportRecipients,
                baseFileName: Config.getEmailConfiguration().syncReportSubject + "-" + request.params._action,
                columns: ["_id", "objectid", "eventdate", "reconid", "mapping", "sourceid", "action", "situation", "status", "message", "target", "rev", "uid", "country", "middleName", "postalCode", "addressLastModified", "employee", "email", "address", "postalAddress", "workerType", "userID", "city", "state", "workerID", "managerID", "hrbu", "title", "legalPrefix", "firstName", "lastName", "legalSuffix", "legalName", "preferredPrefix", "preferredFirstName", "preferredLastName", "preferredSuffix", "active", "fax", "mobile", "telephoneNumber", "trm", "hrPartner", "leaveOfAbsence", "executiveDirector", "companyId", "workerTypeDescriptor", "glPayType", "futureUser"],
                data: syncReportData
            });
        } catch (e) {
            var exc = e;
            logger.error("Synchronization error: {}", exc);
            GenericMail.sendSyncStatusMail("MSH Workday Synchronization Failure", exc.message || exc);

            throw exc;
        } finally {
            if (lockAcquired) {
                lock.unlock();
            }

            var reconAfterSync = openidm.read("recon").reconciliations;
            var reconDelta = [];
            for (var i = 0; i < reconAfterSync.length; i++) {
                if (reconAfterSync[i].started && reconAfterSync[i].started > timeBeforeSync) {
                    reconDelta.push(reconAfterSync[i]);
                }
            }

            var statusObject = {status: reconDelta};
            var errors = Managed.getAuditErrorsReport(that.reconId, 1);
            var errorsData = Util.apply(errors, function(err) {
                return "Action of type '" + err.action + "' failed " + err.count + " times";
            });

            if (errorsData && errorsData.length != 0) {
                statusObject.errors = errorsData;
            }

            statusString = com.mckesson.ScriptUtil.toJSON(statusObject);
            logger.info("Synchronization completed, current recon status: {}", statusString);
        }

        GenericMail.sendSyncStatusMail("MSH Workday Synchronization Status", statusString);

        break;
    default:
        throw {
            "openidmCode": 403,
            "message": "Unsupported action: " + request.params._action + "[_action=dryrun|commit]"
        };
    }

    return response;
} ());
