/* globals request: false */
load.call(this, "script/common/oktaBlackList.js");

(function () {
    var result = {};
    if(request.method === "query") {
        if (request.params._queryId === "isOktaUpdateBlackListed") {
            result["updateBlackListed(" + request.params.uid + ")"] = OktaBlackList.isOktaUpdateBlackListed(request.params.uid);
            return result;
        } else if (request.params._queryId === "isOktaCreateBlackListed") {
            result["createBlackListed(" + request.params.location + ")"] = OktaBlackList.isOktaCreateBlackListed(request.params.location);
            return result;
        }
    } else if (request.method === "action") {
        if (request.params._action === "addLocation2BlackList") {
            OktaBlackList.addHrbu2BlackList(request.params.locationPrefix);
            result["blackListed(" + request.params.locationPrefix + "*)"] = true;
            return result;
        }
    }
    throw "oktaBlackListEndpoint: Unsupported endpoint parameters";
} ());
