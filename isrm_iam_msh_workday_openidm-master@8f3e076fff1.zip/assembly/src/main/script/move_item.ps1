# Command parameters:
#
# $source - source directory
# $target - target directory


try {
    Set-Variable folderName -option Constant -value '2ARCHIVENETSEC'
    $positions=$target.IndexOf($folderName)
    if ($positions -gt 0) {
       #TODO nick - add constant for "2ARCHIVENETSEC" and replace 14 with the length of that constant string
       $archiv = $target.Substring(0, $positions+$folderName.length)
       if (!(Test-Path -Path $archiv)) {
          New-Item -ItemType directory -Path $archiv

          $Acl = Get-Acl $archiv    
       
          $rule = New-Object System.Security.AccessControl.FileSystemAccessRule('Domain Admins', 'FullControl', 'Allow')
          $Acl.AddAccessRule($rule)

          $rule = New-Object System.Security.AccessControl.FileSystemAccessRule('Security Admins', 'FullControl', 'Allow')
          $Acl.AddAccessRule($rule)
         
          $rule = New-Object System.Security.AccessControl.FileSystemAccessRule('Service Desk - IT', 'Modify', 'Allow')
          $Acl.AddAccessRule($rule)

          $rule = New-Object System.Security.AccessControl.FileSystemAccessRule('Administrators_G', 'Modify', 'Allow')
          $Acl.AddAccessRule($rule)
        
          Set-Acl $archiv $Acl | Out-Null
             
       }                          
    }
   
	$ErrorActionPreference = "Stop";
	$Error.clear();
	
	Move-Item $source $target -Confirm:$false -ErrorAction Stop

	Write-Output("Success");
}
catch {
    throw "ERROR: " + $error[0].ToString() + $error[0].InvocationInfo.PositionMessage;
}
