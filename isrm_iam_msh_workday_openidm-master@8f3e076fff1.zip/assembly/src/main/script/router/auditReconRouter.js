/* globals request: false */

(function() {
    if (request.value.entryType == "start" || request.value.entryType == "summary") {
        request.value.action="query";
        var cur = request;
        while (cur){
            if (cur.params && cur.params.mapping) {
                request.value.mapping = cur.params.mapping;
                break;
            }
            cur = cur.parent;
        }
    }
}());
