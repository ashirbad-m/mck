/* globals request: false */
/* globals response: false */

load.call(this, "script/common/util.js");

if (response) {
    var provisioner = (request.id.match(/^\/?system\/([^\/]+)\/.+$/) || [])[1];

    if (provisioner) {
        if (request.method === 'query' && response.result) {
            Util.apply(response.result, function(item) {
                item.provisioner = provisioner;
            });
        } else if (request.method === 'read' && response) {
            response.provisioner = provisioner;
        }
    }
}