/* globals source: false */

(function() {
    var result = source;
    if (result === "USA") {
        result = "United States";
    }

    return result;
}());