load.call(this, "script/common/util.js");

PasswordGenerator = (function() {

    var getRandomCharFormArray = function(category) {
        var charIdxWithinCategory = Util.secureRandom(category.length);
        return category[charIdxWithinCategory];
    };

    return {
        generate: function() {
            var newPassword="", PASSWORD_LENGTH=8;

            var specialSymbols = ["!","@","~","$","%","#","*","?","-","=","+"];
            var symbols = {
                  lower : ["a","b","c","d","e","f","g","h","i","j","k"/*,"l"*/,"m","n"/*,"o"*/,"p","q","r","s","t","u","v","w","x","y","z"],
                  upper : ["A","B","C","D","E","F","G","H"/*,"I"*/,"J","K","L","M","N"/*,"O"*/,"P","Q","R","S","T","U","V","W","X","Y","Z"],
                  numbers : [/*"1",*/"2","3","4","5","6","7","8","9"/*,"0"*/]
                },
                categoryName = "",
                categoryNames = [],
                categoryUsage = {},
                size = 0;

            for (categoryName in symbols) {
                categoryUsage[categoryName] = 0;
                categoryNames[size++] = categoryName;
            }

            // Generate alphanumeric password
            for (var i = 0 ; i < PASSWORD_LENGTH ; i++) {
                var randomCategoryName = categoryNames[Util.secureRandom(size)];
                newPassword += getRandomCharFormArray(symbols[randomCategoryName]);
                categoryUsage[randomCategoryName] ++;
            }

            // Check for symbol categories usage
            for (categoryName in categoryUsage) {
                if (categoryUsage[categoryName] === 0) {
                    newPassword += getRandomCharFormArray(symbols[categoryName]);
                }
            }

            // Insert special symbol randomly
            if (Util.secureRandom(2) == 1) {
                var ssPos = Util.secureRandom(newPassword.length - 1) + 1; // Not the first and not the last character of the password
                newPassword = newPassword.substring(0, ssPos) + getRandomCharFormArray(specialSymbols) + newPassword.substring(ssPos + 1) + newPassword.charAt(ssPos);
            }

            return newPassword;
        }
    };
}());
