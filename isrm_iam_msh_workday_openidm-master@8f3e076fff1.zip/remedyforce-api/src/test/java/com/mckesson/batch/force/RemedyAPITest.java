package com.mckesson.batch.force;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.beanutils.BeanMap;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.force.api.DescribeGlobal;
import com.force.api.DescribeSObject;
import com.force.api.DescribeSObject.Field;
import com.force.api.DescribeSObjectBasic;
import com.force.api.ForceApi;
import com.force.api.QueryResult;
import com.mckesson.batch.force.domain.BMCServiceDeskIncident;
import com.mckesson.batch.force.domain.BMCServiceDeskSRMRequestDefinition;
import com.mckesson.batch.force.domain.BMCServiceDeskSysTemplate;
import com.mckesson.batch.force.domain.BMCServiceDeskTask;
import com.mckesson.batch.force.domain.Group;
import com.mckesson.batch.force.domain.User;

/**
 * JUnit-tests for {@link RemedyApiImpl}
 *
 * @author Eugene Yudin
 */
public class RemedyAPITest {

	/** Logging-support */
	private static final Logger logger = LoggerFactory.getLogger(RemedyAPITest.class);

	/** Dummy-string for wrong-values */
	private static final String NON_EXISTENT_VALUE = "@#$%^&*()";

//	/** E-Mail of test-user */
//	private static final String TEST_E_MAIL = /*"kimberlybardel.whitlock=mckesson.com@example.com"*/"vitalii.rudenskyi@mckesson.com";
	/** Id of test-user */
	private static final String TEST_U_ID = /*"005G0000001jdaoIAA"*/"005P0000000w43pIAA";

	/** FederationIdentifier of user */
	private static final String TEST_F_ID = "elbmft6"; /*"ep8nfas" "ew4ahmz"*/

	/** Properties-resource-name */
	private static final String REMEDY_API_PROPERTIES = "/RemedyApi.properties";

	/**
	 * Created incident-checker
	 *
	 * @param expected Prepared incident
	 * @param actual Created incident
	 *
	 * @param id Created incident-id
	 * @param templateName Name of template
	 * @throws RemedyApiException
	 */
	private static void check2Incidents (BMCServiceDeskIncident expected, BMCServiceDeskIncident actual, String id, String templateName) throws RemedyApiException {
		assertEquals(expected.getBmcRequestDefinition(), actual.getBmcRequestDefinition());
		assertEquals(expected.getBmcShortDescription(), actual.getBmcShortDescription());
		assertEquals(expected.getBmcIncidentDescription(), actual.getBmcIncidentDescription());
		assertEquals(expected.getBmcClientId(), actual.getBmcClientId());
		assertEquals("Service Request", actual.getBmcIncidentType());
		assertEquals("Yes", actual.getBmcServiceRequest());

		assertEquals(id, actual.getId());

		String name = api.getIncidentName(actual.getId());
		logger.info("Name of created incident: \'{}\'", name);
		BMCServiceDeskSRMRequestDefinition def = api.getObject(actual.getBmcRequestDefinition(), BMCServiceDeskSRMRequestDefinition.class);
		logger.info("Related request-definition: \'{}\'", def.getName());

		assertEquals(def.getName().replace(" - ", "-").replace(" ", "_"), templateName.substring(0, templateName.length()-".inc".length()));

		Group serviceDeskQueue = api.getObject(actual.getOwnerId(), Group.class);

		assertEquals(serviceDeskQueue.getName(), actual.getBmcQueue());
		assertEquals(serviceDeskQueue.getName(), actual.getBmcQueueName());

		User user = api.getObject(actual.getBmcClientId(), User.class);
		logger.info("Incident-related User: \'{}\'", user.getEmail());
	}

	/**
	 * Created task-checker
	 *
	 * @param task0 Prepared task
	 * @param task1 Created task
	 *
	 * @param id Created task-id
	 * @param templateName Name of template
	 * @throws RemedyApiException
	 */
	private static void check2Tasks (BMCServiceDeskTask task0, BMCServiceDeskTask task1, String id, String templateName) throws RemedyApiException {
		assertEquals(task0.getBmcTemplateId(), task1.getBmcTemplateId());
		/*assertEquals(task0.getBmcShortDescription(), task1.getBmcShortDescription());*/
		assertEquals(task0.getBmcTaskDescription(), task1.getBmcTaskDescription());
		assertEquals(task0.getBmcClientId(), task1.getBmcClientId());
		assertEquals(task0.getBmcIncidentId(), task1.getBmcIncidentId());

		assertEquals(task1.getId(), id);

		String name = api.getTaskName(task1.getId());
		logger.info("Name of created task: \'{}\'", name);
		BMCServiceDeskSysTemplate templ = api.getObject(task1.getBmcTemplateId(), BMCServiceDeskSysTemplate.class);
		logger.info("Related task-template: \'{}\'", templ.getName());

		assertEquals(templ.getName().replace(" - ", "-").replace(" ", "_"), templateName.substring(0, templateName.length()-".task".length()));

		if (!task0.getBmcQueueName().equals(task1.getBmcQueueName())) {
			logger.warn("check2Tasks ==> Queue-name for \'{}\' is \'{}\' (should be \'{}\')", new Object[] {templ.getName(), task1.getBmcQueueName(), task0.getBmcQueueName()});
		}

		User user = api.getObject(task1.getBmcClientId(), User.class);
		logger.info("Task-related User: \'{}\'", user.getEmail());
	}

	/**
	 * {@link RemedyApiImpl}-instance for tests
	 */
	private static RemedyApiImpl api;

	/**
	 * Salesforce-API for CRUD-operations
	 *
	 * @see #clean()
	 */
	private static ForceApi fapi;

	/**
	 * Created incident-ids
	 *
	 * @see #clean()
	 * @see #commonCreateAndGetTests()
	 */
	private static Set<String> incidentIds;

	/**
	 * Created task-ids
	 *
	 * @see #clean()
	 * @see #commonCreateAndGetTests()
	 */
	private static Set<String> taskIds;

	/**
	 * Test-initializer
	 *
	 * @throws Exception If processing-error
	 */
	@BeforeClass
	public static void init () throws Exception {
		logger.info("Starting RemedyAPITest...");

		System.setProperty("https.protocols", "TLSv1.1,TLSv1.2");

		incidentIds = new HashSet<String>();
		taskIds = new HashSet<String>();

		Properties properties = new Properties();
		InputStream is = null;
		try {
			is = RemedyAPITest.class.getResourceAsStream(REMEDY_API_PROPERTIES);
			properties.load(is);
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					//ignore silently
				}
			}
		}

		api = new RemedyApiImpl("dev",
				properties.getProperty("com.mckesson.remedyforce.endpoint"),
				properties.getProperty("com.mckesson.remedyforce.username"),
				properties.getProperty("com.mckesson.remedyforce.password"));

		fapi = api.getForceApi();

		logger.info("RemedyAPITest started.");
	}

	@Test
	public void selects(){
		/*
		selects(
			BMCServiceDeskSRMRequestDefinition.class,
			RemedyApiImpl.getForceObjectName(BMCServiceDeskSRMRequestDefinition.class),
			RemedyApiImpl.getAttrList(BMCServiceDeskSRMRequestDefinition.class)
		);
		*/
		selects(
			BMCServiceDeskSysTemplate.class,
			RemedyApiImpl.getForceObjectName(BMCServiceDeskSysTemplate.class),
			RemedyApiImpl.getAttrList(BMCServiceDeskSysTemplate.class)
		);
		selects(
			User.class,
			RemedyApiImpl.getForceObjectName(User.class),
			RemedyApiImpl.getAttrList(User.class)
		);
		selects(
			Map.class,
			"Group",
			"Id,Name"
		);
	}

	public <T> void selects(Class<T> clazz, String forceObjectName, String attList) {
		QueryResult<T> result;
		String query = MessageFormat.format(
			"select {0} from {1}",
			new Object[]{ attList, forceObjectName }
		);
		logger.debug("query: {}", query);
		result = fapi.query(query, clazz);
		logger.info("Objects ==>{}", forceObjectName);
		for (T def: result.getRecords()) {
			Map<?,?> beanMap;
			if (Map.class.isAssignableFrom(clazz)) {
				beanMap = (Map<?,?>) def;
				logger.info("Map={}", beanMap);
			} else {
				beanMap = new BeanMap(def);
				logger.info("Id={}, Name={}", beanMap.get("id"), beanMap.get("name"));
			}
			if (def instanceof User) {
				logger.info("\teMail={}, fid={}", ((User)def).getEmail(), ((User)def).getFederationIdentifier());
			}
		}
	}

//	@Test
	public void describeGlobal() {
		DescribeGlobal dg = fapi.describeGlobal();

//		logger.info("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
//		logger.info("<jbg");
//		logger.info("\txmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
//		logger.info("\txmlns=\"http://jbg.sf.net/jbg\"");
//		logger.info("\txsi:schemaLocation=\"http://jbg.sf.net/jbg http://jbg.sf.net/xsd/1.0/jbg.xsd\"");
//		logger.info(">");
//		logger.info("\t<beans>");

		for (DescribeSObjectBasic dobj: dg.getSObjects()) {
			String name = dobj.getName();
			logger.info("\tNAME: {}", name);
			if (
				name.equals("BMCServiceDesk__Incident__c") ||
				name.equals("BMCServiceDesk__Task__c") ||
				name.equals("User") ||
				name.equals("BMCServiceDesk__SRM_RequestDefinition__c") ||
				name.equals("BMCServiceDesk__SYSTemplate__c") ||
				name.startsWith("Group")
//				1==2
			) {

//				logger.info("\t\t<bean class=\"com.mckesson.batch.force.domain.{}\" implements=\"com.mckesson.batch.force.domain.RemedyObject\">", name);
//				logger.info("\t\t\t<annotation>@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown=true)");
//				logger.info("@com.fasterxml.jackson.annotation.JsonRootName(value=\"{}\")</annotation>", name);

				DescribeSObject oneObj = fapi.describeSObject(name);

				for (Field field: oneObj.getAllFields()) {

//					if (field.isCreateable() && !field.isCalculated()) {

//						String type = field.getType();
//						if (
//							type.equals("address") ||
//							type.equals("currency") ||
//							type.equals("email") ||
//							type.equals("id") ||
//							type.equals("multipicklist") ||
//							type.equals("phone") ||
//							type.equals("picklist") ||
//							type.equals("reference") ||
//							type.equals("textarea") ||
//							type.equals("url")
//						) {
//							type="string";
//						} else if (type.equals("datetime")) {
//							type="date";
//						}

//						logger.info("\t\t\t<property name=\"{}\">", field.getName());

//						logger.info("\t\t\t\t<simple-type type=\"{}\" />", type);
//						logger.info("\t\t\t\t<annotation>@com.fasterxml.jackson.annotation.JsonProperty(value=\"{}\")</annotation>", field.getName());
						boolean required = field.isCreateable() && (!field.isNillable()) && (!field.isDefaultedOnCreate());
						logger.info("\t\t\'{}\'::\'{}\'{}==>{}/{}/{}", new Object[] {field.getName(), field.getType(), required?"+":"", field.getReferenceTo(), field.getReferenceToEntity(), field.getRelationshipName()});
//						logger.info("\t\t\t</property>");
					}


//				}

//				logger.info("\t\t</bean>");
			}
		}
//		logger.info("\t</beans>");
//		logger.info("</jbg>");
	}

	/**
	 * Test-finalizer
	 */
	@AfterClass
	public static void clean () {
		logger.info("Finish RemedyAPITest...");

		if (taskIds.size() != 0) {
			logger.info("Cleaning tasks...");
			for (String taskId: taskIds) {
				logger.info("Deleting task {}...", taskId);
				try {
					fapi.deleteSObject(RemedyApiImpl.getForceObjectName(BMCServiceDeskTask.class), taskId);
					logger.info("Task {} deleted.", taskId);
				} catch (Exception ex) {
					logger.error("Task(" + taskId + ") - deleting-error: " + ex.getMessage(), ex);
				}
			}
		}

		if (incidentIds.size() != 0) {
			logger.info("Cleaning incidents...");
			for (String incId: incidentIds) {
				logger.info("Deleting incident {}...", incId);
				try {
					fapi.deleteSObject(RemedyApiImpl.getForceObjectName(BMCServiceDeskIncident.class), incId);
					logger.info("Incident {} deleted.", incId);
				} catch (Exception ex) {
					logger.error("Incident(" + incId + ") - deleting-error: " + ex.getMessage(), ex);
				}
			}
		}

		logger.info("RemedyAPITest finished.");
	}

	/**
	 * Test-method for {@link RemedyApiImpl#getUserByEmail(String)}
	 *
	 * @throws RemedyApiException If processing-error
	 */
	@Test
	public void testGetUser () throws RemedyApiException {
		User user;
		user = api.getUserByEmail(NON_EXISTENT_VALUE);
		assertNull(user);

//		user = api.getUserByEmail(TEST_E_MAIL);
//		String fi = user.getFederationIdentifier();
		String fi = TEST_F_ID;
//		assertEquals(user.getEmail(), TEST_E_MAIL);

		user = api.getUserByFederationIdentifier(fi);
		assertEquals(user.getFederationIdentifier(), fi);
		logger.info("User fid=\'{}\', mail=\'{}\' was readed", fi, user.getEmail());
	}

	/**
	 * Test-method for {@link RemedyApiImpl#getUserIdByEmail(String)}
	 *
	 * @throws RemedyApiException If processing-error
	 */
	@Test
	public void testGetUserId() throws RemedyApiException {
		String sUserId;
		sUserId = api.getUserIdByEmail(NON_EXISTENT_VALUE);
		assertNull(sUserId);

//		sUserId = api.getUserIdbyEmail(TEST_E_MAIL);
//		logger.info("User-id  for \'{}\' was readed: {}", TEST_E_MAIL, sUserId);
//		assertEquals(sUserId, TEST_U_ID);

		sUserId = api.getUserIdByFederationIdentifier(NON_EXISTENT_VALUE);
		assertNull(sUserId);

		sUserId = api.getUserIdByFederationIdentifier(TEST_F_ID);
		logger.info("User-id for \'{}\' was readed: {}", TEST_F_ID, sUserId);
		assertEquals(sUserId, TEST_U_ID);
	}

	@Test
	public void SR00000171_with_Task_178() throws RemedyApiException {
		BMCServiceDeskIncident incident = createChain(
			"Employee_On-board_New_User.inc",
			new String[] {
				"Salesforce.task"
			}
		);

		assertEquals("Service Desk", incident.getBmcQueueName());
	}

	@Test
	public void SR00000172_with_Task_179() throws RemedyApiException {
		BMCServiceDeskIncident incident = createChain(
			"Employee_On-board_New_User-Executive.inc",
			new String[] {
				"Centricity_Business.task"
			}
		);

		assertEquals("Service Desk", incident.getBmcQueueName());
	}

	@Test
	public void SR00000173() throws RemedyApiException {
		BMCServiceDeskIncident incident = createChain(
			"Employee_Termination.inc",
			new String[] {
				"Security-Application.task",
				"Infrastructure_USON-MSH.task",
				"IT_TXO_PMS.task",
				"Tech_Product_Support_L1.task"
			}
		);

		assertEquals("Service Desk", incident.getBmcQueueName());
	}

	@Test
	public void SR00000174() throws RemedyApiException {
		BMCServiceDeskIncident incident = createChain(
			"Employee_HRBU_Transfer.inc",
			new String[] {
				"HR_Applications.task",
				"USON_Service_Desk.task"
			}
		);

		assertEquals("Service Desk", incident.getBmcQueueName());
	}

	@Test
	public void SR00000175() throws RemedyApiException {
		BMCServiceDeskIncident incident = createChain(
			"Domain_Account_Expired.inc",
			new String[0]
		);

		assertEquals("Service Desk", incident.getBmcQueueName());
	}

	@Test
	public void SR00000176() throws RemedyApiException {
		BMCServiceDeskIncident incident = createChain(
			"Provisioning_Action_Failed.inc",
			new String[0]
		);

		assertEquals("Directory Services", incident.getBmcQueueName());
	}

	
	@Test
	public void submitLiceseSubscriptionIncident_isOK() throws RemedyApiException {
		BMCServiceDeskIncident incident = createChain(
			"License_Subscription_Assignment_Failed.inc",
			new String[0]
		);

		assertEquals("Directory Services", incident.getBmcQueueName());
	}
	
	@Test
	public void SR00000177() throws RemedyApiException {
		BMCServiceDeskIncident incident = createChain(
			"Employee_Clinical_Transfer.inc",
			new String[] {
				"Clinical_Applications.task"
			}
		);

		assertEquals("Service Desk", incident.getBmcQueueName());
	}

	private BMCServiceDeskIncident createChain(String incTemplate, String[] taskTemplates) throws RemedyApiException{
		String incId;
//		String userId = api.getUserIdbyEmail(TEST_E_MAIL);
		String userId = api.getUserIdByFederationIdentifier(TEST_F_ID);
		incId = createIncident(
			incTemplate,
			userId,
			"Test incident-short-description (" + incTemplate + ")",
			"Test incident-description (" + incTemplate + ")"
		);
		for (String taskTemplate : taskTemplates) {
			createTask(
				taskTemplate,
				userId,
				incId,
				/*"Task-short-desciption (" + taskTemplate + ")",*/
				"Task-desciption (" + taskTemplate + ")"
			);
		}

		return api.getObject(incId, BMCServiceDeskIncident.class);
	}


	private String createIncident(String templateId, String userId, String shortDesc, String desc) throws RemedyApiException {

		logger.info("Processing Incident-template: {}", templateId);

		String incId;
		BMCServiceDeskIncident inc0, inc1;

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("bmcClientId", userId);
		params.put("bmcShortDescription", shortDesc);
		params.put("bmcIncidentDescription", desc);

		inc0 = api.prepareIncident(templateId, params);
		incId = api.createIncident(templateId, params, true).getId();
		incidentIds.add(incId);
		inc1 = api.getObject(incId, BMCServiceDeskIncident.class);
		logger.info("Incident was created: {}/{}", inc1.getId(), inc1.getName());
		check2Incidents(inc0, inc1, incId, templateId);

		return incId;
	}

	private void createTask(String templateId, String userId, String incId, /*String shortDesc,*/ String desc) throws RemedyApiException{
		BMCServiceDeskTask task0, task1;
		String taskId;

		Map<String, Object> params = new HashMap<String, Object>();

		params.clear();
		params.put("bmcClientId", userId);
		params.put("bmcTaskDescription", desc);
		/*params.put("bmcShortDescription", shortDesc);*/

		task0 = api.prepareTask(templateId, incId, params);
		taskId = api.createTask(templateId, incId, params);
		taskIds.add(taskId);
		task1 = api.getObject(taskId, BMCServiceDeskTask.class);
		logger.info("Task was created: {}/{}", task1.getId(), task1.getName());
		check2Tasks(task0, task1, taskId, templateId);
	}

}
