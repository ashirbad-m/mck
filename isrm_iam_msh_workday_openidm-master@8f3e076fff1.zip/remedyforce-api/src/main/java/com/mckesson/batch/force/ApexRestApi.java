package com.mckesson.batch.force;

import java.io.IOException;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.force.api.ApiConfig;
import com.force.api.ApiException;
import com.force.api.ApiSession;
import com.force.api.ApiTokenException;
import com.force.api.Auth;
import com.force.api.ForceApi;
import com.force.api.ResourceException;
import com.force.api.http.Http;
import com.force.api.http.HttpRequest;
import com.force.api.http.HttpResponse;
import com.mckesson.batch.force.domain.BMCServiceDeskIncident;

class ApexRestApi {

	private static final String objectClass = RemedyApiImpl.getForceObjectName(BMCServiceDeskIncident.class);

	private static final ObjectMapper jsonMapper;

	static {
		jsonMapper = new ObjectMapper();
		jsonMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
	}

	private final ApiConfig config;

	private ApiSession session;

	private final boolean autoRenew;

	private final ForceApi forceApi;

	public ApexRestApi(ForceApi forceApi, ApiConfig config) {
		super();

		this.forceApi = forceApi;
		this.config = config;
		this.session = Auth.authenticate(config);
		this.autoRenew  = true;
	}

	private final String uriBase() {
		return session.getApiEndpoint() + "/services/apexrest/BMCServiceDesk/1.0/ServiceRequest";
	}

	private JsonNode createFieldNode(String name, String value) {
		ObjectNode result = jsonMapper.createObjectNode();

		JsonNodeFactory nodeFactory = jsonMapper.getDeserializationConfig().getNodeFactory();
		result.set("Name", nodeFactory.textNode(name));
		result.set("Value", nodeFactory.textNode(value));

		return result;
	}

	//copied from com.force.api.ForceApi.apiRequest(HttpRequest)
	private final HttpResponse apiRequest(HttpRequest req) {
		req.setAuthorization("Bearer "+session.getAccessToken());
		HttpResponse res = Http.send(req);
		if(res.getResponseCode()==401) {
			// Perform one attempt to auto renew session if possible
			if(autoRenew) {
				System.out.println("Session expired. Refreshing session...");
				if(session.getRefreshToken()!=null) {
					session = Auth.refreshOauthTokenFlow(config, session.getRefreshToken());
				} else {
					session = Auth.authenticate(config);
				}
				req.setAuthorization("Bearer "+session.getAccessToken());
				res = Http.send(req);
			}
		}
		if(res.getResponseCode()>299) {
			if(res.getResponseCode()==401) {
				throw new ApiTokenException(res.getString());
			} else {
				throw new ApiException(res.getResponseCode(), res.getString());
			}
		} else if(req.getExpectedCode()!=-1 && res.getResponseCode()!=req.getExpectedCode()) {
			throw new RuntimeException("Unexpected response from Force API. Got response code "+res.getResponseCode()+
					". Was expecing "+req.getExpectedCode());
		} else {
			return res;
		}
	}

	//based on com.force.api.ForceApi.createSObject(String, Object)
	public IncidentData createIncident(BMCServiceDeskIncident incident) throws RemedyApiException {
		try {

			ObjectNode requestRootNode = jsonMapper.createObjectNode();
			requestRootNode.set("Answers", jsonMapper.createArrayNode());

			ArrayNode fieldsNode = jsonMapper.createArrayNode();
			requestRootNode.set("Fields", fieldsNode);

			fieldsNode.add(createFieldNode("requestDefinitionId", incident.getBmcRequestDefinition()));
			incident.setBmcRequestDefinition(null);

			fieldsNode.add(createFieldNode("client", incident.getBmcClientId()));
			incident.setBmcClientId(null);

			// We're trying to keep Http classes clean with no reference to JSON/Jackson
			// Therefore, we serialize to bytes before we pass object to HttpRequest().
			// But it would be nice to have a streaming implementation. We can do that
			// by using ObjectMapper.writeValue() passing in output stream, but then we have
			// polluted the Http layer.
			IncidentResponse result = jsonMapper.readValue(apiRequest(new HttpRequest()
					.url(uriBase())
					.method("POST")
					.header("Accept", "application/json")
					.header("Content-Type", "application/json")
					.expectsCode(200)
					.content(jsonMapper.writeValueAsBytes(requestRootNode))).getStream(), IncidentResponse.class);

			if (result.isSuccess()) {
				forceApi.updateSObject(objectClass, result.getIncidentData().getId(), incident);
				return (result.getIncidentData());
			} else {
				throw new RemedyApiException(result.getErrorCode() + ":" + result.getErrorMessage());
			}
		} catch (JsonGenerationException e) {
			throw new ResourceException(e);
		} catch (JsonMappingException e) {
			throw new ResourceException(e);
		} catch (IOException e) {
			throw new ResourceException(e);
		}
	}
}
