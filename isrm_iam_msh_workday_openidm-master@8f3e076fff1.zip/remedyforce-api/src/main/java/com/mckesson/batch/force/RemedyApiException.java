package com.mckesson.batch.force;
/**
 * @author Eugene Yudin
 * 
 * RF API for Remedy-interface-specific exception
 */
public class RemedyApiException extends Exception {

	private static final long serialVersionUID = 6274041463798872563L;

	/**
	 * Constructor
	 * 
	 * @see Exception#Exception() 
	 */
	public RemedyApiException () {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @see Exception#Exception(String, Throwable) 
	 */
	public RemedyApiException (String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Constructor
	 * 
	 * @see Exception#Exception(String) 
	 */
	public RemedyApiException (String message) {
		super(message);
	}

	/**
	 * Constructor
	 * 
	 * @see Exception#Exception(Throwable) 
	 */
	public RemedyApiException (Throwable cause) {
		super(cause);
	}
}
