package com.mckesson.batch.force;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.regex.Pattern;

import org.apache.commons.beanutils.BeanMap;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.force.api.ApiConfig;
import com.force.api.ForceApi;
import com.force.api.QueryResult;
import com.mckesson.batch.force.domain.BMCServiceDeskIncident;
import com.mckesson.batch.force.domain.BMCServiceDeskTask;
import com.mckesson.batch.force.domain.User;

/**
 * RF API for Remedy-implementation
 *
 * @see RemedyApi
 *
 * @author Eugene Yudin
 */
public class RemedyApiImpl implements RemedyApi {

	private static final String ENVIRONMENT_PROPERTIES = "environment.properties";

	private static final String DEFAULT_OWNER_PROPERTY = "defaultOwner";

	private static final String RESOURCE_PATH = "META-INF/environments";

	private static final Pattern EXTENDED_ID_PATTERN = Pattern.compile("^([a-zA-Z0-9]{15})([a-zA-Z0-9]{1,3}?)$");

	/** Parser of a JSON-templates */
	private static final ObjectMapper MAPPER;

	/** Logging-support */
	private static final Logger logger = LoggerFactory.getLogger(RemedyApiImpl.class);

	private final Properties environmentProperties;

	static {
		MAPPER = new ObjectMapper();
		MAPPER.setAnnotationIntrospector(AnnotationIntrospector.nopInstance());
	}

	/**
	 * @param clazz Salesforce-DAO-class
	 *
	 * @return Object-name for API-queries
	 */
	static String getForceObjectName (Class<?> clazz) {
		if (clazz  == null) {
			throw new NullPointerException("Class is null");
		}
		JsonRootName rootName = (JsonRootName) clazz.getAnnotation(JsonRootName.class);
		if (rootName != null) {
			return rootName.value();
		}
		return clazz.getSimpleName();
	}

	/**
	 * Injection-prevention for query-values
	 *
	 * @param value Source-value
	 * @param quot quote-character
	 *
	 * @return Quoted query-value-expression
	 */
	private static String escapeValue (String value, String quot) {
		while (value.contains("\\" + quot)) {
			value = value.replace("\\" + quot,  quot);
		}
		return quot + value.replace(quot,"\\" + quot) + quot;
	}

	/**
	 * @param clazz Salesforce-DAO-class
	 *
	 * @return Comma-separated attribute-names
	 */
	static String getAttrList (Class<?> clazz) {
		StringBuilder result = new StringBuilder();
		for (Field f : clazz.getDeclaredFields()) {
			JsonProperty prop = f.getAnnotation(JsonProperty.class);
			if (prop != null) {
				result.append(prop.value()).append(",");
			}
		}
		return result.substring(0, result.length() - 1);
	}

	/**
	 * Chain-method for Exception-logging
	 *
	 * @param wae Source Exception
	 *
	 * @return Source exception
	 */
	private static RemedyApiException log (RemedyApiException wae) {
		logger.error(wae.getMessage(), wae);
		return wae;
	}

	private String endpoint;

	/** Salesforce-API for CRUD-operations */
	private ForceApi api;

	/** Initialization-flag */
	private boolean initialized;

	private ApexRestApi apexApi;

	private final String environment;

	/**
	 * Constructor
	 *
	 * @throws RemedyApiException If initialization - error
	 */
	public RemedyApiImpl(String environment, String endpoint, String username, String password) throws RemedyApiException {
		this.environment = environment;
		this.endpoint = endpoint;

		initialized = false;
		logger.debug("Initialization...");
		try {
			logger.debug("FopceApi-instantiation...");

			ApiConfig apiConfig = new ApiConfig().
				setUsername(username).
				setPassword(password).
				setLoginEndpoint(endpoint);
			api = new ForceApi(apiConfig);
			apexApi = new ApexRestApi(api, apiConfig);
			initialized = true;
		} catch (Exception e) {
			throw log(new RemedyApiException("Initialization-error", e));
		}

		try {
			environmentProperties = readEnvironmentProperties();
		} catch (IOException ex) {
			logger.error(ex.getMessage(), ex);
			throw new RemedyApiException(ex.getMessage(), ex);
		}

		logger.debug("RemedyApiImpl - initialization was finished.");
	}

	/**
	 * @see com.mckesson.batch.force.RemedyApi#createIncident(java.lang.String, java.util.Map, boolean)
	 */
	@Override
	public IncidentData createIncident (String incidentTemplate, Map<String, Object> incidentData, boolean isServiceRequest) throws RemedyApiException {
		checkInit();
		logger.debug("Create incident \'{}/{}\'...", incidentTemplate, incidentData);
		BMCServiceDeskIncident inc = prepareIncident(incidentTemplate, incidentData);
		if (isServiceRequest) {
			IncidentData result = apexApi.createIncident(inc);
			setIncidentUrl(result);
			return result;
		} else {
			String incidentId = createObject(inc);
			String incidentName = getObjectName(incidentId, getForceObjectName(inc.getClass()));

			IncidentData result = new IncidentData();
			result.setId(incidentId);
			result.setName(incidentName);
			setIncidentUrl(result);

			return result;
		}
	}

	/**
	 * @see com.mckesson.batch.force.RemedyApi#createIncident(java.util.Map, boolean)
	 */
	@Override
	public IncidentData createIncident (Map<String, Object> incidentData, boolean isServiceRequest) throws RemedyApiException {
		return createIncident(null, incidentData, isServiceRequest);
	}

	/**
	 * @see com.mckesson.batch.force.RemedyApi#createTask(java.lang.String, java.lang.String, java.util.Map)
	 */
	@Override
	public String createTask (String taskTemplate, String incidentId, Map<String, Object> taskData) throws RemedyApiException {
		checkInit();
		logger.debug("Create task \'{}/{}/{}\'...", new Object[] {taskTemplate, incidentId, taskData});
		BMCServiceDeskTask task = prepareTask(taskTemplate, incidentId,  taskData);
		return createObject(task);
	}

	/**
	 * @see com.mckesson.batch.force.RemedyApi#createTask(java.lang.String, java.util.Map)
	 */
	public String createTask (String incidentId, Map<String, Object> taskData) throws RemedyApiException {
		return createTask(null, incidentId, taskData);
	}

	/**
	 * @see com.mckesson.batch.force.RemedyApi#getUserIdByEmail(java.lang.String)
	 */
	@Override
	public String getUserIdByEmail (String email)  throws RemedyApiException {
		return getUserIdByCriterion ("Email", email);
	}

	/**
	 * @see com.mckesson.batch.force.RemedyApi#getUserByEmail(java.lang.String)
	 */
	@Override
	public User getUserByEmail (String email) throws RemedyApiException {
		return getUserByCriterion ("Email", email);
	}

	/**
	 * @see com.mckesson.batch.force.RemedyApi#getUserIdByFederationIdentifier(java.lang.String)
	 */
	@Override
	public String getUserIdByFederationIdentifier(String federationIdentifier) throws RemedyApiException {
		return getUserIdByCriterion ("FederationIdentifier", federationIdentifier);
	}

	/**
	 * @see com.mckesson.batch.force.RemedyApi#getUserByFederationIdentifier(java.lang.String)
	 */
	@Override
	public User getUserByFederationIdentifier(String federationIdentifier) throws RemedyApiException {
		return getUserByCriterion ("FederationIdentifier", federationIdentifier);
	}

	private User getUserByCriterion (String cName, String cValue)  throws RemedyApiException {
		checkInit();
		QueryResult<User> result;
		logger.debug("Get user ({} = \'{}\')...", cName, cValue);

		try {
			String query = MessageFormat.format(
				"select {0} from {1} where {2}={3}",
				new Object[]{
					getAttrList(User.class),
					getForceObjectName(User.class),
					cName,
					escapeValue(cValue, "\'")
				}
			);
			logger.debug("query: {}", query);
			result = api.query(query, User.class);
		} catch (Exception ex) {
			throw log(new RemedyApiException("getUserByCriterion - error", ex));
		}

		if (result != null ) {
			List<User> users = result.getRecords();
			if (users != null && users.size() != 0) {
				if (users.size() == 1) {
					logger.debug("Get user {}/\'{}\' success.", cName, cValue);
					return users.get(0);
				}
				throw log(new RemedyApiException("getUserByCriterion. Ambiguous result-size: " + users.size()));
			}
		}
		logger.debug("User {}/\'{}\' not found.", cName, cValue);
		return null;
	}

	private String getUserIdByCriterion (String cName, String cValue) throws RemedyApiException {
		checkInit();
		User user = getUserByCriterion(cName, cValue);
		if(user != null) {
			return user.getId();
		}
		return null;
	}

	/**
	 * @see com.mckesson.batch.force.RemedyApi#getObject(java.lang.String, java.lang.Class)
	 */
	@Override
	public <T> T getObject(String oid, Class<T> clazz) throws RemedyApiException {
		checkInit();
		try {
			logger.debug("Get Object \'{}\'...", oid);
			T result = api.getSObject(getForceObjectName(clazz), oid).as(clazz);
			logger.debug("Get Object \'{}\' success.", oid);
			return result;
		} catch (Exception ex) {
			throw log(new RemedyApiException("getObject - error", ex));
		}
	}

	/**
	 * @see com.mckesson.batch.force.RemedyApi#getObjectName(java.lang.String, java.lang.String)
	 */
	@Override
	@SuppressWarnings("rawtypes")
	public String getObjectName(String oid, String forceType) throws RemedyApiException {
		checkInit();
		try {
			String query = MessageFormat.format("select Name from {0} where Id=''{1}''", new Object[] { forceType, oid });
			List<Map> result = api.query(query).getRecords();
			if (result != null && result.size() > 0) {
				return (String) result.get(0).get("Name");
			}
			return null;
		} catch (Exception ex) {
			throw log(new RemedyApiException("getObjectName - error", ex));
		}
	}

	/**
	 * @see com.mckesson.batch.force.RemedyApi#getIncidentName(java.lang.String)
	 */
	@Override
	public String getIncidentName(String incidentId) throws RemedyApiException {
		return getObjectName(incidentId, getForceObjectName(BMCServiceDeskIncident.class));
	}

	/**
	 * @see com.mckesson.batch.force.RemedyApi#getTaskName(java.lang.String)
	 */
	@Override
	public String getTaskName(String taskId) throws RemedyApiException {
		return getObjectName(taskId, getForceObjectName(BMCServiceDeskTask.class));
	}

	BMCServiceDeskIncident prepareIncident (String templateName, Map<String, Object> customData) throws RemedyApiException  {
		checkInit();
		return prepareObject(templateName, BMCServiceDeskIncident.class, customData);
	}

	BMCServiceDeskTask prepareTask (String templateName, String incidentId, Map<String, Object> customData)  throws RemedyApiException {
		checkInit();
		BMCServiceDeskTask task = prepareObject(templateName, BMCServiceDeskTask.class, customData);
		task.setBmcIncidentId(incidentId);
		return task;
	}

	private void setIncidentUrl(IncidentData incidentData) {
		String incidentId = incidentData.getId();
		if (EXTENDED_ID_PATTERN.matcher(incidentId).matches()) {
			incidentId = incidentId.substring(0, 15);
		}

		try {
			incidentData.setUrl(new URI(endpoint).resolve(new URI(null, null, "/" + incidentId, null)).toASCIIString());
		} catch (URISyntaxException e) {
			logger.error(e.getMessage(), e);
		}
	}

	private String createObject (Object wo) throws RemedyApiException {
		checkInit();
		logger.debug("Creating object \'{}\'...", wo.getClass());
		try {
			String result = api.createSObject(getForceObjectName(wo.getClass()), wo);
			logger.debug("Object \'{}/{}\' was created.", wo.getClass(), result);
			return result;
		} catch (Exception ex) {
			throw log(new RemedyApiException(getForceObjectName(wo.getClass()) + "-create - error: ", ex));
		}
	}

	/**
	 * @return Salesforce-API-instance
	 *
	 * @throws RemedyApiException If initialization-error
	 */
	public ForceApi getForceApi () throws RemedyApiException {
		checkInit();
		return api;
	}

	/**
	 * Template - based WordayObject-instance-creation
	 *
	 * @param templateName Full Name of template
	 * @param clazz BMCServiceDesk-bean-class
	 * @param overrides Additional Object-data
	 *
	 * @return Created instance of clazz
	 *
	 * @throws RemedyApiException IF processing - error
	 */
	private <T> T prepareObject (String templateName, Class<T> clazz, Map<String, Object> overrides) throws RemedyApiException {

		Map<String, Object> objectData = new HashMap<String, Object>();
		// read map from template
		if (!StringUtils.isBlank(templateName)) {
			try {
				objectData = readFromTemplate(templateName);
			} catch (IOException e) {
				logger.error("Failed to read template: {}. Ignoring...", templateName, e);
			}
		}

		// override templateData with overrides
		if (overrides != null && overrides.size() > 0) {
			objectData.putAll(overrides);
		}

		// create object and apply data
		T result;
		try {
			result = clazz.newInstance();

			BeanMap beanMap = new BeanMap(result);
			// put one by one ignoring exceptions
			for (Entry<String, Object> e : objectData.entrySet()) {
				try {
					beanMap.put(e.getKey(), e.getValue());
				} catch (Exception ex) {
					logger.warn("Property: [{},{}] was not updated with error: {}", new Object[] {e.getKey(), e.getValue(), ex.getMessage()});
				}
			}

		} catch (Exception e) {
			throw log(new RemedyApiException("Failed to create target object", e));
		}

		return result;
	}

	/**
	 * Initialization-checker
	 *
	 * @throws RemedyApiException If initialization-error
	 */
	private void checkInit () throws RemedyApiException {
		if (!initialized) {
			throw log(new RemedyApiException("Not initialized"));
		}
	}

	private InputStream getEnvironmentResourceInputStream(String resourceName) {
		return this.getClass().getClassLoader().getResourceAsStream(RESOURCE_PATH + '/' + environment + '/' + resourceName);
	}

	@SuppressWarnings("unchecked")
	private Map<String, Object> readFromTemplate(String template) throws IOException {
		InputStream is = null;
		try {
			is = getEnvironmentResourceInputStream(template);
			return MAPPER.readValue(is, Map.class);
		} finally {
			try {
				if (is != null) {
					is.close();
				}
			} catch (IOException ex) {
				logger.error(ex.getMessage(), ex);
			}
		}
	}

	private Properties readEnvironmentProperties() throws IOException {
		Properties properties = new Properties();
		InputStream is = null;
		try {
			is = getEnvironmentResourceInputStream(ENVIRONMENT_PROPERTIES);
			properties.load(is);
		} finally {
			try {
				if (is != null) {
					is.close();
				}
			} catch (IOException ex) {
				logger.error(ex.getMessage(), ex);
			}
		}
		return properties;
	}

	@Override
	public String getDefaultOwnerId() {
		return environmentProperties.getProperty(DEFAULT_OWNER_PROPERTY);
	}
}
