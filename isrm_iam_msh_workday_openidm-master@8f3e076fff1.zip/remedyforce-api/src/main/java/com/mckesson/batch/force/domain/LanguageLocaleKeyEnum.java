package com.mckesson.batch.force.domain;

/**
 * Java model for the LanguageLocaleKey picklist.
 *
 * This enum was auto-generated. It is considered owned
 * by the Force.com database.
 **/

public enum LanguageLocaleKeyEnum  {

    EN_US(true,false,"English","en_US"),
    DE(true,false,"German","de"),
    ES(true,false,"Spanish","es"),
    FR(true,false,"French","fr"),
    IT(true,false,"Italian","it"),
    JA(true,false,"Japanese","ja"),
    SV(true,false,"Swedish","sv"),
    KO(true,false,"Korean","ko"),
    ZH_TW(true,false,"Chinese (Traditional)","zh_TW"),
    ZH_CN(true,false,"Chinese (Simplified)","zh_CN"),
    PT_BR(true,false,"Portuguese (Brazilian)","pt_BR"),
    NL_NL(true,false,"Dutch","nl_NL"),
    DA(true,false,"Danish","da"),
    TH(true,false,"Thai","th"),
    FI(true,false,"Finnish","fi"),
    RU(true,false,"Russian","ru"),
    ES_MX(true,false,"Spanish (Mexican)","es_MX"),
    NO(true,false,"Norwegian","no"),
    ;

    private boolean isActive;
    private boolean isDefaultValue;
    private String label;
    private String value;

    private LanguageLocaleKeyEnum(boolean isActive, boolean isDefaultValue, String label, String value) {
        this.isActive = isActive;
        this.isDefaultValue = isDefaultValue;
        this.label = label;
        this.value = value;
    }

    
    public boolean isActive() { return this.isActive; }

    
    public boolean isDefaultValue() { return this.isDefaultValue; }

    
    public String label() { return this.label; }

    
    public String value() { return this.value; }

    public static LanguageLocaleKeyEnum fromValue(String value) {
        if (value == null) return null;

        for (LanguageLocaleKeyEnum picklistValueEnum : values()) {
            if (value.equals(picklistValueEnum.value())) {
                return picklistValueEnum;
            }
        }

        return null;
    }
}

