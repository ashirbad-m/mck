package com.mckesson.batch.force.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("BMCServiceDesk__Incident__c")
@JsonIgnoreProperties(ignoreUnknown = true)
public class BMCServiceDeskIncident{

	@JsonProperty("Id")
	private String id;

	@JsonProperty("OwnerId")
	private String ownerId;

	@JsonProperty("IsDeleted")
	private Boolean isDeleted;

	@JsonProperty("Name")
	private String name;

	@JsonProperty("CreatedDate")
	private String createdDate;

	@JsonProperty("CreatedById")
	private String createdById;

	@JsonProperty("LastModifiedDate")
	private String lastModifiedDate;

	@JsonProperty("LastModifiedById")
	private String lastModifiedById;

	@JsonProperty("SystemModstamp")
	private String systemModstamp;

	@JsonProperty("LastActivityDate")
	private String lastActivityDate;

	@JsonProperty("LastViewedDate")
	private String lastViewedDate;

	@JsonProperty("LastReferencedDate")
	private String lastReferencedDate;

	@JsonProperty("BMCServiceDesk__ACApprovalStatus__c")
	private String bmcACApprovalStatus;

	@JsonProperty("BMCServiceDesk__ACSeverity__c")
	private String bmcACSeverity;

	@JsonProperty("BMCServiceDesk__Actual_Outage_Time_Hours__c")
	private Double bmcActualOutageTimeHours;

	@JsonProperty("BMCServiceDesk__Additional_email_information__c")
	private String bmcAdditionalEmailInformation;

	@JsonProperty("BMCServiceDesk__AllTaskCloseController__c")
	private Boolean bmcAllTaskCloseController;

	@JsonProperty("BMCServiceDesk__Approved__c")
	private Boolean bmcApproved;

	@JsonProperty("BMCServiceDesk__BLANK__c")
	private String bmcBLANK;

	@JsonProperty("BMCServiceDesk__Category_ID__c")
	private String bmcCategory;

	@JsonProperty("BMCServiceDesk__Client_Account__c")
	private String bmcClientAccount;

	@JsonProperty("BMCServiceDesk__Client_Manager__c")
	private String bmcClientManager;

	@JsonProperty("BMCServiceDesk__Client_Name__c")
	private String bmcClientName;

	@JsonProperty("BMCServiceDesk__Client_Phone__c")
	private String bmcClientPhone;

	@JsonProperty("BMCServiceDesk__Client_Type__c")
	private String bmcClientType;

	@JsonProperty("BMCServiceDesk__Clock_Status__c")
	private String bmcClockStatus;

	@JsonProperty("BMCServiceDesk__Closed_By__c")
	private String bmcClosedBy;

	@JsonProperty("BMCServiceDesk__ClosureCategory__c")
	private String bmcClosureCategory;

	@JsonProperty("BMCServiceDesk__Compliant__c")
	private String bmcCompliant;

	@JsonProperty("BMCServiceDesk__Compliments_and_Complaints__c")
	private String bmcComplimentsAndComplaints;

	@JsonProperty("BMCServiceDesk__Due_Date_Progress__c")
	private String bmcDueDateProgress;

	@JsonProperty("BMCServiceDesk__EmailServiceAddress__c")
	private String bmcEmailServiceAddress;

	@JsonProperty("BMCServiceDesk__Event_ID__c")
	private String bmcEventID;

	@JsonProperty("BMCServiceDesk__FKAccount__c")
	private String bmcAccountId;

	@JsonProperty("BMCServiceDesk__FKBMC_BaseElement__c")
	private String bmcBMCBaseElementId;

	@JsonProperty("BMCServiceDesk__FKBroadcast__c")
	private String bmcBroadcastId;

	@JsonProperty("BMCServiceDesk__FKBusinessService__c")
	private String bmcBusinessServiceId;

	@JsonProperty("BMCServiceDesk__FKCategory__c")
	private String bmcCategoryId;

	@JsonProperty("BMCServiceDesk__FKClient__c")
	private String bmcClientId;

	@JsonProperty("BMCServiceDesk__FKClosedBy__c")
	private String bmcFKClosedBy;

	@JsonProperty("BMCServiceDesk__FKContact__c")
	private String bmcContactId;

	@JsonProperty("BMCServiceDesk__FKImpact__c")
	private String bmcImpactId;

	@JsonProperty("BMCServiceDesk__FKIncident__c")
	private String bmcIncidentId;

	@JsonProperty("BMCServiceDesk__FKLead__c")
	private String bmcLead;

	@JsonProperty("BMCServiceDesk__FKOpenBy__c")
	private String bmcOpenBy;

	@JsonProperty("BMCServiceDesk__FKPriority__c")
	private String bmcPriorityId;

	@JsonProperty("BMCServiceDesk__FKRequestDefinition__c")
	private String bmcRequestDefinition;

	@JsonProperty("BMCServiceDesk__FKRequestDetail__c")
	private String bmcRequestDetail;

	@JsonProperty("BMCServiceDesk__FKServiceOffering__c")
	private String bmcServiceOffering;

	@JsonProperty("BMCServiceDesk__FKStatus__c")
	private String bmcStatusId;

	@JsonProperty("BMCServiceDesk__FKTemplate__c")
	private String bmcTemplateId;

	@JsonProperty("BMCServiceDesk__FKUrgency__c")
	private String bmcUrgencyId;

	@JsonProperty("BMCServiceDesk__Feedback_Last_Submitted__c")
	private String bmcFeedbackLastSubmitted;

	@JsonProperty("BMCServiceDesk__Feedback__c")
	private String bmcFeedback;

	@JsonProperty("BMCServiceDesk__Impact_Id__c")
	private String bmcImpact;

	@JsonProperty("BMCServiceDesk__IncidentType__c")
	private String bmcIncidentType;
	
	@JsonProperty("BMCServiceDesk__Is_New_Record__c")
	private Boolean bmcIsNewRecord;

	@JsonProperty("BMCServiceDesk__Launch_console__c")
	private String bmcLaunchConsole;

	@JsonProperty("BMCServiceDesk__New_Incident__c")
	private String bmcNewIncident;

	@JsonProperty("BMCServiceDesk__PreferredContactMethod__c")
	private String bmcPreferredContactMethod;

	@JsonProperty("BMCServiceDesk__Priority_ID__c")
	private String bmcPriority;

	@JsonProperty("BMCServiceDesk__Recurrence__c")
	private String bmcRecurrence;

	@JsonProperty("BMCServiceDesk__RecurringParentRecordId__c")
	private String bmcRecurringParentRecordId;

	@JsonProperty("BMCServiceDesk__RequestDetailCloneId__c")
	private String bmcRequestDetailCloneId;

	@JsonProperty("BMCServiceDesk__ServiceRequest__c")
	private String bmcServiceRequest;

	@JsonProperty("BMCServiceDesk__Service_Request_Title__c")
	private String bmcServiceRequestTitle;

	@JsonProperty("BMCServiceDesk__ShowDueDateDialog__c")
	private Boolean bmcShowDueDateDialog;

	@JsonProperty("BMCServiceDesk__StatusChangeDate__c")
	private String bmcStatusChangeDate;

	@JsonProperty("BMCServiceDesk__Status_ID__c")
	private String bmcStatus;

	@JsonProperty("BMCServiceDesk__Task_Closed_Controller__c")
	private String bmcTaskClosedController;

	@JsonProperty("BMCServiceDesk__TemplateAlreadyApplied__c")
	private Boolean bmcTemplateAlreadyApplied;

	@JsonProperty("BMCServiceDesk__TemplateName__c")
	private String bmcTemplateName;

	@JsonProperty("BMCServiceDesk__TimeSpentInCurrentStatus__c")
	private Double bmcTimeSpentInCurrentStatus;

	@JsonProperty("BMCServiceDesk__Time_Remaining_Percentage__c")
	private Double bmcTimeRemainingPercentage;

	@JsonProperty("BMCServiceDesk__TotalWorkTime__c")
	private Double bmcTotalWorkTime;

	@JsonProperty("BMCServiceDesk__Type__c")
	private String bmcType;

	@JsonProperty("BMCServiceDesk__UpdateCount__c")
	private Double bmcUpdateCount;

	@JsonProperty("BMCServiceDesk__Urgency_ID__c")
	private String bmcUrgency;

	@JsonProperty("BMCServiceDesk__VIP_Client__c")
	private String bmcVIPClient;

	@JsonProperty("BMCServiceDesk__WorkflowController__c")
	private String bmcWorkflowController;

	@JsonProperty("BMCServiceDesk__actualDuration__c")
	private String bmcActualDuration;

	@JsonProperty("BMCServiceDesk__actualOutageDuration__c")
	private String bmcActualOutageDuration;

	@JsonProperty("BMCServiceDesk__call__c")
	private String bmcCall;

	@JsonProperty("BMCServiceDesk__clientEmail__c")
	private String bmcClientEmail;

	@JsonProperty("BMCServiceDesk__clientFirstName__c")
	private String bmcClientFirstName;

	@JsonProperty("BMCServiceDesk__clientId__c")
	private String bmcClient;

	@JsonProperty("BMCServiceDesk__clientLastName__c")
	private String bmcClientLastName;

	@JsonProperty("BMCServiceDesk__closeDateTime__c")
	private String bmcCloseDateTime;

	@JsonProperty("BMCServiceDesk__closeTasks__c")
	private Boolean bmcCloseTasks;

	@JsonProperty("BMCServiceDesk__completedDate__c")
	private String bmcCompletedDate;

	@JsonProperty("BMCServiceDesk__contactType__c")
	private String bmcContactType;

	@JsonProperty("BMCServiceDesk__dueDateTime__c")
	private String bmcDueDateTime;

	@JsonProperty("BMCServiceDesk__firstCallResolution__c")
	private Boolean bmcFirstCallResolution;

	@JsonProperty("BMCServiceDesk__followUpDateTime__c")
	private String bmcFollowUpDateTime;

	@JsonProperty("BMCServiceDesk__followUp__c")
	private Boolean bmcFollowUp;

	@JsonProperty("BMCServiceDesk__inactive__c")
	private Boolean bmcInactive;

	@JsonProperty("BMCServiceDesk__inc_console_detail_link__c")
	private String bmcIncConsoleDetailLink;

	@JsonProperty("BMCServiceDesk__incidentDescription__c")
	private String bmcIncidentDescription;

	@JsonProperty("BMCServiceDesk__incidentResolution__c")
	private String bmcIncidentResolution;

	@JsonProperty("BMCServiceDesk__maximumDuration__c")
	private String bmcMaximumDuration;

	@JsonProperty("BMCServiceDesk__note__c")
	private String bmcNote;

	@JsonProperty("BMCServiceDesk__openDateTime__c")
	private String bmcOpenDateTime;

	@JsonProperty("BMCServiceDesk__outageFrom__c")
	private String bmcOutageFrom;

	@JsonProperty("BMCServiceDesk__outageTo__c")
	private String bmcOutageTo;

	@JsonProperty("BMCServiceDesk__queueName__c")
	private String bmcQueueName;

	@JsonProperty("BMCServiceDesk__recommendedFixDateTime__c")
	private String bmcRecommendedFixDateTime;

	@JsonProperty("BMCServiceDesk__respondedDateTime__c")
	private String bmcRespondedDateTime;

	@JsonProperty("BMCServiceDesk__responseDateTime__c")
	private String bmcResponseDateTime;

	@JsonProperty("BMCServiceDesk__shortDescription__c")
	private String bmcShortDescription;

	@JsonProperty("BMCServiceDesk__state__c")
	private Boolean bmcState;

	@JsonProperty("BMCServiceDesk__timeSpent__c")
	private String bmcTimeSpent;

	@JsonProperty("BMCServiceDesk__Total_Duration__c")
	private Double bmcTotalDuration;

	@JsonProperty("BMCServiceDesk__Incorrect_category__c")
	private Boolean bmcIncorrectCategory;

	@JsonProperty("Client_VIP__c")
	private Boolean clientVIP;

	@JsonProperty("BMCServiceDesk__Incorrect_owner__c")
	private Boolean bmcIncorrectOwner;

	@JsonProperty("BMCServiceDesk__LockedRecordTimestamp__c")
	private String bmcLockedRecordTimestamp;

	@JsonProperty("BMCServiceDesk__Queue__c")
	private String bmcQueue;

	@JsonProperty("BMCServiceDesk__Reassigned_Count__c")
	private Double bmcReassignedCount;

	@JsonProperty("BMCServiceDesk__isServiceRequest__c")
	private Boolean bmcIsServiceRequest;

	@JsonProperty("Employee__c")
	private String employee;

	@JsonProperty("Alternate_Contact_Name__c")
	private String alternateContactName;

	@JsonProperty("Alternate_Contact_Number__c")
	private String alternateContactNumber;

	@JsonProperty("External_Ticket_Ref__c")
	private String externalTicketRef;

	@JsonProperty("Affected_Application__c")
	private String affectedApplication;

	@JsonProperty("Affected_Hardware__c")
	private String affectedHardware;

	@JsonProperty("Email__c")
	private String email;

	@JsonProperty("Phone__c")
	private String phone;

	@JsonProperty("Quick_Description__c")
	private String quickDescription;

	@JsonProperty("Title__c")
	private String title;

	@JsonProperty("Parent_Category_Tree__c")
	private String parentCategoryTree;

	@JsonProperty("Category_Action_State__c")
	private String categoryActionState;

	@JsonProperty("ManagerID__c")
	private String manager;

	@JsonProperty("HR_Confidential__c")
	private String hrConfidential;

	@JsonProperty("Customer_Practice_Shortname__c")
	private String customerPracticeShortname;

	@JsonProperty("Customer_Region__c")
	private String customerRegion;

	@JsonProperty("Display_Name__c")
	private String displayName;

	@JsonProperty("City__c")
	private String city;

	@JsonProperty("Mobile__c")
	private String mobile;

	@JsonProperty("SAM_Account_Name__c")
	private String sAMAccountName;

	@JsonProperty("Site_Name__c")
	private String siteName;

	@JsonProperty("Client_State__c")
	private String clientState;

	@JsonProperty("Street__c")
	private String street;

	@JsonProperty("Zip_Code__c")
	private String zipCode;

	@JsonProperty("Customer_Manager__c")
	private String customerManager;

	@JsonProperty("Middle_Initial__c")
	private String middleInitial;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedById() {
		return createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLastModifiedById() {
		return lastModifiedById;
	}

	public void setLastModifiedById(String lastModifiedById) {
		this.lastModifiedById = lastModifiedById;
	}

	public String getSystemModstamp() {
		return systemModstamp;
	}

	public void setSystemModstamp(String systemModstamp) {
		this.systemModstamp = systemModstamp;
	}

	public String getLastActivityDate() {
		return lastActivityDate;
	}

	public void setLastActivityDate(String lastActivityDate) {
		this.lastActivityDate = lastActivityDate;
	}

	public String getLastViewedDate() {
		return lastViewedDate;
	}

	public void setLastViewedDate(String lastViewedDate) {
		this.lastViewedDate = lastViewedDate;
	}

	public String getLastReferencedDate() {
		return lastReferencedDate;
	}

	public void setLastReferencedDate(String lastReferencedDate) {
		this.lastReferencedDate = lastReferencedDate;
	}

	public String getBmcACApprovalStatus() {
		return bmcACApprovalStatus;
	}

	public void setBmcACApprovalStatus(String bmcACApprovalStatus) {
		this.bmcACApprovalStatus = bmcACApprovalStatus;
	}

	public String getBmcACSeverity() {
		return bmcACSeverity;
	}

	public void setBmcACSeverity(String bmcACSeverity) {
		this.bmcACSeverity = bmcACSeverity;
	}

	public Double getBmcActualOutageTimeHours() {
		return bmcActualOutageTimeHours;
	}

	public void setBmcActualOutageTimeHours(Double bmcActualOutageTimeHours) {
		this.bmcActualOutageTimeHours = bmcActualOutageTimeHours;
	}

	public String getBmcAdditionalEmailInformation() {
		return bmcAdditionalEmailInformation;
	}

	public void setBmcAdditionalEmailInformation(String bmcAdditionalEmailInformation) {
		this.bmcAdditionalEmailInformation = bmcAdditionalEmailInformation;
	}

	public Boolean getBmcAllTaskCloseController() {
		return bmcAllTaskCloseController;
	}

	public void setBmcAllTaskCloseController(Boolean bmcAllTaskCloseController) {
		this.bmcAllTaskCloseController = bmcAllTaskCloseController;
	}

	public Boolean getBmcApproved() {
		return bmcApproved;
	}

	public void setBmcApproved(Boolean bmcApproved) {
		this.bmcApproved = bmcApproved;
	}

	public String getBmcBLANK() {
		return bmcBLANK;
	}

	public void setBmcBLANK(String bmcBLANK) {
		this.bmcBLANK = bmcBLANK;
	}

	public String getBmcCategory() {
		return bmcCategory;
	}

	public void setBmcCategory(String bmcCategory) {
		this.bmcCategory = bmcCategory;
	}

	public String getBmcClientAccount() {
		return bmcClientAccount;
	}

	public void setBmcClientAccount(String bmcClientAccount) {
		this.bmcClientAccount = bmcClientAccount;
	}

	public String getBmcClientManager() {
		return bmcClientManager;
	}

	public void setBmcClientManager(String bmcClientManager) {
		this.bmcClientManager = bmcClientManager;
	}

	public String getBmcClientName() {
		return bmcClientName;
	}

	public void setBmcClientName(String bmcClientName) {
		this.bmcClientName = bmcClientName;
	}

	public String getBmcClientPhone() {
		return bmcClientPhone;
	}

	public void setBmcClientPhone(String bmcClientPhone) {
		this.bmcClientPhone = bmcClientPhone;
	}

	public String getBmcClientType() {
		return bmcClientType;
	}

	public void setBmcClientType(String bmcClientType) {
		this.bmcClientType = bmcClientType;
	}

	public String getBmcClockStatus() {
		return bmcClockStatus;
	}

	public void setBmcClockStatus(String bmcClockStatus) {
		this.bmcClockStatus = bmcClockStatus;
	}

	public String getBmcClosedBy() {
		return bmcClosedBy;
	}

	public void setBmcClosedBy(String bmcClosedBy) {
		this.bmcClosedBy = bmcClosedBy;
	}

	public String getBmcClosureCategory() {
		return bmcClosureCategory;
	}

	public void setBmcClosureCategory(String bmcClosureCategory) {
		this.bmcClosureCategory = bmcClosureCategory;
	}

	public String getBmcCompliant() {
		return bmcCompliant;
	}

	public void setBmcCompliant(String bmcCompliant) {
		this.bmcCompliant = bmcCompliant;
	}

	public String getBmcComplimentsAndComplaints() {
		return bmcComplimentsAndComplaints;
	}

	public void setBmcComplimentsAndComplaints(String bmcComplimentsAndComplaints) {
		this.bmcComplimentsAndComplaints = bmcComplimentsAndComplaints;
	}

	public String getBmcDueDateProgress() {
		return bmcDueDateProgress;
	}

	public void setBmcDueDateProgress(String bmcDueDateProgress) {
		this.bmcDueDateProgress = bmcDueDateProgress;
	}

	public String getBmcEmailServiceAddress() {
		return bmcEmailServiceAddress;
	}

	public void setBmcEmailServiceAddress(String bmcEmailServiceAddress) {
		this.bmcEmailServiceAddress = bmcEmailServiceAddress;
	}

	public String getBmcEventID() {
		return bmcEventID;
	}

	public void setBmcEventID(String bmcEventID) {
		this.bmcEventID = bmcEventID;
	}

	public String getBmcAccountId() {
		return bmcAccountId;
	}

	public void setBmcAccountId(String bmcAccountId) {
		this.bmcAccountId = bmcAccountId;
	}

	public String getBmcBMCBaseElementId() {
		return bmcBMCBaseElementId;
	}

	public void setBmcBMCBaseElementId(String bmcBMCBaseElementId) {
		this.bmcBMCBaseElementId = bmcBMCBaseElementId;
	}

	public String getBmcBroadcastId() {
		return bmcBroadcastId;
	}

	public void setBmcBroadcastId(String bmcBroadcastId) {
		this.bmcBroadcastId = bmcBroadcastId;
	}

	public String getBmcBusinessServiceId() {
		return bmcBusinessServiceId;
	}

	public void setBmcBusinessServiceId(String bmcBusinessServiceId) {
		this.bmcBusinessServiceId = bmcBusinessServiceId;
	}

	public String getBmcCategoryId() {
		return bmcCategoryId;
	}

	public void setBmcCategoryId(String bmcCategoryId) {
		this.bmcCategoryId = bmcCategoryId;
	}

	public String getBmcClientId() {
		return bmcClientId;
	}

	public void setBmcClientId(String bmcClientId) {
		this.bmcClientId = bmcClientId;
	}

	public String getBmcFKClosedBy() {
		return bmcFKClosedBy;
	}

	public void setBmcFKClosedBy(String bmcFKClosedBy) {
		this.bmcFKClosedBy = bmcFKClosedBy;
	}

	public String getBmcContactId() {
		return bmcContactId;
	}

	public void setBmcContactId(String bmcContactId) {
		this.bmcContactId = bmcContactId;
	}

	public String getBmcImpactId() {
		return bmcImpactId;
	}

	public void setBmcImpactId(String bmcImpactId) {
		this.bmcImpactId = bmcImpactId;
	}

	public String getBmcIncidentId() {
		return bmcIncidentId;
	}

	public void setBmcIncidentId(String bmcIncidentId) {
		this.bmcIncidentId = bmcIncidentId;
	}

	public String getBmcLead() {
		return bmcLead;
	}

	public void setBmcLead(String bmcLead) {
		this.bmcLead = bmcLead;
	}

	public String getBmcOpenBy() {
		return bmcOpenBy;
	}

	public void setBmcOpenBy(String bmcOpenBy) {
		this.bmcOpenBy = bmcOpenBy;
	}

	public String getBmcPriorityId() {
		return bmcPriorityId;
	}

	public void setBmcPriorityId(String bmcPriorityId) {
		this.bmcPriorityId = bmcPriorityId;
	}

	public String getBmcRequestDefinition() {
		return bmcRequestDefinition;
	}

	public void setBmcRequestDefinition(String bmcRequestDefinition) {
		this.bmcRequestDefinition = bmcRequestDefinition;
	}

	public String getBmcRequestDetail() {
		return bmcRequestDetail;
	}

	public void setBmcRequestDetail(String bmcRequestDetail) {
		this.bmcRequestDetail = bmcRequestDetail;
	}

	public String getBmcServiceOffering() {
		return bmcServiceOffering;
	}

	public void setBmcServiceOffering(String bmcServiceOffering) {
		this.bmcServiceOffering = bmcServiceOffering;
	}

	public String getBmcStatusId() {
		return bmcStatusId;
	}

	public void setBmcStatusId(String bmcStatusId) {
		this.bmcStatusId = bmcStatusId;
	}

	public String getBmcTemplateId() {
		return bmcTemplateId;
	}

	public void setBmcTemplateId(String bmcTemplateId) {
		this.bmcTemplateId = bmcTemplateId;
	}

	public String getBmcUrgencyId() {
		return bmcUrgencyId;
	}

	public void setBmcUrgencyId(String bmcUrgencyId) {
		this.bmcUrgencyId = bmcUrgencyId;
	}

	public String getBmcFeedbackLastSubmitted() {
		return bmcFeedbackLastSubmitted;
	}

	public void setBmcFeedbackLastSubmitted(String bmcFeedbackLastSubmitted) {
		this.bmcFeedbackLastSubmitted = bmcFeedbackLastSubmitted;
	}

	public String getBmcFeedback() {
		return bmcFeedback;
	}

	public void setBmcFeedback(String bmcFeedback) {
		this.bmcFeedback = bmcFeedback;
	}

	public String getBmcImpact() {
		return bmcImpact;
	}

	public void setBmcImpact(String bmcImpact) {
		this.bmcImpact = bmcImpact;
	}

	public String getBmcIncidentType() {
		return bmcIncidentType;
	}

	public void setBmcIncidentType(String bmcIncidentType) {
		this.bmcIncidentType = bmcIncidentType;
	}

	public Boolean getBmcIsNewRecord() {
		return bmcIsNewRecord;
	}

	public void setBmcIsNewRecord(Boolean bmcIsNewRecord) {
		this.bmcIsNewRecord = bmcIsNewRecord;
	}

	public String getBmcLaunchConsole() {
		return bmcLaunchConsole;
	}

	public void setBmcLaunchConsole(String bmcLaunchConsole) {
		this.bmcLaunchConsole = bmcLaunchConsole;
	}

	public String getBmcNewIncident() {
		return bmcNewIncident;
	}

	public void setBmcNewIncident(String bmcNewIncident) {
		this.bmcNewIncident = bmcNewIncident;
	}

	public String getBmcPreferredContactMethod() {
		return bmcPreferredContactMethod;
	}

	public void setBmcPreferredContactMethod(String bmcPreferredContactMethod) {
		this.bmcPreferredContactMethod = bmcPreferredContactMethod;
	}

	public String getBmcPriority() {
		return bmcPriority;
	}

	public void setBmcPriority(String bmcPriority) {
		this.bmcPriority = bmcPriority;
	}

	public String getBmcRecurrence() {
		return bmcRecurrence;
	}

	public void setBmcRecurrence(String bmcRecurrence) {
		this.bmcRecurrence = bmcRecurrence;
	}

	public String getBmcRecurringParentRecordId() {
		return bmcRecurringParentRecordId;
	}

	public void setBmcRecurringParentRecordId(String bmcRecurringParentRecordId) {
		this.bmcRecurringParentRecordId = bmcRecurringParentRecordId;
	}

	public String getBmcRequestDetailCloneId() {
		return bmcRequestDetailCloneId;
	}

	public void setBmcRequestDetailCloneId(String bmcRequestDetailCloneId) {
		this.bmcRequestDetailCloneId = bmcRequestDetailCloneId;
	}

	public String getBmcServiceRequest() {
		return bmcServiceRequest;
	}

	public void setBmcServiceRequest(String bmcServiceRequest) {
		this.bmcServiceRequest = bmcServiceRequest;
	}

	public String getBmcServiceRequestTitle() {
		return bmcServiceRequestTitle;
	}

	public void setBmcServiceRequestTitle(String bmcServiceRequestTitle) {
		this.bmcServiceRequestTitle = bmcServiceRequestTitle;
	}

	public Boolean getBmcShowDueDateDialog() {
		return bmcShowDueDateDialog;
	}

	public void setBmcShowDueDateDialog(Boolean bmcShowDueDateDialog) {
		this.bmcShowDueDateDialog = bmcShowDueDateDialog;
	}

	public String getBmcStatusChangeDate() {
		return bmcStatusChangeDate;
	}

	public void setBmcStatusChangeDate(String bmcStatusChangeDate) {
		this.bmcStatusChangeDate = bmcStatusChangeDate;
	}

	public String getBmcStatus() {
		return bmcStatus;
	}

	public void setBmcStatus(String bmcStatus) {
		this.bmcStatus = bmcStatus;
	}

	public String getBmcTaskClosedController() {
		return bmcTaskClosedController;
	}

	public void setBmcTaskClosedController(String bmcTaskClosedController) {
		this.bmcTaskClosedController = bmcTaskClosedController;
	}

	public Boolean getBmcTemplateAlreadyApplied() {
		return bmcTemplateAlreadyApplied;
	}

	public void setBmcTemplateAlreadyApplied(Boolean bmcTemplateAlreadyApplied) {
		this.bmcTemplateAlreadyApplied = bmcTemplateAlreadyApplied;
	}

	public String getBmcTemplateName() {
		return bmcTemplateName;
	}

	public void setBmcTemplateName(String bmcTemplateName) {
		this.bmcTemplateName = bmcTemplateName;
	}

	public Double getBmcTimeSpentInCurrentStatus() {
		return bmcTimeSpentInCurrentStatus;
	}

	public void setBmcTimeSpentInCurrentStatus(Double bmcTimeSpentInCurrentStatus) {
		this.bmcTimeSpentInCurrentStatus = bmcTimeSpentInCurrentStatus;
	}

	public Double getBmcTimeRemainingPercentage() {
		return bmcTimeRemainingPercentage;
	}

	public void setBmcTimeRemainingPercentage(Double bmcTimeRemainingPercentage) {
		this.bmcTimeRemainingPercentage = bmcTimeRemainingPercentage;
	}

	public Double getBmcTotalWorkTime() {
		return bmcTotalWorkTime;
	}

	public void setBmcTotalWorkTime(Double bmcTotalWorkTime) {
		this.bmcTotalWorkTime = bmcTotalWorkTime;
	}

	public String getBmcType() {
		return bmcType;
	}

	public void setBmcType(String bmcType) {
		this.bmcType = bmcType;
	}

	public Double getBmcUpdateCount() {
		return bmcUpdateCount;
	}

	public void setBmcUpdateCount(Double bmcUpdateCount) {
		this.bmcUpdateCount = bmcUpdateCount;
	}

	public String getBmcUrgency() {
		return bmcUrgency;
	}

	public void setBmcUrgency(String bmcUrgency) {
		this.bmcUrgency = bmcUrgency;
	}

	public String getBmcVIPClient() {
		return bmcVIPClient;
	}

	public void setBmcVIPClient(String bmcVIPClient) {
		this.bmcVIPClient = bmcVIPClient;
	}

	public String getBmcWorkflowController() {
		return bmcWorkflowController;
	}

	public void setBmcWorkflowController(String bmcWorkflowController) {
		this.bmcWorkflowController = bmcWorkflowController;
	}

	public String getBmcActualDuration() {
		return bmcActualDuration;
	}

	public void setBmcActualDuration(String bmcActualDuration) {
		this.bmcActualDuration = bmcActualDuration;
	}

	public String getBmcActualOutageDuration() {
		return bmcActualOutageDuration;
	}

	public void setBmcActualOutageDuration(String bmcActualOutageDuration) {
		this.bmcActualOutageDuration = bmcActualOutageDuration;
	}

	public String getBmcCall() {
		return bmcCall;
	}

	public void setBmcCall(String bmcCall) {
		this.bmcCall = bmcCall;
	}

	public String getBmcClientEmail() {
		return bmcClientEmail;
	}

	public void setBmcClientEmail(String bmcClientEmail) {
		this.bmcClientEmail = bmcClientEmail;
	}

	public String getBmcClientFirstName() {
		return bmcClientFirstName;
	}

	public void setBmcClientFirstName(String bmcClientFirstName) {
		this.bmcClientFirstName = bmcClientFirstName;
	}

	public String getBmcClient() {
		return bmcClient;
	}

	public void setBmcClient(String bmcClient) {
		this.bmcClient = bmcClient;
	}

	public String getBmcClientLastName() {
		return bmcClientLastName;
	}

	public void setBmcClientLastName(String bmcClientLastName) {
		this.bmcClientLastName = bmcClientLastName;
	}

	public String getBmcCloseDateTime() {
		return bmcCloseDateTime;
	}

	public void setBmcCloseDateTime(String bmcCloseDateTime) {
		this.bmcCloseDateTime = bmcCloseDateTime;
	}

	public Boolean getBmcCloseTasks() {
		return bmcCloseTasks;
	}

	public void setBmcCloseTasks(Boolean bmcCloseTasks) {
		this.bmcCloseTasks = bmcCloseTasks;
	}

	public String getBmcCompletedDate() {
		return bmcCompletedDate;
	}

	public void setBmcCompletedDate(String bmcCompletedDate) {
		this.bmcCompletedDate = bmcCompletedDate;
	}

	public String getBmcContactType() {
		return bmcContactType;
	}

	public void setBmcContactType(String bmcContactType) {
		this.bmcContactType = bmcContactType;
	}

	public String getBmcDueDateTime() {
		return bmcDueDateTime;
	}

	public void setBmcDueDateTime(String bmcDueDateTime) {
		this.bmcDueDateTime = bmcDueDateTime;
	}

	public Boolean getBmcFirstCallResolution() {
		return bmcFirstCallResolution;
	}

	public void setBmcFirstCallResolution(Boolean bmcFirstCallResolution) {
		this.bmcFirstCallResolution = bmcFirstCallResolution;
	}

	public String getBmcFollowUpDateTime() {
		return bmcFollowUpDateTime;
	}

	public void setBmcFollowUpDateTime(String bmcFollowUpDateTime) {
		this.bmcFollowUpDateTime = bmcFollowUpDateTime;
	}

	public Boolean getBmcFollowUp() {
		return bmcFollowUp;
	}

	public void setBmcFollowUp(Boolean bmcFollowUp) {
		this.bmcFollowUp = bmcFollowUp;
	}

	public Boolean getBmcInactive() {
		return bmcInactive;
	}

	public void setBmcInactive(Boolean bmcInactive) {
		this.bmcInactive = bmcInactive;
	}

	public String getBmcIncConsoleDetailLink() {
		return bmcIncConsoleDetailLink;
	}

	public void setBmcIncConsoleDetailLink(String bmcIncConsoleDetailLink) {
		this.bmcIncConsoleDetailLink = bmcIncConsoleDetailLink;
	}

	public String getBmcIncidentDescription() {
		return bmcIncidentDescription;
	}

	public void setBmcIncidentDescription(String bmcIncidentDescription) {
		this.bmcIncidentDescription = bmcIncidentDescription;
	}

	public String getBmcIncidentResolution() {
		return bmcIncidentResolution;
	}

	public void setBmcIncidentResolution(String bmcIncidentResolution) {
		this.bmcIncidentResolution = bmcIncidentResolution;
	}

	public String getBmcMaximumDuration() {
		return bmcMaximumDuration;
	}

	public void setBmcMaximumDuration(String bmcMaximumDuration) {
		this.bmcMaximumDuration = bmcMaximumDuration;
	}

	public String getBmcNote() {
		return bmcNote;
	}

	public void setBmcNote(String bmcNote) {
		this.bmcNote = bmcNote;
	}

	public String getBmcOpenDateTime() {
		return bmcOpenDateTime;
	}

	public void setBmcOpenDateTime(String bmcOpenDateTime) {
		this.bmcOpenDateTime = bmcOpenDateTime;
	}

	public String getBmcOutageFrom() {
		return bmcOutageFrom;
	}

	public void setBmcOutageFrom(String bmcOutageFrom) {
		this.bmcOutageFrom = bmcOutageFrom;
	}

	public String getBmcOutageTo() {
		return bmcOutageTo;
	}

	public void setBmcOutageTo(String bmcOutageTo) {
		this.bmcOutageTo = bmcOutageTo;
	}

	public String getBmcQueueName() {
		return bmcQueueName;
	}

	public void setBmcQueueName(String bmcQueueName) {
		this.bmcQueueName = bmcQueueName;
	}

	public String getBmcRecommendedFixDateTime() {
		return bmcRecommendedFixDateTime;
	}

	public void setBmcRecommendedFixDateTime(String bmcRecommendedFixDateTime) {
		this.bmcRecommendedFixDateTime = bmcRecommendedFixDateTime;
	}

	public String getBmcRespondedDateTime() {
		return bmcRespondedDateTime;
	}

	public void setBmcRespondedDateTime(String bmcRespondedDateTime) {
		this.bmcRespondedDateTime = bmcRespondedDateTime;
	}

	public String getBmcResponseDateTime() {
		return bmcResponseDateTime;
	}

	public void setBmcResponseDateTime(String bmcResponseDateTime) {
		this.bmcResponseDateTime = bmcResponseDateTime;
	}

	public String getBmcShortDescription() {
		return bmcShortDescription;
	}

	public void setBmcShortDescription(String bmcShortDescription) {
		this.bmcShortDescription = bmcShortDescription;
	}

	public Boolean getBmcState() {
		return bmcState;
	}

	public void setBmcState(Boolean bmcState) {
		this.bmcState = bmcState;
	}

	public String getBmcTimeSpent() {
		return bmcTimeSpent;
	}

	public void setBmcTimeSpent(String bmcTimeSpent) {
		this.bmcTimeSpent = bmcTimeSpent;
	}

	public Double getBmcTotalDuration() {
		return bmcTotalDuration;
	}

	public void setBmcTotalDuration(Double bmcTotalDuration) {
		this.bmcTotalDuration = bmcTotalDuration;
	}

	public Boolean getBmcIncorrectCategory() {
		return bmcIncorrectCategory;
	}

	public void setBmcIncorrectCategory(Boolean bmcIncorrectCategory) {
		this.bmcIncorrectCategory = bmcIncorrectCategory;
	}

	public Boolean getClientVIP() {
		return clientVIP;
	}

	public void setClientVIP(Boolean clientVIP) {
		this.clientVIP = clientVIP;
	}

	public Boolean getBmcIncorrectOwner() {
		return bmcIncorrectOwner;
	}

	public void setBmcIncorrectOwner(Boolean bmcIncorrectOwner) {
		this.bmcIncorrectOwner = bmcIncorrectOwner;
	}

	public String getBmcLockedRecordTimestamp() {
		return bmcLockedRecordTimestamp;
	}

	public void setBmcLockedRecordTimestamp(String bmcLockedRecordTimestamp) {
		this.bmcLockedRecordTimestamp = bmcLockedRecordTimestamp;
	}

	public String getBmcQueue() {
		return bmcQueue;
	}

	public void setBmcQueue(String bmcQueue) {
		this.bmcQueue = bmcQueue;
	}

	public Double getBmcReassignedCount() {
		return bmcReassignedCount;
	}

	public void setBmcReassignedCount(Double bmcReassignedCount) {
		this.bmcReassignedCount = bmcReassignedCount;
	}

	public Boolean getBmcIsServiceRequest() {
		return bmcIsServiceRequest;
	}

	public void setBmcIsServiceRequest(Boolean bmcIsServiceRequest) {
		this.bmcIsServiceRequest = bmcIsServiceRequest;
	}

	public String getEmployee() {
		return employee;
	}

	public void setEmployee(String employee) {
		this.employee = employee;
	}

	public String getAlternateContactName() {
		return alternateContactName;
	}

	public void setAlternateContactName(String alternateContactName) {
		this.alternateContactName = alternateContactName;
	}

	public String getAlternateContactNumber() {
		return alternateContactNumber;
	}

	public void setAlternateContactNumber(String alternateContactNumber) {
		this.alternateContactNumber = alternateContactNumber;
	}

	public String getExternalTicketRef() {
		return externalTicketRef;
	}

	public void setExternalTicketRef(String externalTicketRef) {
		this.externalTicketRef = externalTicketRef;
	}

	public String getAffectedApplication() {
		return affectedApplication;
	}

	public void setAffectedApplication(String affectedApplication) {
		this.affectedApplication = affectedApplication;
	}

	public String getAffectedHardware() {
		return affectedHardware;
	}

	public void setAffectedHardware(String affectedHardware) {
		this.affectedHardware = affectedHardware;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getParentCategoryTree() {
		return parentCategoryTree;
	}

	public void setParentCategoryTree(String parentCategoryTree) {
		this.parentCategoryTree = parentCategoryTree;
	}

	public String getCategoryActionState() {
		return categoryActionState;
	}

	public void setCategoryActionState(String categoryActionState) {
		this.categoryActionState = categoryActionState;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getHrConfidential() {
		return hrConfidential;
	}

	public void setHrConfidential(String hrConfidential) {
		this.hrConfidential = hrConfidential;
	}

	public String getCustomerPracticeShortname() {
		return customerPracticeShortname;
	}

	public void setCustomerPracticeShortname(String customerPracticeShortname) {
		this.customerPracticeShortname = customerPracticeShortname;
	}

	public String getCustomerRegion() {
		return customerRegion;
	}

	public void setCustomerRegion(String customerRegion) {
		this.customerRegion = customerRegion;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getsAMAccountName() {
		return sAMAccountName;
	}

	public void setsAMAccountName(String sAMAccountName) {
		this.sAMAccountName = sAMAccountName;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getClientState() {
		return clientState;
	}

	public void setClientState(String clientState) {
		this.clientState = clientState;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getCustomerManager() {
		return customerManager;
	}

	public void setCustomerManager(String customerManager) {
		this.customerManager = customerManager;
	}

	public String getMiddleInitial() {
		return middleInitial;
	}

	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}

	public String getQuickDescription() {
		return quickDescription;
	}

	public void setQuickDescription(String quickDescription) {
		this.quickDescription = quickDescription;
	}

	
	

}