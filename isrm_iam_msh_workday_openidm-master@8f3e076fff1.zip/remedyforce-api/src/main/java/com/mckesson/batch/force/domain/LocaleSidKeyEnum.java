package com.mckesson.batch.force.domain;

/**
 * Java model for the LocaleSidKey picklist.
 *
 * This enum was auto-generated. It is considered owned
 * by the Force.com database.
 **/

public enum LocaleSidKeyEnum  {

    SQ_AL(true,false,"Albanian (Albania)","sq_AL"),
    AR_BH(true,false,"Arabic (Bahrain)","ar_BH"),
    AR_EG(true,false,"Arabic (Egypt)","ar_EG"),
    AR_JO(true,false,"Arabic (Jordan)","ar_JO"),
    AR_KW(true,false,"Arabic (Kuwait)","ar_KW"),
    AR_LB(true,false,"Arabic (Lebanon)","ar_LB"),
    AR_QA(true,false,"Arabic (Qatar)","ar_QA"),
    AR_SA(true,false,"Arabic (Saudi Arabia)","ar_SA"),
    AR_AE(true,false,"Arabic (United Arab Emirates)","ar_AE"),
    HY_AM(true,false,"Armenian (Armenia)","hy_AM"),
    AZ_AZ(true,false,"Azerbaijani (Azerbaijan)","az_AZ"),
    EU_ES(true,false,"Basque (Spain)","eu_ES"),
    BE_BY(true,false,"Belarusian (Belarus)","be_BY"),
    BN_BD(true,false,"Bengali (Bangladesh)","bn_BD"),
    BS_BA(true,false,"Bosnian (Bosnia & Herzegovina)","bs_BA"),
    BG_BG(true,false,"Bulgarian (Bulgaria)","bg_BG"),
    CA_ES(true,false,"Catalan (Spain)","ca_ES"),
    ZH_CN(true,false,"Chinese (China)","zh_CN"),
    ZH_HK(true,false,"Chinese (Hong Kong SAR China)","zh_HK"),
    ZH_MO(true,false,"Chinese (Macau SAR China)","zh_MO"),
    ZH_SG(true,false,"Chinese (Singapore)","zh_SG"),
    ZH_TW(true,false,"Chinese (Taiwan)","zh_TW"),
    HR_HR(true,false,"Croatian (Croatia)","hr_HR"),
    CS_CZ(true,false,"Czech (Czech Republic)","cs_CZ"),
    DA_DK(true,false,"Danish (Denmark)","da_DK"),
    NL_BE(true,false,"Dutch (Belgium)","nl_BE"),
    NL_NL(true,false,"Dutch (Netherlands)","nl_NL"),
    NL_SR(true,false,"Dutch (Suriname)","nl_SR"),
    EN_AU(true,false,"English (Australia)","en_AU"),
    EN_BB(true,false,"English (Barbados)","en_BB"),
    EN_BM(true,false,"English (Bermuda)","en_BM"),
    EN_CA(true,false,"English (Canada)","en_CA"),
    EN_GH(true,false,"English (Ghana)","en_GH"),
    EN_IN(true,false,"English (India)","en_IN"),
    EN_ID(true,false,"English (Indonesia)","en_ID"),
    EN_IE(true,false,"English (Ireland)","en_IE"),
    EN_MY(true,false,"English (Malaysia)","en_MY"),
    EN_NZ(true,false,"English (New Zealand)","en_NZ"),
    EN_NG(true,false,"English (Nigeria)","en_NG"),
    EN_PK(true,false,"English (Pakistan)","en_PK"),
    EN_PH(true,false,"English (Philippines)","en_PH"),
    EN_SG(true,false,"English (Singapore)","en_SG"),
    EN_ZA(true,false,"English (South Africa)","en_ZA"),
    EN_GB(true,false,"English (United Kingdom)","en_GB"),
    EN_US(true,false,"English (United States)","en_US"),
    ET_EE(true,false,"Estonian (Estonia)","et_EE"),
    FI_FI(true,false,"Finnish (Finland)","fi_FI"),
    FR_BE(true,false,"French (Belgium)","fr_BE"),
    FR_CA(true,false,"French (Canada)","fr_CA"),
    FR_FR(true,false,"French (France)","fr_FR"),
    FR_LU(true,false,"French (Luxembourg)","fr_LU"),
    FR_MC(true,false,"French (Monaco)","fr_MC"),
    FR_CH(true,false,"French (Switzerland)","fr_CH"),
    KA_GE(true,false,"Georgian (Georgia)","ka_GE"),
    DE_AT(true,false,"German (Austria)","de_AT"),
    DE_DE(true,false,"German (Germany)","de_DE"),
    DE_LU(true,false,"German (Luxembourg)","de_LU"),
    DE_CH(true,false,"German (Switzerland)","de_CH"),
    EL_GR(true,false,"Greek (Greece)","el_GR"),
    IW_IL(true,false,"Hebrew (Israel)","iw_IL"),
    HI_IN(true,false,"Hindi (India)","hi_IN"),
    IS_IS(true,false,"Icelandic (Iceland)","is_IS"),
    GA_IE(true,false,"Irish (Ireland)","ga_IE"),
    IT_IT(true,false,"Italian (Italy)","it_IT"),
    IT_CH(true,false,"Italian (Switzerland)","it_CH"),
    JA_JP(true,false,"Japanese (Japan)","ja_JP"),
    KK_KZ(true,false,"Kazakh (Kazakhstan)","kk_KZ"),
    KM_KH(true,false,"Khmer (Cambodia)","km_KH"),
    KO_KR(true,false,"Korean (South Korea)","ko_KR"),
    KY_KG(true,false,"Kyrgyz (Kyrgyzstan)","ky_KG"),
    LV_LV(true,false,"Latvian (Latvia)","lv_LV"),
    LT_LT(true,false,"Lithuanian (Lithuania)","lt_LT"),
    MK_MK(true,false,"Macedonian (Macedonia)","mk_MK"),
    MS_BN(true,false,"Malay (Brunei)","ms_BN"),
    MS_MY(true,false,"Malay (Malaysia)","ms_MY"),
    MT_MT(true,false,"Maltese (Malta)","mt_MT"),
    SH_ME(true,false,"Montenegrin (Montenegro)","sh_ME"),
    NO_NO(true,false,"Norwegian (Norway)","no_NO"),
    PT_AO(true,false,"Portuguese (Angola)","pt_AO"),
    PT_BR(true,false,"Portuguese (Brazil)","pt_BR"),
    PT_PT(true,false,"Portuguese (Portugal)","pt_PT"),
    RO_MD(true,false,"Romanian (Moldova)","ro_MD"),
    RO_RO(true,false,"Romanian (Romania)","ro_RO"),
    RU_RU(true,false,"Russian (Russia)","ru_RU"),
    SR_BA(true,false,"Serbian (Bosnia & Herzegovina)","sr_BA"),
    SH_BA(true,false,"Serbian (Latin) (Bosnia and Herzegovina)","sh_BA"),
    SH_CS(true,false,"Serbian (Latin) (Serbia)","sh_CS"),
    SR_CS(true,false,"Serbian (Serbia)","sr_CS"),
    SK_SK(true,false,"Slovak (Slovakia)","sk_SK"),
    SL_SI(true,false,"Slovenian (Slovenia)","sl_SI"),
    ES_AR(true,false,"Spanish (Argentina)","es_AR"),
    ES_BO(true,false,"Spanish (Bolivia)","es_BO"),
    ES_CL(true,false,"Spanish (Chile)","es_CL"),
    ES_CO(true,false,"Spanish (Colombia)","es_CO"),
    ES_CR(true,false,"Spanish (Costa Rica)","es_CR"),
    ES_DO(true,false,"Spanish (Dominican Republic)","es_DO"),
    ES_EC(true,false,"Spanish (Ecuador)","es_EC"),
    ES_SV(true,false,"Spanish (El Salvador)","es_SV"),
    ES_GT(true,false,"Spanish (Guatemala)","es_GT"),
    ES_HN(true,false,"Spanish (Honduras)","es_HN"),
    ES_MX(true,false,"Spanish (Mexico)","es_MX"),
    ES_PA(true,false,"Spanish (Panama)","es_PA"),
    ES_PY(true,false,"Spanish (Paraguay)","es_PY"),
    ES_PE(true,false,"Spanish (Peru)","es_PE"),
    ES_PR(true,false,"Spanish (Puerto Rico)","es_PR"),
    ES_ES(true,false,"Spanish (Spain)","es_ES"),
    ES_UY(true,false,"Spanish (Uruguay)","es_UY"),
    ES_VE(true,false,"Spanish (Venezuela)","es_VE"),
    SV_SE(true,false,"Swedish (Sweden)","sv_SE"),
    TL_PH(true,false,"Tagalog (Philippines)","tl_PH"),
    TG_TJ(true,false,"Tajik (Tajikistan)","tg_TJ"),
    TH_TH(true,false,"Thai (Thailand)","th_TH"),
    UK_UA(true,false,"Ukrainian (Ukraine)","uk_UA"),
    UR_PK(true,false,"Urdu (Pakistan)","ur_PK"),
    VI_VN(true,false,"Vietnamese (Vietnam)","vi_VN"),
    CY_GB(true,false,"Welsh (United Kingdom)","cy_GB"),
    ;

    private boolean isActive;
    private boolean isDefaultValue;
    private String label;
    private String value;

    private LocaleSidKeyEnum(boolean isActive, boolean isDefaultValue, String label, String value) {
        this.isActive = isActive;
        this.isDefaultValue = isDefaultValue;
        this.label = label;
        this.value = value;
    }

    
    public boolean isActive() { return this.isActive; }

    
    public boolean isDefaultValue() { return this.isDefaultValue; }

    
    public String label() { return this.label; }

    
    public String value() { return this.value; }

    public static LocaleSidKeyEnum fromValue(String value) {
        if (value == null) return null;

        for (LocaleSidKeyEnum picklistValueEnum : values()) {
            if (value.equals(picklistValueEnum.value())) {
                return picklistValueEnum;
            }
        }

        return null;
    }
}


