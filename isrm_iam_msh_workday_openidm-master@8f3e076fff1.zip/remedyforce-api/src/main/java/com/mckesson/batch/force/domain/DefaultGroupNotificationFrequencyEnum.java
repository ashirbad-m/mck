package com.mckesson.batch.force.domain;

/**
 * Java model for the LocaleSidKey picklist.
 *
 * This enum was auto-generated. It is considered owned
 * by the Force.com database.
 **/

public enum DefaultGroupNotificationFrequencyEnum  {

    P("Email on Each Post","P"),
    D("Daily Digests","D"),
    W("Weekly Digests","W"),
    N("Never","N");

    private String label;
    private String value;

    private DefaultGroupNotificationFrequencyEnum(String label, String value) {
        this.label = label;
        this.value = value;
    }

    
   public String label() { return this.label; }

    
    public String value() { return this.value; }

    public static DefaultGroupNotificationFrequencyEnum fromValue(String value) {
        if (value == null) return null;

        for (DefaultGroupNotificationFrequencyEnum picklistValueEnum : values()) {
            if (value.equals(picklistValueEnum.value())) {
                return picklistValueEnum;
            }
        }

        return null;
    }
}


