package com.mckesson.batch.force.domain;

public enum TimeZoneSidKeyEnum  {

    PACIFIC_KIRITIMATI(true,false,"(GMT+14:00) Line Is. Time (Pacific/Kiritimati)","Pacific/Kiritimati"),
    PACIFIC_CHATHAM(true,false,"(GMT+13:45) Chatham Daylight Time (Pacific/Chatham)","Pacific/Chatham"),
    PACIFIC_AUCKLAND(true,false,"(GMT+13:00) New Zealand Daylight Time (Pacific/Auckland)","Pacific/Auckland"),
    PACIFIC_ENDERBURY(true,false,"(GMT+13:00) Phoenix Is. Time (Pacific/Enderbury)","Pacific/Enderbury"),
    PACIFIC_FIJI(true,false,"(GMT+13:00) Fiji Summer Time (Pacific/Fiji)","Pacific/Fiji"),
    PACIFIC_TONGATAPU(true,false,"(GMT+13:00) Tonga Time (Pacific/Tongatapu)","Pacific/Tongatapu"),
    ASIA_KAMCHATKA(true,false,"(GMT+12:00) Petropavlovsk-Kamchatski Time (Asia/Kamchatka)","Asia/Kamchatka"),
    AUSTRALIA_LORD_HOWE(true,false,"(GMT+11:00) Lord Howe Daylight Time (Australia/Lord_Howe)","Australia/Lord_Howe"),
    AUSTRALIA_SYDNEY(true,false,"(GMT+11:00) Australian Eastern Daylight Time (New South Wales) (Australia/Sydney)","Australia/Sydney"),
    PACIFIC_GUADALCANAL(true,false,"(GMT+11:00) Solomon Is. Time (Pacific/Guadalcanal)","Pacific/Guadalcanal"),
    PACIFIC_NORFOLK(true,false,"(GMT+11:00) Norfolk Time (Pacific/Norfolk)","Pacific/Norfolk"),
    AUSTRALIA_ADELAIDE(true,false,"(GMT+10:30) Australian Central Daylight Time (South Australia) (Australia/Adelaide)","Australia/Adelaide"),
    AUSTRALIA_BRISBANE(true,false,"(GMT+10:00) Australian Eastern Standard Time (Queensland) (Australia/Brisbane)","Australia/Brisbane"),
    AUSTRALIA_DARWIN(true,false,"(GMT+09:30) Australian Central Standard Time (Northern Territory) (Australia/Darwin)","Australia/Darwin"),
    ASIA_SEOUL(true,false,"(GMT+09:00) Korea Standard Time (Asia/Seoul)","Asia/Seoul"),
    ASIA_TOKYO(true,false,"(GMT+09:00) Japan Standard Time (Asia/Tokyo)","Asia/Tokyo"),
    ASIA_HONG_KONG(true,false,"(GMT+08:00) Hong Kong Time (Asia/Hong_Kong)","Asia/Hong_Kong"),
    ASIA_KUALA_LUMPUR(true,false,"(GMT+08:00) Malaysia Time (Asia/Kuala_Lumpur)","Asia/Kuala_Lumpur"),
    ASIA_MANILA(true,false,"(GMT+08:00) Philippines Time (Asia/Manila)","Asia/Manila"),
    ASIA_SHANGHAI(true,false,"(GMT+08:00) China Standard Time (Asia/Shanghai)","Asia/Shanghai"),
    ASIA_SINGAPORE(true,false,"(GMT+08:00) Singapore Time (Asia/Singapore)","Asia/Singapore"),
    ASIA_TAIPEI(true,false,"(GMT+08:00) China Standard Time (Asia/Taipei)","Asia/Taipei"),
    AUSTRALIA_PERTH(true,false,"(GMT+08:00) Australian Western Standard Time (Australia/Perth)","Australia/Perth"),
    ASIA_BANGKOK(true,false,"(GMT+07:00) Indochina Time (Asia/Bangkok)","Asia/Bangkok"),
    ASIA_HO_CHI_MINH(true,false,"(GMT+07:00) Indochina Time (Asia/Ho_Chi_Minh)","Asia/Ho_Chi_Minh"),
    ASIA_JAKARTA(true,false,"(GMT+07:00) West Indonesia Time (Asia/Jakarta)","Asia/Jakarta"),
    ASIA_RANGOON(true,false,"(GMT+06:30) Myanmar Time (Asia/Rangoon)","Asia/Rangoon"),
    ASIA_DHAKA(true,false,"(GMT+06:00) Bangladesh Time (Asia/Dhaka)","Asia/Dhaka"),
    ASIA_KATHMANDU(true,false,"(GMT+05:45) Nepal Time (Asia/Kathmandu)","Asia/Kathmandu"),
    ASIA_COLOMBO(true,false,"(GMT+05:30) India Standard Time (Asia/Colombo)","Asia/Colombo"),
    ASIA_KOLKATA(true,false,"(GMT+05:30) India Standard Time (Asia/Kolkata)","Asia/Kolkata"),
    ASIA_KARACHI(true,false,"(GMT+05:00) Pakistan Time (Asia/Karachi)","Asia/Karachi"),
    ASIA_TASHKENT(true,false,"(GMT+05:00) Uzbekistan Time (Asia/Tashkent)","Asia/Tashkent"),
    ASIA_YEKATERINBURG(true,false,"(GMT+05:00) Yekaterinburg Time (Asia/Yekaterinburg)","Asia/Yekaterinburg"),
    ASIA_KABUL(true,false,"(GMT+04:30) Afghanistan Time (Asia/Kabul)","Asia/Kabul"),
    ASIA_DUBAI(true,false,"(GMT+04:00) Gulf Standard Time (Asia/Dubai)","Asia/Dubai"),
    ASIA_TBILISI(true,false,"(GMT+04:00) Georgia Time (Asia/Tbilisi)","Asia/Tbilisi"),
    ASIA_TEHRAN(true,false,"(GMT+03:30) Iran Standard Time (Asia/Tehran)","Asia/Tehran"),
    AFRICA_NAIROBI(true,false,"(GMT+03:00) Eastern African Time (Africa/Nairobi)","Africa/Nairobi"),
    ASIA_BAGHDAD(true,false,"(GMT+03:00) Arabia Standard Time (Asia/Baghdad)","Asia/Baghdad"),
    ASIA_KUWAIT(true,false,"(GMT+03:00) Arabia Standard Time (Asia/Kuwait)","Asia/Kuwait"),
    ASIA_RIYADH(true,false,"(GMT+03:00) Arabia Standard Time (Asia/Riyadh)","Asia/Riyadh"),
    EUROPE_MINSK(true,false,"(GMT+03:00) Moscow Standard Time (Europe/Minsk)","Europe/Minsk"),
    EUROPE_MOSCOW(true,false,"(GMT+03:00) Moscow Standard Time (Europe/Moscow)","Europe/Moscow"),
    AFRICA_CAIRO(true,false,"(GMT+02:00) Eastern European Time (Africa/Cairo)","Africa/Cairo"),
    AFRICA_JOHANNESBURG(true,false,"(GMT+02:00) South Africa Standard Time (Africa/Johannesburg)","Africa/Johannesburg"),
    ASIA_JERUSALEM(true,false,"(GMT+02:00) Israel Standard Time (Asia/Jerusalem)","Asia/Jerusalem"),
    EUROPE_ATHENS(true,false,"(GMT+02:00) Eastern European Time (Europe/Athens)","Europe/Athens"),
    EUROPE_BUCHAREST(true,false,"(GMT+02:00) Eastern European Time (Europe/Bucharest)","Europe/Bucharest"),
    EUROPE_HELSINKI(true,false,"(GMT+02:00) Eastern European Time (Europe/Helsinki)","Europe/Helsinki"),
    EUROPE_ISTANBUL(true,false,"(GMT+02:00) Eastern European Time (Europe/Istanbul)","Europe/Istanbul"),
    AFRICA_ALGIERS(true,false,"(GMT+01:00) Central European Time (Africa/Algiers)","Africa/Algiers"),
    EUROPE_AMSTERDAM(true,false,"(GMT+01:00) Central European Time (Europe/Amsterdam)","Europe/Amsterdam"),
    EUROPE_BERLIN(true,false,"(GMT+01:00) Central European Time (Europe/Berlin)","Europe/Berlin"),
    EUROPE_BRUSSELS(true,false,"(GMT+01:00) Central European Time (Europe/Brussels)","Europe/Brussels"),
    EUROPE_PARIS(true,false,"(GMT+01:00) Central European Time (Europe/Paris)","Europe/Paris"),
    EUROPE_PRAGUE(true,false,"(GMT+01:00) Central European Time (Europe/Prague)","Europe/Prague"),
    EUROPE_ROME(true,false,"(GMT+01:00) Central European Time (Europe/Rome)","Europe/Rome"),
    EUROPE_DUBLIN(true,false,"(GMT+00:00) Greenwich Mean Time (Europe/Dublin)","Europe/Dublin"),
    EUROPE_LISBON(true,false,"(GMT+00:00) Western European Time (Europe/Lisbon)","Europe/Lisbon"),
    EUROPE_LONDON(true,false,"(GMT+00:00) Greenwich Mean Time (Europe/London)","Europe/London"),
    GMT(true,false,"(GMT+00:00) Greenwich Mean Time (GMT)","GMT"),
    ATLANTIC_CAPE_VERDE(true,false,"(GMT-01:00) Cape Verde Time (Atlantic/Cape_Verde)","Atlantic/Cape_Verde"),
    AMERICA_SAO_PAULO(true,false,"(GMT-02:00) Brasilia Summer Time (America/Sao_Paulo)","America/Sao_Paulo"),
    ATLANTIC_SOUTH_GEORGIA(true,false,"(GMT-02:00) South Georgia Standard Time (Atlantic/South_Georgia)","Atlantic/South_Georgia"),
    AMERICA_ARGENTINA_BUENOS_AIRES(true,false,"(GMT-03:00) Argentine Time (America/Argentina/Buenos_Aires)","America/Argentina/Buenos_Aires"),
    AMERICA_SANTIAGO(true,false,"(GMT-03:00) Chile Time (America/Santiago)","America/Santiago"),
    AMERICA_ST_JOHNS(true,false,"(GMT-03:30) Newfoundland Standard Time (America/St_Johns)","America/St_Johns"),
    AMERICA_HALIFAX(true,false,"(GMT-04:00) Atlantic Standard Time (America/Halifax)","America/Halifax"),
    AMERICA_PUERTO_RICO(true,false,"(GMT-04:00) Atlantic Standard Time (America/Puerto_Rico)","America/Puerto_Rico"),
    ATLANTIC_BERMUDA(true,false,"(GMT-04:00) Atlantic Standard Time (Atlantic/Bermuda)","Atlantic/Bermuda"),
    AMERICA_CARACAS(true,false,"(GMT-04:30) Venezuela Time (America/Caracas)","America/Caracas"),
    AMERICA_BOGOTA(true,false,"(GMT-05:00) Colombia Time (America/Bogota)","America/Bogota"),
    AMERICA_INDIANA_INDIANAPOLIS(true,false,"(GMT-05:00) Eastern Standard Time (America/Indiana/Indianapolis)","America/Indiana/Indianapolis"),
    AMERICA_LIMA(true,false,"(GMT-05:00) Peru Time (America/Lima)","America/Lima"),
    AMERICA_NEW_YORK(true,false,"(GMT-05:00) Eastern Standard Time (America/New_York)","America/New_York"),
    AMERICA_PANAMA(true,false,"(GMT-05:00) Eastern Standard Time (America/Panama)","America/Panama"),
    AMERICA_CHICAGO(true,false,"(GMT-06:00) Central Standard Time (America/Chicago)","America/Chicago"),
    AMERICA_EL_SALVADOR(true,false,"(GMT-06:00) Central Standard Time (America/El_Salvador)","America/El_Salvador"),
    AMERICA_MEXICO_CITY(true,false,"(GMT-06:00) Central Standard Time (America/Mexico_City)","America/Mexico_City"),
    AMERICA_DENVER(true,false,"(GMT-07:00) Mountain Standard Time (America/Denver)","America/Denver"),
    AMERICA_PHOENIX(true,false,"(GMT-07:00) Mountain Standard Time (America/Phoenix)","America/Phoenix"),
    AMERICA_LOS_ANGELES(true,false,"(GMT-08:00) Pacific Standard Time (America/Los_Angeles)","America/Los_Angeles"),
    AMERICA_TIJUANA(true,false,"(GMT-08:00) Pacific Standard Time (America/Tijuana)","America/Tijuana"),
    AMERICA_ANCHORAGE(true,false,"(GMT-09:00) Alaska Standard Time (America/Anchorage)","America/Anchorage"),
    PACIFIC_HONOLULU(true,false,"(GMT-10:00) Hawaii-Aleutian Standard Time (Pacific/Honolulu)","Pacific/Honolulu"),
    PACIFIC_NIUE(true,false,"(GMT-11:00) Niue Time (Pacific/Niue)","Pacific/Niue"),
    PACIFIC_PAGO_PAGO(true,false,"(GMT-11:00) Samoa Standard Time (Pacific/Pago_Pago)","Pacific/Pago_Pago"),
    ;

    private boolean isActive;
    private boolean isDefaultValue;
    private String label;
    private String value;

    private TimeZoneSidKeyEnum(boolean isActive, boolean isDefaultValue, String label, String value) {
        this.isActive = isActive;
        this.isDefaultValue = isDefaultValue;
        this.label = label;
        this.value = value;
    }

    
    public boolean isActive() { return this.isActive; }

    
    public boolean isDefaultValue() { return this.isDefaultValue; }

    
    public String label() { return this.label; }

    
    public String value() { return this.value; }

    public static TimeZoneSidKeyEnum fromValue(String value) {
        if (value == null) return null;

        for (TimeZoneSidKeyEnum picklistValueEnum : values()) {
            if (value.equals(picklistValueEnum.value())) {
                return picklistValueEnum;
            }
        }

        return null;
    }
    
}

