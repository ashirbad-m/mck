package com.mckesson.batch.force;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IncidentResponse {

	@JsonProperty("Success")
	private boolean success;

	@JsonProperty("Result")
	private IncidentData incidentData = new IncidentData();

	@JsonProperty("ErrorMessage")
	private String errorMessage;

	@JsonProperty("ErrorCode")
	private String errorCode;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public IncidentData getIncidentData() {
		return incidentData;
	}

	public void setIncidentData(IncidentData incidentData) {
		this.incidentData = incidentData;
	}
}
