
package com.mckesson.batch.force.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Java model for the Force.com User object.
 *
 **/
@JsonIgnoreProperties(ignoreUnknown = true)
public class User {

    @JsonProperty(value = "Id")
    protected String id;

    @JsonProperty(value = "LastModifiedDate")
    protected java.util.Calendar lastModifiedDate;

    @JsonProperty(value = "Username")
    protected String userName;

    @JsonProperty(value = "Alias")
    protected String alias;

    @JsonProperty(value = "Name")
    protected String name;

    @JsonProperty(value = "FirstName")
    protected String firstName;

    @JsonProperty(value = "LastName")
    protected String lastName;

    @JsonProperty(value = "Email")
    protected String email;

/* TODO Comment
 * We have issue with this properties 
    @JsonProperty(value = "Enterprise_Email__c")
    protected String enterpriseEmail;
*/
    @JsonProperty(value = "SAM_Account_Name__c")
    protected String samAccountName;

    @JsonProperty(value = "Title")
    protected String title;

    @JsonProperty(value = "FederationIdentifier")
    protected String federationIdentifier;

    @JsonProperty(value = "Phone")
    protected String phone;

    @JsonProperty(value = "MobilePhone")
    protected String mobilePhone;

    @JsonProperty(value = "CompanyName")
    protected String companyName;

    @JsonProperty(value = "Division")
    protected String division;

    @JsonProperty(value = "Department")
    protected String department;

    @JsonProperty(value = "Street")
    protected String street;

    @JsonProperty(value = "City")
    protected String city;

    @JsonProperty(value = "State")
    protected String state;

    @JsonProperty(value = "PostalCode")
    protected String postalCode;

    @JsonProperty(value = "Country")
    protected String country;

    @JsonProperty(value = "Fax")
    protected String fax;

    @JsonProperty(value = "ManagerId")
    protected String managerId;

    @JsonProperty(value = "AccountId")
    protected String accountId;

    @JsonProperty(value = "IsActive")
    protected Boolean isActive;

    @JsonProperty(value = "TimeZoneSidKey")
    protected String timeZoneSidKey;

    @JsonProperty(value = "LocaleSidKey")
    protected String localeSidKey;

    @JsonProperty(value = "EmailEncodingKey")
    protected String emailEncodingKey;

    @JsonProperty(value = "LanguageLocaleKey")
    protected String languageLocaleKey;

    @JsonProperty(value = "ProfileId")
    protected String profileId;

    @JsonProperty(value = "UserRoleId")
    protected String userRoleId;

/* TODO Comment
 * We have issue with this properties 
    @JsonProperty(value = "ContactId")
    protected String contactId;
*/
    
    @JsonProperty("BMCServiceDesk__ContactId__c")
    protected String bmcContactId;

    @JsonProperty(value = "BMCServiceDesk__Account_Name__c")
    protected String bmcAccountName;

    @JsonProperty(value = "BMCServiceDesk__Account_ID__c")
    protected String bmcAccountId;

    @JsonProperty(value = "Practice_ShortName__c")
    protected String practiceShortname;

    @JsonProperty(value = "Region__c")
    protected String region;

    @JsonProperty(value = "SiteName__c")
    protected String siteName;

    @JsonProperty(value = "BMCServiceDesk__IsStaffUser__c")
    protected Boolean serviceDeskStaff;

    @JsonProperty(value = "BMCServiceDesk__Remedyforce_Knowledge_User__c")
    protected Boolean knowledgeUser;

    @JsonProperty(value = "BMCServiceDesk__Manage_QV__c")
    protected Boolean manageQV;

    @JsonProperty(value = "UserPermissionsMarketingUser")
    protected Boolean marketingUser;

    @JsonProperty(value = "UserPermissionsSupportUser")
    protected Boolean serviceCloudUser;

    @JsonProperty(value = "EmailPreferencesAutoBcc")
    protected Boolean emailPreferencesAutoBcc;

    @JsonProperty(value = "EmailPreferencesAutoBccStayInTouch")
    protected Boolean emailPreferencesAutoBccStayInTouch;

    @JsonProperty(value = "EmailPreferencesStayInTouchReminder")
    protected Boolean emailPreferencesStayInTouchReminder;

    @JsonProperty(value = "ReceivesInfoEmails")
    protected Boolean receivesInfoEmails;

    @JsonProperty(value = "ReceivesAdminInfoEmails")
    protected Boolean receivesAdminInfoEmails;

    @JsonProperty(value = "UserPreferencesActivityRemindersPopup")
    protected Boolean userPreferencesActivityRemindersPopup;

    @JsonProperty(value = "UserPreferencesEventRemindersCheckboxDefault")
    protected Boolean userPreferencesEventRemindersCheckboxDefault;

    @JsonProperty(value = "UserPreferencesTaskRemindersCheckboxDefault")
    protected Boolean userPreferencesTaskRemindersCheckboxDefault;

    @JsonProperty(value = "UserPreferencesDisableAllFeedsEmail")
    protected Boolean userPreferencesDisableAllFeedsEmail;

    @JsonProperty(value = "UserPreferencesDisableFollowersEmail")
    protected Boolean userPreferencesDisableFollowersEmail;

    @JsonProperty(value = "UserPreferencesDisableProfilePostEmail")
    protected Boolean userPreferencesDisableProfilePostEmail;

    @JsonProperty(value = "UserPreferencesDisableChangeCommentEmail")
    protected Boolean userPreferencesDisableChangeCommentEmail;

    @JsonProperty(value = "UserPreferencesDisableLaterCommentEmail")
    protected Boolean userPreferencesDisableLaterCommentEmail;

    @JsonProperty(value = "UserPreferencesDisProfPostCommentEmail")
    protected Boolean userPreferencesDisProfPostCommentEmail;

    @JsonProperty(value = "UserPreferencesContentNoEmail")
    protected Boolean userPreferencesContentNoEmail;

    @JsonProperty(value = "UserPreferencesContentEmailAsAndWhen")
    protected Boolean userPreferencesContentEmailAsAndWhen;

    @JsonProperty(value = "UserPreferencesHideCSNGetChatterMobileTask")
    protected Boolean userPreferencesHideCSNGetChatterMobileTask;

    @JsonProperty(value = "UserPreferencesDisableMentionsPostEmail")
    protected Boolean userPreferencesDisableMentionsPostEmail;

    @JsonProperty(value = "UserPreferencesDisMentionsCommentEmail")
    protected Boolean userPreferencesDisMentionsCommentEmail;

    @JsonProperty(value = "UserPreferencesHideCSNDesktopTask")
    protected Boolean userPreferencesHideCSNDesktopTask;

    @JsonProperty(value = "UserPreferencesHideChatterOnboardingSplash")
    protected Boolean userPreferencesHideChatterOnboardingSplash;

    @JsonProperty(value = "UserPreferencesHideSecondChatterOnboardingSplash")
    protected Boolean userPreferencesHideSecondChatterOnboardingSplash;

    @JsonProperty(value = "UserPreferencesDisCommentAfterLikeEmail")
    protected Boolean userPreferencesDisCommentAfterLikeEmail;

    @JsonProperty(value = "UserPreferencesDisableLikeEmail")
    protected Boolean userPreferencesDisableLikeEmail;

    @JsonProperty(value = "UserPreferencesDisableMessageEmail")
    protected Boolean userPreferencesDisableMessageEmail;

    @JsonProperty(value = "UserPreferencesDisableBookmarkEmail")
    protected Boolean userPreferencesDisableBookmarkEmail;

    @JsonProperty(value = "UserPreferencesDisableSharePostEmail")
    protected Boolean userPreferencesDisableSharePostEmail;

    @JsonProperty(value = "UserPreferencesEnableAutoSubForFeeds")
    protected Boolean userPreferencesEnableAutoSubForFeeds;

    @JsonProperty(value = "UserPreferencesDisableFileShareNotificationsForApi")
    protected Boolean userPreferencesDisableFileShareNotificationsForApi;

    @JsonProperty(value = "UserPreferencesHideS1BrowserUI")
    protected Boolean userPreferencesHideS1BrowserUI;

    @JsonProperty(value = "UserPreferencesDisableEndorsementEmail")
    protected Boolean userPreferencesDisableEndorsementEmail;

    @JsonProperty(value = "DefaultGroupNotificationFrequency")
    protected DefaultGroupNotificationFrequencyEnum defaultGroupNotificationFrequency;

    public void applyRequiredDefaults() {
	timeZoneSidKey = TimeZoneSidKeyEnum.AMERICA_CHICAGO.value();
	localeSidKey = LocaleSidKeyEnum.EN_US.value();
	emailEncodingKey = EmailEncodingKeyEnum.UTF_8.value();
	languageLocaleKey = LanguageLocaleKeyEnum.EN_US.value();
    }

    public void applyOnCreateDefaults() {
	applyRequiredDefaults();

	// emailSettings
	emailPreferencesAutoBcc = Boolean.FALSE;
	emailPreferencesAutoBccStayInTouch = Boolean.FALSE;
	emailPreferencesStayInTouchReminder = Boolean.FALSE;
	receivesInfoEmails = Boolean.FALSE;
	receivesAdminInfoEmails = Boolean.FALSE;
	userPreferencesActivityRemindersPopup = Boolean.FALSE;
	userPreferencesEventRemindersCheckboxDefault = Boolean.FALSE;
	userPreferencesTaskRemindersCheckboxDefault = Boolean.FALSE;
	userPreferencesDisableAllFeedsEmail = Boolean.TRUE;
	userPreferencesDisableFollowersEmail = Boolean.TRUE;
	userPreferencesDisableProfilePostEmail = Boolean.TRUE;
	userPreferencesDisableChangeCommentEmail = Boolean.TRUE;
	userPreferencesDisableLaterCommentEmail = Boolean.TRUE;
	userPreferencesDisProfPostCommentEmail = Boolean.TRUE;
	userPreferencesContentNoEmail = Boolean.TRUE;
	userPreferencesContentEmailAsAndWhen = Boolean.TRUE;
	userPreferencesHideCSNGetChatterMobileTask = Boolean.TRUE;
	userPreferencesDisableMentionsPostEmail = Boolean.TRUE;
	userPreferencesDisMentionsCommentEmail = Boolean.TRUE;
	userPreferencesHideCSNDesktopTask = Boolean.TRUE;
	userPreferencesHideChatterOnboardingSplash = Boolean.TRUE;
	userPreferencesHideSecondChatterOnboardingSplash = Boolean.TRUE;
	userPreferencesDisCommentAfterLikeEmail = Boolean.TRUE;
	userPreferencesDisableLikeEmail = Boolean.TRUE;
	userPreferencesDisableMessageEmail = Boolean.TRUE;
	userPreferencesDisableBookmarkEmail = Boolean.TRUE;
	userPreferencesDisableSharePostEmail = Boolean.TRUE;
	userPreferencesEnableAutoSubForFeeds = Boolean.FALSE;
	userPreferencesDisableFileShareNotificationsForApi = Boolean.TRUE;
	userPreferencesHideS1BrowserUI = Boolean.FALSE;
	userPreferencesDisableEndorsementEmail = Boolean.TRUE;
	defaultGroupNotificationFrequency = DefaultGroupNotificationFrequencyEnum.N;

    }

    public void applyOnUpdateDefaults() {
	// emailSettings
	emailPreferencesAutoBcc = Boolean.FALSE;
	emailPreferencesAutoBccStayInTouch = Boolean.FALSE;
	emailPreferencesStayInTouchReminder = Boolean.FALSE;
	receivesInfoEmails = Boolean.FALSE;
	receivesAdminInfoEmails = Boolean.FALSE;
	userPreferencesActivityRemindersPopup = Boolean.FALSE;
	userPreferencesEventRemindersCheckboxDefault = Boolean.FALSE;
	userPreferencesTaskRemindersCheckboxDefault = Boolean.FALSE;
	userPreferencesDisableAllFeedsEmail = Boolean.TRUE;
	userPreferencesDisableFollowersEmail = Boolean.TRUE;
	userPreferencesDisableProfilePostEmail = Boolean.TRUE;
	userPreferencesDisableChangeCommentEmail = Boolean.TRUE;
	userPreferencesDisableLaterCommentEmail = Boolean.TRUE;
	userPreferencesDisProfPostCommentEmail = Boolean.TRUE;
	userPreferencesContentNoEmail = Boolean.TRUE;
	userPreferencesContentEmailAsAndWhen = Boolean.TRUE;
	userPreferencesHideCSNGetChatterMobileTask = Boolean.TRUE;
	userPreferencesDisableMentionsPostEmail = Boolean.TRUE;
	userPreferencesDisMentionsCommentEmail = Boolean.TRUE;
	userPreferencesHideCSNDesktopTask = Boolean.TRUE;
	userPreferencesHideChatterOnboardingSplash = Boolean.TRUE;
	userPreferencesHideSecondChatterOnboardingSplash = Boolean.TRUE;
	userPreferencesDisCommentAfterLikeEmail = Boolean.TRUE;
	userPreferencesDisableLikeEmail = Boolean.TRUE;
	userPreferencesDisableMessageEmail = Boolean.TRUE;
	userPreferencesDisableBookmarkEmail = Boolean.TRUE;
	userPreferencesDisableSharePostEmail = Boolean.TRUE;
	userPreferencesEnableAutoSubForFeeds = Boolean.FALSE;
	userPreferencesDisableFileShareNotificationsForApi = Boolean.TRUE;
	userPreferencesHideS1BrowserUI = Boolean.FALSE;
	userPreferencesDisableEndorsementEmail = Boolean.TRUE;
	defaultGroupNotificationFrequency = DefaultGroupNotificationFrequencyEnum.N;

    }

    public String getUsername() {
	return this.userName;
    }

    public void setUsername(String userName) {
	this.userName = userName;
    }

    public String getFirstName() {
	return this.firstName;
    }

    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    public String getName() {
	return this.name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public String getLastName() {
	return lastName;
    }

    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    public String getEmail() {
	return email;
    }

    public void setEmail(String email) {
	this.email = email;
    }

    public String getTitle() {
	return title;
    }

    public void setTitle(String title) {
	this.title = title;
    }

    public String getFederationIdentifier() {
	return federationIdentifier;
    }

    public void setFederationIdentifier(String federationIdentifier) {
	this.federationIdentifier = federationIdentifier;
    }

    public String getPhone() {
	return phone;
    }

    public void setPhone(String phone) {
	this.phone = phone;
    }

    public String getMobilePhone() {
	return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
	this.mobilePhone = mobilePhone;
    }

    public String getCompanyName() {
	return companyName;
    }

    public void setCompanyName(String companyName) {
	this.companyName = companyName;
    }

    public String getDivision() {
	return division;
    }

    public void setDivision(String division) {
	this.division = division;
    }

    public String getDepartment() {
	return department;
    }

    public void setDepartment(String department) {
	this.department = department;
    }

    public String getStreet() {
	return street;
    }

    public void setStreet(String street) {
	this.street = street;
    }

    public String getCity() {
	return city;
    }

    public void setCity(String city) {
	this.city = city;
    }

    public String getState() {
	return state;
    }

    public void setState(String state) {
	this.state = state;
    }

    public String getPostalCode() {
	return postalCode;
    }

    public void setPostalCode(String postalCode) {
	this.postalCode = postalCode;
    }

    public String getCountry() {
	return country;
    }

    public void setCountry(String country) {
	this.country = country;
    }

    public String getFax() {
	return fax;
    }

    public void setFax(String fax) {
	this.fax = fax;
    }

    public String getManagerId() {
	return managerId;
    }

    public void setManagerId(String managerId) {
	this.managerId = managerId;
    }

    public String getAccountId() {
	return accountId;
    }

    public void setAccountId(String accountId) {
	this.accountId = accountId;
    }

    public java.util.Calendar getLastModifiedDate() {
	return lastModifiedDate;
    }

    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
	this.lastModifiedDate = lastModifiedDate;
    }

    public String getUserName() {
	return userName;
    }

    public void setUserName(String userName) {
	this.userName = userName;
    }

    public String getAlias() {
	return alias;
    }

    public void setAlias(String alias) {
	if (alias != null && alias.length() > 8) {
	    this.alias = alias.substring(0, 7);
	} else {
	    this.alias = alias;
	}

    }

    public String getProfileId() {
	return profileId;
    }

    public void setProfileId(String profileId) {
	this.profileId = profileId;
    }

    public String getBmcAccountName() {
	return bmcAccountName;
    }

    public void setBmcAccountName(String bmcAccountName) {
	this.bmcAccountName = bmcAccountName;
    }

    public String getBmcAccountId() {
	return bmcAccountId;
    }

    public void setBmcAccountId(String bmcAccountId) {
	this.bmcAccountId = bmcAccountId;
    }

    public String getTimeZoneSidKey() {
	return timeZoneSidKey;
    }

    public void setTimeZoneSidKey(String timeZoneSidKey) {
	this.timeZoneSidKey = timeZoneSidKey;
    }

    public String getLocaleSidKey() {
	return localeSidKey;
    }

    public void setLocaleSidKey(String localeSidKey) {
	this.localeSidKey = localeSidKey;
    }

    public String getEmailEncodingKey() {
	return emailEncodingKey;
    }

    public void setEmailEncodingKey(String emailEncodingKey) {
	this.emailEncodingKey = emailEncodingKey;
    }

    public String getLanguageLocaleKey() {
	return languageLocaleKey;
    }

    public void setLanguageLocaleKey(String languageLocaleKey) {
	this.languageLocaleKey = languageLocaleKey;
    }

    public Boolean getIsActive() {
	return isActive;
    }

    public void setIsActive(Boolean isActive) {
	this.isActive = isActive;
    }

    public String getPracticeShortname() {
	return practiceShortname;
    }

    public void setPracticeShortname(String practiceShortname) {
	this.practiceShortname = practiceShortname;
    }

    public String getRegion() {
	return region;
    }

    public void setRegion(String region) {
	this.region = region;
    }

    public String getSiteName() {
	return siteName;
    }

    public void setSiteName(String siteName) {
	this.siteName = siteName;
    }

    public String getUserRoleId() {
	return userRoleId;
    }

    public void setUserRoleId(String userRoleId) {
	this.userRoleId = userRoleId;
    }

    public Boolean getServiceDeskStaff() {
	return serviceDeskStaff;
    }

    public void setServiceDeskStaff(Boolean serviceDeskStaff) {
	this.serviceDeskStaff = serviceDeskStaff;
    }

    public Boolean getKnowledgeUser() {
	return knowledgeUser;
    }

    public void setKnowledgeUser(Boolean knowledgeUser) {
	this.knowledgeUser = knowledgeUser;
    }

    public Boolean getManageQV() {
	return manageQV;
    }

    public void setManageQV(Boolean manageQV) {
	this.manageQV = manageQV;
    }

 /* TODO Comment
  * We have issue with this properties 
    public String getContactId() {
	return contactId;
    }

    public void setContactId(String contactId) {
	this.contactId = contactId;
    }
/**/
    public String getBmcContactId() {
	return bmcContactId;
    }

    public void setBmcContactId(String bmcContactId) {
	this.bmcContactId = bmcContactId;
    }

    public Boolean getReceivesInfoEmails() {
	return receivesInfoEmails;
    }

    public void setReceivesInfoEmails(Boolean receivesInfoEmails) {
	this.receivesInfoEmails = receivesInfoEmails;
    }

    public Boolean getReceivesAdminInfoEmails() {
	return receivesAdminInfoEmails;
    }

    public void setReceivesAdminInfoEmails(Boolean receivesAdminInfoEmails) {
	this.receivesAdminInfoEmails = receivesAdminInfoEmails;
    }

    public Boolean getUserPreferencesDisableAllFeedsEmail() {
	return userPreferencesDisableAllFeedsEmail;
    }

    public void setUserPreferencesDisableAllFeedsEmail(Boolean userPreferencesDisableAllFeedsEmail) {
	this.userPreferencesDisableAllFeedsEmail = userPreferencesDisableAllFeedsEmail;
    }

    public Boolean getMarketingUser() {
	return marketingUser;
    }

    public void setMarketingUser(Boolean marketingUser) {
	this.marketingUser = marketingUser;
    }

    public Boolean getServiceCloudUser() {
	return serviceCloudUser;
    }

    public void setServiceCloudUser(Boolean serviceCloudUser) {
	this.serviceCloudUser = serviceCloudUser;
    }

    public Boolean getEmailPreferencesAutoBcc() {
	return emailPreferencesAutoBcc;
    }

    public void setEmailPreferencesAutoBcc(Boolean emailPreferencesAutoBcc) {
	this.emailPreferencesAutoBcc = emailPreferencesAutoBcc;
    }

    public Boolean getEmailPreferencesAutoBccStayInTouch() {
	return emailPreferencesAutoBccStayInTouch;
    }

    public void setEmailPreferencesAutoBccStayInTouch(Boolean emailPreferencesAutoBccStayInTouch) {
	this.emailPreferencesAutoBccStayInTouch = emailPreferencesAutoBccStayInTouch;
    }

    public Boolean getEmailPreferencesStayInTouchReminder() {
	return emailPreferencesStayInTouchReminder;
    }

    public void setEmailPreferencesStayInTouchReminder(Boolean emailPreferencesStayInTouchReminder) {
	this.emailPreferencesStayInTouchReminder = emailPreferencesStayInTouchReminder;
    }

    public Boolean getUserPreferencesActivityRemindersPopup() {
	return userPreferencesActivityRemindersPopup;
    }

    public void setUserPreferencesActivityRemindersPopup(Boolean userPreferencesActivityRemindersPopup) {
	this.userPreferencesActivityRemindersPopup = userPreferencesActivityRemindersPopup;
    }

    public Boolean getUserPreferencesEventRemindersCheckboxDefault() {
	return userPreferencesEventRemindersCheckboxDefault;
    }

    public void setUserPreferencesEventRemindersCheckboxDefault(Boolean userPreferencesEventRemindersCheckboxDefault) {
	this.userPreferencesEventRemindersCheckboxDefault = userPreferencesEventRemindersCheckboxDefault;
    }

    public Boolean getUserPreferencesTaskRemindersCheckboxDefault() {
	return userPreferencesTaskRemindersCheckboxDefault;
    }

    public void setUserPreferencesTaskRemindersCheckboxDefault(Boolean userPreferencesTaskRemindersCheckboxDefault) {
	this.userPreferencesTaskRemindersCheckboxDefault = userPreferencesTaskRemindersCheckboxDefault;
    }

    public Boolean getUserPreferencesDisableFollowersEmail() {
	return userPreferencesDisableFollowersEmail;
    }

    public void setUserPreferencesDisableFollowersEmail(Boolean userPreferencesDisableFollowersEmail) {
	this.userPreferencesDisableFollowersEmail = userPreferencesDisableFollowersEmail;
    }

    public Boolean getUserPreferencesDisableProfilePostEmail() {
	return userPreferencesDisableProfilePostEmail;
    }

    public void setUserPreferencesDisableProfilePostEmail(Boolean userPreferencesDisableProfilePostEmail) {
	this.userPreferencesDisableProfilePostEmail = userPreferencesDisableProfilePostEmail;
    }

    public Boolean getUserPreferencesDisableChangeCommentEmail() {
	return userPreferencesDisableChangeCommentEmail;
    }

    public void setUserPreferencesDisableChangeCommentEmail(Boolean userPreferencesDisableChangeCommentEmail) {
	this.userPreferencesDisableChangeCommentEmail = userPreferencesDisableChangeCommentEmail;
    }

    public Boolean getUserPreferencesDisableLaterCommentEmail() {
	return userPreferencesDisableLaterCommentEmail;
    }

    public void setUserPreferencesDisableLaterCommentEmail(Boolean userPreferencesDisableLaterCommentEmail) {
	this.userPreferencesDisableLaterCommentEmail = userPreferencesDisableLaterCommentEmail;
    }

    public Boolean getUserPreferencesDisProfPostCommentEmail() {
	return userPreferencesDisProfPostCommentEmail;
    }

    public void setUserPreferencesDisProfPostCommentEmail(Boolean userPreferencesDisProfPostCommentEmail) {
	this.userPreferencesDisProfPostCommentEmail = userPreferencesDisProfPostCommentEmail;
    }

    public Boolean getUserPreferencesContentNoEmail() {
	return userPreferencesContentNoEmail;
    }

    public void setUserPreferencesContentNoEmail(Boolean userPreferencesContentNoEmail) {
	this.userPreferencesContentNoEmail = userPreferencesContentNoEmail;
    }

    public Boolean getUserPreferencesContentEmailAsAndWhen() {
	return userPreferencesContentEmailAsAndWhen;
    }

    public void setUserPreferencesContentEmailAsAndWhen(Boolean userPreferencesContentEmailAsAndWhen) {
	this.userPreferencesContentEmailAsAndWhen = userPreferencesContentEmailAsAndWhen;
    }

    public Boolean getUserPreferencesHideCSNGetChatterMobileTask() {
	return userPreferencesHideCSNGetChatterMobileTask;
    }

    public void setUserPreferencesHideCSNGetChatterMobileTask(Boolean userPreferencesHideCSNGetChatterMobileTask) {
	this.userPreferencesHideCSNGetChatterMobileTask = userPreferencesHideCSNGetChatterMobileTask;
    }

    public Boolean getUserPreferencesDisableMentionsPostEmail() {
	return userPreferencesDisableMentionsPostEmail;
    }

    public void setUserPreferencesDisableMentionsPostEmail(Boolean userPreferencesDisableMentionsPostEmail) {
	this.userPreferencesDisableMentionsPostEmail = userPreferencesDisableMentionsPostEmail;
    }

    public Boolean getUserPreferencesDisMentionsCommentEmail() {
	return userPreferencesDisMentionsCommentEmail;
    }

    public void setUserPreferencesDisMentionsCommentEmail(Boolean userPreferencesDisMentionsCommentEmail) {
	this.userPreferencesDisMentionsCommentEmail = userPreferencesDisMentionsCommentEmail;
    }

    public Boolean getUserPreferencesHideCSNDesktopTask() {
	return userPreferencesHideCSNDesktopTask;
    }

    public void setUserPreferencesHideCSNDesktopTask(Boolean userPreferencesHideCSNDesktopTask) {
	this.userPreferencesHideCSNDesktopTask = userPreferencesHideCSNDesktopTask;
    }

    public Boolean getUserPreferencesHideChatterOnboardingSplash() {
	return userPreferencesHideChatterOnboardingSplash;
    }

    public void setUserPreferencesHideChatterOnboardingSplash(Boolean userPreferencesHideChatterOnboardingSplash) {
	this.userPreferencesHideChatterOnboardingSplash = userPreferencesHideChatterOnboardingSplash;
    }

    public Boolean getUserPreferencesHideSecondChatterOnboardingSplash() {
	return userPreferencesHideSecondChatterOnboardingSplash;
    }

    public void setUserPreferencesHideSecondChatterOnboardingSplash(
	    Boolean userPreferencesHideSecondChatterOnboardingSplash) {
	this.userPreferencesHideSecondChatterOnboardingSplash = userPreferencesHideSecondChatterOnboardingSplash;
    }

    public Boolean getUserPreferencesDisCommentAfterLikeEmail() {
	return userPreferencesDisCommentAfterLikeEmail;
    }

    public void setUserPreferencesDisCommentAfterLikeEmail(Boolean userPreferencesDisCommentAfterLikeEmail) {
	this.userPreferencesDisCommentAfterLikeEmail = userPreferencesDisCommentAfterLikeEmail;
    }

    public Boolean getUserPreferencesDisableLikeEmail() {
	return userPreferencesDisableLikeEmail;
    }

    public void setUserPreferencesDisableLikeEmail(Boolean userPreferencesDisableLikeEmail) {
	this.userPreferencesDisableLikeEmail = userPreferencesDisableLikeEmail;
    }

    public Boolean getUserPreferencesDisableMessageEmail() {
	return userPreferencesDisableMessageEmail;
    }

    public void setUserPreferencesDisableMessageEmail(Boolean userPreferencesDisableMessageEmail) {
	this.userPreferencesDisableMessageEmail = userPreferencesDisableMessageEmail;
    }

    public Boolean getUserPreferencesDisableBookmarkEmail() {
	return userPreferencesDisableBookmarkEmail;
    }

    public void setUserPreferencesDisableBookmarkEmail(Boolean userPreferencesDisableBookmarkEmail) {
	this.userPreferencesDisableBookmarkEmail = userPreferencesDisableBookmarkEmail;
    }

    public Boolean getUserPreferencesDisableSharePostEmail() {
	return userPreferencesDisableSharePostEmail;
    }

    public void setUserPreferencesDisableSharePostEmail(Boolean userPreferencesDisableSharePostEmail) {
	this.userPreferencesDisableSharePostEmail = userPreferencesDisableSharePostEmail;
    }

    public Boolean getUserPreferencesEnableAutoSubForFeeds() {
	return userPreferencesEnableAutoSubForFeeds;
    }

    public void setUserPreferencesEnableAutoSubForFeeds(Boolean userPreferencesEnableAutoSubForFeeds) {
	this.userPreferencesEnableAutoSubForFeeds = userPreferencesEnableAutoSubForFeeds;
    }

    public Boolean getUserPreferencesDisableFileShareNotificationsForApi() {
	return userPreferencesDisableFileShareNotificationsForApi;
    }

    public void setUserPreferencesDisableFileShareNotificationsForApi(
	    Boolean userPreferencesDisableFileShareNotificationsForApi) {
	this.userPreferencesDisableFileShareNotificationsForApi = userPreferencesDisableFileShareNotificationsForApi;
    }

    public Boolean getUserPreferencesHideS1BrowserUI() {
	return userPreferencesHideS1BrowserUI;
    }

    public void setUserPreferencesHideS1BrowserUI(Boolean userPreferencesHideS1BrowserUI) {
	this.userPreferencesHideS1BrowserUI = userPreferencesHideS1BrowserUI;
    }

    public Boolean getUserPreferencesDisableEndorsementEmail() {
	return userPreferencesDisableEndorsementEmail;
    }

    public void setUserPreferencesDisableEndorsementEmail(Boolean userPreferencesDisableEndorsementEmail) {
	this.userPreferencesDisableEndorsementEmail = userPreferencesDisableEndorsementEmail;
    }

    public DefaultGroupNotificationFrequencyEnum getDefaultGroupNotificationFrequency() {
	return defaultGroupNotificationFrequency;
    }

    public void setDefaultGroupNotificationFrequency(
	    DefaultGroupNotificationFrequencyEnum defaultGroupNotificationFrequency) {
	this.defaultGroupNotificationFrequency = defaultGroupNotificationFrequency;
    }

/* TODO Comment
 * We have issue with this properties 
    public String getEnterpriseEmail() {
	return enterpriseEmail;
    }

    public void setEnterpriseEmail(String enterpriseEmail) {
	this.enterpriseEmail = enterpriseEmail;
    }
/**/
    public String getSamAccountName() {
	return samAccountName;
    }

    public void setSamAccountName(String samAccountName) {
	this.samAccountName = samAccountName;
    }

}