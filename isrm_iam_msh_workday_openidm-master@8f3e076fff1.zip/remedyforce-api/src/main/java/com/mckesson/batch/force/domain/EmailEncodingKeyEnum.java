package com.mckesson.batch.force.domain;

/**
 * Java model for the EmailEncodingKey picklist.
 *
 * This enum was auto-generated. It is considered owned
 * by the Force.com database.
 **/

public enum EmailEncodingKeyEnum  {

    UTF_8(true,false,"Unicode (UTF-8)","UTF-8"),
    ISO_8859_1(true,false,"General US & Western Europe (ISO-8859-1, ISO-LATIN-1)","ISO-8859-1"),
    SHIFT_JIS(true,false,"Japanese (Shift-JIS)","Shift_JIS"),
    ISO_2022_JP(true,false,"Japanese (JIS)","ISO-2022-JP"),
    EUC_JP(true,false,"Japanese (EUC)","EUC-JP"),
    KS_C_5601_1987(true,false,"Korean (ks_c_5601-1987)","ks_c_5601-1987"),
    BIG5(true,false,"Traditional Chinese (Big5)","Big5"),
    GB2312(true,false,"Simplified Chinese (GB2312)","GB2312"),
    ;

    private boolean isActive;
    private boolean isDefaultValue;
    private String label;
    private String value;

    private EmailEncodingKeyEnum(boolean isActive, boolean isDefaultValue, String label, String value) {
        this.isActive = isActive;
        this.isDefaultValue = isDefaultValue;
        this.label = label;
        this.value = value;
    }

    
    public boolean isActive() { return this.isActive; }

    
    public boolean isDefaultValue() { return this.isDefaultValue; }

    
    public String label() { return this.label; }

    
    public String value() { return this.value; }

    public static EmailEncodingKeyEnum fromValue(String value) {
        if (value == null) return null;

        for (EmailEncodingKeyEnum picklistValueEnum : values()) {
            if (value.equals(picklistValueEnum.value())) {
                return picklistValueEnum;
            }
        }

        return null;
    }
}


