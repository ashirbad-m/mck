package com.mckesson.batch.force.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("BMCServiceDesk__Task__c")
@JsonIgnoreProperties(ignoreUnknown = true)
public class BMCServiceDeskTask{


	@JsonProperty("Id")
	private String id;

	@JsonProperty("OwnerId")
	private String ownerId;

	@JsonProperty("IsDeleted")
	private Boolean isDeleted;

	@JsonProperty("Name")
	private String name;

	@JsonProperty("RecordTypeId")
	private String recordTypeId;

	@JsonProperty("CreatedDate")
	private String createdDate;

	@JsonProperty("CreatedById")
	private String createdById;

	@JsonProperty("LastModifiedDate")
	private String lastModifiedDate;

	@JsonProperty("LastModifiedById")
	private String lastModifiedById;

	@JsonProperty("SystemModstamp")
	private String systemModstamp;

	@JsonProperty("LastViewedDate")
	private String lastViewedDate;

	@JsonProperty("LastReferencedDate")
	private String lastReferencedDate;

	@JsonProperty("BMCServiceDesk__ACDeviceID__c")
	private String bmcACDeviceId;

	@JsonProperty("BMCServiceDesk__ACExecute__c")
	private Boolean bmcACExecute;

	@JsonProperty("BMCServiceDesk__ACOpRuleID__c")
	private String bmcACOpRuleId;

	@JsonProperty("BMCServiceDesk__ACOpRuleStatusDescription__c")
	private String bmcACOpRuleStatusDescription;

	@JsonProperty("BMCServiceDesk__ACOpRuleStatus__c")
	private String bmcACOpRuleStatus;

	@JsonProperty("BMCServiceDesk__ACRequiresApproval__c")
	private Boolean bmcACRequiresApproval;

	@JsonProperty("BMCServiceDesk__Additional_email_information__c")
	private String bmcAdditionalEmailInformation;

	@JsonProperty("BMCServiceDesk__BLANK__c")
	private String bmcBLANK;

	@JsonProperty("BMCServiceDesk__Category_ID__c")
	private String bmcCategory;

	@JsonProperty("BMCServiceDesk__Client_Account__c")
	private String bmcClientAccount;

	@JsonProperty("BMCServiceDesk__Client_First_Name__c")
	private String bmcClientFirstName;

	@JsonProperty("BMCServiceDesk__Client_ID__c")
	private String bmcClient;

	@JsonProperty("BMCServiceDesk__Client_Last_Name__c")
	private String bmcClientLastName;

	@JsonProperty("BMCServiceDesk__Client_Name__c")
	private String bmcClientName;

	@JsonProperty("BMCServiceDesk__Client_Type__c")
	private String bmcClientType;

	@JsonProperty("BMCServiceDesk__Closed_By__c")
	private String bmcClosedBy;

	@JsonProperty("BMCServiceDesk__Compliant__c")
	private String bmcCompliant;

	@JsonProperty("BMCServiceDesk__Dummy_Update__c")
	private Boolean bmcDummyUpdate;

	@JsonProperty("BMCServiceDesk__ExistsInManifest__c")
	private Boolean bmcExistsInManifest;

	@JsonProperty("BMCServiceDesk__FKCategory__c")
	private String bmcCategoryId;

	@JsonProperty("BMCServiceDesk__FKChange__c")
	private String bmcChangeId;

	@JsonProperty("BMCServiceDesk__FKClient__c")
	private String bmcClientId;

	@JsonProperty("BMCServiceDesk__FKClosedBy__c")
	private String bmcFKClosedById;

	@JsonProperty("BMCServiceDesk__FKContact__c")
	private String bmcContactId;

	@JsonProperty("BMCServiceDesk__FKImpact__c")
	private String bmcImpactId;

	@JsonProperty("BMCServiceDesk__FKIncident__c")
	private String bmcIncidentId;

	@JsonProperty("BMCServiceDesk__FKLead__c")
	private String bmcLeadId;

	@JsonProperty("BMCServiceDesk__FKOpenBy__c")
	private String bmcOpenById;

	@JsonProperty("BMCServiceDesk__FKPriority__c")
	private String bmcPriorityId;

	@JsonProperty("BMCServiceDesk__FKProblem__c")
	private String bmcProblemId;

	@JsonProperty("BMCServiceDesk__FKRelease__c")
	private String bmcReleaseId;

	@JsonProperty("BMCServiceDesk__FKStatus__c")
	private String bmcStatusId;

	@JsonProperty("BMCServiceDesk__FKTemplate__c")
	private String bmcTemplateId;

	@JsonProperty("BMCServiceDesk__FKUrgency__c")
	private String bmcUrgencyId;

	@JsonProperty("BMCServiceDesk__Impact_ID__c")
	private String bmcImpact;

	@JsonProperty("BMCServiceDesk__Launch_console__c")
	private String bmcLaunchConsole;

	@JsonProperty("BMCServiceDesk__Opened_DateTime__c")
	private String bmcOpenedDateTime;

	@JsonProperty("BMCServiceDesk__Priority_ID__c")
	private String bmcPriority;

	@JsonProperty("BMCServiceDesk__Recurrence__c")
	private String bmcRecurrence;

	@JsonProperty("BMCServiceDesk__RecurringParentRecordId__c")
	private String bmcRecurringParentRecordId;

	@JsonProperty("BMCServiceDesk__Scheduled_End_Date__c")
	private String bmcScheduledEndDate;

	@JsonProperty("BMCServiceDesk__Scheduled_Start_Date__c")
	private String bmcScheduledStartDate;

	@JsonProperty("BMCServiceDesk__Service_Request_Process__c")
	private Boolean bmcServiceRequestProcess;

	@JsonProperty("BMCServiceDesk__ShowDueDateDialog__c")
	private Boolean bmcShowDueDateDialog;

	@JsonProperty("BMCServiceDesk__Status_ID__c")
	private String bmcStatus;

	@JsonProperty("BMCServiceDesk__Task_console_detail_link__c")
	private String bmcTaskConsoleDetailLink;

	@JsonProperty("BMCServiceDesk__TemplateAlreadyApplied__c")
	private Boolean bmcTemplateAlreadyApplied;

	@JsonProperty("BMCServiceDesk__TemplateName__c")
	private String bmcTemplateName;

	@JsonProperty("BMCServiceDesk__Urgency_ID__c")
	private String bmcUrgency;

	@JsonProperty("BMCServiceDesk__busAssessment__c")
	private String bmcBusAssessment;

	@JsonProperty("BMCServiceDesk__closeDateTime__c")
	private String bmcCloseDateTime;

	@JsonProperty("BMCServiceDesk__closedProfile__c")
	private String bmcClosedProfile;

	@JsonProperty("BMCServiceDesk__comments__c")
	private String bmcComments;

	@JsonProperty("BMCServiceDesk__completedDate__c")
	private String bmcCompletedDate;

	@JsonProperty("BMCServiceDesk__contactType__c")
	private String bmcContactType;

	@JsonProperty("BMCServiceDesk__costEstimate__c")
	private String bmcCostEstimate;

	@JsonProperty("BMCServiceDesk__createdOn__c")
	private String bmcCreatedOn;

	@JsonProperty("BMCServiceDesk__decision__c")
	private String bmcDecision;

	@JsonProperty("BMCServiceDesk__dueDateTime__c")
	private String bmcDueDateTime;

	@JsonProperty("BMCServiceDesk__duration__c")
	private String bmcDuration;

	@JsonProperty("BMCServiceDesk__eMailOriginator__c")
	private String bmcEMailOriginator;

	@JsonProperty("BMCServiceDesk__endDate__c")
	private String bmcEndDate;

	@JsonProperty("BMCServiceDesk__inactive__c")
	private Boolean bmcInactive;

	@JsonProperty("BMCServiceDesk__isReopened__c")
	private Boolean bmcIsReopened;

	@JsonProperty("BMCServiceDesk__note__c")
	private String bmcNote;

	@JsonProperty("BMCServiceDesk__openDateTime__c")
	private String bmcOpenDateTime;

	@JsonProperty("BMCServiceDesk__openedProfile__c")
	private String bmcOpenedProfile;

	@JsonProperty("BMCServiceDesk__phone__c")
	private String bmcPhone;

	@JsonProperty("BMCServiceDesk__processTemplateOrder__c")
	private String bmcProcessTemplateOrder;

	@JsonProperty("BMCServiceDesk__queueName__c")
	private String bmcQueueName;

	@JsonProperty("BMCServiceDesk__recommendations__c")
	private String bmcRecommendations;

	@JsonProperty("BMCServiceDesk__recommendedFixDateTime__c")
	private String bmcRecommendedFixDateTime;

	@JsonProperty("BMCServiceDesk__resourceDescription__c")
	private String bmcResourceDescription;

	@JsonProperty("BMCServiceDesk__responseDateTime__c")
	private String bmcResponseDateTime;

	@JsonProperty("BMCServiceDesk__shortDescription__c")
	private String bmcShortDescription;

	@JsonProperty("BMCServiceDesk__startDate__c")
	private String bmcStartDate;

	@JsonProperty("BMCServiceDesk__state__c")
	private Boolean bmcState;

	@JsonProperty("BMCServiceDesk__taskDescription__c")
	private String bmcTaskDescription;

	@JsonProperty("Task_Description__c")
	private String taskDescription;

	@JsonProperty("BMCServiceDesk__taskResolution__c")
	private String bmcTaskResolution;

	@JsonProperty("BMCServiceDesk__taskType__c")
	private String bmcTaskType;

	@JsonProperty("BMCServiceDesk__techAssessment__c")
	private String bmcTechAssessment;

	@JsonProperty("BMCServiceDesk__templateOrder__c")
	private Double bmcTemplateOrder;

	@JsonProperty("BMCServiceDesk__timeSpent__c")
	private String bmcTimeSpent;

	@JsonProperty("BMCServiceDesk__Total_Duration__c")
	private Double bmcTotalDuration;

	@JsonProperty("BMCServiceDesk__UpdateCount__c")
	private Double bmcUpdateCount;

	@JsonProperty("BMCServiceDesk__WebAPIConfiguration__c")
	private String bmcWebAPIConfiguration;

	@JsonProperty("BMCServiceDesk__DisplayInSS__c")
	private Boolean bmcDisplayInSS;

	@JsonProperty("BMCServiceDesk__LockedRecordTimestamp__c")
	private String bmcLockedRecordTimestamp;

	@JsonProperty("BMCServiceDesk__Queue__c")
	private String bmcQueue;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRecordTypeId() {
		return recordTypeId;
	}

	public void setRecordTypeId(String recordTypeId) {
		this.recordTypeId = recordTypeId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedById() {
		return createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLastModifiedById() {
		return lastModifiedById;
	}

	public void setLastModifiedById(String lastModifiedById) {
		this.lastModifiedById = lastModifiedById;
	}

	public String getSystemModstamp() {
		return systemModstamp;
	}

	public void setSystemModstamp(String systemModstamp) {
		this.systemModstamp = systemModstamp;
	}

	public String getLastViewedDate() {
		return lastViewedDate;
	}

	public void setLastViewedDate(String lastViewedDate) {
		this.lastViewedDate = lastViewedDate;
	}

	public String getLastReferencedDate() {
		return lastReferencedDate;
	}

	public void setLastReferencedDate(String lastReferencedDate) {
		this.lastReferencedDate = lastReferencedDate;
	}

	public String getBmcACDeviceId() {
		return bmcACDeviceId;
	}

	public void setBmcACDeviceId(String bmcACDeviceId) {
		this.bmcACDeviceId = bmcACDeviceId;
	}

	public Boolean getBmcACExecute() {
		return bmcACExecute;
	}

	public void setBmcACExecute(Boolean bmcACExecute) {
		this.bmcACExecute = bmcACExecute;
	}

	public String getBmcACOpRuleId() {
		return bmcACOpRuleId;
	}

	public void setBmcACOpRuleId(String bmcACOpRuleId) {
		this.bmcACOpRuleId = bmcACOpRuleId;
	}

	public String getBmcACOpRuleStatusDescription() {
		return bmcACOpRuleStatusDescription;
	}

	public void setBmcACOpRuleStatusDescription(String bmcACOpRuleStatusDescription) {
		this.bmcACOpRuleStatusDescription = bmcACOpRuleStatusDescription;
	}

	public String getBmcACOpRuleStatus() {
		return bmcACOpRuleStatus;
	}

	public void setBmcACOpRuleStatus(String bmcACOpRuleStatus) {
		this.bmcACOpRuleStatus = bmcACOpRuleStatus;
	}

	public Boolean getBmcACRequiresApproval() {
		return bmcACRequiresApproval;
	}

	public void setBmcACRequiresApproval(Boolean bmcACRequiresApproval) {
		this.bmcACRequiresApproval = bmcACRequiresApproval;
	}

	public String getBmcAdditionalEmailInformation() {
		return bmcAdditionalEmailInformation;
	}

	public void setBmcAdditionalEmailInformation(String bmcAdditionalEmailInformation) {
		this.bmcAdditionalEmailInformation = bmcAdditionalEmailInformation;
	}

	public String getBmcBLANK() {
		return bmcBLANK;
	}

	public void setBmcBLANK(String bmcBLANK) {
		this.bmcBLANK = bmcBLANK;
	}

	public String getBmcCategory() {
		return bmcCategory;
	}

	public void setBmcCategory(String bmcCategory) {
		this.bmcCategory = bmcCategory;
	}

	public String getBmcClientAccount() {
		return bmcClientAccount;
	}

	public void setBmcClientAccount(String bmcClientAccount) {
		this.bmcClientAccount = bmcClientAccount;
	}

	public String getBmcClientFirstName() {
		return bmcClientFirstName;
	}

	public void setBmcClientFirstName(String bmcClientFirstName) {
		this.bmcClientFirstName = bmcClientFirstName;
	}

	public String getBmcClient() {
		return bmcClient;
	}

	public void setBmcClient(String bmcClient) {
		this.bmcClient = bmcClient;
	}

	public String getBmcClientLastName() {
		return bmcClientLastName;
	}

	public void setBmcClientLastName(String bmcClientLastName) {
		this.bmcClientLastName = bmcClientLastName;
	}

	public String getBmcClientName() {
		return bmcClientName;
	}

	public void setBmcClientName(String bmcClientName) {
		this.bmcClientName = bmcClientName;
	}

	public String getBmcClientType() {
		return bmcClientType;
	}

	public void setBmcClientType(String bmcClientType) {
		this.bmcClientType = bmcClientType;
	}

	public String getBmcClosedBy() {
		return bmcClosedBy;
	}

	public void setBmcClosedBy(String bmcClosedBy) {
		this.bmcClosedBy = bmcClosedBy;
	}

	public String getBmcCompliant() {
		return bmcCompliant;
	}

	public void setBmcCompliant(String bmcCompliant) {
		this.bmcCompliant = bmcCompliant;
	}

	public Boolean getBmcDummyUpdate() {
		return bmcDummyUpdate;
	}

	public void setBmcDummyUpdate(Boolean bmcDummyUpdate) {
		this.bmcDummyUpdate = bmcDummyUpdate;
	}

	public Boolean getBmcExistsInManifest() {
		return bmcExistsInManifest;
	}

	public void setBmcExistsInManifest(Boolean bmcExistsInManifest) {
		this.bmcExistsInManifest = bmcExistsInManifest;
	}

	public String getBmcCategoryId() {
		return bmcCategoryId;
	}

	public void setBmcCategoryId(String bmcCategoryId) {
		this.bmcCategoryId = bmcCategoryId;
	}

	public String getBmcChangeId() {
		return bmcChangeId;
	}

	public void setBmcChangeId(String bmcChangeId) {
		this.bmcChangeId = bmcChangeId;
	}

	public String getBmcClientId() {
		return bmcClientId;
	}

	public void setBmcClientId(String bmcClientId) {
		this.bmcClientId = bmcClientId;
	}

	public String getBmcFKClosedById() {
		return bmcFKClosedById;
	}

	public void setBmcFKClosedById(String bmcFKClosedById) {
		this.bmcFKClosedById = bmcFKClosedById;
	}

	public String getBmcContactId() {
		return bmcContactId;
	}

	public void setBmcContactId(String bmcContactId) {
		this.bmcContactId = bmcContactId;
	}

	public String getBmcImpactId() {
		return bmcImpactId;
	}

	public void setBmcImpactId(String bmcImpactId) {
		this.bmcImpactId = bmcImpactId;
	}

	public String getBmcIncidentId() {
		return bmcIncidentId;
	}

	public void setBmcIncidentId(String bmcIncidentId) {
		this.bmcIncidentId = bmcIncidentId;
	}

	public String getBmcLeadId() {
		return bmcLeadId;
	}

	public void setBmcLeadId(String bmcLeadId) {
		this.bmcLeadId = bmcLeadId;
	}

	public String getBmcOpenById() {
		return bmcOpenById;
	}

	public void setBmcOpenById(String bmcOpenById) {
		this.bmcOpenById = bmcOpenById;
	}

	public String getBmcPriorityId() {
		return bmcPriorityId;
	}

	public void setBmcPriorityId(String bmcPriorityId) {
		this.bmcPriorityId = bmcPriorityId;
	}

	public String getBmcProblemId() {
		return bmcProblemId;
	}

	public void setBmcProblemId(String bmcProblemId) {
		this.bmcProblemId = bmcProblemId;
	}

	public String getBmcReleaseId() {
		return bmcReleaseId;
	}

	public void setBmcReleaseId(String bmcReleaseId) {
		this.bmcReleaseId = bmcReleaseId;
	}

	public String getBmcStatusId() {
		return bmcStatusId;
	}

	public void setBmcStatusId(String bmcStatusId) {
		this.bmcStatusId = bmcStatusId;
	}

	public String getBmcTemplateId() {
		return bmcTemplateId;
	}

	public void setBmcTemplateId(String bmcTemplateId) {
		this.bmcTemplateId = bmcTemplateId;
	}

	public String getBmcUrgencyId() {
		return bmcUrgencyId;
	}

	public void setBmcUrgencyId(String bmcUrgencyId) {
		this.bmcUrgencyId = bmcUrgencyId;
	}

	public String getBmcImpact() {
		return bmcImpact;
	}

	public void setBmcImpact(String bmcImpact) {
		this.bmcImpact = bmcImpact;
	}

	public String getBmcLaunchConsole() {
		return bmcLaunchConsole;
	}

	public void setBmcLaunchConsole(String bmcLaunchConsole) {
		this.bmcLaunchConsole = bmcLaunchConsole;
	}

	public String getBmcOpenedDateTime() {
		return bmcOpenedDateTime;
	}

	public void setBmcOpenedDateTime(String bmcOpenedDateTime) {
		this.bmcOpenedDateTime = bmcOpenedDateTime;
	}

	public String getBmcPriority() {
		return bmcPriority;
	}

	public void setBmcPriority(String bmcPriority) {
		this.bmcPriority = bmcPriority;
	}

	public String getBmcRecurrence() {
		return bmcRecurrence;
	}

	public void setBmcRecurrence(String bmcRecurrence) {
		this.bmcRecurrence = bmcRecurrence;
	}

	public String getBmcRecurringParentRecordId() {
		return bmcRecurringParentRecordId;
	}

	public void setBmcRecurringParentRecordId(String bmcRecurringParentRecordId) {
		this.bmcRecurringParentRecordId = bmcRecurringParentRecordId;
	}

	public String getBmcScheduledEndDate() {
		return bmcScheduledEndDate;
	}

	public void setBmcScheduledEndDate(String bmcScheduledEndDate) {
		this.bmcScheduledEndDate = bmcScheduledEndDate;
	}

	public String getBmcScheduledStartDate() {
		return bmcScheduledStartDate;
	}

	public void setBmcScheduledStartDate(String bmcScheduledStartDate) {
		this.bmcScheduledStartDate = bmcScheduledStartDate;
	}

	public Boolean getBmcServiceRequestProcess() {
		return bmcServiceRequestProcess;
	}

	public void setBmcServiceRequestProcess(Boolean bmcServiceRequestProcess) {
		this.bmcServiceRequestProcess = bmcServiceRequestProcess;
	}

	public Boolean getBmcShowDueDateDialog() {
		return bmcShowDueDateDialog;
	}

	public void setBmcShowDueDateDialog(Boolean bmcShowDueDateDialog) {
		this.bmcShowDueDateDialog = bmcShowDueDateDialog;
	}

	public String getBmcStatus() {
		return bmcStatus;
	}

	public void setBmcStatus(String bmcStatus) {
		this.bmcStatus = bmcStatus;
	}

	public String getBmcTaskConsoleDetailLink() {
		return bmcTaskConsoleDetailLink;
	}

	public void setBmcTaskConsoleDetailLink(String bmcTaskConsoleDetailLink) {
		this.bmcTaskConsoleDetailLink = bmcTaskConsoleDetailLink;
	}

	public Boolean getBmcTemplateAlreadyApplied() {
		return bmcTemplateAlreadyApplied;
	}

	public void setBmcTemplateAlreadyApplied(Boolean bmcTemplateAlreadyApplied) {
		this.bmcTemplateAlreadyApplied = bmcTemplateAlreadyApplied;
	}

	public String getBmcTemplateName() {
		return bmcTemplateName;
	}

	public void setBmcTemplateName(String bmcTemplateName) {
		this.bmcTemplateName = bmcTemplateName;
	}

	public String getBmcUrgency() {
		return bmcUrgency;
	}

	public void setBmcUrgency(String bmcUrgency) {
		this.bmcUrgency = bmcUrgency;
	}

	public String getBmcBusAssessment() {
		return bmcBusAssessment;
	}

	public void setBmcBusAssessment(String bmcBusAssessment) {
		this.bmcBusAssessment = bmcBusAssessment;
	}

	public String getBmcCloseDateTime() {
		return bmcCloseDateTime;
	}

	public void setBmcCloseDateTime(String bmcCloseDateTime) {
		this.bmcCloseDateTime = bmcCloseDateTime;
	}

	public String getBmcClosedProfile() {
		return bmcClosedProfile;
	}

	public void setBmcClosedProfile(String bmcClosedProfile) {
		this.bmcClosedProfile = bmcClosedProfile;
	}

	public String getBmcComments() {
		return bmcComments;
	}

	public void setBmcComments(String bmcComments) {
		this.bmcComments = bmcComments;
	}

	public String getBmcCompletedDate() {
		return bmcCompletedDate;
	}

	public void setBmcCompletedDate(String bmcCompletedDate) {
		this.bmcCompletedDate = bmcCompletedDate;
	}

	public String getBmcContactType() {
		return bmcContactType;
	}

	public void setBmcContactType(String bmcContactType) {
		this.bmcContactType = bmcContactType;
	}

	public String getBmcCostEstimate() {
		return bmcCostEstimate;
	}

	public void setBmcCostEstimate(String bmcCostEstimate) {
		this.bmcCostEstimate = bmcCostEstimate;
	}

	public String getBmcCreatedOn() {
		return bmcCreatedOn;
	}

	public void setBmcCreatedOn(String bmcCreatedOn) {
		this.bmcCreatedOn = bmcCreatedOn;
	}

	public String getBmcDecision() {
		return bmcDecision;
	}

	public void setBmcDecision(String bmcDecision) {
		this.bmcDecision = bmcDecision;
	}

	public String getBmcDueDateTime() {
		return bmcDueDateTime;
	}

	public void setBmcDueDateTime(String bmcDueDateTime) {
		this.bmcDueDateTime = bmcDueDateTime;
	}

	public String getBmcDuration() {
		return bmcDuration;
	}

	public void setBmcDuration(String bmcDuration) {
		this.bmcDuration = bmcDuration;
	}

	public String getBmcEMailOriginator() {
		return bmcEMailOriginator;
	}

	public void setBmcEMailOriginator(String bmcEMailOriginator) {
		this.bmcEMailOriginator = bmcEMailOriginator;
	}

	public String getBmcEndDate() {
		return bmcEndDate;
	}

	public void setBmcEndDate(String bmcEndDate) {
		this.bmcEndDate = bmcEndDate;
	}

	public Boolean getBmcInactive() {
		return bmcInactive;
	}

	public void setBmcInactive(Boolean bmcInactive) {
		this.bmcInactive = bmcInactive;
	}

	public Boolean getBmcIsReopened() {
		return bmcIsReopened;
	}

	public void setBmcIsReopened(Boolean bmcIsReopened) {
		this.bmcIsReopened = bmcIsReopened;
	}

	public String getBmcNote() {
		return bmcNote;
	}

	public void setBmcNote(String bmcNote) {
		this.bmcNote = bmcNote;
	}

	public String getBmcOpenDateTime() {
		return bmcOpenDateTime;
	}

	public void setBmcOpenDateTime(String bmcOpenDateTime) {
		this.bmcOpenDateTime = bmcOpenDateTime;
	}

	public String getBmcOpenedProfile() {
		return bmcOpenedProfile;
	}

	public void setBmcOpenedProfile(String bmcOpenedProfile) {
		this.bmcOpenedProfile = bmcOpenedProfile;
	}

	public String getBmcPhone() {
		return bmcPhone;
	}

	public void setBmcPhone(String bmcPhone) {
		this.bmcPhone = bmcPhone;
	}

	public String getBmcProcessTemplateOrder() {
		return bmcProcessTemplateOrder;
	}

	public void setBmcProcessTemplateOrder(String bmcProcessTemplateOrder) {
		this.bmcProcessTemplateOrder = bmcProcessTemplateOrder;
	}

	public String getBmcQueueName() {
		return bmcQueueName;
	}

	public void setBmcQueueName(String bmcQueueName) {
		this.bmcQueueName = bmcQueueName;
	}

	public String getBmcRecommendations() {
		return bmcRecommendations;
	}

	public void setBmcRecommendations(String bmcRecommendations) {
		this.bmcRecommendations = bmcRecommendations;
	}

	public String getBmcRecommendedFixDateTime() {
		return bmcRecommendedFixDateTime;
	}

	public void setBmcRecommendedFixDateTime(String bmcRecommendedFixDateTime) {
		this.bmcRecommendedFixDateTime = bmcRecommendedFixDateTime;
	}

	public String getBmcResourceDescription() {
		return bmcResourceDescription;
	}

	public void setBmcResourceDescription(String bmcResourceDescription) {
		this.bmcResourceDescription = bmcResourceDescription;
	}

	public String getBmcResponseDateTime() {
		return bmcResponseDateTime;
	}

	public void setBmcResponseDateTime(String bmcResponseDateTime) {
		this.bmcResponseDateTime = bmcResponseDateTime;
	}

	public String getBmcShortDescription() {
		return bmcShortDescription;
	}

	public void setBmcShortDescription(String bmcShortDescription) {
		this.bmcShortDescription = bmcShortDescription;
	}

	public String getBmcStartDate() {
		return bmcStartDate;
	}

	public void setBmcStartDate(String bmcStartDate) {
		this.bmcStartDate = bmcStartDate;
	}

	public Boolean getBmcState() {
		return bmcState;
	}

	public void setBmcState(Boolean bmcState) {
		this.bmcState = bmcState;
	}

	public String getBmcTaskDescription() {
		return bmcTaskDescription;
	}

	public void setBmcTaskDescription(String bmcTaskDescription) {
		this.bmcTaskDescription = bmcTaskDescription;
	}

	public String getTaskDescription() {
		return taskDescription;
	}

	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}

	public String getBmcTaskResolution() {
		return bmcTaskResolution;
	}

	public void setBmcTaskResolution(String bmcTaskResolution) {
		this.bmcTaskResolution = bmcTaskResolution;
	}

	public String getBmcTaskType() {
		return bmcTaskType;
	}

	public void setBmcTaskType(String bmcTaskType) {
		this.bmcTaskType = bmcTaskType;
	}

	public String getBmcTechAssessment() {
		return bmcTechAssessment;
	}

	public void setBmcTechAssessment(String bmcTechAssessment) {
		this.bmcTechAssessment = bmcTechAssessment;
	}

	public Double getBmcTemplateOrder() {
		return bmcTemplateOrder;
	}

	public void setBmcTemplateOrder(Double bmcTemplateOrder) {
		this.bmcTemplateOrder = bmcTemplateOrder;
	}

	public String getBmcTimeSpent() {
		return bmcTimeSpent;
	}

	public void setBmcTimeSpent(String bmcTimeSpent) {
		this.bmcTimeSpent = bmcTimeSpent;
	}

	public Double getBmcTotalDuration() {
		return bmcTotalDuration;
	}

	public void setBmcTotalDuration(Double bmcTotalDuration) {
		this.bmcTotalDuration = bmcTotalDuration;
	}

	public Double getBmcUpdateCount() {
		return bmcUpdateCount;
	}

	public void setBmcUpdateCount(Double bmcUpdateCount) {
		this.bmcUpdateCount = bmcUpdateCount;
	}

	public String getBmcWebAPIConfiguration() {
		return bmcWebAPIConfiguration;
	}

	public void setBmcWebAPIConfiguration(String bmcWebAPIConfiguration) {
		this.bmcWebAPIConfiguration = bmcWebAPIConfiguration;
	}

	public Boolean getBmcDisplayInSS() {
		return bmcDisplayInSS;
	}

	public void setBmcDisplayInSS(Boolean bmcDisplayInSS) {
		this.bmcDisplayInSS = bmcDisplayInSS;
	}

	public String getBmcLockedRecordTimestamp() {
		return bmcLockedRecordTimestamp;
	}

	public void setBmcLockedRecordTimestamp(String bmcLockedRecordTimestamp) {
		this.bmcLockedRecordTimestamp = bmcLockedRecordTimestamp;
	}

	public String getBmcQueue() {
		return bmcQueue;
	}

	public void setBmcQueue(String bmcQueue) {
		this.bmcQueue = bmcQueue;
	}

}
