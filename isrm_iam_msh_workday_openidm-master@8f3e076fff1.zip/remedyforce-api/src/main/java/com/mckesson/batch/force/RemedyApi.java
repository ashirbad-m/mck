package com.mckesson.batch.force;

import java.util.Map;

import com.mckesson.batch.force.domain.User;
/**
 * RF API for Remedy-interface
 *
 * @author Eugene Yudin
 */
/**
 * @author els1gkr
 *
 */
public interface RemedyApi {

	/**
	 * Creates new incident based on  named template
	 *
	 * @param incidentTemplate - Name of configured template
	 * @param incidentData - Additional Incident - data
	 * @param isServiceRequest - Service request or incident
	 *
	 * @return  - Created incident data
	 *
	 * @throws RemedyApiException If processing-error
	 */
	public IncidentData createIncident (String incidentTemplate, Map<String, Object> incidentData, boolean isServiceRequest) throws RemedyApiException;

	/**
	 * Creates new incident
	 *
	 * @param incidentData - Incident - data
	 * @param isServiceRequest - Service request or incident
	 * @return  - Created incident data
	 *
	 * @throws RemedyApiException If processing-error
	 */
	public IncidentData createIncident (Map<String, Object> incidentData, boolean isServiceRequest) throws RemedyApiException;


	/**
	 * Creates new Task based on template and assign task to an incident
	 *
	 * @param taskTemplate - Name of configured template
	 * @param incidentId - Salesforce Id of an Incident
	 * @param taskData - Additional Incident - data
	 *
	 * @return SalesforceId of generated Task
	 *
	 * @throws RemedyApiException If processing-error
	 */
	public String createTask (String taskTemplate, String incidentId, Map<String, Object> taskData) throws RemedyApiException;

	/**
	 * Creates new Task and assign task to an incident
	 *
	 * @param incidentId - Salesforce Id of an Incident
	 * @param taskData - Task - data
	 *
	 * @return SalesforceId of generated Task
	 *
	 * @throws RemedyApiException If processing-error
	 */
	public String createTask (String incidentId, Map<String, Object> taskData) throws RemedyApiException;

	/**
	 * @param email e-Mail of user
	 *
	 * @return Id of searched User-id or null if not found
	 *
	 * @throws RemedyApiException If processing-error
	 */
	public String getUserIdByEmail (String email) throws RemedyApiException;

	/**
	 * @param federationIdentifier federationIdentifier of user
	 *
	 * @return Id of searched User-id or null if not found
	 *
	 * @throws RemedyApiException If processing-error
	 */
	public String getUserIdByFederationIdentifier (String federationIdentifier) throws RemedyApiException;

	/**
	 * @param email e-Mail of user
	 *
	 * @return User-object or null if not found
	 *
	 * @throws RemedyApiException If processing-error
	 */
	public User getUserByEmail (String email) throws RemedyApiException;

	/**
	 * @param federationIdentifier federationIdentifier of user
	 *
	 * @return User-object or null if not found
	 *
	 * @throws RemedyApiException If processing-error
	 */
	public User getUserByFederationIdentifier (String federationIdentifier) throws RemedyApiException;

	/**
	 * Read incident-name
	 *
	 * @param incidentId Salesforce Id of a incident
	 *
	 * @return Incident-name
	 *
	 * @throws RemedyApiException If processing-error
	 */
	public String getIncidentName (String incidentId) throws RemedyApiException;

	/**
	 * Read Task-name
	 * @param taskId Salesforce Id of a task
	 *
	 * @return Task-name
	 *
	 * @throws RemedyApiException If processing-error
	 */
	public String getTaskName (String taskId) throws RemedyApiException;

	/**
	 * Read Object-name
	 * @param oid Salesforce Id of a Object
	 *
	 * @return Object-name
	 *
	 * @throws RemedyApiException If processing-error
	 */
	public String getObjectName(String oid, String forceType) throws RemedyApiException;

	/**
	 * Read Object
	 * @param oid Salesforce Id of a Object
	 * @param clazz Object-class
	 *
	 * @return Object
	 *
	 * @throws RemedyApiException If processing-error
	 */
	public <T> T getObject(String oid, Class<T> clazz) throws RemedyApiException;

	/**
	 * Get id of the default incident owner
	 * @return Owner id
	 */
	public String getDefaultOwnerId();

}
