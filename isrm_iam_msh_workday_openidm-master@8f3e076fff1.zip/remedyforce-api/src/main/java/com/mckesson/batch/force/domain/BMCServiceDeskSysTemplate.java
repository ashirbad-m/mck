package com.mckesson.batch.force.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("BMCServiceDesk__SYSTemplate__c")
@JsonIgnoreProperties(ignoreUnknown = true)
public class BMCServiceDeskSysTemplate {
	
	@JsonProperty("Id")
	private String id;

	@JsonProperty("OwnerId")
	private String ownerId;

	@JsonProperty("IsDeleted")
	private Boolean isDeleted;

	@JsonProperty("Name")
	private String name;

	@JsonProperty("CreatedDate")
	private String createdDate;

	@JsonProperty("CreatedById")
	private String createdById;

	@JsonProperty("LastModifiedDate")
	private String lastModifiedDate;

	@JsonProperty("LastModifiedById")
	private String lastModifiedById;

	@JsonProperty("SystemModstamp")
	private String systemModstamp;

	@JsonProperty("BMCServiceDesk__HasRecurrence__c")
	private Boolean bmcHasRecurrence;

	@JsonProperty("BMCServiceDesk__Ignore_Execution_Order__c")
	private Boolean bmcIgnoreExecutionOrder;

	@JsonProperty("BMCServiceDesk__RecurrenceDayOfMonth__c")
	private String bmcRecurrenceDayOfMonth;

	@JsonProperty("BMCServiceDesk__RecurrenceDayOfWeekMask__c")
	private String bmcRecurrenceDayOfWeekMask;

	@JsonProperty("BMCServiceDesk__RecurrenceEndDate__c")
	private String bmcRecurrenceEndDate;

	@JsonProperty("BMCServiceDesk__RecurrenceHour__c")
	private String bmcRecurrenceHour;

	@JsonProperty("BMCServiceDesk__RecurrenceInstance__c")
	private String bmcRecurrenceInstance;

	@JsonProperty("BMCServiceDesk__RecurrenceInterval__c")
	private String bmcRecurrenceInterval;

	@JsonProperty("BMCServiceDesk__RecurrenceMinutes__c")
	private String bmcRecurrenceMinutes;

	@JsonProperty("BMCServiceDesk__RecurrenceMonthOfYear__c")
	private String bmcRecurrenceMonthOfYear;

	@JsonProperty("BMCServiceDesk__RecurrenceStartDate__c")
	private String bmcRecurrenceStartDate;

	@JsonProperty("BMCServiceDesk__Recurrence_Type__c")
	private String bmcRecurrenceType;

	@JsonProperty("BMCServiceDesk__Recurrence__c")
	private String bmcRecurrence;

	@JsonProperty("BMCServiceDesk__SelfService_Display_Order__c")
	private String bmcSelfServiceDisplayOrder;

	@JsonProperty("BMCServiceDesk__Sequence__c")
	private String bmcSequence;

	@JsonProperty("BMCServiceDesk__allProfile__c")
	private Boolean bmcAllProfile;

	@JsonProperty("BMCServiceDesk__description__c")
	private String bmcDescription;

	@JsonProperty("BMCServiceDesk__inactive__c")
	private Boolean bmcInactive;

	@JsonProperty("BMCServiceDesk__keywords__c")
	private String bmcKeywords;

	@JsonProperty("BMCServiceDesk__orderNumber__c")
	private String bmcOrderNumber;

	@JsonProperty("BMCServiceDesk__systemTemplate__c")
	private Boolean bmcSystemTemplate;

	@JsonProperty("BMCServiceDesk__templateFor__c")
	private String bmcTemplateFor;

	@JsonProperty("BMCServiceDesk__Export__c")
	private Boolean bmcExport;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedById() {
		return createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLastModifiedById() {
		return lastModifiedById;
	}

	public void setLastModifiedById(String lastModifiedById) {
		this.lastModifiedById = lastModifiedById;
	}

	public String getSystemModstamp() {
		return systemModstamp;
	}

	public void setSystemModstamp(String systemModstamp) {
		this.systemModstamp = systemModstamp;
	}

	public Boolean getBmcHasRecurrence() {
		return bmcHasRecurrence;
	}

	public void setBmcHasRecurrence(Boolean bmcHasRecurrence) {
		this.bmcHasRecurrence = bmcHasRecurrence;
	}

	public Boolean getBmcIgnoreExecutionOrder() {
		return bmcIgnoreExecutionOrder;
	}

	public void setBmcIgnoreExecutionOrder(Boolean bmcIgnoreExecutionOrder) {
		this.bmcIgnoreExecutionOrder = bmcIgnoreExecutionOrder;
	}

	public String getBmcRecurrenceDayOfMonth() {
		return bmcRecurrenceDayOfMonth;
	}

	public void setBmcRecurrenceDayOfMonth(String bmcRecurrenceDayOfMonth) {
		this.bmcRecurrenceDayOfMonth = bmcRecurrenceDayOfMonth;
	}

	public String getBmcRecurrenceDayOfWeekMask() {
		return bmcRecurrenceDayOfWeekMask;
	}

	public void setBmcRecurrenceDayOfWeekMask(String bmcRecurrenceDayOfWeekMask) {
		this.bmcRecurrenceDayOfWeekMask = bmcRecurrenceDayOfWeekMask;
	}

	public String getBmcRecurrenceEndDate() {
		return bmcRecurrenceEndDate;
	}

	public void setBmcRecurrenceEndDate(String bmcRecurrenceEndDate) {
		this.bmcRecurrenceEndDate = bmcRecurrenceEndDate;
	}

	public String getBmcRecurrenceHour() {
		return bmcRecurrenceHour;
	}

	public void setBmcRecurrenceHour(String bmcRecurrenceHour) {
		this.bmcRecurrenceHour = bmcRecurrenceHour;
	}

	public String getBmcRecurrenceInstance() {
		return bmcRecurrenceInstance;
	}

	public void setBmcRecurrenceInstance(String bmcRecurrenceInstance) {
		this.bmcRecurrenceInstance = bmcRecurrenceInstance;
	}

	public String getBmcRecurrenceInterval() {
		return bmcRecurrenceInterval;
	}

	public void setBmcRecurrenceInterval(String bmcRecurrenceInterval) {
		this.bmcRecurrenceInterval = bmcRecurrenceInterval;
	}

	public String getBmcRecurrenceMinutes() {
		return bmcRecurrenceMinutes;
	}

	public void setBmcRecurrenceMinutes(String bmcRecurrenceMinutes) {
		this.bmcRecurrenceMinutes = bmcRecurrenceMinutes;
	}

	public String getBmcRecurrenceMonthOfYear() {
		return bmcRecurrenceMonthOfYear;
	}

	public void setBmcRecurrenceMonthOfYear(String bmcRecurrenceMonthOfYear) {
		this.bmcRecurrenceMonthOfYear = bmcRecurrenceMonthOfYear;
	}

	public String getBmcRecurrenceStartDate() {
		return bmcRecurrenceStartDate;
	}

	public void setBmcRecurrenceStartDate(String bmcRecurrenceStartDate) {
		this.bmcRecurrenceStartDate = bmcRecurrenceStartDate;
	}

	public String getBmcRecurrenceType() {
		return bmcRecurrenceType;
	}

	public void setBmcRecurrenceType(String bmcRecurrenceType) {
		this.bmcRecurrenceType = bmcRecurrenceType;
	}

	public String getBmcRecurrence() {
		return bmcRecurrence;
	}

	public void setBmcRecurrence(String bmcRecurrence) {
		this.bmcRecurrence = bmcRecurrence;
	}

	public String getBmcSelfServiceDisplayOrder() {
		return bmcSelfServiceDisplayOrder;
	}

	public void setBmcSelfServiceDisplayOrder(String bmcSelfServiceDisplayOrder) {
		this.bmcSelfServiceDisplayOrder = bmcSelfServiceDisplayOrder;
	}

	public String getBmcSequence() {
		return bmcSequence;
	}

	public void setBmcSequence(String bmcSequence) {
		this.bmcSequence = bmcSequence;
	}

	public Boolean getBmcAllProfile() {
		return bmcAllProfile;
	}

	public void setBmcAllProfile(Boolean bmcAllProfile) {
		this.bmcAllProfile = bmcAllProfile;
	}

	public String getBmcDescription() {
		return bmcDescription;
	}

	public void setBmcDescription(String bmcDescription) {
		this.bmcDescription = bmcDescription;
	}

	public Boolean getBmcInactive() {
		return bmcInactive;
	}

	public void setBmcInactive(Boolean bmcInactive) {
		this.bmcInactive = bmcInactive;
	}

	public String getBmcKeywords() {
		return bmcKeywords;
	}

	public void setBmcKeywords(String bmcKeywords) {
		this.bmcKeywords = bmcKeywords;
	}

	public String getBmcOrderNumber() {
		return bmcOrderNumber;
	}

	public void setBmcOrderNumber(String bmcOrderNumber) {
		this.bmcOrderNumber = bmcOrderNumber;
	}

	public Boolean getBmcSystemTemplate() {
		return bmcSystemTemplate;
	}

	public void setBmcSystemTemplate(Boolean bmcSystemTemplate) {
		this.bmcSystemTemplate = bmcSystemTemplate;
	}

	public String getBmcTemplateFor() {
		return bmcTemplateFor;
	}

	public void setBmcTemplateFor(String bmcTemplateFor) {
		this.bmcTemplateFor = bmcTemplateFor;
	}

	public Boolean getBmcExport() {
		return bmcExport;
	}

	public void setBmcExport(Boolean bmcExport) {
		this.bmcExport = bmcExport;
	}
	
	

}
