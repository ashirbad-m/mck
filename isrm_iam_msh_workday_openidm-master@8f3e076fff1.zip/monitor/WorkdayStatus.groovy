/*Copyright McKesson 2015*/

import groovy.json.JsonSlurper

enum WDStatus { OK, FAILURE, WARNING }

/**
 * Start with hh:mm time start checking and week comma separated list for days checking
 * For example WorkdayStatus 0:30 1,2,3,4,5,6
 */
class WorkdayStatus {

  def String faultMsg = ""

  static void main(String... args) {
    if (args?.length != 2) {
      print "Start with hh:mm time start checking and week comma separated list for days checking as command line parameters"
      return
    }
    def WorkdayStatus wdst = new WorkdayStatus()

    def status = wdst.processInputJsonStream(wdst.getStartDate(args[0],args[1]))
    print status
    print '\n'
    print wdst.faultMsg
    print '\n'
    return
  }

  /*
   * Process reconciliations OpenIDM Json output
   */
  WDStatus processInputJsonStream(Date checkDate) {
    def prs = "y-M-d H:m:s.S"
    if (null == checkDate) {
      return WDStatus.OK
    }
    def inputJSON
    try {
      inputJSON = new JsonSlurper().parseText(System.in.text)
    } catch (Throwable e) {
      faultMsg = "No data or incorrect data to check status."
      return WDStatus.WARNING
    }
    def started = false
    def status = true
    if (0 < inputJSON?.reconciliations.size()) {
      inputJSON.reconciliations.each {
	def ds = it.started.replace("T"," ")
	def taskDate = Date.parse(prs,ds)
	if (checkDate < taskDate) {
	  started = true
	  if ( (-1 < it?.state?.indexOf("FAIL")) || (-1 < it?.stage?.indexOf("FAIL")) ) {
	    status = false
	    faultMsg = it?.toString()
	  }
	}
      }
    }
    if (! started) {
      faultMsg = "Not started yet!"
    }
    if (started && status) {
      return WDStatus.OK
    } else return WDStatus.FAILURE
  }

  /*
   * Getting date for task checking
   * h_m : time string like 17:30
   * days_of_week : comma separated days ow week like 1,2,3,4,5
   */
  Date getStartDate(String h_m, String days_of_week) {
    def n = Calendar.instance
    Date nowDate = n.time
    def dw = days_of_week?.split ","
    def propper_day = false
    dw.each {
      if (new Integer(it) == nowDate[Calendar.DAY_OF_WEEK]) {
	  propper_day = true
	}
    }
    if (propper_day) {
	def t = h_m?.split ":"
	n.set nowDate[Calendar.YEAR], nowDate[Calendar.MONTH], nowDate[Calendar.DATE], new Integer(t[0]), new Integer(t[1]), 0
	def Date expdate = n.time
	if (nowDate > expdate) return expdate
      }
    return null
  }

}

