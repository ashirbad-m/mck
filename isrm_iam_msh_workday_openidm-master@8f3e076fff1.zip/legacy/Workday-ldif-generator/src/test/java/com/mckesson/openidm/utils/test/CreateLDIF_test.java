package com.mckesson.openidm.utils.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.forgerock.opendj.ldap.DN;
import org.forgerock.opendj.ldap.ModificationType;
import org.forgerock.opendj.ldap.requests.Requests;
import org.forgerock.opendj.ldif.ChangeRecord;
import org.forgerock.opendj.ldif.LDIFChangeRecordWriter;
import org.forgerock.opendj.ldif.LDIFEntryWriter;
import org.junit.Assert;
import org.junit.Test;

public class CreateLDIF_test {
	
	
	
	
	@Test
	public void testJSONParser() throws JsonParseException, JsonMappingException, IOException{
		
		String jsonData = "{\"streetAddress\":{\"new\":\"1330 E 6th St\",\"old\":\"1330 E 6th Street  Suite 204\"},\"facsimileTelephoneNumber\":{\"new\":\"\",\"old\":\"956-968-9744\"},\"street\":{\"new\":\"1330 E 6th St\",\"old\":null},\"state\":{\"new\":\"Texas\",\"old\":\"Southwest\"},\"country\":{\"new\":\"USA\",\"old\":\"US\"},\"workerType\":{\"new\":\"Full time\",\"old\":\"Full Time - Regular\"},\"_id\":\"%3CGUID%3D97bfe7aac8481849bf4845e006f60361%3E\",\"mobilePhone\":{\"new\":\"\",\"old\":null},\"description\":{\"new\":\"Mgr, Nursing Services, Weslaco, Texas\",\"old\":\"Mgr, Nursing Services WESLACO TX\"},\"telephoneNumber\":{\"new\":\"\",\"old\":\"956-969-0021\"},\"ID\":{\"_id\":\"%3CGUID%3D97bfe7aac8481849bf4845e006f60361%3E\",\"dn\":\"CN=Cura\\\\, Judith,OU=Users,OU=South - Rio Grande Valley,OU=TX_TXO,OU=CSA,DC=uson,DC=usoncology,DC=int\"},\"postalAddress\":{\"new\":\"1330 E 6th St\\r\\nWeslaco, TX 78596\\r\\nUnited States of America\",\"old\":null},\"physicalDeliveryOfficeName\":{\"new\":\"HR083,Weslaco,1330 E 6th St\",\"old\":\"Texas Oncology - Weslaco\"},\"st\":{\"new\":\"Texas\",\"old\":\"TX\"}}";
		
		Map<String,Object> jsonDataMap = new HashMap<String,Object>(){
			{
				put("ID",new HashMap<String,String>(){{
					put("_id","");
					put("dn","");
				}});
				put("streetAddress",new HashMap<String,String>(){{
					put("old","1330 E 6th Street  Suite 204");
					put("new","1330 E 6th St");
				}});
				put("facsimileTelephoneNumber",new HashMap<String,String>(){{
					put("old","956-968-9744");
					put("new",null);
				}});
				put("street",new HashMap<String,String>(){{
					put("old","null");
					put("new","1330 E 6th St");
				}});
				put("state",new HashMap<String,String>(){{
					put("old","Southwest");
					put("new","Texas");
				}});
				put("workerType",new HashMap<String,String>(){{
					put("old","");
					put("new","");
				}});
				put("description",new HashMap<String,String>(){{
					put("old","Mgr, Nursing Services WESLACO TX");
					put("new","Mgr, Nursing Services, Weslaco, Texas");
				}});
				put("postalAddress",new HashMap<String,String>(){{
					put("old","null");
					put("new","1330 E 6th St Weslaco, TX 78596 United States of America");
				}});
			}
			
		};
		
		
		ObjectMapper OBJECT_MAPPER = new ObjectMapper();
		TypeReference<LinkedHashMap<String,Object>> TYPE_REF = new TypeReference<LinkedHashMap<String,Object>>() {}; 

		
		//String jsonData = new ObjectMapper().writeValueAsString(jsonDataMap);
		Map<String, Map<String,String>>  data = OBJECT_MAPPER.readValue(jsonData, TYPE_REF);
		Assert.assertNotNull(data);
		Assert.assertNotNull(data.get("ID"));
		Assert.assertNotNull(data.get("ID").get("dn"));
		Assert.assertNotNull(data.get("streetAddress").get("old"));
		Assert.assertNotNull(data.get("streetAddress").get("new"));
		
		System.out.println(data);

		
	}
	
	@Test
	public void testCreateLDIF() throws IOException{
		DN dn = DN.valueOf("CN=Cura\\, Judith,OU=Users,OU=South - Rio Grande Valley,OU=TX_TXO,OU=CSA,DC=uson,DC=usoncology,DC=int");
		
		LDIFEntryWriter createWriter = new LDIFEntryWriter(System.out);
		LDIFChangeRecordWriter changeWriter = new LDIFChangeRecordWriter(System.out);
		
		/*
		Entry ldifEntry = new LinkedHashMapEntry(dn);
		Attribute attr = new LinkedAttribute("phone", "555-555-55-55");
		ldifEntry.addAttribute(attr);
		
		createWriter.writeEntry(ldifEntry);
		
		createWriter.flush();
		createWriter.close();
		
		*/
		ChangeRecord changeRec = Requests.newModifyRequest(dn).addModification(ModificationType.DELETE, "phone", "");
		
		changeWriter.writeChangeRecord(changeRec);
		changeWriter.writeChangeRecord(changeRec);
		changeWriter.writeChangeRecord(changeRec);
		changeWriter.writeChangeRecord(changeRec);
		
		changeWriter.flush();
		changeWriter.close();
	}

}
