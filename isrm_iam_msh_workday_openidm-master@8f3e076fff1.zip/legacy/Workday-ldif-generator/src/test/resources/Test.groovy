import groovyx.net.http.HttpResponseException;

import java.util.List;
import java.util.Map;
import java.text.SimpleDateFormat;



import org.identityconnectors.framework.common.objects.ObjectClass;


/**
 * Search  method
 * @param objClass
 * @param query
 * @return
 */
private List doSearch(String objClass, Map query){
	
	def result = [];
	if (query.get("StartDate") == null){
		query.put("StartDate", new SimpleDateFormat("MM/dd/yyyy hh:mm a").format(new Date(0)));
	}
	Map response = connection.get(["query":query]).data;
	log.ok("Got response:" +response);
	
	def accessList = response.get("AccessList"); 
	
	//process result 
	for (user in accessList){
		//sample response
		/*{[AccessList:[[
		 *      Product:Caremark, 
		 *      Market:Software Vendor, 
		 *      UserID:1234, 
		 *      SpecialPrivilege:null]]
		*/
		result.add([
			 __UID__:user.UserID, 
			 __NAME__:user.UserID, 
			 Uid: user.UserID, 
			 Product: user.Product,
			 Market: user.Market,
			 SpecialPrivilege: user.SpecialPrivilege]);
	}

	//search recursive if until LastID is null
	if (response.LastID != null){
		
	    Map newQuery = new HashMap(query);
		newQuery.put("LastID",response.LastID)
		result.addAll(doSearch(objClass,newQuery))
	}
	return result;
};

/**
 * Create method
 * @param objClass
 * @param attrs
 * @return
 */
private Object doCreate(String objClass, Map attrs){
	
    def response;
		
	def body = new groovy.json.JsonBuilder( 
		    [UserID: attrs["UserID"].get(0),
			MPSNumber: attrs["MPSNumber"].get(0),
			NCPDP: attrs["NCPDP"].get(0)]
			);
	
	
	try {
			response = connection.post(["body":body.toString(),"contentType":"application/json"]);
	        log.ok("Got response: "+response)

	} catch (HttpResponseException e) {
	    log.error(e, ""+e.response.data);
		throw e;
		return null;
	}
	
	return response.data["UserID"];

};

private void doTest(){
	
}


def result = []




switch (action) {
	
	case "TEST":
        doTest();
	break;

	case "CREATE":
	  return doCreate(objectClass, attributes);

	break;
	case "SEARCH":
	  
      result.addAll(doSearch(objectClass, query == null ? new HashMap() : query));
	break;
}


return result;

