package com.mckesson.openidm.utils;

public enum Category {

	TITLE_DESCRIPTION, MANAGERS, NAMING, PHONE, ADDRESS, MAIL, ACCOUNT_STATE, DOMAIN, ORGANIZATIONAL, OTHER, MOVE_USER;

}
