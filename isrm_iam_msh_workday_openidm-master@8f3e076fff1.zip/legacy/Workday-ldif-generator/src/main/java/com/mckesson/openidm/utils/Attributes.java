package com.mckesson.openidm.utils;

import static com.mckesson.openidm.utils.Category.*;

public enum Attributes {

	COMMON_NAME("commonName" ,"cn", NAMING),
	SAMACCOUNT_NAME("sAMAccountName", "sAMAccountName", NAMING),
	MIDDLE_NAME("middleName", "middleName", NAMING),
	SHORT_NAME("__SHORT_NAME__", "SHORT_NAME", NAMING),
	FIRST_NAME("firstName", "givenName", NAMING),
	LEGAL_NAME("legalName", "name", NAMING),
	EMAIL("mail" ,"mail", MAIL),
	ENABLED("enable", "ENABLE", ACCOUNT_STATE),
	COMPANY("company", "company", ORGANIZATIONAL),
	DESCRIPTION("description", "description", TITLE_DESCRIPTION),
	DIVISION("division", "division", ORGANIZATIONAL),
	DISPLAY_NAME("displayName", "displayName", NAMING),
	FAX("facsimileTelephoneNumber", "facsimileTelephoneNumber", PHONE),
	CITY("city", "l", ADDRESS),
	HOME_DIRECTORY("homeDirectory", "homeDirectory", DOMAIN),
	POSTAL_CODE("postalCode", "postalCode", ADDRESS),
	STATE("st", "st", ADDRESS),
	MANAGER("manager", "manager", MANAGERS),
	DEPARTMENT("department" ,"department", ORGANIZATIONAL),
	INITIALS("initials", "initials", NAMING),
	LAST_NAME("lastName", "sn", NAMING),
	PASSWORD_EXPIRED("__PASSWORD_EXPIRED__", "PASSWORD_EXPIRED", ACCOUNT_STATE),
	LOCKOUT("__LOCK_OUT__" ,"LOCK_OUT", ACCOUNT_STATE),
	STREET_ADDRESS("streetAddress", "streetAddress", ADDRESS),
	EMPLOYEE_ID("employeeID", "extensionAttribute8", ORGANIZATIONAL),
	COUNTRY("country", "co", ADDRESS),
	TELEPHONE_NUMBER("telephoneNumber", "telephoneNumber", PHONE),
	TITLE("title", "title", TITLE_DESCRIPTION),
	STATE2("state", "extensionAttribute2", ADDRESS),
	WORKER_TYPE("workerType", "extensionAttribute3", ORGANIZATIONAL),
	HOME_DRIVE("homeDrive", "homeDrive", DOMAIN),
	MOBILE_PHONE("mobilePhone", "mobile", PHONE),
	POSTAL_ADDRESS("postalAddress", "postalAddress", ADDRESS),
	SHOW_IN_ADDRESS_BOOK("showInAddressBook", "showInAddressBook", DOMAIN),
	USER_PRINCIPAL_NAME("userPrincipalName", "userPrincipalName", NAMING),
	PRIMARY_GROUP_ID("primaryGroupID" ,"primaryGroupID", DOMAIN),
	STREET("street", "street", ADDRESS),
	SCRIPT_PATH("scriptPath", "scriptPath", DOMAIN),
	PHYSICAL_DELIVERY_OFFICE_NAME("physicalDeliveryOfficeName", "physicalDeliveryOfficeName", ADDRESS),
	USER_ACCOUNT_CONTROL("userAccountControl", "userAccountControl", ACCOUNT_STATE),
	PWD_LAST_SET("pwdLastSet", "pwdLastSet", ACCOUNT_STATE),
	ACCOUNT_EXPIRES("accountExpires", "accountExpires", ACCOUNT_STATE),
	TS_PROFILE_PATH("terminalServicesProfilePath", "TerminalServicesProfilePath", DOMAIN);
	
	private final String name;
	
	private final String nativeName;
	
	private final Category category;
	
	private Attributes(String name, String nativeName, Category category) {
		this.name = name;
		this.nativeName = nativeName;
		this.category = category;
	}

	public static Attributes getByName(String name) {
		for (Attributes value : Attributes.values()) {
			if (name.equals(value.name)) {
				return value;
			}
		}
		
		return null;
	}
	
	public String getName() {
		return name;
	}
	
	public String getNativeName() {
		return nativeName;
	}
	
	public Category getCategory() {
		return category;
	}
}
