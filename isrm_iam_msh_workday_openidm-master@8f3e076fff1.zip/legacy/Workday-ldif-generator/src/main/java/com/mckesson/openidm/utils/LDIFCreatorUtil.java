package com.mckesson.openidm.utils;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.forgerock.opendj.ldap.DN;
import org.forgerock.opendj.ldap.Entry;
import org.forgerock.opendj.ldap.LinkedAttribute;
import org.forgerock.opendj.ldap.LinkedHashMapEntry;
import org.forgerock.opendj.ldap.ModificationType;
import org.forgerock.opendj.ldap.requests.ModifyDNRequest;
import org.forgerock.opendj.ldap.requests.ModifyRequest;
import org.forgerock.opendj.ldap.requests.Requests;
import org.forgerock.opendj.ldif.LDIFChangeRecordWriter;

public class LDIFCreatorUtil {

	private String JDBC_DRIVER;
	private String JDBC_DB_URL;
	private String JDBC_USER;
	private String JDBC_PASS;
	private String SQL_QUERY;

	private String LDIF_FILENAME;
	//LDIFEntryWriter createWriter;
	LDIFChangeRecordWriter changeWriter;

	ObjectMapper OBJECT_MAPPER = new ObjectMapper();
	TypeReference<LinkedHashMap<String, Object>> TYPE_REF = new TypeReference<LinkedHashMap<String, Object>>() {
	};

	
	
	public static void main(String[] args) {
		LDIFCreatorUtil utl = new LDIFCreatorUtil();
		utl.JDBC_DRIVER = "com.mysql.jdbc.Driver";
		utl.JDBC_DB_URL = "jdbc:mysql://directory.iam.mckesson.com:3306/msh_idm_repo?useSSL=true&requireSSL=true&verifyServerCertificate=false&characterEncoding=utf8";
		utl.JDBC_USER = "msh_idm_usr";
		utl.JDBC_PASS = "lR5khI34ziYwRpT8vdV2";
		utl.SQL_QUERY = "select mu.workerID as id, aar.action, aar.target from audit_async_recon aar join manageduser mu on aar.sourceid = mu.objectid where aar.action like 'AD%User%' and aar.reconid='7c29b1e2-a3ce-4cfb-ac87-ee21a4ebb7d7' order by aar.sourceid, aar.id";
		utl.LDIF_FILENAME = "c:/work/msh/";
		
		try {
			utl.run();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void run() throws Exception {

		Connection conn = null;
		Statement stmt = null;
		OutputStream ldifOut = null;
		try {

			Class.forName(this.JDBC_DRIVER);

			conn = DriverManager.getConnection(this.JDBC_DB_URL,
					this.JDBC_USER, this.JDBC_PASS);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(this.SQL_QUERY);

			List<Modification> modifications = new ArrayList<Modification>();

			while (rs.next()) {

				String recID = rs.getString("id");
				String actionType = rs.getString("action");
				String actionData = rs.getString("target");

				try {
					processAction(recID, actionType, actionData, modifications);
				} catch (Exception e) {
					System.out.println("failed for id=" + recID);
					e.printStackTrace();
				}

			}
			rs.close();
			stmt.close();
			conn.close();
			
			Collections.sort(modifications);

			for (Category category: Category.values()) {
				try {
					ldifOut = new BufferedOutputStream(new FileOutputStream(LDIF_FILENAME + category.toString().toLowerCase() + ".ldif", false));
					//createWriter = new LDIFEntryWriter(ldifOut);
					changeWriter = new LDIFChangeRecordWriter(ldifOut);
					changeWriter.writeComment("**** UPDATES FOR Category: " + category);
					
					for (Modification modification: modifications) {
						if (modification.getCategory() != category) {
							continue;
						}
						
						changeWriter.writeComment("Update for worker: " + modification.getId());
						if (modification.getModifyRequest() != null) {
							changeWriter.writeChangeRecord(modification.getModifyRequest());
						}
						if (modification.getModifyDNRequest() != null) {
							changeWriter.writeChangeRecord(modification.getModifyDNRequest());
						}
						
					}
				} finally {
					//createWriter.close();
					changeWriter.close();
					ldifOut.flush();
					ldifOut.close();
				}
			}
			
		} catch (SQLException se) {

			se.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			if (stmt != null) {
				stmt.close();
			}

			if (conn != null) {
				conn.close();
			}

			
		}
		System.out.println("Done!");

	}

	private void processAction(String id, String actionType, String actionData, List<Modification> modifications)
			throws Exception {

		id = id.replaceAll("[\\r\\n]", "");
		
		if ("AD.updateUser".equals(actionType)) {
			Map<String, Object> data = getData(actionData);
			
			for (Category category: Category.values()) {
				ModifyRequest modifyRequest = createModifyRequest(Mappings.getMappings().get(id), data, category);
				
				if (modifyRequest.getModifications().size() == 0) {
					continue;
				}
				
				modifications.add(new Modification(id, category, modifyRequest, null));
			}
			

		} else if ("AD.moveUserToOU".equals(actionType)) {
			Map<String, Object> data = getData(actionData);
			String dn = Mappings.getMappings().get(id);
			if (dn != null) {
				String newDN = (String) data.get("distinguishedName");
				
				if (!newDN.toLowerCase(Locale.US).contains("termination")) {
					DN newDN2 = DN.valueOf(newDN);
					
					ModifyDNRequest modifyDNRequest = Requests.newModifyDNRequest(DN.valueOf(dn), newDN2.rdn());
					modifyDNRequest.setNewSuperior(newDN2.parent());
					modifyDNRequest.setDeleteOldRDN(true);

					modifications.add(new Modification(id, Category.MOVE_USER, null, modifyDNRequest));
				}
			}
			
		} else if ("ABSENT".equals(actionType)) {
			//TODO - new user
			
			//Entry ldifEntry = createEntryREcord(actionData);
			//changeWriter.writeComment("Create for ID:" + id);
			//changeWriter.writeChangeRecord(Requests.newAddRequest(ldifEntry));
			

		} else {
			System.out.println("");
		}

	}

	private Entry createEntryREcord(String actionData) throws Exception {

		Map<String, Map<String, String>> data = OBJECT_MAPPER.readValue(
				actionData, TYPE_REF);
		String dn = getDN(data);
		Entry ldifEntry = new LinkedHashMapEntry(dn);

		for (java.util.Map.Entry<String, Map<String, String>> e : data
				.entrySet()) {
			// skip "ID", "password", "dn" and empty values
			if ("ID".equalsIgnoreCase(e.getKey())
					|| "password".equalsIgnoreCase(e.getKey())
					|| "dn".equalsIgnoreCase(e.getKey())
					|| "_id".equalsIgnoreCase(e.getKey())
					|| e.getValue() == null)
				continue;
			ldifEntry
					.addAttribute(new LinkedAttribute(e.getKey(), e.getValue()));
		}

		return ldifEntry;
	}

	private Map<String, Object> getData(String s) throws JsonParseException, JsonMappingException, IOException {
		return OBJECT_MAPPER.readValue(s, TYPE_REF);

	}
	
	private ModifyRequest createModifyRequest(String dn, Map<String, Object> data, Category requestedCategory)
			throws Exception {
		
		//if (dn == null) {
			dn = getDN(data);
		//}

		ModifyRequest modifyRequest = Requests.newModifyRequest(dn);

		for (java.util.Map.Entry<String, Object> e : data.entrySet()) {
			// skip "ID" entry in the map
			if ("ID".equalsIgnoreCase(e.getKey()) ||
				"_id".equalsIgnoreCase(e.getKey()))	{
				continue;
			}
			
			if ("isManagerLinked".equalsIgnoreCase(e.getKey()) || 
					"isPasswordSet".equalsIgnoreCase(e.getKey()) || "active".equalsIgnoreCase(e.getKey()) || 
					"hrbu".equalsIgnoreCase(e.getKey()) || "employee".equalsIgnoreCase(e.getKey()) || 
					"nameData".equalsIgnoreCase(e.getKey())) {
				continue;
			}

			if ("groups".equalsIgnoreCase(e.getKey())) {
				//TODO - groups change
				continue;
			}
			
			if ("distinguishedName".equalsIgnoreCase(e.getKey()) || "dn".equalsIgnoreCase(e.getKey()) || "userPassword".equalsIgnoreCase(e.getKey())) {
				//TODO - moving user to another OU
				continue;
			}
			
			String newValue = null;
			
			Object value = e.getValue();
			if (value instanceof Map<?, ?>) {
				Map<String, String> map = (Map<String, String>) value;
				value = map.get("new");
			} else if ("manager".equalsIgnoreCase(e.getKey())) {
				value = String.valueOf(value);
			}
			
			if (value != null) {
				newValue = String.valueOf(value);
			}
			
			Category attrCategory;
			String attrName;
			Attributes attribute = Attributes.getByName(e.getKey());
			if (attribute != null) {
				attrName = attribute.getNativeName();
				attrCategory = attribute.getCategory();
			} else {
				attrName = e.getKey();
				attrCategory = Category.OTHER;
			}
			
			if (attrCategory != requestedCategory) {
				continue;
			}
			
			String maskedNewValue = (newValue == null || "null".equals(newValue.trim())) ? "" : newValue;
			
			if (maskedNewValue.length() == 0 && !attrName.equals("initials") && !attrName.equals("telephoneNumber") && !attrName.equals("facsimileTelephoneNumber") && !attrName.equals("mobile")) {
				System.out.println("LDIFCreatorUtil.createModifyRequest() " + attrName);
				continue;
			}
			
			if (maskedNewValue.length() != 0) {
				modifyRequest.addModification(ModificationType.REPLACE, attrName, maskedNewValue);
			} else {
				modifyRequest.addModification(ModificationType.DELETE, attrName);
			}

			/**
			 * if (newValue == null || "null".equals(newValue)){
			 * modifyRequest.addModification(ModificationType.DELETE,
			 * e.getKey(), oldValue == null ? "" : oldValue); } else if(oldValue
			 * == null || "null".equals(oldValue)){
			 * modifyRequest.addModification(ModificationType.ADD, e.getKey(),
			 * newValue == null ? "" : newValue); } else{
			 * modifyRequest.addModification(ModificationType.REPLACE,
			 * e.getKey(), newValue == null ? "" : newValue); }
			 **/
		}

		return modifyRequest;
	}

	/**
	 * get DN either prop "dn" or "ID->dn"
	 * @param data
	 * @return
	 */
	private String getDN(Map data) {
		String dn = null;
		Map<String, String> idRecord = (Map<String, String>) data.get("ID");
		if (idRecord != null){
			dn = idRecord.get("dn");	
		}else{
			dn = (String) data.get("dn");
		}
		
		if (dn == null) {
			throw new IllegalArgumentException("DN not found for: "
					+ data.toString());
		}

		
		return dn;
	}
}
