package com.mckesson.openidm.utils;

import org.forgerock.opendj.ldap.requests.ModifyDNRequest;
import org.forgerock.opendj.ldap.requests.ModifyRequest;

public class Modification implements Comparable<Modification> {

	private final String id;
	
	private final Category category;
	
	private final ModifyRequest modifyRequest;
	
	private final ModifyDNRequest modifyDNRequest;

	public Modification(String id, Category category, ModifyRequest modifyRequest, ModifyDNRequest modifyDNRequest) {
		super();
		this.id = id;
		this.category = category;
		this.modifyRequest = modifyRequest;
		this.modifyDNRequest = modifyDNRequest;
	}
	
	public String getId() {
		return id;
	}
	
	public Category getCategory() {
		return category;
	}
	
	public ModifyRequest getModifyRequest() {
		return modifyRequest;
	}

	public ModifyDNRequest getModifyDNRequest() {
		return modifyDNRequest;
	}
	
	@Override
	public int compareTo(Modification o) {
		if (this.getCategory() != o.getCategory()) {
			return this.getCategory().compareTo(o.getCategory());
		}
		
		return getId().compareTo(o.getId());
	}
	
}
