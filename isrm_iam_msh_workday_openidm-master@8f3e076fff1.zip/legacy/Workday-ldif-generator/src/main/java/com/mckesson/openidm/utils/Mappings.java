package com.mckesson.openidm.utils;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Mappings {

	private static final Map<String, String> mappings = new HashMap<String, String>();
	
	static {
		try {
			BufferedReader reader = new BufferedReader(new FileReader("c:/Users/els1gkr/Documents/MSH/uson_usoncology_int_636 (DC=uson).csv"));
			
			while (true) {
				String string = reader.readLine();
				
				if (string == null) {
					break;
				}
				
				int idx = string.indexOf(",");
				
				mappings.put(string.substring(0, idx), string.substring(idx + 1));
			}
			
			
			reader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static Map<String, String> getMappings() {
		return mappings;
	}
}
