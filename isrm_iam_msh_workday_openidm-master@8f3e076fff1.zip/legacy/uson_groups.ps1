Import-Csv groups.csv -OutVariable groups | Out-Null

foreach ($group in $groups) 
{
    $id = $group.id;
    $dn = $group.dn;
    $cn = [regex]::replace($dn, '^CN=([^,]+),.+$', '$1')

    $groupObject = Get-ADObject -Filter { cn -eq $cn } -Server uson.usoncology.int
    $groupDN = $groupObject.DistinguishedName;

    if ($groupDN.length -eq 0)
    {
        Write-Host ("Group ""{0}"" is missing" -f $cn) -foregroundcolor red;
        continue;
    }

    if ($groupDN -ne $dn)
    {
        $sql = "UPDATE msh_idm_repo.group_mapping SET dn=""{0}"" WHERE id={1};" -f $groupDN, $id;
        $sql
    }
}
