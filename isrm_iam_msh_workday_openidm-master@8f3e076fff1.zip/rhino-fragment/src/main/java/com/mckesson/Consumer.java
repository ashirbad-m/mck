package com.mckesson;

public interface Consumer<T> {

    public void accept(T t);

}
