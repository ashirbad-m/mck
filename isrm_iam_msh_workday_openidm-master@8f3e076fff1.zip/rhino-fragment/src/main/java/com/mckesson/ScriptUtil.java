package com.mckesson;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.forgerock.json.fluent.JsonValue;
import org.forgerock.json.resource.JsonResourceContext;
import org.forgerock.openidm.objset.ObjectSetContext;
import org.forgerock.openidm.script.javascript.ScriptableWrapper;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ScriptUtil {

    private static final long MILLISECONDS_IN_MINUTE = TimeUnit.MILLISECONDS.convert(1, TimeUnit.MINUTES);

    private static final Logger LOGGER = LoggerFactory.getLogger(ScriptUtil.class);

    private static final String FRACTION_FORMAT = "yyyyMMddHHmmss.SSS";

    private static final String FRACTIONLESS_FORMAT = "yyyyMMddHHmmss";

    private static final Pattern TIMEZONE_SEPARATOR = Pattern.compile("[Z+-]");

    private static final Map<String, Lock> GLOBAL_LOCKS = new HashMap<String, Lock>();

    private static final Set<String> UTC_TIMEZONES;
    private static final TimeZone HARDCODED = TimeZone.getTimeZone("UTC");

    private static final String S_FIRST_SDF = "yyyy-MM-dd";
    private static final String S_SECOND_SDF = "HH:mm:ss.SSS";
    private static volatile String HOST_NAME;

    static {
        UTC_TIMEZONES = new HashSet<String>();
        UTC_TIMEZONES.add("+00");
        UTC_TIMEZONES.add("-00");
        UTC_TIMEZONES.add("+0000");
        UTC_TIMEZONES.add("-0000");
    }

    public static final Pattern START_TIME_PATTERN = Pattern.compile("(\\d\\d)(\\d\\d)");
    public static final long SLEEP_PAUSE = 5000L;

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private static final TypeReference<LinkedHashMap<String, Object>> MAP_TYPE_REF = new TypeReference<LinkedHashMap<String, Object>>() {};

    private static final TypeReference<LinkedList<Object>> LIST_TYPE_REF = new TypeReference<LinkedList<Object>>() {};

    public static class ReconInfo {

        private static final Pattern HOURS_PATTREN = Pattern.compile("(\\d\\d)(\\d\\d) ?");

        private static Calendar cloneCalendar (Calendar source) {
            return (Calendar)source.clone();
        }

        private transient Calendar now, nearest, maximum, parsed;
        private transient Matcher matcher;
        private transient long maxHour, maxMin, duration;

        private String startDate;
        private boolean shouldBeFinish;

        ReconInfo(String sTimes, String sDuration) throws Exception {
            if (sTimes == null) {
                throw new Exception("Times not found");
            }
            if (sDuration == null) {
                throw new Exception("Duration not found");
            }
            try {
                init(sTimes, sDuration);
                process();
                assign();
            } finally {
                clean();
            }
        }
        private void process () throws Exception {
            boolean nearestFound = false;
            boolean maximumFound = false;
            while(parseNext()) {
                if(!(parsed.before(nearest) || parsed.after(now))){
                    nearest = cloneCalendar(parsed);
                    nearestFound = true;
                }
                if (!parsed.before(maximum)) {
                    maximum = cloneCalendar(parsed);
                    maximumFound = true;
                }
            }
            if (!nearestFound) {
                if (maximumFound) {
                    // Latest yesterday
                    maximum.add(Calendar.DAY_OF_MONTH, -1);
                    nearest = maximum;
                } else {
                    throw new Exception("Time-points not found.");
                }
            }
        }
        private boolean parseNext () throws Exception {
            if(!matcher.find()) {
                return false;
            }

            int h = Integer.parseInt(matcher.group(1));
            if (h > maxHour) {
                throw new Exception("Illegal hours-value: " + h);
            }

            int m = Integer.parseInt(matcher.group(2));
            if (m > maxMin) {
                throw new Exception("Illegal minutes-value: " + m);
            }

            parsed.set(Calendar.HOUR_OF_DAY, h);
            parsed.set(Calendar.MINUTE, m);

            return true;
        }
        private void init(String sTimes, String sDuration) throws Exception {
            duration = Long.parseLong(sDuration);

            now = Calendar.getInstance();

            maxHour = now.getMaximum(Calendar.HOUR_OF_DAY);
            maxMin = now.getMaximum(Calendar.MINUTE);

            if (
                duration <= 0L ||
                duration >= ((maxHour + 1L) * (maxMin + 1L))
            ) {
                throw new Exception("Illegal dutration-value: " + duration);
            }

            nearest = cloneCalendar(now);
            nearest.set(Calendar.MILLISECOND, 0);
            nearest.set(Calendar.SECOND, 0);
            nearest.set(Calendar.MINUTE, 0);
            nearest.set(Calendar.HOUR_OF_DAY, 0);

            maximum = cloneCalendar(nearest);

            parsed = cloneCalendar(now);
            parsed.set(Calendar.MILLISECOND, 0);
            parsed.set(Calendar.SECOND, 0);

            matcher = HOURS_PATTREN.matcher(sTimes);

        }
        private void assign () {
            startDate = dateFormat(nearest.getTime(), HARDCODED);
            shouldBeFinish = TimeUnit.MILLISECONDS.toMinutes(
                now.getTimeInMillis() - nearest.getTimeInMillis()
            ) >= duration;
        }
        private void clean ()  {
            now = nearest = maximum = parsed = null;
            matcher = null;
        }
        public String getStartDate() {
            return startDate;
        }

        public boolean isShouldBeFinish() {
            return shouldBeFinish;
        }

    }

    private static boolean containsFractionPart(String s) {
        if (s.indexOf('.') >= 0) {
            return true;
        }

        return false;
    }

    private static TimeZone getTimeZone(String timeZoneString) throws ParseException {
        if ("Z".equals(timeZoneString)) {
            return TimeZone.getTimeZone("UTC");
        }

        TimeZone tz = TimeZone.getTimeZone("GMT" + timeZoneString);
        if (tz.getRawOffset() == 0 && !UTC_TIMEZONES.contains(timeZoneString)) {
            throw new ParseException("Cannot parse timezone: " + timeZoneString, 0);
        }

        return tz;
    }

    public static long parseGeneralizedTimeString(String fullTimeString) {
        if (fullTimeString == null || fullTimeString.length() == 0) {
            return Long.MIN_VALUE;
        }

        if ("000001010000Z".equals(fullTimeString)) {
            return Long.MIN_VALUE;
        }

        try {
            String timeString;
            String timeZoneString;

            Matcher timezoneMatcher = TIMEZONE_SEPARATOR.matcher(fullTimeString);
            if (timezoneMatcher.find()) {
                timeString = fullTimeString.substring(0, timezoneMatcher.start());
                timeString = timeString.replace(',', '.');

                timeZoneString = fullTimeString.substring(timezoneMatcher.start());
            } else {
                throw new ParseException("Cannot determine timezone: " + fullTimeString, 0);
            }

            TimeZone timeZone = getTimeZone(timeZoneString);

            String patternFormat = containsFractionPart(timeString) ? FRACTION_FORMAT : FRACTIONLESS_FORMAT;
            SimpleDateFormat dateParser = new java.text.SimpleDateFormat(patternFormat);
            dateParser.setTimeZone(timeZone);
            dateParser.setLenient(false);

            Date parsedDate = dateParser.parse(fullTimeString);
            return parsedDate.getTime();
        } catch (ParseException e) {
            LOGGER.error(e.getMessage(), e);
            return Long.MIN_VALUE;
        }
    }


    /**
     * OpenIDM overrides #toString method defined by JS hash & array objects, making it non-usable directly from JS context.
     * But when Java method is called, OpenIDM unwraps real Java object and passes it as method argument, so we have access to the real object
     */
    public static String toString(Object obj) {
        return String.valueOf(obj);
    }

    public static JsonValue getRequest() {
        return ObjectSetContext.get();
    }

    public static void setRequestVar(String key, Object value) {
        getRequest().put(key, value);
    }

    public static Object getRequestVar(String key) {
        JsonValue request = getRequest();

        while (request != null && !request.isNull()) {
            if (request.isDefined(key)) {
                return request.get(key).getObject();
            }

            request = JsonResourceContext.getParentContext(request);
        }

        return new JsonValue(null);
    }

    private static Object convert(Object data) {
        Map<String, Object> container = new HashMap<String, Object>(2);
        Scriptable scriptable = (Scriptable) ScriptableWrapper.wrap(container);
        scriptable.put("data", scriptable, data);
        return container.get("data");
    }

    public static String toJSON(Object data) throws Exception {
        if (data == null) {
            return null;
        }

        Object convertedData = convert(data);
        if (convertedData == null) {
            return null;
        }

        if (convertedData instanceof Map<?, ?>) {
            return toJSON((Map<?, ?>) convertedData);
        }

        if (convertedData instanceof Collection<?>) {
            return toJSON((Collection<?>) convertedData);
        }

        throw new IllegalArgumentException("Map or list is expected, but received: " + convertedData.getClass().getName());
    }

    public static String toJSON(Map<?, ?> data) throws Exception {
        return OBJECT_MAPPER.writeValueAsString(data);
    }

    public static String toJSON(Collection<?> data) throws Exception {
        return OBJECT_MAPPER.writeValueAsString(data);
    }

    public static Object fromJSON(String jsonData) throws Exception {
        JsonNode jsonDataTree = OBJECT_MAPPER.readTree(jsonData);

        Object result = OBJECT_MAPPER.convertValue(jsonDataTree, jsonDataTree.isArray() ? LIST_TYPE_REF : MAP_TYPE_REF);
        return ScriptableWrapper.wrap(result);
    }

    public static synchronized Lock getGlobalLock(String name) {
        Lock lock = GLOBAL_LOCKS.get(name);

        if (lock == null) {
            lock = new ReentrantLock();
            GLOBAL_LOCKS.put(name, lock);
        }

        return lock;
    }

    public static String getHostName() {
        String hostName = HOST_NAME;

        if (hostName == null || hostName.isEmpty()) {
            try {
                hostName = InetAddress.getLocalHost().getHostName();
            } catch (UnknownHostException e) {
                //ignore
            }

            if (hostName == null || hostName.isEmpty()) {
                hostName = System.getenv("COMPUTERNAME");
            }

            if (hostName == null || hostName.isEmpty()) {
                hostName = System.getenv("HOSTNAME");
            }

            HOST_NAME = hostName;
        }

        return hostName;
    }

    public static void sleepToTime(String sStartTime, Long startPoint){
        if(sStartTime == null){
            return;
        }

        Matcher m = START_TIME_PATTERN.matcher(sStartTime);
        if(!m.matches()){
            throw new NumberFormatException("Time-format should be HHmm");
        }
        int hours = Integer.parseInt(m.group(1));
        if(hours > 23){
            throw new NumberFormatException("Illegal hours-value");
        }
        int mins = Integer.parseInt(m.group(2));
        if(mins > 59){
            throw new NumberFormatException("Illegal minutes-value");
        }

        Calendar c1 = Calendar.getInstance(TimeZone.getDefault(), Locale.getDefault());

        c1.set(Calendar.HOUR_OF_DAY, hours);
        c1.set(Calendar.MINUTE, mins);
        c1.set(Calendar.SECOND, 0);
        c1.set(Calendar.MILLISECOND, 0);

        Calendar c0 = Calendar.getInstance(TimeZone.getDefault(), Locale.getDefault());
        if(startPoint != null && startPoint.longValue() >= 0L){
            c0.setTimeInMillis(startPoint.longValue());
        }

        if(c0.after(c1)){
            c1.add(Calendar.DAY_OF_MONTH, 1);
        }
        LOGGER.info("Dates: {} - {}", new Object[]{c0.getTime(), c1.getTime()});
        long timeTo = c1.getTimeInMillis();

        LOGGER.info("WAITING for {}...", new Object[]{c1.getTime()});
        while(timeTo > System.currentTimeMillis()){
            try {
                Thread.sleep(SLEEP_PAUSE);
            } catch (InterruptedException e) {
                throw new RuntimeException("Internal-error. Thread was interrupted", e);
            }
        }
        LOGGER.info("WAITING WAS FINISHED");
    }

    public static void sleep(long sleepIntervalInSeconds) throws InterruptedException {
        long currentTime = System.currentTimeMillis();
        long sleepIntervalInMilliseconds = TimeUnit.MILLISECONDS.convert(sleepIntervalInSeconds, TimeUnit.SECONDS);
        long targetTimeMillis = currentTime + sleepIntervalInMilliseconds;

        while (true) {
            long remainingSleepTime = targetTimeMillis - System.currentTimeMillis();

            if (remainingSleepTime <= 0) {
                break;
            }

            //wake up and check clock periodically: sleep either remaining interval or 1 minute, whatever is smaller
            Thread.sleep(Math.min(remainingSleepTime, MILLISECONDS_IN_MINUTE));
        }
    }

    private static String dateFormat(Date date, TimeZone zone){
        final DateFormat FIRST_SDF = new SimpleDateFormat(S_FIRST_SDF);
        final DateFormat SECOND_SDF = new SimpleDateFormat(S_SECOND_SDF);
        FIRST_SDF.setTimeZone(zone);
        SECOND_SDF.setTimeZone(zone);
        return FIRST_SDF.format(date) + "T" + SECOND_SDF.format(date);
    }

    /**
     * @param sTimes Space-separated HHmm-string sush as "0130 0330 2140"
     *
     * @param sDuration Planned duration in minutes as String [1..1440[
     *
     * @return nearest Start-date + estimated finish-flag inside ReconInfo - instance
     *
     * @throws Exception If Validation-errors
     */
    public static ReconInfo nearestReconInfo(String sTimes, String sDuration) throws Exception {
        return new ReconInfo(sTimes, sDuration);
    }

    public static void seal(ScriptableObject object) {
        object.sealObject();
    }

    public static void dumpStack(String message) {
        LOGGER.error("{}", new Exception(message));
    }
}
