package com.mckesson;

import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.forgerock.json.fluent.JsonValue;
import org.forgerock.json.resource.JsonResourceContext;
import org.forgerock.openidm.objset.ObjectSetContext;
import org.forgerock.openidm.script.javascript.ScriptableWrapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Phase {

    private static final Logger LOGGER = LoggerFactory.getLogger(Phase.class);

    //limit of nested exceptions lookup for phase abortion detection, normally should 1 iteration should be enough
    private static final int NESTED_EXCEPTIONS_LIMIT = 8;

    private final String name;

    private final Iterator<Object> producer;

    private final Consumer<Object> consumer;

    private final Semaphore poolSemaphore;

    private final ExecutorService executorService;

    private final AtomicBoolean aborted;

    private final AtomicInteger progressCounter;

    public Phase(String name, int threads, Iterator<Object> producer, Consumer<Object> consumer) {
        super();
        this.name = name;
        this.producer = producer;
        this.consumer = consumer;
        this.poolSemaphore = new Semaphore(threads);
        this.executorService = Executors.newFixedThreadPool(threads);
        this.aborted = new AtomicBoolean(false);
        this.progressCounter = new AtomicInteger(0);
    }

    private void reportProgress() {
        int counterValue = progressCounter.incrementAndGet();
        if (counterValue % 100 == 0) {
            LOGGER.info("Completed task #{} of phase {}", counterValue, name);
        }
    }

    private boolean isAbortPhaseException(Throwable throwable) {
        Throwable cause = throwable;
        for (int i = 0; i < NESTED_EXCEPTIONS_LIMIT && cause != null; i++) {
            if (cause instanceof AbortPhaseException) {
                return true;
            }

            cause = cause.getCause();
        }

        return false;
    }

    public void execute() throws InterruptedException {
        LOGGER.info("Starting phase {}", name);

        try {
            final JsonValue parentContext = ObjectSetContext.get();

            while (producer.hasNext()) {
                if (aborted.get()) {
                    break;
                }

                final Object nextItem = producer.next();
                poolSemaphore.acquire();
                try {
                    executorService.execute(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                ObjectSetContext.push(JsonResourceContext.newContext("resource", parentContext));

                                if (!aborted.get()) {
                                    consumer.accept(ScriptableWrapper.wrap(nextItem));
                                    reportProgress();
                                }
                            } catch (Throwable t) {
                                if (isAbortPhaseException(t)) {
                                    aborted.set(true);
                                }

                                LOGGER.error(t.getMessage(), t);
                            } finally {
                                ObjectSetContext.pop();
                                poolSemaphore.release();
                            }
                        }
                    });
                } catch (RejectedExecutionException e) {
                    poolSemaphore.release();
                }
            }
        } finally {
            executorService.shutdown();
            executorService.awaitTermination(1, TimeUnit.DAYS);
        }

        if (aborted.get()) {
            throw new IllegalStateException("Phase " + name + " has been aborted");
        }
    }

    public static void abort() {
        throw new AbortPhaseException();
    }

    public static void abort(String message) {
        throw new AbortPhaseException(message);
    }
}
