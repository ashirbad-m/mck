package com.mckesson;

import org.forgerock.openidm.core.IdentityServer;

import com.mckesson.batch.force.RemedyApi;
import com.mckesson.batch.force.RemedyApiImpl;

public class RemedyForceUtil {

    private static RemedyApi remedyApi;

    public static synchronized Object api() throws Exception {
        if (remedyApi == null) {
            IdentityServer identityServer = IdentityServer.getInstance();
            remedyApi = new RemedyApiImpl(
                    identityServer.getProperty("com.mckesson.remedyforce.environment"),
                    identityServer.getProperty("com.mckesson.remedyforce.endpoint"),
                    identityServer.getProperty("com.mckesson.remedyforce.username"),
                    identityServer.getProperty("com.mckesson.remedyforce.password"));
        }

        return remedyApi;
    }

}
