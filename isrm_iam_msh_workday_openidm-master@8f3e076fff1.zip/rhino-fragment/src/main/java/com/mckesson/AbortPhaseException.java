package com.mckesson;

public class AbortPhaseException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 894583172998395195L;

    public AbortPhaseException() {
        super();
    }

    public AbortPhaseException(String message) {
        super(message);
    }

    public AbortPhaseException(Throwable cause) {
        super(cause);
    }

    public AbortPhaseException(String message, Throwable cause) {
        super(message, cause);
    }
}
