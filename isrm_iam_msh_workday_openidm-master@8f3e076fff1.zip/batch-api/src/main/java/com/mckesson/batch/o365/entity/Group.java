package com.mckesson.batch.o365.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Group {

    @JsonProperty
    private final ObjectType objectType = ObjectType.Group;

    @JsonProperty
    private String displayName;

    @JsonProperty
    private String onPremisesSecurityIdentifier;

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getOnPremisesSecurityIdentifier() {
        return onPremisesSecurityIdentifier;
    }

    public void setOnPremisesSecurityIdentifier(String onPremisesSecurityIdentifier) {
        this.onPremisesSecurityIdentifier = onPremisesSecurityIdentifier;
    }

    public ObjectType getObjectType() {
        return objectType;
    }

}
