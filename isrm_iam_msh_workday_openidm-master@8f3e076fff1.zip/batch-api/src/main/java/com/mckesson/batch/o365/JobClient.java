package com.mckesson.batch.o365;

import com.mckesson.batch.o365.entity.StartJobRequest;

public interface JobClient {

    public static final String USERNAME_HEADER = "X-o365-Username";

    public static final String PASSWORD_HEADER = "X-o365-Password";

    public String startJob(boolean dryRun, StartJobRequest job) throws Exception;

    public JobStatus checkJobStatus(String uri) throws Exception;

    public JobStatus waitForJobCompletion(String uri, long seconds) throws Exception;

}
