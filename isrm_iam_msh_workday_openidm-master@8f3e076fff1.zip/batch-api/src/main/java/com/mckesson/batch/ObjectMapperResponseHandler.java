package com.mckesson.batch;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpResponseException;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.AbstractResponseHandler;
import org.apache.http.util.EntityUtils;

public class ObjectMapperResponseHandler<T> extends AbstractResponseHandler<T> {

    private static final int RESPONSE_STATUS_OK = 200;

    private final Class<T> entityClass;

    public ObjectMapperResponseHandler(Class<T> entityClass) {
        super();
        this.entityClass = entityClass;
    }

    @Override
    public T handleResponse(HttpResponse response) throws HttpResponseException, IOException {
        try {
            int statusCode = response.getStatusLine().getStatusCode();

            if (RESPONSE_STATUS_OK != statusCode) {
                throw new IllegalStateException("Unexpected response code: " + statusCode);
            }

            return super.handleResponse(response);
        } finally {
            EntityUtils.consumeQuietly(response.getEntity());
        }
    }

    @Override
    public T handleEntity(HttpEntity entity) throws IOException {
        ContentType contentType = ContentType.getOrDefault(entity);

        if (!ContentType.APPLICATION_JSON.getMimeType().equals(contentType.getMimeType())) {
            throw new IllegalStateException("Invalid response content type: " + contentType);
        }

        String jsonString = EntityUtils.toString(entity);

        return ObjectMapperSingleton.OBJECT_MAPPER.readerFor(entityClass).readValue(jsonString);
    }

}
