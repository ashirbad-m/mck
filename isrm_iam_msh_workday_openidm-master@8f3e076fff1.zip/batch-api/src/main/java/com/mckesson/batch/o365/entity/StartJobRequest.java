package com.mckesson.batch.o365.entity;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StartJobRequest {

    private final String reconId;

    private final List<String> upns = new ArrayList<String>();

    private final List<String> groups = new ArrayList<String>();

    private List<User> users = new ArrayList<User>();

    public StartJobRequest(String reconId) {
        super();
        this.reconId = reconId;
    }

    @JsonProperty("reconId")
    public String getReconId() {
        return reconId;
    }

    @JsonProperty("upnsList")
    public List<String> getUpns() {
        return upns;
    }

    @JsonProperty("groupsList")
    public List<String> getGroups() {
        return groups;
    }

    @JsonProperty("usersList")
    public List<User> getUsers() {
        return users;
    }

}
