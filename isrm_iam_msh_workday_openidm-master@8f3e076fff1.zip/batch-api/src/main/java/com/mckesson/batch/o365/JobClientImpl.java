package com.mckesson.batch.o365;

import java.io.StringWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;

import com.fasterxml.jackson.databind.ObjectWriter;
import com.mckesson.batch.HttpClientFactory;
import com.mckesson.batch.ObjectMapperResponseHandler;
import com.mckesson.batch.ObjectMapperSingleton;
import com.mckesson.batch.Util;
import com.mckesson.batch.o365.entity.JobStatusResponse;
import com.mckesson.batch.o365.entity.StartJobRequest;

public class JobClientImpl implements JobClient {

    private static final ObjectMapperResponseHandler<JobStatusResponse> RESPONSE_HANDLER = new ObjectMapperResponseHandler<JobStatusResponse>(JobStatusResponse.class);

    private static final int RESPONSE_STATUS_OK = 200;

    private static final Log LOG = LogFactory.getLog(JobClientImpl.class);

    private static final Properties URL_PROPERTIES = Util.loadPropertiesFromClassPath("META-INF/o365service.properties");

    private final Set<String> jobEndpointHosts;

    private final String[] jobEndpointAddresses;

    private final int pollInterval;

    private final HttpClient httpClient;

    private final String healthEndpointUrl;

    private final Pattern healthOkPattern;

    private final String jobEndpointUrl;

    public JobClientImpl(String jobEndpointAddressString, String username, String password, int pollInterval, int clientTimeout) throws URISyntaxException {
        jobEndpointAddresses = jobEndpointAddressString.trim().split("\\s*(;|,)\\s*");
        jobEndpointHosts = new HashSet<String>();

        for (String jobEndpointAddress: jobEndpointAddresses) {
            jobEndpointHosts.add(new URI(jobEndpointAddress).getHost().toLowerCase(Locale.US));
        }

        this.httpClient = HttpClientFactory.createClient(new AuthenticationRequestInterceptor(username, password), clientTimeout);
        this.pollInterval = pollInterval;

        this.healthEndpointUrl = URL_PROPERTIES.getProperty("healthEndpoint");
        this.healthOkPattern = Pattern.compile(URL_PROPERTIES.getProperty("healthOkPattern"), Pattern.CASE_INSENSITIVE);
        this.jobEndpointUrl = URL_PROPERTIES.getProperty("jobEndpoint");
    }

    private boolean isHostAllowed(String uri) throws URISyntaxException {
        return jobEndpointHosts.contains(new URI(uri).getHost().toLowerCase(Locale.US));
    }

    private HttpEntity createJobEntity(StartJobRequest job) throws Exception {
        StringWriter output = new StringWriter();
        ObjectWriter objectWriter = ObjectMapperSingleton.OBJECT_MAPPER.writer();
        objectWriter.writeValue(output, job);

        StringEntity result = new StringEntity(output.toString());
        result.setContentType(ContentType.APPLICATION_JSON.getMimeType());

        return result;
    }

    private String getStartJobUrl(String jobEndpoint, boolean dryRun) throws URISyntaxException {
        URIBuilder uriBuilder = new URIBuilder(jobEndpoint);
        uriBuilder.setParameter("dryrun", Boolean.toString(dryRun));
        return uriBuilder.toString();
    }

    private String getJobUrlForId(String jobEndpoint, Long jobId) throws URISyntaxException {
        URIBuilder uriBuilder = new URIBuilder(jobEndpoint);
        uriBuilder.setPath(uriBuilder.getPath() + '/' + jobId);
        return uriBuilder.toString();
    }

    /**
     * Based on HEAD request probe finds the first available job endpoint
     * @return
     */
    private String findAvailableJobEndpoint() {
        for (String jobEndpointAddress: jobEndpointAddresses) {
            HttpGet healthRequest = new HttpGet(jobEndpointAddress + healthEndpointUrl);
            HttpResponse response = null;
            try {
                response = httpClient.execute(healthRequest);

                if (RESPONSE_STATUS_OK != response.getStatusLine().getStatusCode()) {
                    LOG.warn("Endpoint " + jobEndpointAddress + " is unavailable, unexpected response status received: " + response.getStatusLine());
                    continue;
                }

                String responseBody = EntityUtils.toString(response.getEntity());
                if (!healthOkPattern.matcher(responseBody).find()) {
                    LOG.warn("Endpoint " + jobEndpointAddress + " health status is not ok: " + responseBody);
                    continue;
                }

                LOG.info("Using available enpoint " + jobEndpointAddress);

                return jobEndpointAddress + jobEndpointUrl;
            } catch (Exception e) {
                LOG.warn("Endpoint " + jobEndpointAddress + " is unavailable because of: " + e.getMessage(), e);
            } finally {
                if (response != null) {
                    EntityUtils.consumeQuietly(response.getEntity());
                }
                healthRequest.releaseConnection();
            }
        }

        LOG.error("None of endpoints is available: " + Arrays.toString(jobEndpointAddresses));
        throw new IllegalStateException("Job endpoint is not available");
    }

    @Override
    public String startJob(boolean dryRun, StartJobRequest job) throws Exception {
        String jobEndpoint = findAvailableJobEndpoint();

        HttpPost postRequest = new HttpPost(getStartJobUrl(jobEndpoint, dryRun));
        try {
            LOG.info("Submitting job data");
            postRequest.setEntity(createJobEntity(job));
            JobStatusResponse response = httpClient.execute(postRequest, RESPONSE_HANDLER);

            LOG.info("Job id: " + response.getId() + ", status is: " + response.getStatus());

            return getJobUrlForId(jobEndpoint, response.getId());
        } catch (Exception e) {
            LOG.error("Failed to start job: " + e.getMessage(), e);
            throw e;
        } finally {
            postRequest.releaseConnection();
        }
    }

    @Override
    public JobStatus checkJobStatus(String uri) throws Exception {
        if (!isHostAllowed(uri)) {
            throw new IllegalStateException("URI is incorrect: " + uri);
        }

        HttpGet statusRequest = new HttpGet(uri);
        try {
            JobStatusResponse response = httpClient.execute(statusRequest, RESPONSE_HANDLER);

            return JobStatusMapper.getStatus(response.getStatus());
        } finally {
            statusRequest.releaseConnection();
        }
    }

    @Override
    public JobStatus waitForJobCompletion(String uri, long seconds) throws Exception {
        long startTime = System.currentTimeMillis();

        JobStatus jobStatus = null;

        while (true) {

            try {
                jobStatus = checkJobStatus(uri);

                if (jobStatus == JobStatus.SUCCESS || jobStatus == JobStatus.FAILURE) {
                    break;
                }
            } catch (Exception e) {
                //unspecified exception - assume job is still running
                jobStatus = JobStatus.RUNNING;

                LOG.error("Failed to check job status: " + e.getMessage(), e);
            }

            long secondsSpent = TimeUnit.SECONDS.convert(System.currentTimeMillis() - startTime, TimeUnit.MILLISECONDS);

            if (secondsSpent > seconds) {
                LOG.error("Wait timeout exceeded for job: " + uri);
                jobStatus = JobStatus.FAILURE;
                break;
            }

            Thread.sleep(TimeUnit.MILLISECONDS.convert(pollInterval, TimeUnit.SECONDS));
        }

        return jobStatus;
    }
}
