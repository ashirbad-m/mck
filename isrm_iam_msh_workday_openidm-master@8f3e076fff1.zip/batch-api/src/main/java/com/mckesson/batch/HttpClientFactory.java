package com.mckesson.batch;

import java.util.concurrent.TimeUnit;

import org.apache.http.HttpRequestInterceptor;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.config.RequestConfig.Builder;
import org.apache.http.impl.NoConnectionReuseStrategy;
import org.apache.http.impl.client.HttpClientBuilder;

public final class HttpClientFactory {

    private HttpClientFactory() {
    }

    public static HttpClient createClient(HttpRequestInterceptor requestInterceptor, int clientTimeout) {
        Builder requestConfigBuilder = RequestConfig.custom();
        requestConfigBuilder.setConnectTimeout((int) TimeUnit.MILLISECONDS.convert(clientTimeout, TimeUnit.SECONDS));
        requestConfigBuilder.setAuthenticationEnabled(false);
        requestConfigBuilder.setSocketTimeout((int) TimeUnit.MILLISECONDS.convert(clientTimeout, TimeUnit.SECONDS));

        HttpClientBuilder clientBuilder = HttpClientBuilder.create();
        clientBuilder.setDefaultRequestConfig(requestConfigBuilder.build());
        clientBuilder.disableAutomaticRetries();
        clientBuilder.disableAuthCaching();
        clientBuilder.disableRedirectHandling();
        clientBuilder.disableCookieManagement();
        clientBuilder.setConnectionReuseStrategy(NoConnectionReuseStrategy.INSTANCE);
        clientBuilder.addInterceptorLast(requestInterceptor);

        return clientBuilder.build();
    }

}
