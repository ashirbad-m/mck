package com.mckesson.batch.o365;

import java.io.IOException;

import org.apache.http.HttpException;
import org.apache.http.HttpRequest;
import org.apache.http.HttpRequestInterceptor;
import org.apache.http.protocol.HttpContext;

public final class AuthenticationRequestInterceptor implements HttpRequestInterceptor {

    private final String username;

    private final String password;

    public AuthenticationRequestInterceptor(String username, String password) {
        super();
        this.username = username;
        this.password = password;
    }

    public void process(HttpRequest request, HttpContext context) throws HttpException, IOException {
        request.addHeader(JobClient.USERNAME_HEADER, username);
        request.addHeader(JobClient.PASSWORD_HEADER, password);
    }

}
