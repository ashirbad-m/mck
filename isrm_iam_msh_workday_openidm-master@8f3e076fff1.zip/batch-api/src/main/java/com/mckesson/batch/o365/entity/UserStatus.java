package com.mckesson.batch.o365.entity;

public enum UserStatus {

    NEW, DELETED, UPDATED

}
