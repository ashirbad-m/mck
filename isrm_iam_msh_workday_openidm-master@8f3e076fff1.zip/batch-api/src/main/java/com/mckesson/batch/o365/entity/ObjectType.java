package com.mckesson.batch.o365.entity;

public enum ObjectType {

    User, Group

}
