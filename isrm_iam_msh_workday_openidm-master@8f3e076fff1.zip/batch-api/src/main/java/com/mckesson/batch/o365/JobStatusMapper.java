package com.mckesson.batch.o365;

import java.util.HashMap;
import java.util.Map;

public final class JobStatusMapper {

    private static final Map<String, JobStatus> STATUS_MAP = new HashMap<String, JobStatus>();

    static {
        STATUS_MAP.put("COMPLETED", JobStatus.SUCCESS);

        STATUS_MAP.put("STARTING", JobStatus.RUNNING);
        STATUS_MAP.put("STARTED", JobStatus.RUNNING);

        STATUS_MAP.put("STOPPING", JobStatus.FAILURE);
        STATUS_MAP.put("STOPPED", JobStatus.FAILURE);
        STATUS_MAP.put("FAILED", JobStatus.FAILURE);
        STATUS_MAP.put("ABANDONED", JobStatus.FAILURE);
        STATUS_MAP.put("UNKNOWN", JobStatus.FAILURE);
        STATUS_MAP.put("NOT_FOUND", JobStatus.FAILURE);

        STATUS_MAP.put("EXCEPTION", JobStatus.FAILURE);
    }

    private JobStatusMapper() {
    }

    public static JobStatus getStatus(String statusString) {
        JobStatus status = STATUS_MAP.get(statusString);

        if (status == null) {
            throw new IllegalStateException("Unexpected status: " + statusString);
        }

        return status;
    }
}
