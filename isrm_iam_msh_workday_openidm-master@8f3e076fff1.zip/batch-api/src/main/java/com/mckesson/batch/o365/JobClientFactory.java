package com.mckesson.batch.o365;

import java.util.Properties;

public final class JobClientFactory {

    public static final String BASE_URL_PROPERTY = "com.mckesson.o365batch.base";

    public static final String USERNAME_PROPERTY = "com.mckesson.o365batch.username";

    public static final String PASSWORD_PROPERTY = "com.mckesson.o365batch.password";

    public static final String POLL_INTERVAL_PROPERTY = "com.mckesson.o365batch.jobPollInterval";

    public static final String CLIENT_TIMEOUT_PROPERTY = "com.mckesson.o365batch.clientTimeout";

    private JobClientFactory() {
    }

    public static JobClient createClient() throws Exception {
        return createClient(System.getProperties());
    }

    public static JobClient createClient(Properties properties) throws Exception {
        String url = properties.getProperty(BASE_URL_PROPERTY);
        String username = properties.getProperty(USERNAME_PROPERTY);
        String password = properties.getProperty(PASSWORD_PROPERTY);
        int pollInterval = Integer.parseInt(properties.getProperty(POLL_INTERVAL_PROPERTY));
        int clientTimeout = Integer.parseInt(properties.getProperty(CLIENT_TIMEOUT_PROPERTY));

        return new JobClientImpl(url, username, password, pollInterval, clientTimeout);
    }
}
