package com.mckesson.batch;

import com.fasterxml.jackson.databind.ObjectMapper;

public final class ObjectMapperSingleton {

    public final static ObjectMapper OBJECT_MAPPER = createObjectMapper();

    private static ObjectMapper createObjectMapper() {
        return new ObjectMapper();
    }

    private ObjectMapperSingleton() {
    }

}
