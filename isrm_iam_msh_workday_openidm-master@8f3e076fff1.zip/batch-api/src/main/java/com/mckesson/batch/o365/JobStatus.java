package com.mckesson.batch.o365;

public enum JobStatus {

    RUNNING, FAILURE, SUCCESS;

}
