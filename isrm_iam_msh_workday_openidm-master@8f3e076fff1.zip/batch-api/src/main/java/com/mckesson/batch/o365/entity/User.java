package com.mckesson.batch.o365.entity;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class User {

    @JsonProperty
    private final ObjectType objectType = ObjectType.User;

    @JsonProperty
    private String userPrincipalName;

    @JsonProperty
    private String displayName;

    @JsonProperty
    private String mail;

    @JsonProperty
    private String employeeId;

    private List<Group> groups = new ArrayList<Group>();

    public String getUserPrincipalName() {
        return userPrincipalName;
    }

    public void setUserPrincipalName(String userPrincipalName) {
        this.userPrincipalName = userPrincipalName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    @JsonProperty("memberOfGroups")
    public List<Group> getGroups() {
        return groups;
    }

    public ObjectType getObjectType() {
        return objectType;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }
}
