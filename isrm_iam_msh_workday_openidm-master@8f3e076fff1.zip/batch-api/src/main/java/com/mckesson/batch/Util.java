package com.mckesson.batch;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class Util {

    private Util() {
    }

    private static Properties loadPropertiesFromClassPathWithClassLoader(ClassLoader classLoader, String resourceName) throws IOException {
        if (classLoader == null) {
            return null;
        }

        try (InputStream is = classLoader.getResourceAsStream(resourceName)) {
            if (is == null) {
                return null;
            }

            Properties properties = new Properties();
            properties.load(is);

            return properties;
        }
    }

    public static Properties loadPropertiesFromClassPath(String resourceName) throws IllegalStateException {
        Properties properties = null;

        try {
            properties = loadPropertiesFromClassPathWithClassLoader(Thread.currentThread().getContextClassLoader(), resourceName);

            if (properties == null) {
                properties = loadPropertiesFromClassPathWithClassLoader(Util.class.getClassLoader(), resourceName);
            }

            if (properties == null) {
                properties = loadPropertiesFromClassPathWithClassLoader(ClassLoader.getSystemClassLoader(), resourceName);
            }

            if (properties == null) {
                throw new IOException("Resource: " + resourceName + " not found in classpath");
            }
        } catch (IOException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }

        return properties;
    }
}
