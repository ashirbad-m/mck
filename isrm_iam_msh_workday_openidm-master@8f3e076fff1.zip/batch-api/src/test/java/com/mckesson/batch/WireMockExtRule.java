package com.mckesson.batch;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.requestMatching;
import static com.github.tomakehurst.wiremock.matching.MatchResult.of;
import static com.mckesson.batch.TestProperties.getTestProperties;

import java.util.List;
import java.util.Properties;

import com.github.tomakehurst.wiremock.extension.Parameters;
import com.github.tomakehurst.wiremock.http.Request;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.github.tomakehurst.wiremock.matching.MatchResult;
import com.github.tomakehurst.wiremock.matching.RequestMatcherExtension;
import com.github.tomakehurst.wiremock.verification.LoggedRequest;
import com.mckesson.batch.o365.JobClient;
import com.mckesson.batch.o365.JobClientFactory;

public class WireMockExtRule extends WireMockRule {

    private static final int UNAUTHORIZED_CODE = 401;

    private final String username;

    private final String password;

    public WireMockExtRule() {
        super(Integer.parseInt(getTestProperties().getProperty("com.mckesson.o365batch.wireMockPort")));

        Properties properties = getTestProperties();

        username = properties.getProperty(JobClientFactory.USERNAME_PROPERTY);
        password = properties.getProperty(JobClientFactory.PASSWORD_PROPERTY);
    }

    @Override
    protected void before() {
        super.before();

        stubFor(requestMatching(new RequestMatcherExtension() {
            @Override
            public MatchResult match(Request request, Parameters parameters) {
                String usernameValue = request.getHeader(JobClient.USERNAME_HEADER);
                String passwordValue = request.getHeader(JobClient.PASSWORD_HEADER);

                return of(!username.equals(usernameValue) || !password.equals(passwordValue));
            }
        }).willReturn(aResponse().withStatus(UNAUTHORIZED_CODE)));
    }

    @Override
    protected void after() {
        super.after();

        List<LoggedRequest> unmatchedRequests = findAllUnmatchedRequests();
        for (LoggedRequest request: unmatchedRequests) {
            System.err.println(request);
        }
    }

}
