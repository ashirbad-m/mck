package com.mckesson.batch;

import java.util.Properties;

public class TestProperties {

    private final static Properties testProperties = Util.loadPropertiesFromClassPath("test.properties");

    private TestProperties() {
    }

    public static Properties getTestProperties() {
        //returns defensive copy of properties
        return new Properties(testProperties);
    }

}
