package com.mckesson.batch;

import static com.mckesson.batch.TestProperties.getTestProperties;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.net.SocketTimeoutException;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestRule;

import com.mckesson.batch.o365.JobClient;
import com.mckesson.batch.o365.JobClientFactory;
import com.mckesson.batch.o365.JobStatus;

public class ScriptTest {

    @Rule
    public RhinoResource rhino = new RhinoResource();

    @Rule
    public TestRule wireMockRule = new WireMockExtRule();

    private JobClient jobApiClient;

    private String expectedBaseUrl;

    @Before
    public void setUp() throws Exception {
        jobApiClient = JobClientFactory.createClient(getTestProperties());
        expectedBaseUrl = getTestProperties().getProperty("com.mckesson.o365batch.baseEndpoint");

        rhino.putProperty("apiClient", jobApiClient);
        rhino.putProperty("baseUrl", expectedBaseUrl);
    }

    @After
    public void tearDown() throws Exception {
        jobApiClient = null;
        expectedBaseUrl = null;
    }

    @Test
    public void testStartDryRunJob() throws Exception {
        String batchJobPath = (String) rhino.exec("startDryRunJob.js");
        assertNotNull(batchJobPath);
        assertEquals(expectedBaseUrl + "/batch/jobs/1", batchJobPath);
    }

    @Test
    public void testStartDryRunJob2() throws Exception {
        String batchJobPath = (String) rhino.exec("startDryRunJob2.js");
        assertNotNull(batchJobPath);
        assertEquals(expectedBaseUrl + "/batch/jobs/2", batchJobPath);
    }

    @Test
    public void testStartCommitRunJob() throws Exception {
        String batchJobPath = (String) rhino.exec("startCommitRunJob.js");
        assertNotNull(batchJobPath);
        assertEquals(expectedBaseUrl + "/batch/jobs/100", batchJobPath);
    }

    @Test
    public void testCheckJobStatusSuccess() throws Exception {
        JobStatus status = (JobStatus) rhino.exec("checkJobStatusSuccess.js");
        assertNotNull(status);
        assertEquals(JobStatus.SUCCESS, status);
    }

    @Test
    public void testCheckJobStatusFailure() throws Exception {
        JobStatus status = (JobStatus) rhino.exec("checkJobStatusFailure.js");
        assertNotNull(status);
        assertEquals(JobStatus.FAILURE, status);
    }

    @Test
    public void testCheckJobStatusRunning() throws Exception {
        JobStatus status = (JobStatus) rhino.exec("checkJobStatusRunning.js");
        assertNotNull(status);
        assertEquals(JobStatus.RUNNING, status);
    }

    @Test
    public void testWaitForJobCompletionOk() throws Exception {
        JobStatus status = (JobStatus) rhino.exec("waitForJobCompletionOk.js");
        assertNotNull(status);
        assertEquals(JobStatus.SUCCESS, status);
    }

    @Test
    public void testWaitForJobCompletionFailure() throws Exception {
        JobStatus status = (JobStatus) rhino.exec("waitForJobCompletionFailure.js");
        assertNotNull(status);
        assertEquals(JobStatus.FAILURE, status);
    }

    @Test
    public void testWaitForJobCompletionTimeout() throws Exception {
        JobStatus status = (JobStatus) rhino.exec("waitForJobCompletionTimeout.js");
        assertNotNull(status);
        assertEquals(JobStatus.FAILURE, status);
    }

    @Test
    public void testWaitForJobCompletionServiceTimeout() throws Exception {
        try {
            rhino.exec("waitForJobCompletionServiceTimeoutBase.js");
            fail();
        } catch (Exception e) {
            assertTrue(e.getCause() instanceof SocketTimeoutException);
        }

        JobStatus status = (JobStatus) rhino.exec("waitForJobCompletionServiceTimeout.js");
        assertNotNull(status);
        assertEquals(JobStatus.SUCCESS, status);
    }
}
