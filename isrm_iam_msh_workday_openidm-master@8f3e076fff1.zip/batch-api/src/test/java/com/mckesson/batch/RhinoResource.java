package com.mckesson.batch;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import org.junit.rules.ExternalResource;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Wrapper;
import org.mozilla.javascript.tools.shell.Global;

public class RhinoResource extends ExternalResource {

    private Context context;

    private Scriptable scope;

    private Object unwrap(Object o) {
        if (o instanceof Wrapper) {
            return ((Wrapper) o).unwrap();
        }

        return o;
    }

    private Object doExec(Script script) {
        return unwrap(script.exec(context, scope));
    }

    public Script loadScript(String name) throws Exception {
        try (InputStream is = getClass().getClassLoader().getResourceAsStream(name)) {
            if (is == null) {
                throw new IOException("Resource [" + name + "] not found");
            }

            try (Reader reader = new InputStreamReader(is)) {
                return context.compileReader(reader, null, 1, null);
            }
        }
    }

    public Object exec(String scriptName) throws Exception {
        return doExec(loadScript(scriptName));
    }

    public Object exec(Script script) throws Exception {
        return doExec(script);
    }

    public void putProperty(String name, Object object) {
        ScriptableObject.putProperty(scope, name, object);
    }

    @Override
    protected void before() throws Throwable {
        super.before();
        context = Context.enter();
        scope = new Global(context);
    }

    @Override
    protected void after() {
        super.after();
        context = null;
        scope = null;
    }
}
