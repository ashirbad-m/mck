importPackage(Packages.com.mckesson.batch.o365.entity);

var request = new StartJobRequest("commit-run");

apiClient.startJob(false, request);