importPackage(Packages.com.mckesson.batch.o365.entity);

var user = new User();
user.userPrincipalName = "test@mckesson.com";
user.displayName = "test";
user.employeeId = "999999";
user.mail = "o365test@mckesson.com";

var group = new Group();
group.displayName = "Group X";
group.onPremisesSecurityIdentifier = "S-1-9-8899-12001";

user.groups.add(group);

var request = new StartJobRequest("dry-run");
request.users.add(user);

apiClient.startJob(true, request);