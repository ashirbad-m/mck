importPackage(Packages.com.mckesson.batch.o365.entity);

var createUser1 = function() {
    var user = new User();
    user.userPrincipalName = "test@mckesson.com";
    user.displayName = "test";
    user.employeeId = "999999";
    user.mail = "o365test@mckesson.com";
    return user;
}

var createUser2 = function() {
    var user = new User();
    user.userPrincipalName = "o365user@mckesson.com";
    user.displayName = "user";
    user.employeeId = "888888";
    user.mail = "o365user@mckesson.com";
    return user;
}

var createUser3 = function() {
    var user = new User();
    user.userPrincipalName = "admin@mckesson.com";
    user.displayName = "admin";
    user.employeeId = "111111";
    user.mail = "admin@mckesson.com";
    return user;
}

var createGroup1 = function() {
    var group = new Group();
    group.displayName = "Group X";
    group.onPremisesSecurityIdentifier = "S-1-9-8899-12001";
    return group;
}

var createGroup2 = function() {
    var group = new Group();
    group.displayName = "Admins";
    group.onPremisesSecurityIdentifier = "S-1-9-8899-13001";
    return group;
}

var createGroup3 = function() {
    var group = new Group();
    group.displayName = "Users";
    group.onPremisesSecurityIdentifier = "S-1-9-8899-14001";
    return group;
}

var group1 = createGroup1();
var group2 = createGroup2();
var group3 = createGroup3();

var user1 = createUser1();
user1.groups.add(group1);
user1.groups.add(group2);
user1.groups.add(group3);

var user2 = createUser2();

var user3 = createUser3();
user3.groups.add(group2);

var request = new StartJobRequest("dry-run2");
request.users.add(user1);
request.users.add(user2);
request.users.add(user3);

apiClient.startJob(true, request);